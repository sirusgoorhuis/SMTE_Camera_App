// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.a.a;
import com.samsung.context.sdk.samsunganalytics.a.i.c;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.e:
//            c

public class d
{

    private d()
    {
    }

    public static int a(Context context, int i)
    {
        int j = 0;
        context = c.a(context);
        if (i == 1)
        {
            j = context.getInt("dq-w", 0);
            i = context.getInt("wifi_used", 0);
        } else
        if (i == 0)
        {
            j = context.getInt("dq-3g", 0);
            i = context.getInt("data_used", 0);
        } else
        {
            boolean flag = false;
            i = j;
            j = ((flag) ? 1 : 0);
        }
        return j - i;
    }

    public static com.samsung.context.sdk.samsunganalytics.a.e.c a(Context context, Configuration configuration, com.samsung.context.sdk.samsunganalytics.a.b.a a1, com.samsung.context.sdk.samsunganalytics.a.a a2)
    {
        SharedPreferences sharedpreferences = c.a(context);
        context = new com.samsung.context.sdk.samsunganalytics.a.e.c(a.a, configuration.getTrackingId(), a(context, a1, configuration), sharedpreferences, a2);
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("trid: ").append(configuration.getTrackingId().substring(0, 7)).append(", uv: ").append(configuration.getVersion()).toString());
        return context;
    }

    public static Map a(Context context, com.samsung.context.sdk.samsunganalytics.a.b.a a1, Configuration configuration)
    {
        HashMap hashmap = new HashMap();
        hashmap.put("pkn", context.getPackageName());
        hashmap.put("dm", a1.g());
        if (!TextUtils.isEmpty(a1.a()))
        {
            hashmap.put("mcc", a1.a());
        }
        if (!TextUtils.isEmpty(a1.b()))
        {
            hashmap.put("mnc", a1.b());
        }
        hashmap.put("uv", configuration.getVersion());
        return hashmap;
    }

    public static void a(Context context, Configuration configuration, com.samsung.context.sdk.samsunganalytics.a.d.c c1, com.samsung.context.sdk.samsunganalytics.a.b.a a1)
    {
        c1.a(a(context, configuration, a1, ((com.samsung.context.sdk.samsunganalytics.a.a) (null))));
    }

    public static void a(Context context, Configuration configuration, com.samsung.context.sdk.samsunganalytics.a.d.c c1, com.samsung.context.sdk.samsunganalytics.a.b.a a1, com.samsung.context.sdk.samsunganalytics.a.a a2)
    {
        c1.a(a(context, configuration, a1, a2));
    }

    public static void a(SharedPreferences sharedpreferences)
    {
        sharedpreferences.edit().putLong("quota_reset_date", System.currentTimeMillis()).putInt("data_used", 0).putInt("wifi_used", 0).apply();
    }

    public static boolean a(Context context)
    {
        context = c.a(context);
        if (com.samsung.context.sdk.samsunganalytics.a.i.d.a(1, Long.valueOf(context.getLong("quota_reset_date", 0L))))
        {
            a(((SharedPreferences) (context)));
        }
        return com.samsung.context.sdk.samsunganalytics.a.i.d.a(context.getInt("rint", 1), Long.valueOf(context.getLong("policy_received_date", 0L)));
    }

    public static boolean a(Context context, int i, int j)
    {
        context = c.a(context);
        int k;
        int l;
        if (i == 1)
        {
            l = context.getInt("dq-w", 0);
            k = context.getInt("wifi_used", 0);
            i = context.getInt("oq-w", 0);
        } else
        if (i == 0)
        {
            l = context.getInt("dq-3g", 0);
            k = context.getInt("data_used", 0);
            i = context.getInt("oq-3g", 0);
        } else
        {
            i = 0;
            k = 0;
            l = 0;
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("Quota : ").append(l).append("/ Uploaded : ").append(k).append("/ limit : ").append(i).append("/ size : ").append(j).toString());
        if (l < k + j)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLS Sender", "send result fail : Over daily quota");
            return false;
        }
        if (i < j)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLS Sender", "send result fail : Over once quota");
            return false;
        } else
        {
            return true;
        }
    }

    public static void b(Context context, int i, int j)
    {
        SharedPreferences sharedpreferences = c.a(context);
        if (i == 1)
        {
            i = sharedpreferences.getInt("wifi_used", 0);
            sharedpreferences.edit().putInt("wifi_used", i + j).apply();
        } else
        if (i == 0)
        {
            i = c.a(context).getInt("data_used", 0);
            sharedpreferences.edit().putInt("data_used", i + j).apply();
            return;
        }
    }
}
