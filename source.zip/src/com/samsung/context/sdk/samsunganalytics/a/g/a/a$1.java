// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.samsung.context.sdk.samsunganalytics.a.i.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.a:
//            a

class a
    implements ServiceConnection
{

    final com.samsung.context.sdk.samsunganalytics.a.g.a.a a;

    public void onServiceConnected(ComponentName componentname, IBinder ibinder)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "DLC Client ServiceConnected");
        com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a, com.sec.spp.push.dlc.api.Service.a.a(ibinder));
        if (com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a) != null)
        {
            com.samsung.context.sdk.samsunganalytics.a.g.a.a.b(a).unregisterReceiver(com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a));
            com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a, null);
        }
        if (com.samsung.context.sdk.samsunganalytics.a.g.a.a.c(a) != null)
        {
            com.samsung.context.sdk.samsunganalytics.a.g.a.a.c(a).a(null);
        }
    }

    public void onServiceDisconnected(ComponentName componentname)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "Client ServiceDisconnected");
        com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a, null);
        com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a, false);
    }

    (com.samsung.context.sdk.samsunganalytics.a.g.a.a a1)
    {
        a = a1;
        super();
    }
}
