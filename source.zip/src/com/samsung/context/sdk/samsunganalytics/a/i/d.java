// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.i;

import android.os.Build;
import com.samsung.context.sdk.samsunganalytics.AnalyticsException;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.i:
//            a

public class d
{

    private d()
    {
    }

    public static long a(int i)
    {
        return Long.valueOf(System.currentTimeMillis()).longValue() - (long)i * 0x5265c00L;
    }

    public static String a(Map map)
    {
        String s;
        if (((String)map.get("t")).equals("pv"))
        {
            s = (new StringBuilder()).append("page: ").append((String)map.get("pn")).toString();
            map = (new StringBuilder()).append("detail: ").append((String)map.get("pd")).append("  value: ").append((String)map.get("pv")).toString();
        } else
        if (((String)map.get("t")).equals("ev"))
        {
            s = (new StringBuilder()).append("event: ").append((String)map.get("en")).toString();
            map = (new StringBuilder()).append("detail: ").append((String)map.get("ed")).append("  value: ").append((String)map.get("ev")).toString();
        } else
        if (((String)map.get("t")).equals("st"))
        {
            s = "status";
            map = (String)map.get("sti");
        } else
        {
            s = "";
            map = "";
        }
        return (new StringBuilder()).append(s).append("\n").append(map).toString();
    }

    public static void a(String s)
    {
        if (a())
        {
            throw new AnalyticsException(s);
        } else
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.e(s);
            return;
        }
    }

    public static boolean a()
    {
        return Build.TYPE.equals("eng");
    }

    public static boolean a(int i, Long long1)
    {
        return Long.valueOf(System.currentTimeMillis()).longValue() > long1.longValue() + (long)i * 0x5265c00L;
    }
}
