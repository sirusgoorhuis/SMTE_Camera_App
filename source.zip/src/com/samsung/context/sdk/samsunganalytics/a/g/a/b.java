// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import android.content.Context;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.d.c;
import com.samsung.context.sdk.samsunganalytics.a.g.a;
import com.samsung.context.sdk.samsunganalytics.a.g.d;
import java.util.Map;
import java.util.Queue;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.a:
//            a, c

public class b extends a
{

    private com.samsung.context.sdk.samsunganalytics.a.g.a.a g;

    public b(Context context, Configuration configuration)
    {
        super(context, configuration);
        g = new com.samsung.context.sdk.samsunganalytics.a.g.a.a(context, new com.samsung.context.sdk.samsunganalytics.a.a() {

            final b a;

            public volatile Object a(Object obj)
            {
                return a((Void)obj);
            }

            public Void a(Void void1)
            {
                com.samsung.context.sdk.samsunganalytics.a.g.a.b.a(a);
                return null;
            }

            
            {
                a = b.this;
                super();
            }
        });
        g.b();
    }

    private void a()
    {
        for (Queue queue = e.d(); !queue.isEmpty(); f.a(new com.samsung.context.sdk.samsunganalytics.a.g.a.c(g, b, (d)queue.poll(), null))) { }
    }

    static void a(b b1)
    {
        b1.a();
    }

    protected Map a(Map map)
    {
        map = super.a(map);
        map.remove("do");
        map.remove("dm");
        map.remove("v");
        return map;
    }

    public int d(Map map)
    {
        c(map);
        if (g.c())
        {
            if (g.d() != null)
            {
                a();
            }
        } else
        {
            g.b();
        }
        return 0;
    }

    public int e(Map map)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLCLogSender", "not support sync api");
        d(map);
        return -100;
    }
}
