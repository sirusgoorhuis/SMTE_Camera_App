// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.samsung.context.sdk.samsunganalytics.a.i.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.a:
//            a

class a extends BroadcastReceiver
{

    final com.samsung.context.sdk.samsunganalytics.a.g.a.a a;

    public void onReceive(Context context, Intent intent)
    {
        com.samsung.context.sdk.samsunganalytics.a.g.a.a.b(a, false);
        if (intent == null)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "dlc register reply fail");
        } else
        {
            context = intent.getAction();
            intent = intent.getExtras();
            if (context == null || intent == null)
            {
                com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "dlc register reply fail");
                return;
            }
            if (context.equals(com.samsung.context.sdk.samsunganalytics.a.g.a.a.d(a)))
            {
                context = intent.getString("EXTRA_STR");
                int i = intent.getInt("EXTRA_RESULT_CODE");
                com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("register DLC result:").append(context).toString());
                if (i < 0)
                {
                    com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("register DLC result fail:").append(context).toString());
                    return;
                } else
                {
                    context = intent.getString("EXTRA_STR_ACTION");
                    com.samsung.context.sdk.samsunganalytics.a.g.a.a.a(a, context);
                    return;
                }
            }
        }
    }

    (com.samsung.context.sdk.samsunganalytics.a.g.a.a a1)
    {
        a = a1;
        super();
    }
}
