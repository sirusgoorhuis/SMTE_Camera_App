// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.b;

import com.samsung.context.sdk.samsunganalytics.a.d.a;
import com.samsung.context.sdk.samsunganalytics.a.e.d;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.b:
//            b

class t> extends a
{

    final int a;
    final b b;

    public void a(int i, String s, String s1)
    {
    }

    public void b(int i, String s, String s1)
    {
        com.samsung.context.sdk.samsunganalytics.a.g.b.b.a(b).a(Long.valueOf(s).longValue(), "", s1);
        d.b(com.samsung.context.sdk.samsunganalytics.a.g.b.b.b(b), a, s1.getBytes().length * -1);
    }

    (b b1, int i)
    {
        b = b1;
        a = i;
        super();
    }
}
