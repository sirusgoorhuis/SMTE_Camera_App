// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g;


public class d
{

    private String a;
    private long b;
    private String c;

    public d()
    {
    }

    public d(long l, String s)
    {
        this("", l, s);
    }

    public d(String s, long l, String s1)
    {
        a = s;
        b = l;
        c = s1;
    }

    public String a()
    {
        return a;
    }

    public void a(long l)
    {
        b = l;
    }

    public void a(String s)
    {
        a = s;
    }

    public long b()
    {
        return b;
    }

    public void b(String s)
    {
        c = s;
    }

    public String c()
    {
        return c;
    }
}
