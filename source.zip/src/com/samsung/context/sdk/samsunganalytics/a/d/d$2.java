// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.d;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.d:
//            d, b

class a
    implements Runnable
{

    final b a;
    final d b;

    public void run()
    {
        a.a();
        a.b();
    }

    (d d1, b b1)
    {
        b = d1;
        a = b1;
        super();
    }
}
