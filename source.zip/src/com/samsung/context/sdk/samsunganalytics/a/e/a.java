// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;


public class a
{

    private int a;
    private int b;
    private int c;
    private int d;
    private int e;

    public a()
    {
    }

    public int a()
    {
        return a;
    }

    public void a(int i)
    {
        a = i;
    }

    public int b()
    {
        return b;
    }

    public void b(int i)
    {
        b = i;
    }

    public int c()
    {
        return c;
    }

    public void c(int i)
    {
        c = i;
    }

    public int d()
    {
        return d;
    }

    public void d(int i)
    {
        d = i;
    }

    public int e()
    {
        return e;
    }

    public void e(int i)
    {
        e = i;
    }
}
