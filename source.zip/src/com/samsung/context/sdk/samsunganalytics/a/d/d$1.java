// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.d;

import com.samsung.context.sdk.samsunganalytics.a.i.a;
import java.util.concurrent.ThreadFactory;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.d:
//            d

class a
    implements ThreadFactory
{

    final d a;

    public Thread newThread(Runnable runnable)
    {
        runnable = new Thread(runnable);
        runnable.setPriority(1);
        runnable.setDaemon(true);
        com.samsung.context.sdk.samsunganalytics.a.i.a.d("newThread on Executor");
        return runnable;
    }

    (d d1)
    {
        a = d1;
        super();
    }
}
