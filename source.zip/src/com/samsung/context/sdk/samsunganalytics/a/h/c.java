// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.h;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.b;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class c
{

    private static final int f = 512;
    private Set a;
    private Context b;
    private final String c;
    private final String d;
    private final String e;

    public c(Context context)
    {
        b = context;
        a = com.samsung.context.sdk.samsunganalytics.a.i.c.a(context).getStringSet("AppPrefs", new HashSet());
        c = com.samsung.context.sdk.samsunganalytics.a.i.b.a.b.b();
        d = com.samsung.context.sdk.samsunganalytics.a.i.b.a.b.a();
        e = com.samsung.context.sdk.samsunganalytics.a.i.b.a.c.a();
    }

    private SharedPreferences a(String s)
    {
        return b.getSharedPreferences(s, 0);
    }

    private List b()
    {
        Object obj1;
        ArrayList arraylist;
        Iterator iterator;
        if (a.isEmpty())
        {
            return null;
        }
        arraylist = new ArrayList();
        obj1 = "";
        iterator = a.iterator();
_L2:
        Object obj;
        Set set1;
        Iterator iterator1;
        if (iterator.hasNext())
        {
            String s = (String)iterator.next();
            obj = a(s);
            set1 = b(s);
            iterator1 = ((SharedPreferences) (obj)).getAll().entrySet().iterator();
            obj = obj1;
        } else
        {
            if (((String) (obj1)).length() != 0)
            {
                arraylist.add(obj1);
            }
            return arraylist;
        }
_L3:
        obj1 = obj;
        if (!iterator1.hasNext()) goto _L2; else goto _L1
_L1:
        obj1 = (java.util.Map.Entry)iterator1.next();
        if (set1.contains(((java.util.Map.Entry) (obj1)).getKey()))
        {
            Class class1 = ((java.util.Map.Entry) (obj1)).getValue().getClass();
            if (class1.equals(java/lang/Integer) || class1.equals(java/lang/Float) || class1.equals(java/lang/Long) || class1.equals(java/lang/String) || class1.equals(java/lang/Boolean))
            {
                obj1 = (new StringBuilder()).append("").append((String)((java.util.Map.Entry) (obj1)).getKey()).append(c).append(((java.util.Map.Entry) (obj1)).getValue()).toString();
            } else
            {
                Set set = (Set)((java.util.Map.Entry) (obj1)).getValue();
                String s1 = (new StringBuilder()).append("").append((String)((java.util.Map.Entry) (obj1)).getKey()).append(c).toString();
                Iterator iterator2 = set.iterator();
                Object obj2;
                String s2;
                for (obj1 = null; iterator2.hasNext(); obj1 = (new StringBuilder()).append(((String) (obj2))).append(s2).toString())
                {
                    s2 = (String)iterator2.next();
                    obj2 = obj1;
                    if (!TextUtils.isEmpty(((CharSequence) (obj1))))
                    {
                        obj2 = (new StringBuilder()).append(((String) (obj1))).append(e).toString();
                    }
                }

                obj1 = (new StringBuilder()).append(s1).append(((String) (obj1))).toString();
            }
            if (((String) (obj)).length() + ((String) (obj1)).length() > 512)
            {
                arraylist.add(obj);
                obj = "";
            } else
            if (!TextUtils.isEmpty(((CharSequence) (obj))))
            {
                obj = (new StringBuilder()).append(((String) (obj))).append(d).toString();
            }
            obj = (new StringBuilder()).append(((String) (obj))).append(((String) (obj1))).toString();
        }
          goto _L3
    }

    private Set b(String s)
    {
        return com.samsung.context.sdk.samsunganalytics.a.i.c.a(b).getStringSet(s, new HashSet());
    }

    public List a()
    {
        List list = b();
        Map map = a("SASettingPref").getAll();
        if (map != null && !map.isEmpty())
        {
            list.add((new b()).a(map, com.samsung.context.sdk.samsunganalytics.a.i.b.a.b));
        }
        return list;
    }
}
