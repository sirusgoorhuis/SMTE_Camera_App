// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g;

import android.content.Context;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.g.b.b;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g:
//            b

public class c
{
    public static final class a extends Enum
    {

        public static final a a;
        public static final a b;
        public static final a c;
        private static final a d[];

        public static a valueOf(String s)
        {
            return (a)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/g/c$a, s);
        }

        public static a[] values()
        {
            return (a[])d.clone();
        }

        static 
        {
            a = new a("DLC", 0);
            b = new a("DLS", 1);
            c = new a("INTENT", 2);
            d = (new a[] {
                a, b, c
            });
        }

        private a(String s, int i)
        {
            super(s, i);
        }
    }


    private static b a;
    private static com.samsung.context.sdk.samsunganalytics.a.g.a.b b;

    private c()
    {
    }

    public static com.samsung.context.sdk.samsunganalytics.a.g.b a(Context context, a a1, Configuration configuration)
    {
        a a2;
        a2 = a1;
        if (a1 == null)
        {
            if (configuration.isEnableUseInAppLogging())
            {
                a2 = com.samsung.context.sdk.samsunganalytics.a.g.a.b;
            } else
            {
                a2 = a.a;
            }
        }
        if (a2 != com.samsung.context.sdk.samsunganalytics.a.g.a.b)
        {
            break MISSING_BLOCK_LABEL_65;
        }
        if (a != null) goto _L2; else goto _L1
_L1:
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorenter ;
        a = new b(context, configuration);
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorexit ;
_L2:
        return a;
        context;
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorexit ;
        throw context;
        if (a2 != a.a)
        {
            break MISSING_BLOCK_LABEL_106;
        }
        if (b != null) goto _L4; else goto _L3
_L3:
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorenter ;
        b = new com.samsung.context.sdk.samsunganalytics.a.g.a.b(context, configuration);
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorexit ;
_L4:
        return b;
        context;
        com/samsung/context/sdk/samsunganalytics/a/g/c;
        JVM INSTR monitorexit ;
        throw context;
        return null;
    }
}
