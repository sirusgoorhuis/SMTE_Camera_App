// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.h;

import android.content.SharedPreferences;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class b
    implements com.samsung.context.sdk.samsunganalytics.a.d.b
{

    private SharedPreferences a;
    private Map b;

    public b(SharedPreferences sharedpreferences, Map map)
    {
        a = sharedpreferences;
        b = map;
    }

    public void a()
    {
        String s;
        for (Iterator iterator = a.getStringSet("AppPrefs", new HashSet()).iterator(); iterator.hasNext(); a.edit().remove(s).apply())
        {
            s = (String)iterator.next();
        }

        HashSet hashset = new HashSet();
        a.edit().remove("AppPrefs").apply();
        java.util.Map.Entry entry;
        String s1;
        for (Iterator iterator1 = b.entrySet().iterator(); iterator1.hasNext(); a.edit().putStringSet(s1, (Set)entry.getValue()).apply())
        {
            entry = (java.util.Map.Entry)iterator1.next();
            s1 = (String)entry.getKey();
            hashset.add(s1);
        }

        a.edit().putStringSet("AppPrefs", hashset).apply();
    }

    public int b()
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("RegisterClient:").append(a.getAll().toString()).toString());
        return 0;
    }
}
