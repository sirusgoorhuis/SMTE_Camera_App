// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.b;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.d.c;
import com.samsung.context.sdk.samsunganalytics.a.e.d;
import com.samsung.context.sdk.samsunganalytics.a.g.a;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.b:
//            a

public class b extends a
{

    public static final int g = 200;

    public b(Context context, Configuration configuration)
    {
        super(context, configuration);
    }

    private int a()
    {
        NetworkInfo networkinfo = ((ConnectivityManager)a.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkinfo == null || !networkinfo.isConnected())
        {
            return -4;
        } else
        {
            return networkinfo.getType();
        }
    }

    private int a(int i)
    {
        if (i == -4)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLS Sender", "Network unavailable.");
            return -4;
        }
        if (com.samsung.context.sdk.samsunganalytics.a.e.d.a(a))
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLS Sender", "policy expired. request policy");
            return -6;
        }
        if (b.getRestrictedNetworkType() == i)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLS Sender", (new StringBuilder()).append("Network unavailable by restrict option:").append(i).toString());
            return -4;
        } else
        {
            return 0;
        }
    }

    private int a(int i, com.samsung.context.sdk.samsunganalytics.a.g.d d1, com.samsung.context.sdk.samsunganalytics.a.d.a a1, boolean flag)
    {
        if (d1 == null)
        {
            return -100;
        }
        int j = d1.c().getBytes().length;
        if (!com.samsung.context.sdk.samsunganalytics.a.e.d.a(a, i, j))
        {
            return -1;
        }
        com.samsung.context.sdk.samsunganalytics.a.e.d.b(a, i, j);
        d1 = new com.samsung.context.sdk.samsunganalytics.a.g.b.a(d1, b.getTrackingId(), b.getNetworkTimeoutInMilliSeconds(), a1);
        if (flag)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("sync send");
            d1.a();
            return d1.b();
        } else
        {
            f.a(d1);
            return 0;
        }
    }

    private int a(int i, Queue queue, com.samsung.context.sdk.samsunganalytics.a.d.a a1)
    {
        ArrayList arraylist;
        boolean flag;
        flag = false;
        arraylist = new ArrayList();
_L9:
        int j = ((flag) ? 1 : 0);
        if (queue.isEmpty()) goto _L2; else goto _L1
_L1:
        LinkedBlockingQueue linkedblockingqueue;
        com.samsung.context.sdk.samsunganalytics.a.g.d d1;
        int k;
        linkedblockingqueue = new LinkedBlockingQueue();
        j = com.samsung.context.sdk.samsunganalytics.a.e.d.a(a, i);
        if (51200 <= j)
        {
            j = 51200;
        }
        k = 0;
_L7:
        if (queue.isEmpty()) goto _L4; else goto _L3
_L3:
        d1 = (com.samsung.context.sdk.samsunganalytics.a.g.d)queue.element();
        if (d1.c().getBytes().length + k <= j) goto _L5; else goto _L4
_L4:
        if (!linkedblockingqueue.isEmpty())
        {
            break; /* Loop/switch isn't completed */
        }
        j = -1;
_L2:
        return j;
_L5:
        int l = k + d1.c().getBytes().length;
        linkedblockingqueue.add(d1);
        queue.poll();
        arraylist.add(d1.a());
        k = l;
        if (queue.isEmpty())
        {
            e.a(arraylist);
            queue = e.a(200);
            k = l;
        }
        if (true) goto _L7; else goto _L6
_L6:
        e.a(arraylist);
        a(i, ((Queue) (linkedblockingqueue)), k, a1);
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLSLogSender", (new StringBuilder()).append("send packet : num(").append(linkedblockingqueue.size()).append(") size(").append(k).append(")").toString());
        if (true) goto _L9; else goto _L8
_L8:
    }

    static com.samsung.context.sdk.samsunganalytics.a.g.c.a a(b b1)
    {
        return b1.e;
    }

    private void a(int i, Queue queue, int j, com.samsung.context.sdk.samsunganalytics.a.d.a a1)
    {
        com.samsung.context.sdk.samsunganalytics.a.e.d.b(a, i, j);
        f.a(new com.samsung.context.sdk.samsunganalytics.a.g.b.a(queue, b.getTrackingId(), b.getNetworkTimeoutInMilliSeconds(), a1));
    }

    static Context b(b b1)
    {
        return b1.a;
    }

    public int d(Map map)
    {
        com.samsung.context.sdk.samsunganalytics.a.d.a a1;
        int i;
        i = a();
        int j = a(i);
        if (j != 0)
        {
            c(map);
            if (j == -6)
            {
                com.samsung.context.sdk.samsunganalytics.a.e.d.a(a, b, f, c);
                e.c();
            }
            return j;
        }
        a1 = new com.samsung.context.sdk.samsunganalytics.a.d.a(i) {

            final int a;
            final b b;

            public void a(int l, String s, String s1)
            {
            }

            public void b(int l, String s, String s1)
            {
                com.samsung.context.sdk.samsunganalytics.a.g.b.b.a(b).a(Long.valueOf(s).longValue(), "", s1);
                com.samsung.context.sdk.samsunganalytics.a.e.d.b(b.b(b), a, s1.getBytes().length * -1);
            }

            
            {
                b = b.this;
                a = i;
                super();
            }
        };
        a(i, new com.samsung.context.sdk.samsunganalytics.a.g.d(Long.valueOf((String)map.get("ts")).longValue(), b(a(map))), a1, false);
        map = e.a(200);
        if (!e.b()) goto _L2; else goto _L1
_L1:
        a(i, map, a1);
_L4:
        return 0;
_L2:
        int k;
        do
        {
            if (map.isEmpty())
            {
                continue; /* Loop/switch isn't completed */
            }
            k = a(i, (com.samsung.context.sdk.samsunganalytics.a.g.d)map.poll(), a1, false);
        } while (k == 0);
        break; /* Loop/switch isn't completed */
        if (true) goto _L4; else goto _L3
_L3:
        return k;
    }

    public int e(Map map)
    {
        int k;
label0:
        {
            k = a();
            int j = a(k);
            if (j == 0)
            {
                break label0;
            }
            int i = j;
            if (j == -6)
            {
                com.samsung.context.sdk.samsunganalytics.a.e.c c1 = com.samsung.context.sdk.samsunganalytics.a.e.d.a(a, b, c, null);
                c1.a();
                i = c1.b();
                com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("get policy sync ").append(i).toString());
                if (i == 0)
                {
                    break label0;
                }
            }
            return i;
        }
        return a(k, new com.samsung.context.sdk.samsunganalytics.a.g.d(Long.valueOf((String)map.get("ts")).longValue(), b(a(map))), ((com.samsung.context.sdk.samsunganalytics.a.d.a) (null)), true);
    }
}
