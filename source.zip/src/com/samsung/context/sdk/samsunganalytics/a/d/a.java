// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.d;


public abstract class a
{

    public a()
    {
    }

    public abstract void a(int i, String s, String s1);

    public abstract void b(int i, String s, String s1);
}
