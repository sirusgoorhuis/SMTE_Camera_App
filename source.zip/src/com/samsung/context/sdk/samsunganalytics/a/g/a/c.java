// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.d.b;
import com.samsung.context.sdk.samsunganalytics.a.g.d;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.sec.spp.push.dlc.api.IDlcService;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.a:
//            a

public class c
    implements b
{

    private static final String a = "SAM";
    private com.samsung.context.sdk.samsunganalytics.a.g.a.a b;
    private Configuration c;
    private d d;
    private com.samsung.context.sdk.samsunganalytics.a.d.a e;
    private int f;

    public c(com.samsung.context.sdk.samsunganalytics.a.g.a.a a1, Configuration configuration, d d1, com.samsung.context.sdk.samsunganalytics.a.d.a a2)
    {
        f = -1;
        b = a1;
        c = configuration;
        d = d1;
        e = a2;
    }

    public void a()
    {
        try
        {
            f = b.d().requestSend("SAM", c.getTrackingId().substring(0, 3), d.b(), d.a(), "0", "", "1.11.040", d.c());
            com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("send to DLC : ").append(d.c()).toString());
            return;
        }
        catch (Exception exception)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), exception);
        }
    }

    public int b()
    {
        if (f == 0)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("send result success : ").append(f).toString());
            return 1;
        } else
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("send result fail : ").append(f).toString());
            return -7;
        }
    }
}
