// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.d;

import com.samsung.context.sdk.samsunganalytics.a.i.a;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.d:
//            c, b

public class d
    implements c
{

    private static ExecutorService a;
    private static d b;

    public d()
    {
        a = Executors.newSingleThreadExecutor(new ThreadFactory() {

            final d a;

            public Thread newThread(Runnable runnable)
            {
                runnable = new Thread(runnable);
                runnable.setPriority(1);
                runnable.setDaemon(true);
                com.samsung.context.sdk.samsunganalytics.a.i.a.d("newThread on Executor");
                return runnable;
            }

            
            {
                a = d.this;
                super();
            }
        });
    }

    public static c a()
    {
        if (b == null)
        {
            b = new d();
        }
        return b;
    }

    public void a(b b1)
    {
        a.submit(new Runnable(b1) {

            final b a;
            final d b;

            public void run()
            {
                a.a();
                a.b();
            }

            
            {
                b = d.this;
                a = b1;
                super();
            }
        });
    }
}
