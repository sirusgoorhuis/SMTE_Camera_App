// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.a;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.a:
//            c, b, d

public final class a extends Enum
{

    public static final a a;
    public static final a b;
    public static final a c;
    private static final a g[];
    c d;
    b e;
    d f;

    private a(String s, int i, c c1, b b1, d d1)
    {
        super(s, i);
        d = c1;
        e = b1;
        f = d1;
    }

    public static a valueOf(String s)
    {
        return (a)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/a/a, s);
    }

    public static a[] values()
    {
        return (a[])g.clone();
    }

    public String a()
    {
        return (new StringBuilder()).append(d.a()).append(e.a()).toString();
    }

    public String b()
    {
        return f.a();
    }

    static 
    {
        a = new a("GET_POLICY", 0, c.a, b.a, d.a);
        b = new a("SEND_LOG", 1, c.b, b.b, d.b);
        c = new a("SEND_BUFFERED_LOG", 2, c.b, b.c, d.b);
        g = (new a[] {
            a, b, c
        });
    }
}
