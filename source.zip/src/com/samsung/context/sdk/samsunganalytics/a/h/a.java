// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.h;

import android.content.Context;
import android.content.SharedPreferences;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.d.b;
import com.samsung.context.sdk.samsunganalytics.a.g.c;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.h:
//            c

public class a
    implements b
{

    private static boolean a = true;
    private Context b;
    private Configuration c;
    private List d;

    public a(Context context, Configuration configuration)
    {
        b = context;
        c = configuration;
    }

    public static void a(boolean flag)
    {
        a = flag;
    }

    public static boolean c()
    {
        return a;
    }

    public void a()
    {
        d = (new com.samsung.context.sdk.samsunganalytics.a.h.c(b)).a();
    }

    public int b()
    {
        if (d.isEmpty())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("Setting Sender", "No status log");
        } else
        {
            HashMap hashmap = new HashMap();
            hashmap.put("ts", String.valueOf(System.currentTimeMillis()));
            hashmap.put("t", "st");
            Iterator iterator = d.iterator();
            long l = 0L;
            while (iterator.hasNext()) 
            {
                hashmap.put("sti", (String)iterator.next());
                if (com.samsung.context.sdk.samsunganalytics.a.g.c.a(b, null, c).d(hashmap) == 0)
                {
                    com.samsung.context.sdk.samsunganalytics.a.i.a.a("Setting Sender", "Send success");
                    l = System.currentTimeMillis();
                } else
                {
                    com.samsung.context.sdk.samsunganalytics.a.i.a.a("Setting Sender", "Send fail");
                }
            }
            if (l != 0L)
            {
                com.samsung.context.sdk.samsunganalytics.a.i.c.a(b).edit().putLong("status_sent_date", l).apply();
                return 0;
            }
        }
        return 0;
    }

}
