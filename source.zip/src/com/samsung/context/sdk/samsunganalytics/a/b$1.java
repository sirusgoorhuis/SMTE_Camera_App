// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a;

import android.app.Application;
import com.samsung.context.sdk.samsunganalytics.UserAgreement;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a:
//            b

class a
    implements UserAgreement
{

    final Application a;
    final b b;

    public boolean isAgreement()
    {
        return android.provider.ings.System.getInt(a.getContentResolver(), "samsung_errorlog_agree", 0) == 1;
    }

    reement(b b1, Application application)
    {
        b = b1;
        a = application;
        super();
    }
}
