// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.c;

import java.io.PrintWriter;
import java.io.StringWriter;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.c:
//            a

public class b
    implements a
{

    public b()
    {
    }

    public String a(String s, Throwable throwable)
    {
        StringWriter stringwriter = new StringWriter();
        PrintWriter printwriter = new PrintWriter(stringwriter);
        throwable.printStackTrace(printwriter);
        throwable = stringwriter.toString();
        printwriter.close();
        return (new StringBuilder()).append("thread(").append(s).append(") : ").append(throwable).toString();
    }
}
