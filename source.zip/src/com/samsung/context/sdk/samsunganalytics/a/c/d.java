// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.c;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.c:
//            a

public class d
    implements a
{

    private static final String a = "\007";

    public d()
    {
    }

    public String a(String s, Throwable throwable)
    {
        s = new StringBuilder();
        s.append("");
        if (throwable == null) goto _L2; else goto _L1
_L1:
        int i;
        int j;
        s.append(throwable.getClass().getName());
        s.append(":");
        s.append(throwable.getLocalizedMessage());
        s.append("\007");
        throwable = throwable.getStackTrace();
        j = throwable.length;
        i = 0;
_L6:
        if (i >= j) goto _L2; else goto _L3
_L3:
        s.append(throwable[i].toString());
        s.append("\007");
        if (s.length() <= 700) goto _L4; else goto _L2
_L2:
        return s.toString();
_L4:
        i++;
        if (true) goto _L6; else goto _L5
_L5:
    }
}
