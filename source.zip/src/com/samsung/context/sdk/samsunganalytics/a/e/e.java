// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.UserManager;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.SamsungAnalytics;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;

public class e
{

    public static final int a = 0;
    public static final int b = -1001;
    public static String c = "RSSAV1wsc2s314SAamk";
    private static HashMap d;

    private e()
    {
    }

    public static int a(String s, String s1)
    {
        if (TextUtils.isEmpty(s) || TextUtils.isEmpty(s1))
        {
            return -1001;
        }
        if (d == null)
        {
            b();
        }
        s = (Integer)d.get(s);
        if (s != null && s.intValue() < s1.length())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.e((new StringBuilder()).append("Invalid length : ").append(s1).toString());
            com.samsung.context.sdk.samsunganalytics.a.i.a.e((new StringBuilder()).append("MAX length : ").append(s).toString());
            return -1001;
        } else
        {
            return 0;
        }
    }

    public static String a(String s)
    {
        if (s == null)
        {
            return null;
        }
        MessageDigest messagedigest = MessageDigest.getInstance("SHA-256");
        messagedigest.update(s.getBytes("UTF-8"));
        s = String.format(Locale.US, "%064x", new Object[] {
            new BigInteger(1, messagedigest.digest())
        });
_L2:
        return s;
        s;
_L3:
        com.samsung.context.sdk.samsunganalytics.a.i.a.a(com/samsung/context/sdk/samsunganalytics/a/e/e, s);
        s = null;
        if (true) goto _L2; else goto _L1
_L1:
        s;
          goto _L3
    }

    public static boolean a()
    {
        String s;
        Object obj;
        boolean flag;
        if (android.os.Build.VERSION.SDK_INT > 23)
        {
            obj = "com.samsung.android.feature.SemFloatingFeature";
            s = "getBoolean";
        } else
        {
            obj = "com.samsung.android.feature.FloatingFeature";
            s = "getEnableStatus";
        }
        try
        {
            obj = Class.forName(((String) (obj)));
            Object obj1 = ((Class) (obj)).getMethod("getInstance", null).invoke(null, new Object[0]);
            flag = ((Boolean)((Class) (obj)).getMethod(s, new Class[] {
                java/lang/String
            }).invoke(obj1, new Object[] {
                "SEC_FLOATING_FEATURE_CONTEXTSERVICE_ENABLE_SURVEY_MODE"
            })).booleanValue();
        }
        catch (Exception exception)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("Floating feature is not supported (non-samsung device)");
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(com/samsung/context/sdk/samsunganalytics/a/e/e, exception);
            return false;
        }
        if (!flag)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("feature is not supported");
            return flag;
        } else
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("cf feature is supported");
            return flag;
        }
    }

    public static boolean a(Application application, Configuration configuration)
    {
        if (application == null)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.d.a("context cannot be null");
            return false;
        }
        if (configuration == null)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.d.a("Configuration cannot be null");
            return false;
        }
        if (TextUtils.isEmpty(configuration.getDeviceId()) && !configuration.isEnableAutoDeviceId())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.d.a("Device Id is empty, set Device Id or enable auto device id");
            return false;
        }
        if (configuration.isEnableUseInAppLogging())
        {
            if (configuration.getUserAgreement() == null)
            {
                com.samsung.context.sdk.samsunganalytics.a.i.d.a("If you want to use In App Logging, you should implement UserAgreement interface");
                return false;
            }
        } else
        {
            if (!a(((Context) (application)), "com.sec.spp.permission.TOKEN", false))
            {
                com.samsung.context.sdk.samsunganalytics.a.i.d.a("If you want to use DLC Logger, define 'com.sec.spp.permission.TOKEN_XXXX' permission in AndroidManifest");
                return false;
            }
            if (!TextUtils.isEmpty(configuration.getDeviceId()))
            {
                com.samsung.context.sdk.samsunganalytics.a.i.d.a("This mode is not allowed to set device Id");
                return false;
            }
            if (!TextUtils.isEmpty(configuration.getUserId()))
            {
                com.samsung.context.sdk.samsunganalytics.a.i.d.a("This mode is not allowed to set user Id");
                return false;
            }
        }
        if (configuration.getVersion() == null)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.d.a("you should set the version");
            return false;
        }
        if (android.os.Build.VERSION.SDK_INT >= 24)
        {
            UserManager usermanager = (UserManager)application.getSystemService("user");
            if (usermanager != null && !usermanager.isUserUnlocked())
            {
                com.samsung.context.sdk.samsunganalytics.a.i.a.e("The user has not unlocked the device.");
                configuration = new BroadcastReceiver(application, configuration) {

                    final Application a;
                    final Configuration b;

                    public void onReceive(Context context, Intent intent)
                    {
                        com.samsung.context.sdk.samsunganalytics.a.i.a.d((new StringBuilder()).append("receive ").append(intent.getAction()).toString());
                        SamsungAnalytics.setConfiguration(a, b);
                    }

            
            {
                a = application;
                b = configuration;
                super();
            }
                };
                IntentFilter intentfilter = new IntentFilter();
                intentfilter.addAction("android.intent.action.BOOT_COMPLETED");
                intentfilter.addAction("android.intent.action.USER_UNLOCKED");
                application.registerReceiver(configuration, intentfilter);
                return false;
            }
        }
        return true;
    }

    public static boolean a(Context context, String s, boolean flag)
    {
        boolean flag2 = true;
        context = context.getPackageManager().getPackageInfo(context.getPackageName(), 4096);
        if (((PackageInfo) (context)).requestedPermissions == null) goto _L2; else goto _L1
_L1:
        int j;
        context = ((PackageInfo) (context)).requestedPermissions;
        j = context.length;
        int i = 0;
_L3:
        String s1;
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        s1 = context[i];
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_63;
        }
        if (s1.equalsIgnoreCase(s))
        {
            return true;
        }
        break MISSING_BLOCK_LABEL_79;
        boolean flag3 = s1.startsWith(s);
        boolean flag1;
        flag1 = flag2;
        if (flag3)
        {
            break MISSING_BLOCK_LABEL_98;
        }
        i++;
        if (true) goto _L3; else goto _L2
        context;
        com.samsung.context.sdk.samsunganalytics.a.i.a.a(com/samsung/context/sdk/samsunganalytics/a/e/e, context);
_L2:
        flag1 = false;
        return flag1;
    }

    private static void b()
    {
        d = new HashMap();
        d.put("pn", Integer.valueOf(100));
        d.put("pnd", Integer.valueOf(400));
        d.put("en", Integer.valueOf(100));
        d.put("ed", Integer.valueOf(400));
        d.put("exm", Integer.valueOf(400));
        d.put("exd", Integer.valueOf(1000));
        d.put("sti", Integer.valueOf(1000));
        d.put("cd", Integer.valueOf(1000));
        d.put("cm", Integer.valueOf(1000));
    }

}
