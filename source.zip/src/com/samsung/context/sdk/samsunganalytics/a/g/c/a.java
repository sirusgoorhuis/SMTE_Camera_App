// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.c;

import android.content.Context;
import android.content.SharedPreferences;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.g.d;
import com.samsung.context.sdk.samsunganalytics.a.i.c;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;

public class a
{

    private static a d;
    private com.samsung.context.sdk.samsunganalytics.a.g.c.a.a a;
    private com.samsung.context.sdk.samsunganalytics.a.g.c.b.a b;
    private boolean c;

    private a(Context context, boolean flag)
    {
        this(context, flag, 0);
    }

    private a(Context context, boolean flag, int i)
    {
        if (flag)
        {
            a = new com.samsung.context.sdk.samsunganalytics.a.g.c.a.a(context);
        }
        b = new com.samsung.context.sdk.samsunganalytics.a.g.c.b.a(i);
        c = flag;
    }

    public static a a(Context context, Configuration configuration)
    {
        if (d != null) goto _L2; else goto _L1
_L1:
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorenter ;
        int i;
        i = configuration.getQueueSize();
        if (!configuration.isEnableUseInAppLogging())
        {
            break MISSING_BLOCK_LABEL_84;
        }
        if (!com.samsung.context.sdk.samsunganalytics.a.i.c.a(context).getString("lgt", "").equals("rtb")) goto _L4; else goto _L3
_L3:
        d = new a(context, true, i);
_L5:
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorexit ;
_L2:
        return d;
_L4:
        d = new a(context, false, i);
          goto _L5
        context;
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorexit ;
        throw context;
        d = new a(context, false, i);
          goto _L5
    }

    public static a a(Context context, Boolean boolean1, int i)
    {
        if (d != null) goto _L2; else goto _L1
_L1:
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorenter ;
        if (!boolean1.booleanValue())
        {
            break MISSING_BLOCK_LABEL_36;
        }
        d = new a(context, true, i);
_L3:
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorexit ;
_L2:
        return d;
        d = new a(context, false, i);
          goto _L3
        context;
        com/samsung/context/sdk/samsunganalytics/a/g/c/a;
        JVM INSTR monitorexit ;
        throw context;
    }

    private void g()
    {
        if (!b.a().isEmpty())
        {
            d d1;
            for (Iterator iterator = b.a().iterator(); iterator.hasNext(); a.a(d1))
            {
                d1 = (d)iterator.next();
            }

            b.a().clear();
        }
    }

    public Queue a(int i)
    {
        Queue queue;
        if (c)
        {
            c();
            StringBuilder stringbuilder;
            if (i <= 0)
            {
                queue = a.a();
            } else
            {
                queue = a.a(i);
            }
        } else
        {
            queue = b.a();
        }
        if (!queue.isEmpty())
        {
            stringbuilder = (new StringBuilder()).append("get log from ");
            String s;
            if (c)
            {
                s = "Database ";
            } else
            {
                s = "Queue ";
            }
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(stringbuilder.append(s).append("(").append(queue.size()).append(")").toString());
        }
        return queue;
    }

    public void a()
    {
        c = false;
    }

    public void a(long l, String s, String s1)
    {
        a(new d(s, l, s1));
    }

    public void a(Context context)
    {
        c = true;
        if (a == null)
        {
            a = new com.samsung.context.sdk.samsunganalytics.a.g.c.a.a(context);
        }
        g();
    }

    public void a(d d1)
    {
        if (c)
        {
            a.a(d1);
            return;
        } else
        {
            b.a(d1);
            return;
        }
    }

    public void a(String s)
    {
        if (c)
        {
            a.a(s);
        }
    }

    public void a(List list)
    {
        while (list.isEmpty() || !c) 
        {
            return;
        }
        a.a(list);
    }

    public boolean b()
    {
        return c;
    }

    public void c()
    {
        if (c)
        {
            a.a(com.samsung.context.sdk.samsunganalytics.a.i.d.a(5));
        }
    }

    public Queue d()
    {
        return a(0);
    }

    public long e()
    {
        if (c)
        {
            return a.d();
        } else
        {
            return b.b();
        }
    }

    public boolean f()
    {
        if (c)
        {
            return a.c();
        } else
        {
            return b.c();
        }
    }
}
