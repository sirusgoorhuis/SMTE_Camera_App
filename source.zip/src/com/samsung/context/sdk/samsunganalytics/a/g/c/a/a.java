// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.c.a;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import com.samsung.context.sdk.samsunganalytics.a.g.d;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.c.a:
//            b

public class a
{

    private SQLiteDatabase a;
    private b b;
    private Queue c;

    public a(Context context)
    {
        c = new LinkedBlockingQueue();
        b = new b(context);
        a(5L);
    }

    private Queue b(String s)
    {
        c.clear();
        a = b.getReadableDatabase();
        d d1;
        for (s = a.rawQuery(s, null); s.moveToNext(); c.add(d1))
        {
            d1 = new d();
            d1.a(s.getString(s.getColumnIndex("_id")));
            d1.b(s.getString(s.getColumnIndex("data")));
            d1.a(s.getLong(s.getColumnIndex("timestamp")));
        }

        s.close();
        return c;
    }

    public Queue a()
    {
        return b("select * from logs");
    }

    public Queue a(int i)
    {
        return b((new StringBuilder()).append("select * from logs LIMIT ").append(i).toString());
    }

    public void a(long l)
    {
        a = b.getWritableDatabase();
        String s = (new StringBuilder()).append("timestamp <= ").append(l).toString();
        a.delete("logs", s, null);
    }

    public void a(d d1)
    {
        a = b.getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put("timestamp", Long.valueOf(d1.b()));
        contentvalues.put("data", d1.c());
        a.insert("logs", null, contentvalues);
    }

    public void a(String s)
    {
        a = b.getWritableDatabase();
        s = (new StringBuilder()).append("_id = ").append(s).toString();
        a.delete("logs", s, null);
    }

    public void a(List list)
    {
        a = b.getWritableDatabase();
        a.beginTransaction();
        int i = list.size();
        int j = 0;
          goto _L1
_L5:
        int k;
        List list1 = list.subList(j, j + k);
        String s = (new StringBuilder()).append("_id IN(").append((new String(new char[list1.size() - 1])).replaceAll("\0", "?,")).toString();
        s = (new StringBuilder()).append(s).append("?)").toString();
        a.delete("logs", s, (String[])list1.toArray(new String[0]));
        i -= k;
        j += k;
          goto _L1
_L3:
        list.clear();
        a.setTransactionSuccessful();
        a.endTransaction();
        return;
        list;
        list.printStackTrace();
        a.endTransaction();
        return;
        list;
        a.endTransaction();
        throw list;
_L1:
        if (i <= 0) goto _L3; else goto _L2
_L2:
        if (i < 900)
        {
            k = i;
        } else
        {
            k = 900;
        }
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void b()
    {
        if (b != null)
        {
            b.close();
        }
    }

    public boolean c()
    {
        return d() <= 0L;
    }

    public long d()
    {
        a = b.getReadableDatabase();
        return DatabaseUtils.queryNumEntries(a, "logs");
    }
}
