// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.a;


public final class d extends Enum
{

    public static final d a;
    public static final d b;
    private static final d d[];
    String c;

    private d(String s, int i, String s1)
    {
        super(s, i);
        c = s1;
    }

    public static d valueOf(String s)
    {
        return (d)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/a/d, s);
    }

    public static d[] values()
    {
        return (d[])d.clone();
    }

    public String a()
    {
        return c;
    }

    static 
    {
        a = new d("GET", 0, "GET");
        b = new d("POST", 1, "POST");
        d = (new d[] {
            a, b
        });
    }
}
