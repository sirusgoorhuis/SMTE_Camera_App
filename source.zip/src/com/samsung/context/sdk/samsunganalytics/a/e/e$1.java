// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.SamsungAnalytics;
import com.samsung.context.sdk.samsunganalytics.a.i.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.e:
//            e

static final class b extends BroadcastReceiver
{

    final Application a;
    final Configuration b;

    public void onReceive(Context context, Intent intent)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.d((new StringBuilder()).append("receive ").append(intent.getAction()).toString());
        SamsungAnalytics.setConfiguration(a, b);
    }

    ation(Application application, Configuration configuration)
    {
        a = application;
        b = configuration;
        super();
    }
}
