// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.b;

import android.net.Uri;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.d.b;
import com.samsung.context.sdk.samsunganalytics.a.e.e;
import com.samsung.context.sdk.samsunganalytics.a.g.d;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Queue;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import org.json.JSONObject;

public class a
    implements b
{

    private static final com.samsung.context.sdk.samsunganalytics.a.a.a a;
    private static final com.samsung.context.sdk.samsunganalytics.a.a.a b;
    private static final int c = 3000;
    private static final int d = 15000;
    private Queue e;
    private d f;
    private String g;
    private HttpsURLConnection h;
    private com.samsung.context.sdk.samsunganalytics.a.d.a i;
    private Boolean j;
    private int k;

    public a(d d1, String s, int l, com.samsung.context.sdk.samsunganalytics.a.d.a a1)
    {
        h = null;
        j = Boolean.valueOf(false);
        f = d1;
        g = s;
        i = a1;
        k = a(l);
    }

    public a(Queue queue, String s, int l, com.samsung.context.sdk.samsunganalytics.a.d.a a1)
    {
        h = null;
        j = Boolean.valueOf(false);
        e = queue;
        g = s;
        i = a1;
        j = Boolean.valueOf(true);
        k = a(l);
    }

    private int a(int l)
    {
        int i1;
        if (l == 0)
        {
            i1 = 3000;
        } else
        {
            i1 = l;
            if (l > 15000)
            {
                return 15000;
            }
        }
        return i1;
    }

    private void a(int l, String s)
    {
        if (i != null && (l != 200 || !s.equalsIgnoreCase("1000")))
        {
            if (j.booleanValue())
            {
                while (!e.isEmpty()) 
                {
                    s = (d)e.poll();
                    i.b(l, (new StringBuilder()).append(s.b()).append("").toString(), s.c());
                }
            } else
            {
                i.b(l, (new StringBuilder()).append(f.b()).append("").toString(), f.c());
                return;
            }
        }
    }

    private void a(BufferedReader bufferedreader)
    {
        if (bufferedreader == null)
        {
            break MISSING_BLOCK_LABEL_8;
        }
        bufferedreader.close();
        if (h != null)
        {
            h.disconnect();
        }
        return;
        bufferedreader;
    }

    private String c()
    {
        Object obj;
        if (j.booleanValue())
        {
            Iterator iterator = e.iterator();
            String s = ((d)iterator.next()).c();
            do
            {
                obj = s;
                if (!iterator.hasNext())
                {
                    break;
                }
                obj = (d)iterator.next();
                s = (new StringBuilder()).append(s).append("\016").append(((d) (obj)).c()).toString();
            } while (true);
        } else
        {
            obj = f.c();
        }
        return ((String) (obj));
    }

    public void a()
    {
        if (!j.booleanValue()) goto _L2; else goto _L1
_L1:
        Object obj = b;
_L5:
        Object obj1;
        obj1 = Uri.parse(((com.samsung.context.sdk.samsunganalytics.a.a.a) (obj)).a()).buildUpon();
        String s = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(new Date());
        ((android.net.Uri.Builder) (obj1)).appendQueryParameter("ts", s).appendQueryParameter("tid", g).appendQueryParameter("hc", com.samsung.context.sdk.samsunganalytics.a.e.e.a((new StringBuilder()).append(g).append(s).append(e.c).toString()));
        h = (HttpsURLConnection)(new URL(((android.net.Uri.Builder) (obj1)).build().toString())).openConnection();
        h.setSSLSocketFactory(com.samsung.context.sdk.samsunganalytics.a.f.a.a().b().getSocketFactory());
        h.setRequestMethod(((com.samsung.context.sdk.samsunganalytics.a.a.a) (obj)).b());
        obj1 = h;
        if (j.booleanValue())
        {
            obj = "gzip";
        } else
        {
            obj = "text";
        }
        ((HttpsURLConnection) (obj1)).addRequestProperty("Content-Encoding", ((String) (obj)));
        h.setConnectTimeout(k);
        obj1 = c();
        if (TextUtils.isEmpty(((CharSequence) (obj1)))) goto _L4; else goto _L3
_L3:
        h.setDoOutput(true);
        if (!j.booleanValue())
        {
            break MISSING_BLOCK_LABEL_283;
        }
        obj = new BufferedOutputStream(new GZIPOutputStream(h.getOutputStream()));
_L6:
        ((OutputStream) (obj)).write(((String) (obj1)).getBytes());
        ((OutputStream) (obj)).flush();
        ((OutputStream) (obj)).close();
_L4:
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("[DLS Client] Send to DLS : ").append(((String) (obj1))).toString());
        return;
_L2:
        try
        {
            obj = a;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.e("[DLS Client] Send fail.");
            com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("[DLS Client] ").append(((Exception) (obj)).getMessage()).toString());
            return;
        }
          goto _L5
        obj = new BufferedOutputStream(h.getOutputStream());
          goto _L6
    }

    public int b()
    {
        Object obj1;
        int i1;
        i1 = h.getResponseCode();
        obj1 = new BufferedReader(new InputStreamReader(h.getInputStream()));
        Object obj = obj1;
        String s = (new JSONObject(((BufferedReader) (obj1)).readLine())).getString("rc");
        if (i1 != 200) goto _L2; else goto _L1
_L1:
        obj = obj1;
        if (!s.equalsIgnoreCase("1000")) goto _L2; else goto _L3
_L3:
        int l;
        l = 1;
        obj = obj1;
        com.samsung.context.sdk.samsunganalytics.a.i.a.d((new StringBuilder()).append("[DLS Sender] send result success : ").append(i1).append(" ").append(s).toString());
_L5:
        obj = obj1;
        a(i1, s);
        a(((BufferedReader) (obj1)));
        return l;
_L2:
        l = -7;
        obj = obj1;
        com.samsung.context.sdk.samsunganalytics.a.i.a.d((new StringBuilder()).append("[DLS Sender] send result fail : ").append(i1).append(" ").append(s).toString());
        if (true) goto _L5; else goto _L4
_L4:
        Exception exception;
        exception;
_L9:
        obj = obj1;
        com.samsung.context.sdk.samsunganalytics.a.i.a.e("[DLS Client] Send fail.");
        obj = obj1;
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("[DLS Client] ").append(exception.getMessage()).toString());
        obj = obj1;
        a(0, "");
        a(((BufferedReader) (obj1)));
        return -41;
        obj1;
        obj = null;
_L7:
        a(((BufferedReader) (obj)));
        throw obj1;
        obj1;
        if (true) goto _L7; else goto _L6
_L6:
        exception;
        obj1 = null;
        if (true) goto _L9; else goto _L8
_L8:
    }

    static 
    {
        a = com.samsung.context.sdk.samsunganalytics.a.a.a.b;
        b = com.samsung.context.sdk.samsunganalytics.a.a.a.c;
    }
}
