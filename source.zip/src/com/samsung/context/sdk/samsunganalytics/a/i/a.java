// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.i;

import android.util.Log;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.i:
//            d

public class a
{

    private static final String a = "SamsungAnalytics111040";

    private a()
    {
    }

    public static void a(Class class1, Exception exception)
    {
        if (exception != null)
        {
            Log.w("SamsungAnalytics111040", (new StringBuilder()).append("[").append(class1.getSimpleName()).append("] ").append(exception.getClass().getSimpleName()).append(" ").append(exception.getMessage()).toString());
        }
    }

    public static void a(String s)
    {
        if (com.samsung.context.sdk.samsunganalytics.a.i.d.a())
        {
            Log.d("SamsungAnalytics111040", (new StringBuilder()).append("[ENG ONLY] ").append(s).toString());
        }
    }

    public static void a(String s, String s1)
    {
        d((new StringBuilder()).append("[").append(s).append("] ").append(s1).toString());
    }

    public static void b(String s)
    {
        Log.v("SamsungAnalytics111040", s);
    }

    public static void b(String s, String s1)
    {
        e((new StringBuilder()).append("[").append(s).append("] ").append(s1).toString());
    }

    public static void c(String s)
    {
        Log.i("SamsungAnalytics111040", s);
    }

    public static void d(String s)
    {
        Log.d("SamsungAnalytics111040", s);
    }

    public static void e(String s)
    {
        Log.e("SamsungAnalytics111040", s);
    }
}
