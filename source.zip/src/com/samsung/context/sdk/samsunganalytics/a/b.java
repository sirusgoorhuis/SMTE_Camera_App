// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.UserAgreement;
import com.samsung.context.sdk.samsunganalytics.a.d.d;
import com.samsung.context.sdk.samsunganalytics.a.e.e;
import com.samsung.context.sdk.samsunganalytics.a.g.c;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a:
//            a

public class b
{

    public static final int a = 128;
    private static final int b = 0;
    private static final int c = 1;
    private static final int d = 2;
    private Application e;
    private Thread.UncaughtExceptionHandler f;
    private Thread.UncaughtExceptionHandler g;
    private boolean h;
    private boolean i;
    private android.app.Application.ActivityLifecycleCallbacks j;
    private Configuration k;
    private Intent l;

    public b(Application application, Configuration configuration)
    {
        h = false;
        i = false;
        e = application;
        k = configuration;
        if (!TextUtils.isEmpty(configuration.getDeviceId()))
        {
            k.setAuidType(2);
        } else
        if (!m() && configuration.isEnableAutoDeviceId())
        {
            l();
        }
        if (configuration.isEnableUseInAppLogging())
        {
            i();
        } else
        {
            k.setUserAgreement(new UserAgreement(application) {

                final Application a;
                final b b;

                public boolean isAgreement()
                {
                    return android.provider.Settings.System.getInt(a.getContentResolver(), "samsung_errorlog_agree", 0) == 1;
                }

            
            {
                b = b.this;
                a = application;
                super();
            }
            });
        }
        if (p())
        {
            if (configuration.isEnableFastReady())
            {
                com.samsung.context.sdk.samsunganalytics.a.g.c.a(application, null, configuration);
            }
            o();
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("Tracker", "Tracker start:1.11.040");
    }

    static void a(b b1)
    {
        b1.o();
    }

    static void a(b b1, String s, int i1)
    {
        b1.a(s, i1);
    }

    private void a(String s, int i1)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.c.a(e.getApplicationContext()).edit().putString("deviceId", s).putInt("auidType", i1).apply();
        k.setAuidType(i1);
        k.setDeviceId(s);
    }

    private boolean a(String s)
    {
        int i1;
        int j1;
        int k1;
        try
        {
            s = new StringTokenizer(e.getApplicationContext().getPackageManager().getPackageInfo(s, 0).versionName, ".");
            i1 = Integer.parseInt(s.nextToken());
            j1 = Integer.parseInt(s.nextToken());
            k1 = Integer.parseInt(s.nextToken());
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), s);
            return false;
        }
        if (i1 >= 2)
        {
            break MISSING_BLOCK_LABEL_65;
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("CF version < 2.0.9");
        return false;
        if (i1 != 2 || j1 != 0 || k1 >= 9)
        {
            break MISSING_BLOCK_LABEL_99;
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("CF version < 2.0.9");
        return false;
        return true;
    }

    static Application b(b b1)
    {
        return b1.e;
    }

    private void b(Map map)
    {
        map.remove("t");
        map = new com.samsung.context.sdk.samsunganalytics.a.d.b(map) {

            final Map a;
            final b b;

            public void a()
            {
                SharedPreferences sharedpreferences = b.b(b).getSharedPreferences("SASettingPref", 0);
                String s;
                for (Iterator iterator = a.keySet().iterator(); iterator.hasNext(); sharedpreferences.edit().putString(s, (String)a.get(s)).apply())
                {
                    s = (String)iterator.next();
                }

            }

            public int b()
            {
                return 0;
            }

            
            {
                b = b.this;
                a = map;
                super();
            }
        };
        com.samsung.context.sdk.samsunganalytics.a.d.d.a().a(map);
        if (com.samsung.context.sdk.samsunganalytics.a.h.a.c() && k.isAlwaysRunningApp() && (k.isEnableUseInAppLogging() || com.samsung.context.sdk.samsunganalytics.a.e.e.a()))
        {
            h();
        }
    }

    static Configuration c(b b1)
    {
        return b1.k;
    }

    static boolean d(b b1)
    {
        return b1.h;
    }

    static Thread.UncaughtExceptionHandler e(b b1)
    {
        return b1.g;
    }

    static String f(b b1)
    {
        return b1.n();
    }

    private void h()
    {
        if (com.samsung.context.sdk.samsunganalytics.a.h.a.c())
        {
            com.samsung.context.sdk.samsunganalytics.a.h.a.a(false);
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("register BR");
        IntentFilter intentfilter = new IntentFilter();
        intentfilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
        e.getApplicationContext().registerReceiver(new BroadcastReceiver() {

            final b a;

            public void onReceive(Context context, Intent intent)
            {
                com.samsung.context.sdk.samsunganalytics.a.i.a.a("receive BR");
                com.samsung.context.sdk.samsunganalytics.a.b.a(a);
            }

            
            {
                a = b.this;
                super();
            }
        }, intentfilter);
    }

    private void i()
    {
        SharedPreferences sharedpreferences = com.samsung.context.sdk.samsunganalytics.a.i.c.a(e);
        com.samsung.context.sdk.samsunganalytics.a.a.c.b.a(sharedpreferences.getString("dom", ""));
        com.samsung.context.sdk.samsunganalytics.a.a.b.b.a(sharedpreferences.getString("uri", ""));
        com.samsung.context.sdk.samsunganalytics.a.a.b.c.a(sharedpreferences.getString("bat-uri", ""));
        if (com.samsung.context.sdk.samsunganalytics.a.e.d.a(e.getApplicationContext()))
        {
            com.samsung.context.sdk.samsunganalytics.a.e.d.a(e, k, com.samsung.context.sdk.samsunganalytics.a.d.d.a(), new com.samsung.context.sdk.samsunganalytics.a.b.a(e), new com.samsung.context.sdk.samsunganalytics.a.a() {

                final b a;

                public volatile Object a(Object obj)
                {
                    return a((Boolean)obj);
                }

                public Void a(Boolean boolean1)
                {
                    if (boolean1.booleanValue())
                    {
                        com.samsung.context.sdk.samsunganalytics.a.g.c.a.a(b.b(a).getApplicationContext(), Boolean.valueOf(true), com.samsung.context.sdk.samsunganalytics.a.b.c(a).getQueueSize()).a(b.b(a).getApplicationContext());
                    }
                    return null;
                }

            
            {
                a = b.this;
                super();
            }
            });
        }
    }

    private android.app.Application.ActivityLifecycleCallbacks j()
    {
        if (j == null)
        {
            j = new android.app.Application.ActivityLifecycleCallbacks() {

                final b a;

                public void onActivityCreated(Activity activity, Bundle bundle)
                {
                }

                public void onActivityDestroyed(Activity activity)
                {
                }

                public void onActivityPaused(Activity activity)
                {
                }

                public void onActivityResumed(Activity activity)
                {
                }

                public void onActivitySaveInstanceState(Activity activity, Bundle bundle)
                {
                }

                public void onActivityStarted(Activity activity)
                {
                    activity = (com.samsung.context.sdk.samsunganalytics.LogBuilders.ScreenViewBuilder)(new com.samsung.context.sdk.samsunganalytics.LogBuilders.ScreenViewBuilder()).setScreenView(activity.getComponentName().getShortClassName());
                    a.a(activity.build(), false);
                }

                public void onActivityStopped(Activity activity)
                {
                }

            
            {
                a = b.this;
                super();
            }
            };
            return j;
        } else
        {
            return j;
        }
    }

    private boolean k()
    {
        if (com.samsung.context.sdk.samsunganalytics.a.e.e.a() && !k.isEnableUseInAppLogging() && TextUtils.isEmpty(k.getUserId()) && a("com.samsung.android.providers.context"))
        {
            BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {

                final b a;

                public void onReceive(Context context, Intent intent)
                {
                    context = intent.getStringExtra("DID");
                    int i1;
                    if (TextUtils.isEmpty(context))
                    {
                        context = b.f(a);
                        i1 = 1;
                        com.samsung.context.sdk.samsunganalytics.a.i.a.d("Get CF id empty");
                    } else
                    {
                        i1 = 0;
                        com.samsung.context.sdk.samsunganalytics.a.i.a.d("Get CF id");
                    }
                    com.samsung.context.sdk.samsunganalytics.a.b.a(a, context, i1);
                    b.b(a).unregisterReceiver(this);
                }

            
            {
                a = b.this;
                super();
            }
            };
            e.registerReceiver(broadcastreceiver, new IntentFilter("com.samsung.android.providers.context.log.action.GET_DID"));
            l = new Intent("com.samsung.android.providers.context.log.action.REQUEST_DID");
            l.putExtra("PKGNAME", e.getPackageName());
            l.setPackage("com.samsung.android.providers.context");
            e.sendBroadcast(l);
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("request CF id");
            return true;
        } else
        {
            return false;
        }
    }

    private void l()
    {
        if (!k())
        {
            a(n(), 1);
        }
    }

    private boolean m()
    {
        SharedPreferences sharedpreferences = com.samsung.context.sdk.samsunganalytics.a.i.c.a(e);
        String s = sharedpreferences.getString("deviceId", "");
        int i1 = sharedpreferences.getInt("auidType", -1);
        if (TextUtils.isEmpty(s) || s.length() != 32 || i1 == -1)
        {
            return false;
        } else
        {
            k.setAuidType(i1);
            k.setDeviceId(s);
            return true;
        }
    }

    private String n()
    {
        SecureRandom securerandom = new SecureRandom();
        byte abyte0[] = new byte[16];
        StringBuilder stringbuilder = new StringBuilder(32);
        int i1 = 0;
        do
        {
            if (i1 >= 32)
            {
                break;
            }
            securerandom.nextBytes(abyte0);
            try
            {
                stringbuilder.append("0123456789abcdefghijklmjopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt((int)(Math.abs((new BigInteger(abyte0)).longValue()) % (long)"0123456789abcdefghijklmjopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".length())));
            }
            catch (Exception exception)
            {
                com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), exception);
                return null;
            }
            i1++;
        } while (true);
        return stringbuilder.toString();
    }

    private void o()
    {
        if (!com.samsung.context.sdk.samsunganalytics.a.i.d.a(7, Long.valueOf(com.samsung.context.sdk.samsunganalytics.a.i.c.a(e).getLong("status_sent_date", 0L))))
        {
            return;
        }
        if (!p())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("user do not agree");
            return;
        } else
        {
            com.samsung.context.sdk.samsunganalytics.a.d.d.a().a(new com.samsung.context.sdk.samsunganalytics.a.h.a(e, k));
            return;
        }
    }

    private boolean p()
    {
        return k.getUserAgreement().isAgreement();
    }

    private boolean q()
    {
        if (TextUtils.isEmpty(k.getDeviceId()))
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("did is empty");
            return false;
        } else
        {
            return true;
        }
    }

    public int a(Map map, boolean flag)
    {
        if (!p())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("user do not agree");
            return -2;
        }
        if (map == null || map.isEmpty())
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.d("Failure to send Logs : No data");
            return -3;
        }
        if (!q())
        {
            if (l != null)
            {
                e.sendBroadcast(l);
            }
            return -5;
        }
        if (((String)map.get("t")).equalsIgnoreCase("st"))
        {
            b(map);
            return 0;
        }
        if (flag)
        {
            return com.samsung.context.sdk.samsunganalytics.a.g.c.a(e, null, k).e(map);
        } else
        {
            return com.samsung.context.sdk.samsunganalytics.a.g.c.a(e, null, k).d(map);
        }
    }

    public void a()
    {
        h = true;
        if (f == null)
        {
            g = Thread.getDefaultUncaughtExceptionHandler();
            f = new Thread.UncaughtExceptionHandler() {

                final b a;

                public void uncaughtException(Thread thread, Throwable throwable)
                {
                    if (com.samsung.context.sdk.samsunganalytics.a.b.d(a))
                    {
                        com.samsung.context.sdk.samsunganalytics.a.i.a.d("get un exc");
                        String s = com.samsung.context.sdk.samsunganalytics.a.c.c.a(com.samsung.context.sdk.samsunganalytics.a.c.c.a.b).a(thread.getName(), throwable);
                        a.a(((com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder)((com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder)((com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder)((com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder)((com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder)(new com.samsung.context.sdk.samsunganalytics.LogBuilders.CustomBuilder()).set("pn", thread.getName())).set("ecn", throwable.getClass().getSimpleName())).set("exd", s)).set("t", "ex")).set("ext", "cr")).build(), false);
                        com.samsung.context.sdk.samsunganalytics.a.b.e(a).uncaughtException(thread, throwable);
                        return;
                    } else
                    {
                        com.samsung.context.sdk.samsunganalytics.a.b.e(a).uncaughtException(thread, throwable);
                        return;
                    }
                }

            
            {
                a = b.this;
                super();
            }
            };
            Thread.setDefaultUncaughtExceptionHandler(f);
        }
    }

    public void a(Map map)
    {
        com.samsung.context.sdk.samsunganalytics.a.d.d.a().a(new com.samsung.context.sdk.samsunganalytics.a.h.b(com.samsung.context.sdk.samsunganalytics.a.i.c.a(e), map));
        if (com.samsung.context.sdk.samsunganalytics.a.h.a.c() && k.isAlwaysRunningApp() && (k.isEnableUseInAppLogging() || com.samsung.context.sdk.samsunganalytics.a.e.e.a()))
        {
            h();
        }
    }

    public void b()
    {
        h = false;
    }

    public void c()
    {
        e.registerActivityLifecycleCallbacks(j());
    }

    public void d()
    {
        if (j != null)
        {
            e.unregisterActivityLifecycleCallbacks(j);
        }
    }

    public boolean e()
    {
        return h;
    }

    public boolean f()
    {
        return i;
    }

    public Configuration g()
    {
        return k;
    }
}
