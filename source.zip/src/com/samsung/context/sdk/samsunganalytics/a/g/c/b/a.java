// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.c.b;

import com.samsung.context.sdk.samsunganalytics.a.g.d;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class a
{

    private static final int b = 25;
    private static final int c = 100;
    protected LinkedBlockingQueue a;

    public a()
    {
        a = new LinkedBlockingQueue(25);
    }

    public a(int i)
    {
        if (i < 25)
        {
            a = new LinkedBlockingQueue(25);
            return;
        }
        if (i > 100)
        {
            a = new LinkedBlockingQueue(100);
            return;
        } else
        {
            a = new LinkedBlockingQueue(i);
            return;
        }
    }

    public Queue a()
    {
        return a;
    }

    public void a(d d)
    {
        if (!a.offer(d))
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("QueueManager", "queue size over. remove oldest log");
            a.poll();
            a.offer(d);
        }
    }

    public long b()
    {
        return (long)a.size();
    }

    public boolean c()
    {
        return a.isEmpty();
    }
}
