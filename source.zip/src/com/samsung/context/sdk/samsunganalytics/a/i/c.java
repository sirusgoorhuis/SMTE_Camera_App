// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.i;

import android.content.Context;
import android.content.SharedPreferences;

public class c
{

    public static final String a = "SamsungAnalyticsPrefs";
    public static final String b = "SASettingPref";
    public static final String c = "deviceId";
    public static final String d = "auidType";
    public static final String e = "AppPrefs";
    public static final String f = "status_sent_date";

    private c()
    {
    }

    public static SharedPreferences a(Context context)
    {
        return context.getSharedPreferences("SamsungAnalyticsPrefs", 0);
    }
}
