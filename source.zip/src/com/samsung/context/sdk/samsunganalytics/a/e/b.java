// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;


public class b
{

    public static final String a = "rint";
    public static final String b = "dq-w";
    public static final String c = "dq-3g";
    public static final String d = "wifi_used";
    public static final String e = "data_used";
    public static final String f = "oq-w";
    public static final String g = "oq-3g";
    public static final String h = "dom";
    public static final String i = "uri";
    public static final String j = "bat-uri";
    public static final String k = "lgt";
    public static final String l = "rel";
    public static final String m = "rtb";
    public static final String n = "policy_received_date";
    public static final String o = "quota_reset_date";
    public static final int p = 3000;
    public static final int q = 51200;
    public static final int r = 5;

    private b()
    {
    }
}
