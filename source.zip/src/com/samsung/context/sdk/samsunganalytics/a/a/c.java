// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.a;


public final class c extends Enum
{

    public static final c a;
    public static final c b;
    private static final c d[];
    String c;

    private c(String s, int i, String s1)
    {
        super(s, i);
        c = s1;
    }

    public static c valueOf(String s)
    {
        return (c)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/a/c, s);
    }

    public static c[] values()
    {
        return (c[])d.clone();
    }

    public String a()
    {
        return c;
    }

    public void a(String s)
    {
        c = s;
    }

    static 
    {
        a = new c("POLICY", 0, "https://dc.di.atlas.samsung.com");
        b = new c("DLS", 1, "");
        d = (new c[] {
            a, b
        });
    }
}
