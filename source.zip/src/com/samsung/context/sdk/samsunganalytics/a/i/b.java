// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.i;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class b
{
    public static final class a extends Enum
    {

        public static final a a;
        public static final a b;
        public static final a c;
        private static final a f[];
        private String d;
        private String e;

        public static a valueOf(String s)
        {
            return (a)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/i/b$a, s);
        }

        public static a[] values()
        {
            return (a[])f.clone();
        }

        public String a()
        {
            return d;
        }

        public String b()
        {
            return e;
        }

        static 
        {
            a = new a("ONE_DEPTH", 0, "\002", "\003");
            b = new a("TWO_DEPTH", 1, "\004", "\005");
            c = new a("THREE_DEPTH", 2, "\006", "\007");
            f = (new a[] {
                a, b, c
            });
        }

        private a(String s, int i, String s1, String s2)
        {
            super(s, i);
            d = s1;
            e = s2;
        }
    }


    public static final String a = "\016";

    public b()
    {
    }

    public String a(Map map, a a1)
    {
        Iterator iterator = map.entrySet().iterator();
        map = null;
        while (iterator.hasNext()) 
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            if (map == null)
            {
                map = entry.getKey().toString();
            } else
            {
                map = (new StringBuilder()).append(map).append(a1.a()).toString();
                map = (new StringBuilder()).append(map).append(entry.getKey()).toString();
            }
            map = (new StringBuilder()).append(map).append(a1.b()).toString();
            map = (new StringBuilder()).append(map).append(entry.getValue()).toString();
        }
        return map;
    }
}
