// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.f;

import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class com.samsung.context.sdk.samsunganalytics.a.f.a
{
    private static class a
    {

        private static final com.samsung.context.sdk.samsunganalytics.a.f.a a = new com.samsung.context.sdk.samsunganalytics.a.f.a();

        static com.samsung.context.sdk.samsunganalytics.a.f.a a()
        {
            return a;
        }


        private a()
        {
        }
    }


    private static final String b = "AndroidCAStore";
    private static final String c = "TLS";
    private SSLContext a;

    private com.samsung.context.sdk.samsunganalytics.a.f.a()
    {
        c();
    }


    public static com.samsung.context.sdk.samsunganalytics.a.f.a a()
    {
        return a.a();
    }

    private void c()
    {
        Object obj;
        try
        {
            obj = KeyStore.getInstance(KeyStore.getDefaultType());
            ((KeyStore) (obj)).load(null, null);
            KeyStore keystore = KeyStore.getInstance("AndroidCAStore");
            keystore.load(null, null);
            Enumeration enumeration = keystore.aliases();
            do
            {
                if (!enumeration.hasMoreElements())
                {
                    break;
                }
                String s = (String)enumeration.nextElement();
                X509Certificate x509certificate = (X509Certificate)keystore.getCertificate(s);
                if (s.startsWith("system:"))
                {
                    ((KeyStore) (obj)).setCertificateEntry(s, x509certificate);
                }
            } while (true);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("pinning fail : ").append(((Exception) (obj)).getMessage()).toString());
            return;
        }
        TrustManagerFactory trustmanagerfactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustmanagerfactory.init(((KeyStore) (obj)));
        a = SSLContext.getInstance("TLS");
        a.init(null, trustmanagerfactory.getTrustManagers(), null);
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("pinning success");
        return;
    }

    public SSLContext b()
    {
        return a;
    }
}
