// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a;

import android.app.Application;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.g.c.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a:
//            a, b

class a
    implements com.samsung.context.sdk.samsunganalytics.a.a
{

    final b a;

    public volatile Object a(Object obj)
    {
        return a((Boolean)obj);
    }

    public Void a(Boolean boolean1)
    {
        if (boolean1.booleanValue())
        {
            com.samsung.context.sdk.samsunganalytics.a.g.c.a.a(b.b(a).getApplicationContext(), Boolean.valueOf(true), b.c(a).getQueueSize()).a(b.b(a).getApplicationContext());
        }
        return null;
    }

    a(b b1)
    {
        a = b1;
        super();
    }
}
