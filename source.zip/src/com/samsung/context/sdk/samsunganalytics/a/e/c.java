// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.e;

import android.content.SharedPreferences;
import android.net.Uri;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.a.a;
import com.samsung.context.sdk.samsunganalytics.a.d.b;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.e:
//            e

public class c
    implements b
{

    private String a;
    private Map b;
    private a c;
    private HttpsURLConnection d;
    private SharedPreferences e;
    private com.samsung.context.sdk.samsunganalytics.a.a f;

    public c(a a1, String s, Map map, SharedPreferences sharedpreferences, com.samsung.context.sdk.samsunganalytics.a.a a2)
    {
        d = null;
        a = s;
        c = a1;
        b = map;
        e = sharedpreferences;
        f = a2;
    }

    private void a(BufferedReader bufferedreader)
    {
        if (bufferedreader == null)
        {
            break MISSING_BLOCK_LABEL_8;
        }
        bufferedreader.close();
        if (d != null)
        {
            d.disconnect();
        }
        return;
        bufferedreader;
    }

    public void a()
    {
        Object obj;
        try
        {
            obj = Uri.parse(c.a()).buildUpon();
            String s1;
            for (Iterator iterator = b.keySet().iterator(); iterator.hasNext(); ((android.net.Uri.Builder) (obj)).appendQueryParameter(s1, (String)b.get(s1)))
            {
                s1 = (String)iterator.next();
            }

        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.e("Fail to get Policy");
            return;
        }
        String s = SimpleDateFormat.getTimeInstance(2, Locale.US).format(new Date());
        ((android.net.Uri.Builder) (obj)).appendQueryParameter("ts", s).appendQueryParameter("tid", a).appendQueryParameter("hc", com.samsung.context.sdk.samsunganalytics.a.e.e.a((new StringBuilder()).append(a).append(s).append(e.c).toString()));
        d = (HttpsURLConnection)(new URL(((android.net.Uri.Builder) (obj)).build().toString())).openConnection();
        d.setSSLSocketFactory(com.samsung.context.sdk.samsunganalytics.a.f.a.a().b().getSocketFactory());
        d.setRequestMethod(c.b());
        d.setConnectTimeout(3000);
        return;
    }

    public void a(JSONObject jsonobject)
    {
        try
        {
            e.edit().putInt("oq-3g", jsonobject.getInt("oq-3g") * 1024).putInt("dq-3g", jsonobject.getInt("dq-3g") * 1024).putInt("oq-w", jsonobject.getInt("oq-w") * 1024).putInt("dq-w", jsonobject.getInt("dq-w") * 1024).putString("dom", (new StringBuilder()).append("https://").append(jsonobject.getString("dom")).toString()).putString("uri", jsonobject.getString("uri")).putString("bat-uri", jsonobject.getString("bat-uri")).putString("lgt", jsonobject.getString("lgt")).putInt("rint", jsonobject.getInt("rint")).putLong("policy_received_date", System.currentTimeMillis()).apply();
            com.samsung.context.sdk.samsunganalytics.a.a.c.b.a((new StringBuilder()).append("https://").append(jsonobject.getString("dom")).toString());
            com.samsung.context.sdk.samsunganalytics.a.a.b.b.a(jsonobject.getString("uri"));
            com.samsung.context.sdk.samsunganalytics.a.a.b.c.a(jsonobject.getString("bat-uri"));
            com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("dq-3g: ").append(jsonobject.getInt("dq-3g") * 1024).append(", dq-w: ").append(jsonobject.getInt("dq-w") * 1024).append(", oq-3g: ").append(jsonobject.getInt("oq-3g") * 1024).append(", oq-w: ").append(jsonobject.getInt("oq-w") * 1024).toString());
            return;
        }
        // Misplaced declaration of an exception variable
        catch (JSONObject jsonobject)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.e("Fail to get Policy");
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("[GetPolicyClient] ").append(jsonobject.getMessage()).toString());
    }

    public int b()
    {
        Object obj;
        byte byte0;
        byte0 = 0;
        obj = null;
        if (d.getResponseCode() == 200)
        {
            break MISSING_BLOCK_LABEL_51;
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.e((new StringBuilder()).append("Fail to get Policy. Response code : ").append(d.getResponseCode()).toString());
        byte0 = -61;
        Object obj1 = new BufferedReader(new InputStreamReader(d.getInputStream()));
        int i;
        obj = new JSONObject(((BufferedReader) (obj1)).readLine());
        i = ((JSONObject) (obj)).getInt("rc");
        if (i == 1000) goto _L2; else goto _L1
_L1:
        com.samsung.context.sdk.samsunganalytics.a.i.a.e((new StringBuilder()).append("Fail to get Policy; Invalid Message. Result code : ").append(i).toString());
        byte0 = -61;
_L4:
        if (d != null)
        {
            d.disconnect();
        }
        a(((BufferedReader) (obj1)));
        return byte0;
_L2:
        String s;
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("GetPolicyClient", "Get Policy Success");
        if (!TextUtils.isEmpty(e.getString("lgt", "")) || f == null)
        {
            break MISSING_BLOCK_LABEL_223;
        }
        s = ((JSONObject) (obj)).getString("lgt");
        if (s == null)
        {
            break MISSING_BLOCK_LABEL_223;
        }
        if (s.equals("rtb"))
        {
            f.(Boolean.valueOf(true));
        }
        a(((JSONObject) (obj)));
        if (true) goto _L4; else goto _L3
_L3:
        obj1;
_L8:
        com.samsung.context.sdk.samsunganalytics.a.i.a.e("Fail to get Policy");
        a(((BufferedReader) (obj)));
        return -61;
        obj;
        obj1 = null;
_L6:
        a(((BufferedReader) (obj1)));
        throw obj;
        obj;
        continue; /* Loop/switch isn't completed */
        Exception exception1;
        exception1;
        obj1 = obj;
        obj = exception1;
        if (true) goto _L6; else goto _L5
_L5:
        Exception exception;
        exception;
        exception = ((Exception) (obj1));
        if (true) goto _L8; else goto _L7
_L7:
    }
}
