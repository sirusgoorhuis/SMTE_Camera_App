// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.c;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.c:
//            b, d, a

public class c
{
    public static final class a extends Enum
    {

        public static final a a;
        public static final a b;
        private static final a c[];

        public static a valueOf(String s)
        {
            return (a)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/c/c$a, s);
        }

        public static a[] values()
        {
            return (a[])c.clone();
        }

        static 
        {
            a = new a("FULL", 0);
            b = new a("SIMPLE", 1);
            c = (new a[] {
                a, b
            });
        }

        private a(String s, int i)
        {
            super(s, i);
        }
    }


    private c()
    {
    }

    public static com.samsung.context.sdk.samsunganalytics.a.c.a a(a a1)
    {
        if (a1 == a.a)
        {
            return new b();
        }
        if (a1 == a.b)
        {
            return new d();
        } else
        {
            return new d();
        }
    }
}
