// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g;

import android.content.Context;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.Configuration;
import com.samsung.context.sdk.samsunganalytics.a.d.c;
import com.samsung.context.sdk.samsunganalytics.a.d.d;
import com.samsung.context.sdk.samsunganalytics.a.i.b;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g:
//            b

public abstract class a
    implements com.samsung.context.sdk.samsunganalytics.a.g.b
{

    protected Context a;
    protected Configuration b;
    protected com.samsung.context.sdk.samsunganalytics.a.b.a c;
    protected b d;
    protected com.samsung.context.sdk.samsunganalytics.a.g.c.a e;
    protected c f;

    public a(Context context, Configuration configuration)
    {
        a = context.getApplicationContext();
        b = configuration;
        f = com.samsung.context.sdk.samsunganalytics.a.d.d.a();
        c = new com.samsung.context.sdk.samsunganalytics.a.b.a(context);
        d = new b();
        e = com.samsung.context.sdk.samsunganalytics.a.g.c.a.a(context, configuration);
    }

    protected Map a(Map map)
    {
        map.put("v", "1.11.040");
        map.put("tid", b.getTrackingId());
        map.put("la", c.d());
        if (!TextUtils.isEmpty(c.a()))
        {
            map.put("mcc", c.a());
        }
        if (!TextUtils.isEmpty(c.b()))
        {
            map.put("mnc", c.b());
        }
        map.put("dm", c.g());
        map.put("auid", b.getDeviceId());
        if (b.isUseAnonymizeIp())
        {
            map.put("aip", "1");
            String s = b.getOverrideIp();
            if (s != null)
            {
                map.put("oip", s);
            }
        }
        if (!TextUtils.isEmpty(b.getUserId()))
        {
            map.put("uid", b.getUserId());
        }
        map.put("do", c.e());
        map.put("av", c.h());
        map.put("uv", b.getVersion());
        map.put("tz", c.i());
        map.put("at", String.valueOf(b.getAuidType()));
        map.put("fv", c.j());
        return map;
    }

    protected String b(Map map)
    {
        return d.a(map, com.samsung.context.sdk.samsunganalytics.a.i.b.a.a);
    }

    protected void c(Map map)
    {
        e.a(Long.valueOf((String)map.get("ts")).longValue(), (String)map.get("t"), b(a(map)));
    }
}
