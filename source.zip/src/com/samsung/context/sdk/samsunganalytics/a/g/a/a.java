// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.sec.spp.push.dlc.api.IDlcService;

public class a
{

    private static final String a = "com.sec.spp.push.REQUEST_REGISTER";
    private static final String b = "com.sec.spp.push.REQUEST_DEREGISTER";
    private static String c = "com.sec.spp.push";
    private static String d = "com.sec.spp.push.dlc.writer.WriterService";
    private static final String e = "EXTRA_PACKAGENAME";
    private static final String f = "EXTRA_INTENTFILTER";
    private static final String g = "EXTRA_STR";
    private static final String h = "EXTRA_RESULT_CODE";
    private static final String i = "EXTRA_STR_ACTION";
    private static final int j = 100;
    private static final int k = 200;
    private static final int l = -2;
    private static final int m = -3;
    private static final int n = -4;
    private static final int o = -5;
    private static final int p = -6;
    private static final int q = -7;
    private static final int r = -8;
    private Context s;
    private BroadcastReceiver t;
    private String u;
    private com.samsung.context.sdk.samsunganalytics.a.a v;
    private boolean w;
    private boolean x;
    private IDlcService y;
    private ServiceConnection z = new ServiceConnection() {

        final a a;

        public void onServiceConnected(ComponentName componentname, IBinder ibinder)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "DLC Client ServiceConnected");
            a.a(a, com.sec.spp.push.dlc.api.IDlcService.a.a(ibinder));
            if (a.a(a) != null)
            {
                a.b(a).unregisterReceiver(a.a(a));
                a.a(a, null);
            }
            if (a.c(a) != null)
            {
                a.c(a).a(null);
            }
        }

        public void onServiceDisconnected(ComponentName componentname)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "Client ServiceDisconnected");
            a.a(a, null);
            a.a(a, false);
        }

            
            {
                a = a.this;
                super();
            }
    };

    public a(Context context)
    {
        w = false;
        x = false;
        s = context;
        u = context.getPackageName();
        u = (new StringBuilder()).append(u).append(".REGISTER_FILTER").toString();
    }

    public a(Context context, com.samsung.context.sdk.samsunganalytics.a.a a1)
    {
        this(context);
        v = a1;
    }

    static BroadcastReceiver a(a a1)
    {
        return a1.t;
    }

    static BroadcastReceiver a(a a1, BroadcastReceiver broadcastreceiver)
    {
        a1.t = broadcastreceiver;
        return broadcastreceiver;
    }

    static IDlcService a(a a1, IDlcService idlcservice)
    {
        a1.y = idlcservice;
        return idlcservice;
    }

    static void a(a a1, String s1)
    {
        a1.a(s1);
    }

    private void a(String s1)
    {
        if (w)
        {
            e();
        }
        try
        {
            s1 = new Intent(s1);
            s1.setClassName(c, d);
            w = s.bindService(s1, z, 1);
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLCBinder", "bind");
            return;
        }
        // Misplaced declaration of an exception variable
        catch (String s1)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), s1);
        }
    }

    static boolean a(a a1, boolean flag)
    {
        a1.w = flag;
        return flag;
    }

    static Context b(a a1)
    {
        return a1.s;
    }

    static boolean b(a a1, boolean flag)
    {
        a1.x = flag;
        return flag;
    }

    static com.samsung.context.sdk.samsunganalytics.a.a c(a a1)
    {
        return a1.v;
    }

    static String d(a a1)
    {
        return a1.u;
    }

    private void e()
    {
        if (!w)
        {
            break MISSING_BLOCK_LABEL_30;
        }
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLCBinder", "unbind");
        s.unbindService(z);
        w = false;
        return;
        Exception exception;
        exception;
        com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), exception);
        return;
    }

    public void a()
    {
        IntentFilter intentfilter = new IntentFilter();
        intentfilter.addAction(u);
        if (t == null)
        {
            t = new BroadcastReceiver() {

                final a a;

                public void onReceive(Context context, Intent intent)
                {
                    a.b(a, false);
                    if (intent == null)
                    {
                        com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "dlc register reply fail");
                    } else
                    {
                        context = intent.getAction();
                        intent = intent.getExtras();
                        if (context == null || intent == null)
                        {
                            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", "dlc register reply fail");
                            return;
                        }
                        if (context.equals(a.d(a)))
                        {
                            context = intent.getString("EXTRA_STR");
                            int i1 = intent.getInt("EXTRA_RESULT_CODE");
                            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("register DLC result:").append(context).toString());
                            if (i1 < 0)
                            {
                                com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLC Sender", (new StringBuilder()).append("register DLC result fail:").append(context).toString());
                                return;
                            } else
                            {
                                context = intent.getString("EXTRA_STR_ACTION");
                                a.a(a, context);
                                return;
                            }
                        }
                    }
                }

            
            {
                a = a.this;
                super();
            }
            };
        }
        s.registerReceiver(t, intentfilter);
    }

    public void b()
    {
        if (t == null)
        {
            a();
        }
        if (!x)
        {
            Intent intent = new Intent("com.sec.spp.push.REQUEST_REGISTER");
            intent.putExtra("EXTRA_PACKAGENAME", s.getPackageName());
            intent.putExtra("EXTRA_INTENTFILTER", u);
            intent.setPackage("com.sec.spp.push");
            s.sendBroadcast(intent);
            x = true;
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLCBinder", "send register Request");
            com.samsung.context.sdk.samsunganalytics.a.i.a.a((new StringBuilder()).append("send register Request:").append(s.getPackageName()).toString());
            return;
        } else
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a("DLCBinder", "already send register request");
            return;
        }
    }

    public boolean c()
    {
        return w;
    }

    public IDlcService d()
    {
        return y;
    }

}
