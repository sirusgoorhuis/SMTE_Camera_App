// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a;

import android.app.Application;
import android.content.SharedPreferences;
import com.samsung.context.sdk.samsunganalytics.a.d.b;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a:
//            b

class a
    implements b
{

    final Map a;
    final com.samsung.context.sdk.samsunganalytics.a.b b;

    public void a()
    {
        SharedPreferences sharedpreferences = com.samsung.context.sdk.samsunganalytics.a.b.b(b).getSharedPreferences("SASettingPref", 0);
        String s;
        for (Iterator iterator = a.keySet().iterator(); iterator.hasNext(); sharedpreferences.edit().putString(s, (String)a.get(s)).apply())
        {
            s = (String)iterator.next();
        }

    }

    public int b()
    {
        return 0;
    }

    (com.samsung.context.sdk.samsunganalytics.a.b b1, Map map)
    {
        b = b1;
        a = map;
        super();
    }
}
