// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.b;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.telephony.TelephonyManager;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class a
{

    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;

    public a(Context context)
    {
        a = "";
        b = "";
        c = "";
        d = "";
        e = "";
        f = "";
        g = "";
        h = "";
        i = "";
        j = "";
        Locale locale = context.getResources().getConfiguration().locale;
        a = locale.getDisplayCountry();
        Object obj = (TelephonyManager)context.getSystemService("phone");
        if (obj != null)
        {
            obj = ((TelephonyManager) (obj)).getSimOperator();
            if (obj != null && ((String) (obj)).length() >= 3)
            {
                g = ((String) (obj)).substring(0, 3);
                h = ((String) (obj)).substring(3);
            }
        }
        b = locale.getLanguage();
        c = android.os.Build.VERSION.RELEASE;
        d = Build.BRAND;
        e = Build.MODEL;
        j = android.os.Build.VERSION.INCREMENTAL;
        i = String.valueOf(TimeUnit.MILLISECONDS.toMinutes(TimeZone.getDefault().getRawOffset()));
        try
        {
            f = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Context context)
        {
            com.samsung.context.sdk.samsunganalytics.a.i.a.a(getClass(), context);
        }
    }

    public String a()
    {
        return g;
    }

    public String b()
    {
        return h;
    }

    public String c()
    {
        return a;
    }

    public String d()
    {
        return b;
    }

    public String e()
    {
        return c;
    }

    public String f()
    {
        return d;
    }

    public String g()
    {
        return e;
    }

    public String h()
    {
        return f;
    }

    public String i()
    {
        return i;
    }

    public String j()
    {
        return j;
    }
}
