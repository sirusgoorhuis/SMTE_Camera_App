// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.a;


public final class b extends Enum
{

    public static final b a;
    public static final b b;
    public static final b c;
    private static final b e[];
    String d;

    private b(String s, int i, String s1)
    {
        super(s, i);
        d = s1;
    }

    public static b valueOf(String s)
    {
        return (b)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/a/b, s);
    }

    public static b[] values()
    {
        return (b[])e.clone();
    }

    public String a()
    {
        return d;
    }

    public void a(String s)
    {
        d = s;
    }

    static 
    {
        a = new b("DEVICE_CONTROLLER_DIR", 0, "/dc/qtransf");
        b = new b("DLS_DIR", 1, "");
        c = new b("DLS_DIR_BAT", 2, "");
        e = (new b[] {
            a, b, c
        });
    }
}
