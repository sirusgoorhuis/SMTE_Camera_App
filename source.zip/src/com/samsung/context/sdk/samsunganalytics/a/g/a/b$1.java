// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.g.a;

import com.samsung.context.sdk.samsunganalytics.a.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.g.a:
//            b

class a
    implements a
{

    final b a;

    public volatile Object a(Object obj)
    {
        return a((Void)obj);
    }

    public Void a(Void void1)
    {
        com.samsung.context.sdk.samsunganalytics.a.g.a.b.a(a);
        return null;
    }

    (b b1)
    {
        a = b1;
        super();
    }
}
