// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.samsung.context.sdk.samsunganalytics.a.i.a;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a:
//            b

class a extends BroadcastReceiver
{

    final b a;

    public void onReceive(Context context, Intent intent)
    {
        com.samsung.context.sdk.samsunganalytics.a.i.a.a("receive BR");
        com.samsung.context.sdk.samsunganalytics.a.b.a(a);
    }

    (b b1)
    {
        a = b1;
        super();
    }
}
