// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics.a.i;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics.a.i:
//            b

public static final class e extends Enum
{

    public static final c a;
    public static final c b;
    public static final c c;
    private static final c f[];
    private String d;
    private String e;

    public static e valueOf(String s)
    {
        return (e)Enum.valueOf(com/samsung/context/sdk/samsunganalytics/a/i/b$a, s);
    }

    public static e[] values()
    {
        return (e[])f.clone();
    }

    public String a()
    {
        return d;
    }

    public String b()
    {
        return e;
    }

    static 
    {
        a = new <init>("ONE_DEPTH", 0, "\002", "\003");
        b = new <init>("TWO_DEPTH", 1, "\004", "\005");
        c = new <init>("THREE_DEPTH", 2, "\006", "\007");
        f = (new f[] {
            a, b, c
        });
    }

    private (String s, int i, String s1, String s2)
    {
        super(s, i);
        d = s1;
        e = s2;
    }
}
