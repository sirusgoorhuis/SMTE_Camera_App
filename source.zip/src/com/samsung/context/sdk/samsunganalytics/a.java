// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;


public final class a
{

    public static final boolean a = false;
    public static final String b = "com.samsung.context.sdk.samsunganalytics";
    public static final String c = "release";
    public static final String d = "";
    public static final int e = 0x1b1c0;
    public static final String f = "1.11.040";

    public a()
    {
    }
}
