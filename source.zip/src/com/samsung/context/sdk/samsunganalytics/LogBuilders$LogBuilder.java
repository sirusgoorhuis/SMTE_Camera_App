// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.app.Activity;
import android.app.Fragment;
import android.content.ComponentName;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.samsung.context.sdk.samsunganalytics.a.i.b;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

protected static abstract class <init>
{

    protected Map logs;

    public Map build()
    {
        set("ts", String.valueOf(getTimeStamp()));
        return logs;
    }

    protected abstract logs getThis();

    public long getTimeStamp()
    {
        return System.currentTimeMillis();
    }

    public final logs set(String s, String s1)
    {
        if (s != null)
        {
            logs.put(s, s1);
        }
        return getThis();
    }

    public getThis setDimension(Map map)
    {
        set("cd", (new b()).a(map, com.samsung.context.sdk.samsunganalytics.a.i.his));
        return getThis();
    }

    public getThis setMetrics(Map map)
    {
        set("cm", (new b()).a(map, com.samsung.context.sdk.samsunganalytics.a.i.his));
        return getThis();
    }

    public getThis setReferral(String s)
    {
        set("ch", "rf");
        set("so", s);
        return getThis();
    }

    public getThis setScreenView(Activity activity)
    {
        try
        {
            setScreenView(activity.getComponentName().getShortClassName());
        }
        // Misplaced declaration of an exception variable
        catch (Activity activity)
        {
            a.a(getClass(), activity);
        }
        return getThis();
    }

    public getThis setScreenView(Fragment fragment)
    {
        try
        {
            setScreenView(fragment.getActivity().getLocalClassName());
            setScreenViewDetail(fragment.getClass().getSimpleName());
        }
        // Misplaced declaration of an exception variable
        catch (Fragment fragment)
        {
            a.a(getClass(), fragment);
        }
        return getThis();
    }

    public getThis setScreenView(String s)
    {
        set("pn", s);
        return getThis();
    }

    public getThis setScreenViewDetail(String s)
    {
        set("pnd", s);
        return getThis();
    }

    public final getThis setSessionEnd()
    {
        set("sc", "e");
        return getThis();
    }

    public final getThis setSessionStart()
    {
        set("sc", "s");
        return getThis();
    }

    public final getThis setSessionUpdate()
    {
        set("sc", "u");
        return getThis();
    }

    private ()
    {
        logs = new HashMap();
    }

    logs(logs logs1)
    {
        this();
    }
}
