// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;


// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            UserAgreement

public class Configuration
{

    private int auidType;
    private String deviceId;
    private boolean enableAutoDeviceId;
    private boolean enableFastReady;
    private boolean enableUseInAppLogging;
    private boolean isAlwaysRunningApp;
    private int networkTimeoutInMilliSeconds;
    private String overrideIp;
    private int queueSize;
    private int restrictedNetworkType;
    private String trackingId;
    private boolean useAnonymizeIp;
    private UserAgreement userAgreement;
    private String userId;
    private String version;

    public Configuration()
    {
        enableAutoDeviceId = false;
        enableUseInAppLogging = false;
        useAnonymizeIp = false;
        isAlwaysRunningApp = false;
        enableFastReady = false;
        auidType = -1;
        restrictedNetworkType = -1;
        networkTimeoutInMilliSeconds = 0;
        queueSize = 0;
    }

    public Configuration disableAutoDeviceId()
    {
        enableAutoDeviceId = false;
        return this;
    }

    public Configuration enableAutoDeviceId()
    {
        enableAutoDeviceId = true;
        return this;
    }

    public Configuration enableFastReady(boolean flag)
    {
        enableFastReady = flag;
        return this;
    }

    public Configuration enableUseInAppLogging(UserAgreement useragreement)
    {
        setUserAgreement(useragreement);
        enableUseInAppLogging = true;
        return this;
    }

    public int getAuidType()
    {
        return auidType;
    }

    public String getDeviceId()
    {
        return deviceId;
    }

    public int getNetworkTimeoutInMilliSeconds()
    {
        return networkTimeoutInMilliSeconds;
    }

    public String getOverrideIp()
    {
        return overrideIp;
    }

    public int getQueueSize()
    {
        return queueSize;
    }

    public int getRestrictedNetworkType()
    {
        return restrictedNetworkType;
    }

    public String getTrackingId()
    {
        return trackingId;
    }

    public UserAgreement getUserAgreement()
    {
        return userAgreement;
    }

    public String getUserId()
    {
        return userId;
    }

    public String getVersion()
    {
        return version;
    }

    public boolean isAlwaysRunningApp()
    {
        return isAlwaysRunningApp;
    }

    public boolean isEnableAutoDeviceId()
    {
        return enableAutoDeviceId;
    }

    public boolean isEnableFastReady()
    {
        return enableFastReady;
    }

    public boolean isEnableUseInAppLogging()
    {
        return enableUseInAppLogging;
    }

    public boolean isUseAnonymizeIp()
    {
        return useAnonymizeIp;
    }

    public Configuration setAlwaysRunningApp(boolean flag)
    {
        isAlwaysRunningApp = flag;
        return this;
    }

    public void setAuidType(int i)
    {
        auidType = i;
    }

    public Configuration setDeviceId(String s)
    {
        deviceId = s;
        return this;
    }

    public Configuration setNetworkTimeoutInMilliSeconds(int i)
    {
        networkTimeoutInMilliSeconds = i;
        return this;
    }

    public Configuration setOverrideIp(String s)
    {
        overrideIp = s;
        return this;
    }

    public Configuration setQueueSize(int i)
    {
        queueSize = i;
        return this;
    }

    protected void setRestrictedNetworkType(int i)
    {
        restrictedNetworkType = i;
    }

    public Configuration setTrackingId(String s)
    {
        trackingId = s;
        return this;
    }

    public Configuration setUseAnonymizeIp(boolean flag)
    {
        useAnonymizeIp = flag;
        return this;
    }

    public Configuration setUserAgreement(UserAgreement useragreement)
    {
        userAgreement = useragreement;
        return this;
    }

    public Configuration setUserId(String s)
    {
        userId = s;
        return this;
    }

    public Configuration setVersion(String s)
    {
        version = s;
        return this;
    }
}
