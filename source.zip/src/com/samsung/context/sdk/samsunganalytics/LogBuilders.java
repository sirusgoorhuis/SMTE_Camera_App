// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.app.Activity;
import android.app.Fragment;
import android.content.ComponentName;
import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.samsung.context.sdk.samsunganalytics.a.i.b;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class LogBuilders
{
    public static class CustomBuilder extends LogBuilder
    {

        public volatile Map build()
        {
            return super.build();
        }

        protected CustomBuilder getThis()
        {
            return this;
        }

        protected volatile LogBuilder getThis()
        {
            return getThis();
        }

        public volatile long getTimeStamp()
        {
            return super.getTimeStamp();
        }

        public CustomBuilder()
        {
        }
    }

    public static class EventBuilder extends LogBuilder
    {

        public Map build()
        {
            if (!logs.containsKey("en"))
            {
                d.a("Failure to build Log : Event name cannot be null");
            }
            set("t", "ev");
            return super.build();
        }

        protected EventBuilder getThis()
        {
            return this;
        }

        protected volatile LogBuilder getThis()
        {
            return getThis();
        }

        public volatile long getTimeStamp()
        {
            return super.getTimeStamp();
        }

        public EventBuilder setEventDetail(String s)
        {
            if (TextUtils.isEmpty(s))
            {
                d.a("Failure to build Log : Event detail cannot be null");
            }
            set("ed", s);
            return this;
        }

        public EventBuilder setEventName(String s)
        {
            if (TextUtils.isEmpty(s))
            {
                d.a("Failure to build Log : Event name cannot be null");
            }
            set("en", s);
            return this;
        }

        public EventBuilder setEventValue(long l)
        {
            set("ev", String.valueOf(l));
            return this;
        }

        public EventBuilder()
        {
        }
    }

    public static class ExceptionBuilder extends LogBuilder
    {

        public Map build()
        {
            set("t", "ex");
            set("ext", "ex");
            return super.build();
        }

        protected ExceptionBuilder getThis()
        {
            return this;
        }

        protected volatile LogBuilder getThis()
        {
            return getThis();
        }

        public volatile long getTimeStamp()
        {
            return super.getTimeStamp();
        }

        public ExceptionBuilder isCrash(boolean flag)
        {
            return this;
        }

        public ExceptionBuilder setClassName(String s)
        {
            if (!TextUtils.isEmpty(s))
            {
                set("ecn", s);
            }
            return this;
        }

        public ExceptionBuilder setDescription(String s)
        {
            return this;
        }

        public ExceptionBuilder setMessage(String s)
        {
            if (!TextUtils.isEmpty(s))
            {
                if (s.length() >= 100)
                {
                    s = s.substring(0, 100);
                }
                set("exm", s);
            }
            return this;
        }

        public ExceptionBuilder()
        {
        }
    }

    protected static abstract class LogBuilder
    {

        protected Map logs;

        public Map build()
        {
            set("ts", String.valueOf(getTimeStamp()));
            return logs;
        }

        protected abstract LogBuilder getThis();

        public long getTimeStamp()
        {
            return System.currentTimeMillis();
        }

        public final LogBuilder set(String s, String s1)
        {
            if (s != null)
            {
                logs.put(s, s1);
            }
            return getThis();
        }

        public LogBuilder setDimension(Map map)
        {
            set("cd", (new b()).a(map, com.samsung.context.sdk.samsunganalytics.a.i.b.a.b));
            return getThis();
        }

        public LogBuilder setMetrics(Map map)
        {
            set("cm", (new b()).a(map, com.samsung.context.sdk.samsunganalytics.a.i.b.a.b));
            return getThis();
        }

        public LogBuilder setReferral(String s)
        {
            set("ch", "rf");
            set("so", s);
            return getThis();
        }

        public LogBuilder setScreenView(Activity activity)
        {
            try
            {
                setScreenView(activity.getComponentName().getShortClassName());
            }
            // Misplaced declaration of an exception variable
            catch (Activity activity)
            {
                a.a(getClass(), activity);
            }
            return getThis();
        }

        public LogBuilder setScreenView(Fragment fragment)
        {
            try
            {
                setScreenView(fragment.getActivity().getLocalClassName());
                setScreenViewDetail(fragment.getClass().getSimpleName());
            }
            // Misplaced declaration of an exception variable
            catch (Fragment fragment)
            {
                a.a(getClass(), fragment);
            }
            return getThis();
        }

        public LogBuilder setScreenView(String s)
        {
            set("pn", s);
            return getThis();
        }

        public LogBuilder setScreenViewDetail(String s)
        {
            set("pnd", s);
            return getThis();
        }

        public final LogBuilder setSessionEnd()
        {
            set("sc", "e");
            return getThis();
        }

        public final LogBuilder setSessionStart()
        {
            set("sc", "s");
            return getThis();
        }

        public final LogBuilder setSessionUpdate()
        {
            set("sc", "u");
            return getThis();
        }

        private LogBuilder()
        {
            logs = new HashMap();
        }

    }

    public static class ScreenViewBuilder extends LogBuilder
    {

        public Map build()
        {
            if (TextUtils.isEmpty((CharSequence)logs.get("pn")))
            {
                d.a("Failure to build Log : Screen name cannot be null");
            } else
            {
                set("t", "pv");
            }
            return super.build();
        }

        protected volatile LogBuilder getThis()
        {
            return getThis();
        }

        protected ScreenViewBuilder getThis()
        {
            return this;
        }

        public volatile long getTimeStamp()
        {
            return super.getTimeStamp();
        }

        public ScreenViewBuilder setScreenValue(int i)
        {
            set("pv", String.valueOf(i));
            return this;
        }

        public ScreenViewBuilder setScreenViewDepth(int i)
        {
            set("pd", String.valueOf(i));
            return this;
        }

        public ScreenViewBuilder()
        {
        }
    }

    public static class SettingBuilder
    {

        private Map map;

        public Map build()
        {
            map.put("t", "st");
            return map;
        }

        public final SettingBuilder set(String s, float f)
        {
            return set(s, Float.toString(f));
        }

        public final SettingBuilder set(String s, int i)
        {
            return set(s, Integer.toString(i));
        }

        public final SettingBuilder set(String s, String s1)
        {
            if (s != null)
            {
                if (s.equalsIgnoreCase("t"))
                {
                    d.a("Failure to build logs [setting] : 't' is reserved word, choose another word.");
                    return this;
                } else
                {
                    map.put(s, s1);
                    return this;
                }
            } else
            {
                d.a("Failure to build logs [setting] : Key cannot be null.");
                return this;
            }
        }

        public final SettingBuilder set(String s, Set set1)
        {
            Object obj = "";
            Iterator iterator = set1.iterator();
            String s1;
            for (set1 = ((Set) (obj)); iterator.hasNext(); set1 = (new StringBuilder()).append(((String) (obj))).append(s1).toString())
            {
                s1 = (String)iterator.next();
                obj = set1;
                if (!TextUtils.isEmpty(set1))
                {
                    obj = (new StringBuilder()).append(set1).append(com.samsung.context.sdk.samsunganalytics.a.i.b.a.c.a()).toString();
                }
            }

            return set(s, ((String) (set1)));
        }

        public final SettingBuilder set(String s, boolean flag)
        {
            return set(s, Boolean.toString(flag));
        }

        public SettingBuilder()
        {
            map = new HashMap();
        }
    }

    public static class SettingPrefBuilder
    {

        private Map map;

        private SettingPrefBuilder addAppPref(String s)
        {
            if (!map.containsKey(s) && !TextUtils.isEmpty(s))
            {
                map.put(s, new HashSet());
            } else
            if (TextUtils.isEmpty(s))
            {
                d.a("Failure to build logs [setting preference] : Preference name cannot be null.");
                return this;
            }
            return this;
        }

        public SettingPrefBuilder addKey(String s, String s1)
        {
            if (TextUtils.isEmpty(s1))
            {
                d.a("Failure to build logs [setting preference] : Setting key cannot be null.");
            }
            addAppPref(s);
            ((Set)map.get(s)).add(s1);
            return this;
        }

        public SettingPrefBuilder addKeys(String s, Set set)
        {
            if (set == null || set.isEmpty())
            {
                d.a("Failure to build logs [setting preference] : Setting keys cannot be null.");
            }
            addAppPref(s);
            s = (Set)map.get(s);
            set = set.iterator();
            do
            {
                if (!set.hasNext())
                {
                    break;
                }
                String s1 = (String)set.next();
                if (!TextUtils.isEmpty(s1))
                {
                    s.add(s1);
                }
            } while (true);
            return this;
        }

        public Map build()
        {
            a.a(map.toString());
            return map;
        }

        public SettingPrefBuilder()
        {
            map = new HashMap();
        }
    }


    private LogBuilders()
    {
    }
}
