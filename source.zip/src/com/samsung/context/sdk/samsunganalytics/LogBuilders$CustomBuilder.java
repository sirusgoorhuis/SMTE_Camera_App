// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class it> extends it>
{

    public volatile Map build()
    {
        return super.ld();
    }

    protected ld getThis()
    {
        return this;
    }

    protected volatile ld getThis()
    {
        return getThis();
    }

    public volatile long getTimeStamp()
    {
        return super.TimeStamp();
    }

    public ()
    {
        super(null);
    }
}
