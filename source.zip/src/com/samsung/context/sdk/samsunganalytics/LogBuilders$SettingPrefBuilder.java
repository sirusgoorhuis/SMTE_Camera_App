// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class map
{

    private Map map;

    private map addAppPref(String s)
    {
        if (!map.containsKey(s) && !TextUtils.isEmpty(s))
        {
            map.put(s, new HashSet());
        } else
        if (TextUtils.isEmpty(s))
        {
            d.a("Failure to build logs [setting preference] : Preference name cannot be null.");
            return this;
        }
        return this;
    }

    public map addKey(String s, String s1)
    {
        if (TextUtils.isEmpty(s1))
        {
            d.a("Failure to build logs [setting preference] : Setting key cannot be null.");
        }
        addAppPref(s);
        ((Set)map.get(s)).add(s1);
        return this;
    }

    public map addKeys(String s, Set set)
    {
        if (set == null || set.isEmpty())
        {
            d.a("Failure to build logs [setting preference] : Setting keys cannot be null.");
        }
        addAppPref(s);
        s = (Set)map.get(s);
        set = set.iterator();
        do
        {
            if (!set.hasNext())
            {
                break;
            }
            String s1 = (String)set.next();
            if (!TextUtils.isEmpty(s1))
            {
                s.add(s1);
            }
        } while (true);
        return this;
    }

    public Map build()
    {
        a.a(map.toString());
        return map;
    }

    public ()
    {
        map = new HashMap();
    }
}
