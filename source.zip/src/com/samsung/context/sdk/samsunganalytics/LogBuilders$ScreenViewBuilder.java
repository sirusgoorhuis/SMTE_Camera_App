// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class  extends 
{

    public Map build()
    {
        if (TextUtils.isEmpty((CharSequence)logs.get("pn")))
        {
            d.a("Failure to build Log : Screen name cannot be null");
        } else
        {
            set("t", "pv");
        }
        return super.set();
    }

    protected volatile set getThis()
    {
        return getThis();
    }

    protected getThis getThis()
    {
        return this;
    }

    public volatile long getTimeStamp()
    {
        return super.Stamp();
    }

    public Stamp setScreenValue(int i)
    {
        set("pv", String.valueOf(i));
        return this;
    }

    public set setScreenViewDepth(int i)
    {
        set("pd", String.valueOf(i));
        return this;
    }

    public ()
    {
        super(null);
    }
}
