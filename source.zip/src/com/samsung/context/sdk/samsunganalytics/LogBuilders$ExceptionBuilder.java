// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.text.TextUtils;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class  extends 
{

    public Map build()
    {
        set("t", "ex");
        set("ext", "ex");
        return super.set();
    }

    protected set getThis()
    {
        return this;
    }

    protected volatile set getThis()
    {
        return getThis();
    }

    public volatile long getTimeStamp()
    {
        return super.eStamp();
    }

    public eStamp isCrash(boolean flag)
    {
        return this;
    }

    public eStamp setClassName(String s)
    {
        if (!TextUtils.isEmpty(s))
        {
            set("ecn", s);
        }
        return this;
    }

    public set setDescription(String s)
    {
        return this;
    }

    public set setMessage(String s)
    {
        if (!TextUtils.isEmpty(s))
        {
            if (s.length() >= 100)
            {
                s = s.substring(0, 100);
            }
            set("exm", s);
        }
        return this;
    }

    public ()
    {
        super(null);
    }
}
