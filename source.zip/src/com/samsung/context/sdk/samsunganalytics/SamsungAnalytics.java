// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.app.Application;
import com.samsung.context.sdk.samsunganalytics.a.b;
import com.samsung.context.sdk.samsunganalytics.a.e.e;
import com.samsung.context.sdk.samsunganalytics.a.i.a;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            Configuration

public class SamsungAnalytics
{

    public static final String SDK_VERSION = "1.11.040";
    private static SamsungAnalytics instance;
    private b tracker;

    private SamsungAnalytics(Application application, Configuration configuration)
    {
        tracker = null;
        if (e.a(application, configuration))
        {
            if (configuration.isEnableUseInAppLogging())
            {
                tracker = new b(application, configuration);
            } else
            if (e.a())
            {
                tracker = new b(application, configuration);
                return;
            }
        }
    }

    public static Configuration getConfiguration()
    {
        if (instance == null || instance.tracker == null)
        {
            return null;
        } else
        {
            return instance.tracker.g();
        }
    }

    public static SamsungAnalytics getInstance()
    {
        if (instance == null)
        {
            d.a("call after setConfiguration() method");
            if (!d.a())
            {
                return getInstanceAndConfig(null, null);
            }
        }
        return instance;
    }

    private static SamsungAnalytics getInstanceAndConfig(Application application, Configuration configuration)
    {
        if (instance != null && instance.tracker != null) goto _L2; else goto _L1
_L1:
        com/samsung/context/sdk/samsunganalytics/SamsungAnalytics;
        JVM INSTR monitorenter ;
        instance = new SamsungAnalytics(application, configuration);
        com/samsung/context/sdk/samsunganalytics/SamsungAnalytics;
        JVM INSTR monitorexit ;
_L2:
        return instance;
        application;
        com/samsung/context/sdk/samsunganalytics/SamsungAnalytics;
        JVM INSTR monitorexit ;
        throw application;
    }

    public static void setConfiguration(Application application, Configuration configuration)
    {
        getInstanceAndConfig(application, configuration);
    }

    public void disableAutoActivityTracking()
    {
        try
        {
            tracker.d();
            return;
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
        }
    }

    public void disableUncaughtExceptionLogging()
    {
        try
        {
            tracker.b();
            return;
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
        }
    }

    public SamsungAnalytics enableAutoActivityTracking()
    {
        try
        {
            tracker.c();
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
            return this;
        }
        return this;
    }

    public SamsungAnalytics enableUncaughtExceptionLogging()
    {
        try
        {
            tracker.a();
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
            return this;
        }
        return this;
    }

    public boolean isEnableAutoActivityTracking()
    {
        boolean flag;
        try
        {
            flag = tracker.f();
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
            return false;
        }
        return flag;
    }

    public boolean isEnableUncaughtExceptionLogging()
    {
        boolean flag;
        try
        {
            flag = tracker.e();
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
            return false;
        }
        return flag;
    }

    public void registerSettingPref(Map map)
    {
        try
        {
            tracker.a(map);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Map map)
        {
            a.a(getClass(), map);
        }
    }

    public void restrictNetworkType(int i)
    {
        try
        {
            tracker.g().setRestrictedNetworkType(i);
            return;
        }
        catch (NullPointerException nullpointerexception)
        {
            a.a(getClass(), nullpointerexception);
        }
    }

    public int sendLog(Map map)
    {
        int i;
        try
        {
            i = tracker.a(map, false);
        }
        // Misplaced declaration of an exception variable
        catch (Map map)
        {
            a.a(getClass(), map);
            return -100;
        }
        return i;
    }

    public int sendLogSync(Map map)
    {
        int i;
        try
        {
            i = tracker.a(map, true);
        }
        // Misplaced declaration of an exception variable
        catch (Map map)
        {
            a.a(getClass(), map);
            return -100;
        }
        return i;
    }
}
