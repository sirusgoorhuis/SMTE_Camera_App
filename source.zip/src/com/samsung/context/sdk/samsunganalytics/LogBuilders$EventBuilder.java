// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.Map;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class nit> extends nit>
{

    public Map build()
    {
        if (!logs.containsKey("en"))
        {
            d.a("Failure to build Log : Event name cannot be null");
        }
        set("t", "ev");
        return super.ild();
    }

    protected ild getThis()
    {
        return this;
    }

    protected volatile ild getThis()
    {
        return getThis();
    }

    public volatile long getTimeStamp()
    {
        return super.tTimeStamp();
    }

    public tTimeStamp setEventDetail(String s)
    {
        if (TextUtils.isEmpty(s))
        {
            d.a("Failure to build Log : Event detail cannot be null");
        }
        set("ed", s);
        return this;
    }

    public set setEventName(String s)
    {
        if (TextUtils.isEmpty(s))
        {
            d.a("Failure to build Log : Event name cannot be null");
        }
        set("en", s);
        return this;
    }

    public set setEventValue(long l)
    {
        set("ev", String.valueOf(l));
        return this;
    }

    public ()
    {
        super(null);
    }
}
