// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.context.sdk.samsunganalytics;

import android.text.TextUtils;
import com.samsung.context.sdk.samsunganalytics.a.i.d;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package com.samsung.context.sdk.samsunganalytics:
//            LogBuilders

public static class map
{

    private Map map;

    public Map build()
    {
        map.put("t", "st");
        return map;
    }

    public final map set(String s, float f)
    {
        return set(s, Float.toString(f));
    }

    public final set set(String s, int i)
    {
        return set(s, Integer.toString(i));
    }

    public final set set(String s, String s1)
    {
        if (s != null)
        {
            if (s.equalsIgnoreCase("t"))
            {
                d.a("Failure to build logs [setting] : 't' is reserved word, choose another word.");
                return this;
            } else
            {
                map.put(s, s1);
                return this;
            }
        } else
        {
            d.a("Failure to build logs [setting] : Key cannot be null.");
            return this;
        }
    }

    public final map set(String s, Set set1)
    {
        Object obj = "";
        Iterator iterator = set1.iterator();
        String s1;
        for (set1 = ((Set) (obj)); iterator.hasNext(); set1 = (new StringBuilder()).append(((String) (obj))).append(s1).toString())
        {
            s1 = (String)iterator.next();
            obj = set1;
            if (!TextUtils.isEmpty(set1))
            {
                obj = (new StringBuilder()).append(set1).append(com.samsung.context.sdk.samsunganalytics.a.i..()).toString();
            }
        }

        return set(s, ((String) (set1)));
    }

    public final set set(String s, boolean flag)
    {
        return set(s, Boolean.toString(flag));
    }

    public I()
    {
        map = new HashMap();
    }
}
