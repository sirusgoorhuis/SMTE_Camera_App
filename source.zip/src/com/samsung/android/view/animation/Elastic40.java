// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;

import android.view.animation.Interpolator;

public class Elastic40
    implements Interpolator
{

    private float amplitude;
    private float period;

    public Elastic40()
    {
        amplitude = 1.0F;
        period = 0.8F;
    }

    private float out(float f, float f1, float f2)
    {
        if (f == 0.0F)
        {
            return 0.0F;
        }
        if (f >= 1.0F)
        {
            return 1.0F;
        }
        float f3 = f2;
        if (f2 == 0.0F)
        {
            f3 = 0.3F;
        }
        if (f1 == 0.0F || f1 < 1.0F)
        {
            f1 = 1.0F;
            f2 = f3 / 4F;
        } else
        {
            double d = (double)f3 / 6.2831853071795862D;
            f2 = (float)(Math.asin(1.0F / f1) * d);
        }
        return (float)((double)f1 * Math.pow(2D, -10F * f) * Math.sin(((double)(f - f2) * 6.2831853071795862D) / (double)f3) + 1.0D);
    }

    public float getAmplitude()
    {
        return amplitude;
    }

    public float getInterpolation(float f)
    {
        return out(f, amplitude, period);
    }

    public float getPeriod()
    {
        return period;
    }
}
