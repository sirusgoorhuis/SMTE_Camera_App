// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;

import android.view.animation.PathInterpolator;

public class Acceleration extends PathInterpolator
{

    public Acceleration()
    {
        super(0.4F, 0.0F, 1.0F, 1.0F);
    }
}
