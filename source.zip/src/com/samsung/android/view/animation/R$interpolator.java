// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;


// Referenced classes of package com.samsung.android.view.animation:
//            R

public static final class 
{

    public static final int acceleration = 0x7f060000;
    public static final int deceleration = 0x7f060001;
    public static final int elastic_10 = 0x7f060002;
    public static final int elastic_20 = 0x7f060003;
    public static final int elastic_30 = 0x7f060004;
    public static final int elastic_40 = 0x7f060005;
    public static final int elastic_5 = 0x7f060006;
    public static final int elastic_50 = 0x7f060007;
    public static final int elastic_60 = 0x7f060008;
    public static final int elastic_70 = 0x7f060009;
    public static final int elastic_80 = 0x7f06000a;
    public static final int elastic_90 = 0x7f06000b;
    public static final int sharp = 0x7f06000c;
    public static final int sine_in_33 = 0x7f06000d;
    public static final int sine_in_50 = 0x7f06000e;
    public static final int sine_in_60 = 0x7f06000f;
    public static final int sine_in_70 = 0x7f060010;
    public static final int sine_in_80 = 0x7f060011;
    public static final int sine_in_90 = 0x7f060012;
    public static final int sine_in_out_33 = 0x7f060013;
    public static final int sine_in_out_50 = 0x7f060014;
    public static final int sine_in_out_60 = 0x7f060015;
    public static final int sine_in_out_70 = 0x7f060016;
    public static final int sine_in_out_80 = 0x7f060017;
    public static final int sine_in_out_90 = 0x7f060018;
    public static final int sine_out_33 = 0x7f060019;
    public static final int sine_out_50 = 0x7f06001a;
    public static final int sine_out_60 = 0x7f06001b;
    public static final int sine_out_70 = 0x7f06001c;
    public static final int sine_out_80 = 0x7f06001d;
    public static final int sine_out_90 = 0x7f06001e;
    public static final int standard = 0x7f06001f;

    public ()
    {
    }
}
