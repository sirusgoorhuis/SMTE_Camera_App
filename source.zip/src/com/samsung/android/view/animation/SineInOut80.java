// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;

import android.view.animation.PathInterpolator;

public class SineInOut80 extends PathInterpolator
{

    public SineInOut80()
    {
        super(0.33F, 0.0F, 0.2F, 1.0F);
    }
}
