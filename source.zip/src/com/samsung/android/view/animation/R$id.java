// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;


// Referenced classes of package com.samsung.android.view.animation:
//            R

public static final class 
{

    public static final int bottom = 0x7f0f0000;
    public static final int checkbox = 0x7f0f0014;
    public static final int text = 0x7f0f002c;
    public static final int title = 0x7f0f004b;
    public static final int top = 0x7f0f0005;

    public ()
    {
    }
}
