// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;

import android.view.animation.PathInterpolator;

public class Deceleration extends PathInterpolator
{

    public Deceleration()
    {
        super(0.0F, 0.0F, 0.2F, 1.0F);
    }
}
