// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.view.animation;

import android.view.animation.PathInterpolator;

public class SineIn70 extends PathInterpolator
{

    public SineIn70()
    {
        super(0.7F, 0.0F, 0.83F, 0.83F);
    }
}
