// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.media.soundshot;


public class SemAudioVisualization
{

    private static final int visualizationBands[][];
    private static final int visualizationRandSeed[] = {
        2, 3, 3, 3, 3, 3, 3, 2, 3, 3, 
        3
    };
    private int prev_amplitude;
    private int prev_visualization[];

    public SemAudioVisualization()
    {
        prev_visualization = new int[11];
        prev_amplitude = 0;
        prev_amplitude = 0;
        int i = 0;
        do
        {
            if (i >= 11)
            {
                return;
            }
            prev_visualization[i] = 0;
            i++;
        } while (true);
    }

    private int clipVisualizatoin(int i)
    {
        int j;
        if (i < 0)
        {
            j = 0;
        } else
        {
            j = i;
            if (i > 20)
            {
                return 20;
            }
        }
        return j;
    }

    public void getAudioAnalysisData(byte abyte0[], int i, int ai[], int ai1[])
    {
        float f;
        float f1;
        int j;
        int k;
        f = 0.0F;
        f1 = 0.0F;
        k = 0;
        j = 0;
_L2:
        if (j >= i)
        {
            return;
        }
        int l = 0;
        do
        {
label0:
            {
                if (l < (abyte0.length - 1) / i)
                {
                    break label0;
                }
                f /= (abyte0.length - 1) / i;
                float f2 = f1 / (float)((abyte0.length - 1) / i);
                f1 = f - 50F;
                f2 -= 50F;
                f = f1;
                if (f1 < 0.0F)
                {
                    f = 0.0F;
                }
                f1 = f2;
                if (f2 < 0.0F)
                {
                    f1 = 0.0F;
                }
                ai1[j] = (int)f;
                ai[j] = (int)f1;
                j++;
            }
            if (true)
            {
                continue;
            }
            short word0 = (short)(abyte0[k + 1] << 8 | abyte0[k] & 0xff);
            k += 2;
            f1 += Math.abs(word0);
            f += Math.abs(word0);
            l += 2;
        } while (true);
        if (true) goto _L2; else goto _L1
_L1:
    }

    public int[] getVisualizationBands(int i)
    {
        int ai[];
        int j;
        j = 1;
        ai = new int[11];
        if (i < 50)
        {
            i = 0;
        } else
        if (i < 100)
        {
            i = 1;
        } else
        if (i < 150)
        {
            i = 2;
        } else
        if (i < 200)
        {
            i = 3;
        } else
        if (i < 300)
        {
            i = 4;
        } else
        if (i < 400)
        {
            i = 5;
        } else
        if (i < 500)
        {
            i = 6;
        } else
        if (i < 600)
        {
            i = 7;
        } else
        if (i < 700)
        {
            i = 8;
        } else
        if (i < 800)
        {
            i = 9;
        } else
        if (i < 1000)
        {
            i = 10;
        } else
        if (i < 1200)
        {
            i = 11;
        } else
        if (i < 1400)
        {
            i = 12;
        } else
        if (i < 1600)
        {
            i = 13;
        } else
        if (i < 1800)
        {
            i = 14;
        } else
        if (i < 2000)
        {
            i = 15;
        } else
        if (i < 2500)
        {
            i = 16;
        } else
        if (i < 3000)
        {
            i = 17;
        } else
        if (i < 3500)
        {
            i = 18;
        } else
        if (i < 4000)
        {
            i = 19;
        } else
        {
            i = 20;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_295;
        }
        prev_amplitude = 0;
        i = 0;
_L3:
        if (i < 11) goto _L2; else goto _L1
_L1:
        return ai;
_L2:
        prev_visualization[i] = 0;
        i++;
          goto _L3
        if (i < prev_amplitude)
        {
            j = -1;
        }
        prev_amplitude = i;
        int k = 0;
        while (k < visualizationRandSeed.length) 
        {
            int l;
            if (j > 0)
            {
                ai[k] = (int)(Math.random() * (double)visualizationRandSeed[k] + (double)visualizationBands[i][k]);
            } else
            {
                ai[k] = (int)(Math.random() * (double)visualizationRandSeed[k] * (double)j + (double)visualizationBands[i][k]);
            }
            if (Math.abs(ai[k] - prev_visualization[k]) > 5)
            {
                if (j > 0)
                {
                    ai[k] = prev_visualization[k] + 5;
                } else
                {
                    ai[k] = prev_visualization[k] - 5;
                }
            }
            l = clipVisualizatoin(ai[k]);
            ai[k] = l;
            prev_visualization[k] = l;
            k++;
        }
          goto _L1
    }

    static 
    {
        int ai[] = new int[11];
        ai[0] = 1;
        ai[1] = 5;
        ai[2] = 4;
        ai[3] = 2;
        ai[4] = 2;
        ai[5] = 1;
        ai[6] = 1;
        ai[7] = 1;
        ai[8] = 2;
        ai[10] = 1;
        int ai1[] = {
            1, 6, 5, 3, 2, 1, 1, 2, 3, 1, 
            1
        };
        int ai2[] = {
            2, 7, 6, 5, 3, 2, 2, 2, 3, 2, 
            1
        };
        int ai3[] = {
            2, 8, 7, 7, 4, 3, 3, 2, 1, 3, 
            1
        };
        int ai4[] = {
            3, 9, 9, 7, 4, 4, 3, 2, 1, 3, 
            2
        };
        int ai5[] = {
            3, 10, 10, 8, 6, 3, 1, 2, 1, 4, 
            1
        };
        int ai6[] = {
            4, 12, 11, 7, 8, 4, 3, 4, 1, 4, 
            1
        };
        int ai7[] = {
            4, 14, 12, 10, 8, 6, 3, 2, 2, 4, 
            1
        };
        int ai8[] = {
            5, 14, 13, 7, 9, 7, 3, 3, 3, 5, 
            2
        };
        int ai9[] = {
            6, 14, 14, 7, 10, 6, 3, 4, 3, 5, 
            2
        };
        int ai10[] = {
            8, 15, 15, 7, 8, 8, 3, 3, 4, 6, 
            3
        };
        int ai11[] = {
            10, 15, 16, 10, 12, 8, 7, 4, 5, 7, 
            4
        };
        int ai12[] = {
            11, 16, 15, 13, 12, 10, 7, 5, 5, 8, 
            5
        };
        int ai13[] = {
            13, 17, 17, 15, 14, 12, 10, 8, 7, 10, 
            7
        };
        int ai14[] = {
            14, 18, 17, 16, 15, 14, 12, 10, 10, 13, 
            10
        };
        int ai15[] = {
            16, 18, 18, 18, 16, 16, 15, 15, 15, 16, 
            16
        };
        int ai16[] = {
            18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 
            18
        };
        int ai17[] = {
            18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 
            18
        };
        visualizationBands = (new int[][] {
            ai, ai1, ai2, ai3, ai4, ai5, new int[] {
                3, 11, 10, 8, 7, 4, 3, 2, 1, 4, 
                1
            }, ai6, new int[] {
                4, 13, 12, 7, 7, 5, 3, 3, 2, 4, 
                1
            }, ai7, 
            ai8, ai9, new int[] {
                7, 15, 15, 7, 10, 7, 3, 2, 4, 5, 
                2
            }, ai10, ai11, ai12, ai13, ai14, ai15, ai16, 
            ai17
        });
    }
}
