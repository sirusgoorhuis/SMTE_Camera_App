// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.media.soundshot;

import android.media.AudioRecord;
import android.util.Log;

public class SemAudioRecorder
{

    private static final int QURAM_RECORDER_BUFFERSIZE = 16384;
    private static final String TAG = "SEFSemAudioRecorder";
    private static SemAudioRecorder qRecorder = new SemAudioRecorder();
    private int QURAM_RECORDER_AUDIO_ENCODING;
    private int QURAM_RECORDER_BPP;
    private int QURAM_RECORDER_CHANNELS;
    private int QURAM_RECORDER_SAMPLERATE;
    private int bufferSize;
    private int mAudioSource;
    private AudioRecord recorder;

    private SemAudioRecorder()
    {
        recorder = null;
        mAudioSource = 1;
        bufferSize = 16384;
        QURAM_RECORDER_BPP = 16;
        QURAM_RECORDER_SAMPLERATE = 44100;
        QURAM_RECORDER_CHANNELS = 16;
        QURAM_RECORDER_AUDIO_ENCODING = 2;
    }

    public static SemAudioRecorder getInstance()
    {
        return qRecorder;
    }

    public int getAudioSampleRate()
    {
        return QURAM_RECORDER_SAMPLERATE;
    }

    public int getBufferSize()
    {
        return bufferSize;
    }

    public int getChannel()
    {
        return QURAM_RECORDER_CHANNELS == 16 ? 1 : 2;
    }

    public int getRecorderBPP()
    {
        return QURAM_RECORDER_BPP;
    }

    public boolean init(int i)
    {
        bufferSize = AudioRecord.getMinBufferSize(QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING);
        if (bufferSize < 16384)
        {
            bufferSize = 16384;
        }
        mAudioSource = i;
        if (recorder != null)
        {
            Log.d("SEFSemAudioRecorder", (new StringBuilder("recorder.getState() = ")).append(recorder.getState()).toString());
            if (recorder.getState() != 0)
            {
                return true;
            }
        }
        Log.i("SEFSemAudioRecorder", "make new Recorder");
        Log.d("SEFSemAudioRecorder", (new StringBuilder("mAudioSource : ")).append(mAudioSource).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_SAMPLERATE : ")).append(QURAM_RECORDER_SAMPLERATE).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_CHANNELS : ")).append(QURAM_RECORDER_CHANNELS).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_AUDIO_ENCODING : ")).append(QURAM_RECORDER_AUDIO_ENCODING).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("bufferSize : ")).append(bufferSize).toString());
        recorder = new AudioRecord(mAudioSource, QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING, bufferSize);
        if (recorder == null)
        {
            Log.d("SEFSemAudioRecorder", "===> recorder null!!!!");
            return false;
        }
        return recorder.getState() != 0;
    }

    public boolean init(int i, int j)
    {
        if (j > 0)
        {
            QURAM_RECORDER_SAMPLERATE = j;
        }
        bufferSize = AudioRecord.getMinBufferSize(QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING);
        if (bufferSize < 16384)
        {
            bufferSize = 16384;
        }
        mAudioSource = i;
        if (recorder != null)
        {
            Log.d("SEFSemAudioRecorder", (new StringBuilder("recorder.getState() = ")).append(recorder.getState()).toString());
            if (recorder.getState() != 0)
            {
                return true;
            }
        }
        Log.i("SEFSemAudioRecorder", "make new Recorder");
        Log.d("SEFSemAudioRecorder", (new StringBuilder("mAudioSource : ")).append(mAudioSource).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_SAMPLERATE : ")).append(QURAM_RECORDER_SAMPLERATE).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_CHANNELS : ")).append(QURAM_RECORDER_CHANNELS).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("QURAM_RECORDER_AUDIO_ENCODING : ")).append(QURAM_RECORDER_AUDIO_ENCODING).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("bufferSize : ")).append(bufferSize).toString());
        recorder = new AudioRecord(mAudioSource, QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING, bufferSize);
        if (recorder == null)
        {
            Log.d("SEFSemAudioRecorder", "===> recorder null!!!!");
            return false;
        }
        return recorder.getState() != 0;
    }

    public boolean init(int i, int j, int k)
    {
        if (k == 0)
        {
            QURAM_RECORDER_CHANNELS = 16;
        } else
        {
            QURAM_RECORDER_CHANNELS = 12;
        }
        if (j > 0)
        {
            QURAM_RECORDER_SAMPLERATE = j;
        }
        bufferSize = AudioRecord.getMinBufferSize(QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING);
        if (bufferSize < 16384)
        {
            bufferSize = 16384;
        }
        mAudioSource = i;
        if (recorder != null)
        {
            Log.d("SEFSemAudioRecorder", (new StringBuilder("recorder.getState() = ")).append(recorder.getState()).toString());
            if (recorder.getState() != 0)
            {
                return true;
            }
        }
        Log.i("SEFSemAudioRecorder", "make new Recorder");
        Log.d("SEFSemAudioRecorder", (new StringBuilder("AudioSource : ")).append(mAudioSource).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("RECORDER_SAMPLERATE : ")).append(QURAM_RECORDER_SAMPLERATE).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("RECORDER_CHANNELS : ")).append(QURAM_RECORDER_CHANNELS).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("RECORDER_AUDIO_ENCODING : ")).append(QURAM_RECORDER_AUDIO_ENCODING).toString());
        Log.d("SEFSemAudioRecorder", (new StringBuilder("bufferSize : ")).append(bufferSize).toString());
        recorder = new AudioRecord(mAudioSource, QURAM_RECORDER_SAMPLERATE, QURAM_RECORDER_CHANNELS, QURAM_RECORDER_AUDIO_ENCODING, bufferSize);
        if (recorder == null)
        {
            Log.d("SEFSemAudioRecorder", "===> recorder null!!!!");
            return false;
        }
        return recorder.getState() != 0;
    }

    public int read(byte abyte0[])
    {
        if (recorder == null)
        {
            return -3;
        }
        if (recorder != null && recorder.getState() == 0)
        {
            synchronized (recorder)
            {
                if (recorder == null)
                {
                    break MISSING_BLOCK_LABEL_51;
                }
            }
            return -3;
        }
          goto _L1
        abyte0;
        audiorecord;
        JVM INSTR monitorexit ;
        throw abyte0;
        audiorecord;
        JVM INSTR monitorexit ;
_L1:
        return recorder.read(abyte0, 0, bufferSize);
    }

    public boolean start()
    {
        Log.w("SEFSemAudioRecorder", "qRecorder start start");
        if (recorder != null && recorder.getState() == 0)
        {
            synchronized (recorder)
            {
                Log.w("SEFSemAudioRecorder", "stop recorder in start");
                recorder.release();
                recorder = null;
            }
        }
        if (!init(mAudioSource, QURAM_RECORDER_SAMPLERATE))
        {
            Log.e("SEFSemAudioRecorder", (new StringBuilder("Audio Recorder init failed samplerate = ")).append(QURAM_RECORDER_SAMPLERATE).toString());
            return false;
        }
        break MISSING_BLOCK_LABEL_101;
        exception;
        audiorecord;
        JVM INSTR monitorexit ;
        throw exception;
        synchronized (recorder)
        {
            if (recorder.getRecordingState() != 3)
            {
                recorder.startRecording();
                Log.d("SEFSemAudioRecorder", "record start");
            }
        }
        Log.w("SEFSemAudioRecorder", "qrecorder start end");
        return true;
        exception1;
        audiorecord1;
        JVM INSTR monitorexit ;
        throw exception1;
    }

    public void stop()
    {
        Log.w("SEFSemAudioRecorder", "qRecorder stop start");
        if (recorder == null)
        {
            return;
        }
        if (recorder != null && recorder.getState() == 0)
        {
            synchronized (recorder)
            {
                if (recorder == null)
                {
                    break MISSING_BLOCK_LABEL_55;
                }
            }
            return;
        }
          goto _L1
        exception;
        audiorecord;
        JVM INSTR monitorexit ;
        throw exception;
        audiorecord;
        JVM INSTR monitorexit ;
_L1:
        recorder.stop();
        recorder.release();
        recorder = null;
        Log.w("SEFSemAudioRecorder", "qRecorder stop end");
        return;
    }

}
