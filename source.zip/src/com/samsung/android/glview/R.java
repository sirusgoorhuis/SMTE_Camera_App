// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


public final class R
{
    public static final class color
    {

        public static final int default_black_color = 0x7f0b000e;
        public static final int default_text_color = 0x7f0b0011;
        public static final int default_white_color = 0x7f0b0013;

        public color()
        {
        }
    }

    public static final class drawable
    {

        public static final int overscroll_landscape_left = 0x7f02024a;
        public static final int overscroll_landscape_right = 0x7f02024b;
        public static final int overscroll_portrait_bottom = 0x7f02024c;
        public static final int overscroll_portrait_top = 0x7f02024d;

        public drawable()
        {
        }
    }

    public static final class string
    {

        public static final int button = 0x7f090142;
        public static final int disable = 0x7f09018b;
        public static final int tts_hour = 0x7f0902c4;
        public static final int tts_hours = 0x7f0902c5;
        public static final int tts_minute = 0x7f0902c6;
        public static final int tts_minutes = 0x7f0902c7;
        public static final int tts_not_selected = 0x7f0902c8;
        public static final int tts_second = 0x7f0902ca;
        public static final int tts_seconds = 0x7f0902cb;
        public static final int tts_selected = 0x7f0902cc;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int Activity_WithActionBar_FullScreen = 0x7f0e0000;
        public static final int AppActionBar = 0x7f0e0001;
        public static final int CustomTheme = 0x7f0e0002;

        public style()
        {
        }
    }


    public R()
    {
    }
}
