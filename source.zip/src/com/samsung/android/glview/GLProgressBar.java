// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            GLView, GLContext, GLNinePatch, GLText

public class GLProgressBar extends GLView
{

    private static final int DEFAULT_PADDING = 10;
    private static final int DEFAULT_TEXT_COLOR;
    private float mFontsize;
    private GLContext mGL;
    private float mHeight;
    private int mMax;
    private int mProgress;
    private GLNinePatch mProgressBarBg;
    private GLNinePatch mProgressBarGauge;
    private float mProgressBarHeight;
    private GLText mProgressBarText;
    private int mTextinterval;
    private float mWidth;

    public GLProgressBar(GLContext glcontext, float f, float f1, float f2, float f3, float f4, int i, 
            int j, int k, float f5)
    {
        super(glcontext, f, f1, f2, f3);
        mMax = 0;
        mProgress = 0;
        mTextinterval = 0;
        mWidth = 0.0F;
        mHeight = 0.0F;
        mProgressBarHeight = 0.0F;
        mFontsize = 20F;
        mProgressBarBg = null;
        mProgressBarGauge = null;
        mProgressBarText = null;
        mGL = glcontext;
        mWidth = f2;
        mHeight = f3;
        mProgressBarHeight = f4;
        mTextinterval = k;
        mFontsize = f5;
        mProgressBarBg = new GLNinePatch(glcontext, 0.0F, (mHeight - mProgressBarHeight) / 2.0F, mWidth - (float)mTextinterval, mProgressBarHeight, i);
        mProgressBarGauge = new GLNinePatch(glcontext, 0.0F, (mHeight - mProgressBarHeight) / 2.0F, mWidth - (float)mTextinterval, mProgressBarHeight, j);
        mProgressBarGauge.setVisibility(4);
        mProgressBarText = new GLText(glcontext, 10F + (mWidth - (float)mTextinterval), 0.0F, mTextinterval - 10, mHeight, (new StringBuilder()).append(Integer.toString(mProgress)).append(" / ").append(Integer.toString(mMax)).toString(), mFontsize, DEFAULT_TEXT_COLOR, true);
        mProgressBarText.setAlign(1, 2);
        init();
    }

    public GLProgressBar(GLContext glcontext, float f, float f1, float f2, float f3, float f4, int i, 
            int j, int k, int l, float f5)
    {
        super(glcontext, f, f1, f2, f3);
        mMax = 0;
        mProgress = 0;
        mTextinterval = 0;
        mWidth = 0.0F;
        mHeight = 0.0F;
        mProgressBarHeight = 0.0F;
        mFontsize = 20F;
        mProgressBarBg = null;
        mProgressBarGauge = null;
        mProgressBarText = null;
        mGL = glcontext;
        mWidth = f2;
        mHeight = f3;
        mProgressBarHeight = f4;
        mTextinterval = l;
        mFontsize = f5;
        mAlpha = k;
        mProgressBarBg = new GLNinePatch(glcontext, 0.0F, (mHeight - mProgressBarHeight) / 2.0F, mWidth - (float)mTextinterval, mProgressBarHeight, i, mAlpha);
        mProgressBarGauge = new GLNinePatch(glcontext, 0.0F, (mHeight - mProgressBarHeight) / 2.0F, mWidth - (float)mTextinterval, mProgressBarHeight, j, mAlpha);
        mProgressBarGauge.setVisibility(4);
        mProgressBarText = new GLText(glcontext, 10F + (mWidth - (float)mTextinterval), 0.0F, mTextinterval - 10, mHeight, (new StringBuilder()).append(Integer.toString(mProgress)).append(" / ").append(Integer.toString(mMax)).toString(), mFontsize, DEFAULT_TEXT_COLOR, true);
        mProgressBarText.setAlign(1, 2);
        init();
    }

    public GLProgressBar(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j)
    {
        super(glcontext, f, f1, f2, f3);
        mMax = 0;
        mProgress = 0;
        mTextinterval = 0;
        mWidth = 0.0F;
        mHeight = 0.0F;
        mProgressBarHeight = 0.0F;
        mFontsize = 20F;
        mProgressBarBg = null;
        mProgressBarGauge = null;
        mProgressBarText = null;
        mGL = glcontext;
        mWidth = f2;
        mHeight = f3;
        mProgressBarBg = new GLNinePatch(glcontext, 0.0F, 0.0F, mWidth, mHeight, i);
        mProgressBarGauge = new GLNinePatch(glcontext, 0.0F, 0.0F, mWidth, mHeight, j);
        mProgressBarGauge.setVisibility(4);
        init();
    }

    public GLProgressBar(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k)
    {
        super(glcontext, f, f1, f2, f3);
        mMax = 0;
        mProgress = 0;
        mTextinterval = 0;
        mWidth = 0.0F;
        mHeight = 0.0F;
        mProgressBarHeight = 0.0F;
        mFontsize = 20F;
        mProgressBarBg = null;
        mProgressBarGauge = null;
        mProgressBarText = null;
        mGL = glcontext;
        mWidth = f2;
        mHeight = f3;
        mAlpha = k;
        mProgressBarBg = new GLNinePatch(glcontext, 0.0F, 0.0F, mWidth, mHeight, i, mAlpha);
        mProgressBarGauge = new GLNinePatch(glcontext, 0.0F, 0.0F, mWidth, mHeight, j, mAlpha);
        mProgressBarGauge.setVisibility(4);
        init();
    }

    private void init()
    {
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.mParent = this;
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.mParent = this;
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.mParent = this;
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        if (mProgressBarText != null)
        {
            mProgressBarText.clear();
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.clear();
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.clear();
        }
        mGL = null;
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public int getMax()
    {
        return mMax;
    }

    public int getProgress()
    {
        return mProgress;
    }

    public void initSize()
    {
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        if (mProgressBarText != null)
        {
            mProgressBarText.onAlphaUpdated();
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.onAlphaUpdated();
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.onAlphaUpdated();
        }
    }

    protected void onDraw()
    {
        if (mProgressBarBg != null)
        {
            mProgressBarBg.draw(getMatrix(), getClipRect());
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.draw(getMatrix(), getClipRect());
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.draw(getMatrix(), getClipRect());
        }
    }

    public void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        if (mProgressBarText != null)
        {
            mProgressBarText.onLayoutUpdated();
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.onLayoutUpdated();
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.onLayoutUpdated();
        }
    }

    protected boolean onLoad()
    {
        boolean flag1 = true;
        if (mProgressBarText != null)
        {
            flag1 = true & mProgressBarText.load();
        }
        boolean flag = flag1;
        if (mProgressBarBg != null)
        {
            flag = flag1 & mProgressBarBg.load();
        }
        flag1 = flag;
        if (mProgressBarGauge != null)
        {
            flag1 = flag & mProgressBarGauge.load();
        }
        return flag1;
    }

    protected void onReset()
    {
        if (mProgressBarText != null)
        {
            mProgressBarText.reset();
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.reset();
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.reset();
        }
    }

    protected void onVisibilityChanged(int i)
    {
        super.onVisibilityChanged(i);
        if (mProgressBarText != null)
        {
            mProgressBarText.onVisibilityChanged(i);
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.onVisibilityChanged(i);
        }
        if (mProgressBarBg != null)
        {
            mProgressBarBg.onVisibilityChanged(i);
        }
    }

    public void setHeight(float f)
    {
    }

    public void setMax(int i)
    {
        mMax = i;
        if ((mWidth * (float)mProgress) / (float)mMax > 0.0F)
        {
            if (mTextinterval != 0)
            {
                mProgressBarGauge.setSize(((mWidth - (float)mTextinterval) * (float)mProgress) / (float)mMax, mProgressBarHeight);
            } else
            {
                mProgressBarGauge.setSize(((mWidth - (float)mTextinterval) * (float)mProgress) / (float)mMax, mHeight);
            }
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setText((new StringBuilder()).append(Integer.toString(mProgress)).append(" / ").append(Integer.toString(mMax)).toString());
        }
    }

    public void setProgress(int i)
    {
        mProgress = i;
        mProgressBarGauge.setVisibility(0);
        if ((mWidth * (float)mProgress) / (float)mMax > 0.0F)
        {
            if (mTextinterval != 0)
            {
                mProgressBarGauge.setSize(((mWidth - (float)mTextinterval) * (float)mProgress) / (float)mMax, mProgressBarHeight);
            } else
            {
                mProgressBarGauge.setSize(((mWidth - (float)mTextinterval) * (float)mProgress) / (float)mMax, mHeight);
            }
        } else
        {
            mProgressBarGauge.setVisibility(4);
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setText((new StringBuilder()).append(Integer.toString(mProgress)).append(" / ").append(Integer.toString(mMax)).toString());
        }
    }

    public void setShaderParameter(float f)
    {
        if (mProgressBarBg != null)
        {
            mProgressBarBg.setShaderParameter(f);
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.setShaderParameter(f);
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setShaderParameter(f);
        }
    }

    public void setShaderProgram(int i)
    {
        if (mProgressBarBg != null)
        {
            mProgressBarBg.setShaderProgram(i);
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.setShaderProgram(i);
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setShaderProgram(i);
        }
    }

    public void setShaderStep(float f)
    {
        if (mProgressBarBg != null)
        {
            mProgressBarBg.setShaderStep(f);
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.setShaderStep(f);
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setShaderStep(f);
        }
    }

    public void setSize(float f, float f1)
    {
        super.setSize(f, f1);
        mWidth = f;
        mHeight = f1;
        if (mTextinterval != 0)
        {
            mProgressBarBg.setSize(mWidth - (float)mTextinterval, mProgressBarHeight);
            if ((mWidth * (float)mProgress) / (float)mMax > 0.0F)
            {
                mProgressBarGauge.setSize(((mWidth - (float)mTextinterval) * (float)mProgress) / (float)mMax, mProgressBarHeight);
            } else
            {
                mProgressBarGauge.setSize(mWidth - (float)mTextinterval, mProgressBarHeight);
            }
            if (mProgressBarText != null)
            {
                mProgressBarText = new GLText(mGL, (mWidth - (float)mTextinterval) + 10F, 0.0F, mTextinterval - 10, mHeight, (new StringBuilder()).append(Integer.toString(mProgress)).append(" / ").append(Integer.toString(mMax)).toString(), mFontsize, DEFAULT_TEXT_COLOR, true);
                mProgressBarText.setAlign(1, 2);
                mProgressBarText.mParent = this;
            }
            return;
        } else
        {
            mProgressBarGauge.setSize(f, f1);
            mProgressBarBg.setSize(f, f1);
            setProgress(mProgress);
            return;
        }
    }

    public void setTint(int i)
    {
        super.setTint(i);
        if (mProgressBarBg != null)
        {
            mProgressBarBg.setTint(i);
        }
        if (mProgressBarGauge != null)
        {
            mProgressBarGauge.setTint(i);
        }
        if (mProgressBarText != null)
        {
            mProgressBarText.setTint(i);
        }
    }

    public void setWidth(float f)
    {
    }

    static 
    {
        DEFAULT_TEXT_COLOR = GLContext.getColor(R.color.default_white_color);
    }
}
