// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import java.util.Comparator;

// Referenced classes of package com.samsung.android.glview:
//            GLViewGroup, GLView

class this._cls0
    implements Comparator
{

    final GLViewGroup this$0;

    public int compare(GLView glview, GLView glview1)
    {
        return Float.compare(glview.getLayoutZ(), glview1.getLayoutZ());
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((GLView)obj, (GLView)obj1);
    }

    ()
    {
        this$0 = GLViewGroup.this;
        super();
    }
}
