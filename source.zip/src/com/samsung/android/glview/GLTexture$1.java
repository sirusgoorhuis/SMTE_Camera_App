// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.opengl.GLES20;
import android.opengl.GLU;
import android.util.Log;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture

class this._cls0
    implements Runnable
{

    final GLTexture this$0;

    public void run()
    {
        GLTexture.access$002(GLTexture.this, true);
        initSize();
        if (mBitmap == null)
        {
            return;
        }
        setVertices();
        initBuffers();
        generateTexture();
        int i = GLES20.glGetError();
        if (i != 0)
        {
            Log.e("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glGenTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        }
        GLES20.glBindTexture(3553, mTextures[0]);
        i = GLES20.glGetError();
        if (i != 0)
        {
            Log.e("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glBindTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        }
        GLES20.glTexParameterf(3553, 10241, 9729F);
        GLES20.glTexParameterf(3553, 10240, 9729F);
        GLES20.glTexParameterf(3553, 10242, 33071F);
        GLES20.glTexParameterf(3553, 10243, 33071F);
        if (mNewProgramType != mProgramType)
        {
            mProgramType = mNewProgramType;
        }
        loadProgram();
        loadGLTexture();
        mTextureLoaded = true;
        GLTexture.access$002(GLTexture.this, false);
    }

    ()
    {
        this$0 = GLTexture.this;
        super();
    }
}
