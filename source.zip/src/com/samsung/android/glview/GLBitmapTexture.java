// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLContext

public class GLBitmapTexture extends GLTexture
{

    private Bitmap mOriginalBitmap;

    public GLBitmapTexture(GLContext glcontext, float f, float f1, float f2, float f3, Bitmap bitmap)
    {
        super(glcontext, f, f1, f2, f3);
        mOriginalBitmap = null;
        mOriginalBitmap = bitmap;
    }

    public GLBitmapTexture(GLContext glcontext, float f, float f1, Bitmap bitmap)
    {
        super(glcontext, f, f1);
        mOriginalBitmap = null;
        mOriginalBitmap = bitmap;
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        super.clear();
        if (mOriginalBitmap != null)
        {
            mOriginalBitmap = null;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected void clearBitmap()
    {
        super.clearBitmap();
        if (mOriginalBitmap != null)
        {
            mOriginalBitmap = null;
        }
    }

    protected Bitmap loadBitmap()
    {
        this;
        JVM INSTR monitorenter ;
        Bitmap bitmap = mOriginalBitmap;
        if (bitmap != null) goto _L2; else goto _L1
_L1:
        bitmap = null;
_L4:
        this;
        JVM INSTR monitorexit ;
        return bitmap;
_L2:
        if (mSizeGiven)
        {
            bitmap = Bitmap.createScaledBitmap(mOriginalBitmap, (int)getWidth(), (int)getHeight(), false);
            continue; /* Loop/switch isn't completed */
        }
        bitmap = Bitmap.createBitmap(mOriginalBitmap);
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }
}
