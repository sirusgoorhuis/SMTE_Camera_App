// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.os.Handler;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLContext

class this._cls0
    implements Runnable
{

    final GLView this$0;

    public void run()
    {
        while (mGLContext == null || GLContext.getApplicationContext() == null || !GLView.access$300(GLView.this) || !GLView.access$400(GLView.this)) 
        {
            return;
        }
        if (mClickListener != null)
        {
            mClickListener.onClick(mThis);
        }
        mGLContext.getMainHandler().postDelayed(this, GLView.access$500(GLView.this));
    }

    ickListener()
    {
        this$0 = GLView.this;
        super();
    }
}
