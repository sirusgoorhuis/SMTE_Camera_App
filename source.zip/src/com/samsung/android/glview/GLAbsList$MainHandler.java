// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.os.Handler;
import android.os.Message;
import java.lang.ref.WeakReference;

// Referenced classes of package com.samsung.android.glview:
//            GLAbsList

private static class mList extends Handler
{

    private final WeakReference mList;

    public void handleMessage(Message message)
    {
        GLAbsList glabslist;
        glabslist = (GLAbsList)mList.get();
        if (glabslist == null)
        {
            return;
        }
        switch (message.what)
        {
        default:
            return;

        case 1: // '\001'
            glabslist.hideScrollBar();
            return;

        case 2: // '\002'
            message = mList;
            break;
        }
        message;
        JVM INSTR monitorenter ;
        GLAbsList.access$100(glabslist, true);
        GLAbsList.access$202(glabslist, true);
        message;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        message;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public (GLAbsList glabslist)
    {
        mList = new WeakReference(glabslist);
    }
}
