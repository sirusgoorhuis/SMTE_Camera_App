// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.util.Log;
import android.util.SparseArray;

public class GLTextureStorage
{
    public static class TextureInfo
    {

        public int mCounter;
        public float mHeight;
        public int mTextureID;
        public float mWidth;

        public TextureInfo(int i, int j, float f, float f1)
        {
            mTextureID = i;
            mCounter = j;
            mWidth = f;
            mHeight = f1;
        }
    }


    private SparseArray mTextureMap;

    public GLTextureStorage()
    {
        mTextureMap = new SparseArray();
    }

    protected void addTexture(int i, int j, float f, float f1)
    {
        TextureInfo textureinfo = (TextureInfo)mTextureMap.get(i);
        if (textureinfo == null)
        {
            mTextureMap.put(i, new TextureInfo(j, 1, f, f1));
            return;
        } else
        {
            mTextureMap.put(i, new TextureInfo(j, textureinfo.mCounter + 1, f, f1));
            return;
        }
    }

    protected void clear()
    {
        mTextureMap.clear();
    }

    public void dump()
    {
        int i = 0;
        while (i < mTextureMap.size()) 
        {
            TextureInfo textureinfo = (TextureInfo)mTextureMap.get(mTextureMap.keyAt(i));
            if (textureinfo != null)
            {
                Log.e("GLTextureStorage", (new StringBuilder()).append("Info(").append(i).append(") res = ").append(mTextureMap.keyAt(i)).append(", id = ").append(textureinfo.mTextureID).append(", counter = ").append(textureinfo.mCounter).append(", width = ").append(textureinfo.mWidth).append(", height = ").append(textureinfo.mHeight).toString());
            } else
            {
                Log.e("GLTextureStorage", (new StringBuilder()).append("no info at key : ").append(mTextureMap.keyAt(i)).toString());
            }
            i++;
        }
    }

    protected TextureInfo getTextureInfo(int i)
    {
        TextureInfo textureinfo = (TextureInfo)mTextureMap.get(i);
        if (textureinfo != null)
        {
            return textureinfo;
        } else
        {
            return null;
        }
    }

    protected int removeTexture(int i)
    {
        TextureInfo textureinfo = (TextureInfo)mTextureMap.get(i);
        if (textureinfo == null)
        {
            return 0;
        }
        if (textureinfo.mCounter == 1)
        {
            mTextureMap.delete(i);
            return 0;
        } else
        {
            mTextureMap.put(i, new TextureInfo(textureinfo.mTextureID, textureinfo.mCounter - 1, textureinfo.mWidth, textureinfo.mHeight));
            return textureinfo.mCounter - 1;
        }
    }
}
