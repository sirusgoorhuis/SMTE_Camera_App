// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

public class AccessibilityGestureHandler extends AccessibilityService
    implements android.speech.tts.TextToSpeech.OnInitListener
{

    public static final String ACTION_ACCESSIBILITY_GESTURE_DETECTED = "com.samsung.android.glview.ACCESSIBILITY_GESTURE_DETECTED";
    public static final String ACTION_ACCESSIBILITY_VIEW_FOCUS_GONE = "com.samsung.android.glview.ACTION_ACCESSIBILITY_VIEW_FOCUS_GONE";
    public static final int GESTURE_SWIPE_DOWN = 2;
    public static final int GESTURE_SWIPE_LEFT = 3;
    public static final int GESTURE_SWIPE_RIGHT = 4;
    public static final int GESTURE_SWIPE_UP = 1;
    public static final String KEY_ACCESSIBILITY_EVENT_ID = "accessibilityeventid";
    public static final String KEY_ACCESSIBILITY_NODE_INFO_ID = "accessibilitynodeinfoid";
    public static final String KEY_GESTURE_ID = "gestureId";
    public static final String SYSTEM_PACKAGE_NAME = "com.android.systemui";
    private static final String TAG = "AccessibilityHandler";

    public AccessibilityGestureHandler()
    {
    }

    public void onAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        if (accessibilityevent.getPackageName().equals("com.android.systemui") && accessibilityevent.getEventType() == 32768)
        {
            Bundle bundle = new Bundle();
            bundle.putParcelable("accessibilitynodeinfoid", accessibilityevent.getSource());
            accessibilityevent = new Intent("com.samsung.android.glview.ACTION_ACCESSIBILITY_VIEW_FOCUS_GONE");
            accessibilityevent.putExtra("accessibilityeventid", bundle);
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(accessibilityevent);
        }
    }

    public void onDestroy()
    {
        Log.v("AccessibilityHandler", "onDestroy");
        super.onDestroy();
    }

    protected boolean onGesture(int i)
    {
        Intent intent;
        Log.v("AccessibilityHandler", (new StringBuilder()).append("onGesture, gestureId : ").append(i).toString());
        intent = new Intent("com.samsung.android.glview.ACCESSIBILITY_GESTURE_DETECTED");
        i;
        JVM INSTR tableswitch 1 16: default 116
    //                   1 152
    //                   2 163
    //                   3 130
    //                   4 141
    //                   5 116
    //                   6 116
    //                   7 116
    //                   8 116
    //                   9 130
    //                   10 130
    //                   11 141
    //                   12 141
    //                   13 152
    //                   14 152
    //                   15 163
    //                   16 163;
           goto _L1 _L2 _L3 _L4 _L5 _L1 _L1 _L1 _L1 _L4 _L4 _L5 _L5 _L2 _L2 _L3 _L3
_L1:
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
        return false;
_L4:
        intent.putExtra("gestureId", 3);
        continue; /* Loop/switch isn't completed */
_L5:
        intent.putExtra("gestureId", 4);
        continue; /* Loop/switch isn't completed */
_L2:
        intent.putExtra("gestureId", 1);
        continue; /* Loop/switch isn't completed */
_L3:
        intent.putExtra("gestureId", 2);
        if (true) goto _L1; else goto _L6
_L6:
    }

    public void onInit(int i)
    {
        Log.v("AccessibilityHandler", "onInit");
    }

    public void onInterrupt()
    {
        Log.v("AccessibilityHandler", "onInterrupt");
    }

    public void onServiceConnected()
    {
        Log.v("AccessibilityHandler", "onServiceConnected");
        Object obj = new AccessibilityServiceInfo();
        obj.flags = 5;
        obj.eventTypes = 32768;
        obj.feedbackType = 1;
        setServiceInfo(((AccessibilityServiceInfo) (obj)));
        obj = new Intent("com.samsung.android.glview.ACTION_ACCESSIBILITY_VIEW_FOCUS_GONE");
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(((Intent) (obj)));
    }
}
