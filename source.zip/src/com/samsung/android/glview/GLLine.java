// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Log;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLUtil, GLContext, GLProgramStorage, 
//            GLProgram

public class GLLine extends GLTexture
{

    private static final float DEFAULT_THICKNESS = 1F;
    private static final String TAG = "GLLine";
    private float mColor[];
    private GLProgram.NameIndexerObj mObjPointSize;
    private GLProgram.NameIndexerObj mObjSampler;
    private float mThickness[];
    private FloatBuffer mThicknessBuffer;

    public GLLine(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4)
    {
        super(glcontext, 0.0F, 0.0F);
        mThickness = new float[2];
        mObjSampler = null;
        mObjPointSize = null;
        mColor = new float[4];
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness[0] = 1.0F;
            mThickness[1] = 1.0F;
        } else
        {
            mThickness[0] = f4;
            mThickness[1] = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    protected void clearBuffers()
    {
        if (mThicknessBuffer != null)
        {
            mThicknessBuffer.clear();
        }
        super.clearBuffers();
    }

    public int getColor()
    {
        return Color.argb((int)(mColor[0] * 255F), (int)(mColor[1] * 255F), (int)(mColor[2] * 255F), (int)(mColor[3] * 255F));
    }

    public float getThickness()
    {
        return mThickness[0];
    }

    protected void initBuffers()
    {
        this;
        JVM INSTR monitorenter ;
        byte abyte0[];
        clearBuffers();
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        mThicknessBuffer = GLUtil.getFloatBufferFromFloatArray(mThickness);
        if (mIndices == null)
        {
            mIndices = new byte[2];
        }
        abyte0 = mIndices;
        int i;
        i = 0 + 1;
        abyte0[0] = 0;
        mIndices[i] = 1;
        mIndexBuffer = GLUtil.getByteBufferFromByteArray(mIndices);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void initSize()
    {
        setSize(getWidth(), getHeight());
    }

    protected Bitmap loadBitmap()
    {
        return null;
    }

    public void onDraw()
    {
        if (!mTextureLoaded)
        {
            return;
        }
        if (!mLayoutUpdated) goto _L2; else goto _L1
_L1:
        setVertices();
        if (mVertexBuffer != null)
        {
            mVertexBuffer.clear();
        }
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        mLayoutUpdated = false;
_L4:
        GLES20.glLineWidth(mThickness[0]);
        GLES20.glUseProgram(mProgramID);
        GLES20.glUniform4fv(mObjSampler.mHandle, 1, mColor, 0);
        Matrix.multiplyMM(mViewMatrix, 0, getContext().getProjMatrix(), 0, getMatrix(), 0);
        GLES20.glUniformMatrix4fv(mObjMVPMatrix.mHandle, 1, false, mViewMatrix, 0);
        GLES20.glUniform1f(mObjAlpha.mHandle, getAlpha());
        GLES20.glEnableVertexAttribArray(mObjPointSize.mHandle);
        GLES20.glEnableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glDisable(2929);
        GLES20.glVertexAttribPointer(mObjPointSize.mHandle, 1, 5126, false, 0, mThicknessBuffer);
        GLES20.glVertexAttribPointer(mObjPosition.mHandle, 3, 5126, false, 0, mVertexBuffer);
        if (mTextureReloaded)
        {
            mTextureReloaded = false;
        }
        GLES20.glDrawElements(1, mIndices.length, 5121, mIndexBuffer);
        GLES20.glDisableVertexAttribArray(mObjPointSize.mHandle);
        GLES20.glDisableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glEnable(2929);
        return;
_L2:
        if (mVertexBuffer == null || mIndexBuffer == null || mThicknessBuffer == null)
        {
            Log.e("GLLine", "init buffers on onDraw");
            setVertices();
            initBuffers();
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    protected boolean onLoad()
    {
        initSize();
        setVertices();
        initBuffers();
        GLProgram glprogram = getContext().getProgramStorage().getProgram(1003);
        if (glprogram != null)
        {
            mProgramID = glprogram.getProgramID();
            mObjPosition = glprogram.getNameIndexer("a_position");
            mObjPointSize = glprogram.getNameIndexer("a_pointsize");
            mObjSampler = glprogram.getNameIndexer("tex_sampler");
            mObjMVPMatrix = glprogram.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram.getNameIndexer("u_alpha");
        }
        mTextureLoaded = true;
        return true;
    }

    public void setColor(int i)
    {
        mColor[0] = (float)Color.red(i) / 255F;
        mColor[1] = (float)Color.green(i) / 255F;
        mColor[2] = (float)Color.blue(i) / 255F;
        mColor[3] = (float)Color.alpha(i) / 255F;
    }

    public void setLine(float f, float f1, float f2, float f3)
    {
        translateAbsolute(f, f1);
        setSize(f2, f3);
        setVertices();
        initBuffers();
    }

    public void setThickness(float f)
    {
        mThickness[0] = f;
        mThickness[1] = f;
        initBuffers();
    }

    protected void setVertices()
    {
        this;
        JVM INSTR monitorenter ;
        if (mVertices == null)
        {
            mVertices = new float[6];
        }
        mVertices[0] = getLeft();
        mVertices[1] = getTop();
        mVertices[2] = 0.0F;
        mVertices[3] = getRight() - getThickness();
        mVertices[4] = getBottom() - getThickness();
        mVertices[5] = 0.0F;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }
}
