// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.view.KeyEvent;

// Referenced classes of package com.samsung.android.glview:
//            GLView

public static interface 
{

    public abstract boolean onKeyDown(GLView glview, KeyEvent keyevent);

    public abstract boolean onKeyUp(GLView glview, KeyEvent keyevent);
}
