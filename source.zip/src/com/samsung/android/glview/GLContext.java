// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.AudioManager;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.support.v4.content.LocalBroadcastManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import com.samsung.android.desktopmode.SemDesktopModeManager;
import com.samsung.android.hardware.context.SemContext;
import com.samsung.android.hardware.context.SemContextAutoRotation;
import com.samsung.android.hardware.context.SemContextEvent;
import com.samsung.android.hardware.context.SemContextListener;
import com.samsung.android.hardware.context.SemContextManager;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

// Referenced classes of package com.samsung.android.glview:
//            GLTextureStorage, GLUtil, GLViewGroup, GLView, 
//            GLTexture, GLSlider, GLProgramStorage, GLPreviewData, 
//            GLAccessibilityNodeProvider

public class GLContext
    implements android.opengl.GLSurfaceView.Renderer, android.speech.tts.TextToSpeech.OnInitListener, SemContextListener, android.view.Choreographer.FrameCallback, android.view.View.OnHoverListener
{
    public static interface GLInitializeListener
    {

        public abstract void onGLInitialized(GLViewGroup glviewgroup);
    }

    public static interface HoverEventChangedObserver
    {

        public abstract void onHoverEventChanged(GLView glview, MotionEvent motionevent);
    }


    public static final int FOCUSED = 1;
    private static final int FOCUS_INDICATOR_DEFAULT_COLOR = Color.argb(230, 0, 0, 255);
    private static final int FOCUS_INDICATOR_DEFAULT_THICKNESS = 1;
    private static final int FPS_CALCULATION_INTERVAL_THRESHOLD = 100;
    public static final int GL_TEXTURE_EXTERNAL_OES = 36197;
    public static final int HOVER_ENTER = 0;
    public static final int HOVER_EXIT = 1;
    private static final int HOVER_INDICATOR_DEFAULT_COLOR = Color.argb(230, 0, 76, 232);
    private static final int HOVER_INDICATOR_DEFAULT_THICKNESS = 2;
    public static final int NOT_FOCUSED = 0;
    public static final int ORIENTATION_CHANGE_MARGIN_IN_DEGREE = 10;
    private static final String SENSORHUB_SERVICE_NAME = "scontext";
    public static final String SHOW_BUTTON_BACKGROUND_SETTING_KEY = "show_button_background";
    private static final String TAG = "GLContext";
    protected static final boolean TEXTURE_SHARING = true;
    protected static Context mApplicationContext;
    private static final Object mFrameLock = new Object();
    private static boolean mGLSurfaceOrientationFixed = false;
    private static final Object mInitLock = new Object();
    private static int mLastOrientation = 0;
    private static int mNavigatorHeight = 0;
    private static int mOrientationCompensationValue = 0;
    private static final Object mOrientationUpdateLock = new Object();
    private static Resources mResources;
    private static int mScreenHeight = 0;
    private static int mScreenWidth = 0;
    private AccessibilityNodeInfo mAccNode;
    private BroadcastReceiver mAccViewFocusedReceiver;
    private android.view.View.AccessibilityDelegate mAccessibilityDelegate;
    private long mAccumulatedTime;
    private boolean mAlignToPixel;
    private boolean mAutoOrientationStatus;
    private Choreographer mChoreographer;
    private Rect mClipRect;
    private GLView mCurrentFocusedView;
    private GLView mCurrentHoverFocusedView;
    private ContentObserver mCursorColorObserver;
    private final Object mDeleteTexturesLock;
    private float mDensity;
    private boolean mDirty;
    private ContentObserver mDisplaySizeObserver;
    private ContentObserver mEnabledAccessibilityServicesContentObserver;
    private int mEstimatedFPS;
    private int mFocusIndicatorColor;
    private int mFocusIndicatorThickness;
    private boolean mFocusIndicatorVisibilityChanged;
    private long mFrameCountForFPS;
    private Handler mFrameHandler;
    private HandlerThread mFrameHandlerThread;
    private long mFrameNum;
    private GLPreviewData mGLPreviewData;
    private GLProgramStorage mGLProgramStorage;
    private GLSurfaceView mGLSurfaceView;
    private GLTextureStorage mGLTextureStorage;
    private int mHeight;
    private View mHoverBaseView;
    private int mHoverIndicatorColor;
    private int mHoverIndicatorThickness;
    private BroadcastReceiver mHoverSwipeReceiver;
    private float mIdentityMatrix[];
    private boolean mIsAccessibilityNodeEnabled;
    private boolean mIsAccessibilityServiceEnabled;
    private boolean mIsFocusIndicatorVisible;
    private boolean mIsFocusNavigationEnabled;
    private boolean mIsSemContextListenerAvailable;
    private boolean mIsTouchExplorationEnabled;
    private GLView mLastHoverView;
    private MotionEvent mLastMotionEvent;
    private GLView mLastTouchView;
    private GLInitializeListener mListener;
    private Handler mMainHandler;
    private HandlerThread mMainHandlerThread;
    protected List mObservers;
    private final Object mObserversLock;
    private OrientationEventListener mOrientationListener;
    private boolean mPaused;
    private long mPrevFrameTimeStamp;
    private float mProjMatrix[];
    private boolean mRenderRequested;
    private int mRippleEffectColor;
    private boolean mRippleEffectEnabled;
    private GLViewGroup mRootView;
    private boolean mScrollBarAutoHide;
    private SemContextManager mSemContextManager;
    private ContentObserver mSettingInteractionControlObserver;
    private boolean mShowButtonBackgroundEnabled;
    private int mTapDir;
    private int mTapDirState;
    private ArrayList mTexturesToDelete;
    private ContentObserver mTouchExplorationEnabledContentObserver;
    private TextToSpeech mTts;
    private int mWidth;

    public GLContext(Context context, GLInitializeListener glinitializelistener, GLSurfaceView glsurfaceview, boolean flag)
    {
        mObservers = new ArrayList();
        mObserversLock = new Object();
        mDeleteTexturesLock = new Object();
        mRootView = null;
        mAutoOrientationStatus = false;
        mCurrentFocusedView = null;
        mCurrentHoverFocusedView = null;
        mAccNode = null;
        mIdentityMatrix = new float[16];
        mProjMatrix = new float[16];
        mClipRect = new Rect();
        mMainHandler = null;
        mMainHandlerThread = null;
        mFrameHandler = null;
        mFrameHandlerThread = null;
        mTexturesToDelete = new ArrayList();
        mGLProgramStorage = null;
        mDirty = false;
        mRenderRequested = false;
        mPaused = false;
        mScrollBarAutoHide = true;
        mAlignToPixel = true;
        mRippleEffectEnabled = true;
        mRippleEffectColor = 0;
        mDensity = 1.0F;
        mIsFocusIndicatorVisible = false;
        mFocusIndicatorVisibilityChanged = false;
        mHoverIndicatorColor = HOVER_INDICATOR_DEFAULT_COLOR;
        mFocusIndicatorColor = FOCUS_INDICATOR_DEFAULT_COLOR;
        mHoverIndicatorThickness = 0;
        mFocusIndicatorThickness = 0;
        mGLPreviewData = null;
        mTapDir = 0;
        mTapDirState = 0;
        mHoverBaseView = null;
        mFrameNum = 0L;
        mIsAccessibilityNodeEnabled = false;
        mIsAccessibilityServiceEnabled = false;
        mFrameCountForFPS = 0L;
        mAccumulatedTime = 0L;
        mPrevFrameTimeStamp = 0L;
        mEstimatedFPS = 0;
        mChoreographer = null;
        mIsFocusNavigationEnabled = true;
        mAccessibilityDelegate = null;
        mShowButtonBackgroundEnabled = false;
        mSemContextManager = null;
        mOrientationListener = null;
        mIsSemContextListenerAvailable = false;
        mLastMotionEvent = null;
        mHoverSwipeReceiver = new BroadcastReceiver() {

            final GLContext this$0;

            public void onReceive(Context context1, Intent intent)
            {
                if (!isFocusNavigationEnabled() || intent.getExtras() == null)
                {
                    return;
                }
                switch (intent.getExtras().getInt("gestureId"))
                {
                default:
                    return;

                case 1: // '\001'
                    onHoverSwipeEvent(65);
                    return;

                case 3: // '\003'
                    onHoverSwipeEvent(49);
                    return;

                case 4: // '\004'
                    onHoverSwipeEvent(98);
                    return;

                case 2: // '\002'
                    onHoverSwipeEvent(82);
                    return;
                }
            }

            
            {
                this$0 = GLContext.this;
                super();
            }
        };
        mAccViewFocusedReceiver = new BroadcastReceiver() {

            final GLContext this$0;

            public void onReceive(Context context1, Intent intent)
            {
                if (!isFocusNavigationEnabled())
                {
                    return;
                }
                clearFocus();
                setDirty(true);
                context1 = intent.getBundleExtra("accessibilityeventid");
                if (context1 == null)
                {
                    mGLSurfaceView.sendAccessibilityEvent(32768);
                    return;
                } else
                {
                    mAccNode = (AccessibilityNodeInfo)context1.getParcelable("accessibilitynodeinfoid");
                    return;
                }
            }

            
            {
                this$0 = GLContext.this;
                super();
            }
        };
        mDisplaySizeObserver = new ContentObserver(mMainHandler) {

            final GLContext this$0;

            public void onChange(boolean flag1)
            {
                SemLog.secV("GLContext", "Display size changed");
                updateScreenSize();
            }

            
            {
                this$0 = GLContext.this;
                super(handler);
            }
        };
        mCursorColorObserver = new ContentObserver(mMainHandler) {

            final GLContext this$0;

            public void onChange(boolean flag1)
            {
                SemLog.secV("GLContext", "Cursor color changed");
                if (mRootView != null)
                {
                    mRootView.onHoverIndicatorColorChanged();
                }
            }

            
            {
                this$0 = GLContext.this;
                super(handler);
            }
        };
        mTouchExplorationEnabledContentObserver = new ContentObserver(mMainHandler) {

            final GLContext this$0;

            public void onChange(boolean flag1)
            {
                super.onChange(flag1);
                SemLog.secV("GLContext", "Touch Exploration ContentObserver onChange");
                updateTouchExplorationEnabled();
                if (GLContext.isTalkBackEnabled())
                {
                    enableAccessibilityService(GLContext.mApplicationContext);
                }
            }

            
            {
                this$0 = GLContext.this;
                super(handler);
            }
        };
        mEnabledAccessibilityServicesContentObserver = new ContentObserver(mMainHandler) {

            final GLContext this$0;

            public void onChange(boolean flag1)
            {
                super.onChange(flag1);
                SemLog.secV("GLContext", "Enabled Accessibility Services ContentObserver onChange");
                if (!GLContext.isTalkBackEnabled())
                {
                    disableAccessibilityService(GLContext.mApplicationContext);
                }
            }

            
            {
                this$0 = GLContext.this;
                super(handler);
            }
        };
        mSettingInteractionControlObserver = new ContentObserver(new Handler()) {

            final GLContext this$0;

            public void onChange(boolean flag1)
            {
                if (mPaused)
                {
                    SemLog.secW("GLContext", "GLContext is pausing, not updated");
                } else
                {
                    if (android.provider.Settings.System.getInt(GLContext.mApplicationContext.getContentResolver(), "access_control_enabled", 0) == 0)
                    {
                        enableOrientationListener();
                        return;
                    }
                    if (android.provider.Settings.System.getInt(GLContext.mApplicationContext.getContentResolver(), "access_control_enabled", 0) == 1)
                    {
                        disableOrientationListener();
                        return;
                    }
                }
            }

            
            {
                this$0 = GLContext.this;
                super(handler);
            }
        };
        Matrix.setIdentityM(mIdentityMatrix, 0);
        synchronized (mInitLock)
        {
            mApplicationContext = context;
            mResources = mApplicationContext.getResources();
        }
        mGLTextureStorage = new GLTextureStorage();
        mListener = glinitializelistener;
        mGLSurfaceView = glsurfaceview;
        mDensity = mApplicationContext.getResources().getDisplayMetrics().density;
        mGLSurfaceOrientationFixed = flag;
        updateScreenSize();
        setOrientationListener();
        updateTouchExplorationEnabled();
        context = new TypedValue();
        mApplicationContext.getTheme().resolveAttribute(0x101042c, context, true);
        mRippleEffectColor = ((TypedValue) (context)).data;
        mFocusIndicatorThickness = (int)(1.0F * mDensity + 0.5F);
        mHoverIndicatorThickness = (int)((float)android.provider.Settings.Secure.getInt(getApplicationContext().getContentResolver(), "accessibility_large_cursor", 2) * mDensity + 0.5F);
        mAccessibilityDelegate = new android.view.View.AccessibilityDelegate() {

            AccessibilityNodeProvider mNodeProvider;
            final GLContext this$0;

            public AccessibilityNodeProvider getAccessibilityNodeProvider(View view)
            {
                if (mNodeProvider == null)
                {
                    mNodeProvider = new GLAccessibilityNodeProvider(GLContext.this, mGLSurfaceView);
                }
                return mNodeProvider;
            }

            
            {
                this$0 = GLContext.this;
                super();
                mNodeProvider = null;
            }
        };
        startFrameHandlerThread();
        return;
        context;
        obj;
        JVM INSTR monitorexit ;
        throw context;
    }

    private void disableOrientationListener()
    {
        Log.d("GLContext", "disableOrientationListener");
        if (mIsSemContextListenerAvailable)
        {
            mSemContextManager.unregisterListener(this, 6);
            return;
        } else
        {
            mOrientationListener.disable();
            return;
        }
    }

    protected static Context getApplicationContext()
    {
        return mApplicationContext;
    }

    private int getAudioSoundOfTapDirection()
    {
        switch (mTapDirState)
        {
        default:
            return 0;

        case 0: // '\0'
            return 4;

        case 1: // '\001'
            return 2;

        case 2: // '\002'
            return 3;

        case 3: // '\003'
            return 1;
        }
    }

    public static int getColor(int i)
    {
        return mResources.getColor(i);
    }

    public static float getDimension(int i)
    {
        return mResources.getDimension(i);
    }

    private static Set getEnabledServicesFromSettings(Context context)
    {
        android.text.TextUtils.SimpleStringSplitter simplestringsplitter;
        simplestringsplitter = new android.text.TextUtils.SimpleStringSplitter(':');
        context = android.provider.Settings.Secure.getString(context.getContentResolver(), "enabled_accessibility_services");
        if (context != null) goto _L2; else goto _L1
_L1:
        context = Collections.emptySet();
_L4:
        return context;
_L2:
        HashSet hashset = new HashSet();
        simplestringsplitter.setString(context);
        do
        {
            context = hashset;
            if (!simplestringsplitter.hasNext())
            {
                continue;
            }
            context = ComponentName.unflattenFromString(simplestringsplitter.next());
            if (context != null)
            {
                hashset.add(context);
            }
        } while (true);
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static int getInteger(int i)
    {
        return mResources.getInteger(i);
    }

    public static int getLastOrientation()
    {
        return mLastOrientation;
    }

    public static int getNavigatorHeightPixels()
    {
        return mNavigatorHeight;
    }

    public static int getOrientationCompensationValue()
    {
        return mOrientationCompensationValue;
    }

    public static int getScreenHeightPixels()
    {
        return mScreenHeight;
    }

    public static int getScreenWidthPixels()
    {
        return mScreenWidth;
    }

    public static int getScreenWidthPixelsExceptNavigation()
    {
        return mScreenWidth - mNavigatorHeight;
    }

    public static String getString(int i)
    {
        return mResources.getString(i);
    }

    private void handleOrientationChanged(int i)
    {
        if (i == -1)
        {
            Log.d("GLContext", "handleOrientationChanged - ORIENTATION_UNKNOWN");
        } else
        {
            if (GLUtil.isReversePortraitOrientation(i))
            {
                Log.v("GLContext", "handleOrientationChanged - ignore Reverse Portrait orientation");
                return;
            }
            i = GLUtil.getGLOrientationBySystemOrientation(i);
            if (mLastOrientation != i || !mGLSurfaceOrientationFixed)
            {
                setLastOrientation(i);
                if (mRootView != null)
                {
                    Log.v("GLContext", (new StringBuilder()).append("onOrientationChanged, newOrientation : ").append(i).toString());
                    mRootView.onOrientationChanged(i);
                    setDirty(true);
                    return;
                }
            }
        }
    }

    private boolean handlingKeyEventTap()
    {
        boolean flag = false;
        GLView glview;
        if (hasHardwareKeyPad())
        {
            glview = mRootView.findViewOnSameLine(mCurrentFocusedView, 66);
        } else
        {
            GLView glview3 = mRootView.findViewById(mCurrentFocusedView.getNextFocusForwardId());
            glview = glview3;
            if (glview3 == null)
            {
                switch (mLastOrientation)
                {
                default:
                    glview = glview3;
                    break;

                case 0: // '\0'
                    glview = mRootView.findViewOnSameLine(mCurrentFocusedView, 66);
                    break;

                case 2: // '\002'
                    glview = mRootView.findViewOnSameLine(mCurrentFocusedView, 17);
                    break;

                case 1: // '\001'
                    glview = mRootView.findViewOnSameLine(mCurrentFocusedView, 130);
                    break;

                case 3: // '\003'
                    glview = mRootView.findViewOnSameLine(mCurrentFocusedView, 33);
                    break;
                }
                continue; /* Loop/switch isn't completed */
            }
        }
_L18:
        if (glview == null) goto _L2; else goto _L1
_L1:
        glview.requestFocus();
        mCurrentFocusedView = glview;
        flag = true;
_L15:
        return flag;
_L2:
        float f;
        float f1;
        float f2;
        float f3;
        f3 = (float)(mCurrentFocusedView.getOriginalClipRect().left + mCurrentFocusedView.getOriginalClipRect().right) / 2.0F;
        f2 = (float)(mCurrentFocusedView.getOriginalClipRect().top + mCurrentFocusedView.getOriginalClipRect().bottom) / 2.0F;
        f = 0.0F;
        f1 = 0.0F;
        mLastOrientation;
        JVM INSTR tableswitch 0 3: default 272
    //                   0 305
    //                   1 333
    //                   2 316
    //                   3 345;
           goto _L3 _L4 _L5 _L6 _L7
_L3:
        GLView glview1 = mRootView.findViewFromLeftMostTop(mLastOrientation, f, f1);
        if (glview1 != null)
        {
            glview1.requestFocus();
            mCurrentFocusedView = glview1;
            return true;
        }
        break; /* Loop/switch isn't completed */
_L4:
        f = 0.0F;
        f1 = f2 + 0.01F;
        continue; /* Loop/switch isn't completed */
_L6:
        f = mRootView.getRight();
        f1 = f2 - 0.01F;
        continue; /* Loop/switch isn't completed */
_L5:
        f = f3 - 0.01F;
        f1 = 0.0F;
        continue; /* Loop/switch isn't completed */
_L7:
        f = f3 + 0.01F;
        f1 = mRootView.getBottom();
        if (true) goto _L3; else goto _L8
_L8:
        mLastOrientation;
        JVM INSTR tableswitch 0 3: default 396
    //                   0 429
    //                   1 455
    //                   2 436
    //                   3 468;
           goto _L9 _L10 _L11 _L12 _L13
_L13:
        break MISSING_BLOCK_LABEL_468;
_L9:
        break; /* Loop/switch isn't completed */
_L10:
        break; /* Loop/switch isn't completed */
_L16:
        GLView glview2 = mRootView.findViewFromLeftMostTop(mLastOrientation, f, f1);
        if (glview2 != null)
        {
            glview2.requestFocus();
            mCurrentFocusedView = glview2;
            return true;
        }
        if (true) goto _L15; else goto _L14
_L14:
        f = 0.0F;
        f1 = 0.0F;
          goto _L16
_L12:
        f = mRootView.getRight();
        f1 = mRootView.getBottom();
          goto _L16
_L11:
        f = mRootView.getRight();
        f1 = 0.0F;
          goto _L16
        f = 0.0F;
        f1 = mRootView.getBottom();
          goto _L16
        if (true) goto _L18; else goto _L17
_L17:
    }

    public static boolean hasHardwareKeyPad()
    {
        Configuration configuration;
        if (mApplicationContext != null)
        {
            if ((configuration = mApplicationContext.getResources().getConfiguration()).keyboard == 3 && configuration.navigation == 2)
            {
                return true;
            }
        }
        return false;
    }

    public static boolean isGLSurfaceOrientationFixed()
    {
        return mGLSurfaceOrientationFixed;
    }

    public static boolean isScreenOrientationLandscape()
    {
        return false;
    }

    public static boolean isTalkBackEnabled()
    {
        if (mApplicationContext == null)
        {
            return false;
        }
        boolean flag = false;
        String s = android.provider.Settings.Secure.getString(mApplicationContext.getContentResolver(), "enabled_accessibility_services");
        if (s != null)
        {
            if (s.matches("(?i).*com.samsung.android.app.talkback.TalkBackService.*") || s.matches("(?i).*com.google.android.marvin.talkback.TalkBackService.*"))
            {
                flag = true;
            } else
            {
                flag = false;
            }
        }
        return flag;
    }

    public static void setFixedOrientation(boolean flag)
    {
        mGLSurfaceOrientationFixed = flag;
    }

    private void setLastOrientation(int i)
    {
        synchronized (mOrientationUpdateLock)
        {
            mLastOrientation = i;
        }
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public static void setOrientationCompensationValue(int i)
    {
        mOrientationCompensationValue = i;
    }

    private void setOrientationListener()
    {
        PackageManager packagemanager = mApplicationContext.getPackageManager();
        if (packagemanager != null && packagemanager.hasSystemFeature("com.sec.feature.sensorhub"))
        {
            mSemContextManager = (SemContextManager)mApplicationContext.getSystemService("scontext");
            if (mSemContextManager != null)
            {
                mIsSemContextListenerAvailable = mSemContextManager.isAvailableService(6);
            }
        }
        if (mIsSemContextListenerAvailable)
        {
            Log.i("GLContext", "using SemContextListener");
            return;
        } else
        {
            Log.i("GLContext", "using OrientationEventListener of android");
            mOrientationListener = new OrientationEventListener(mApplicationContext) {

                final GLContext this$0;

                public void onOrientationChanged(int i)
                {
                    if (i == -1)
                    {
                        Log.v("GLContext", "android onOrientationChanged - ORIENTATION_UNKNOWN");
                        return;
                    } else
                    {
                        handleOrientationChanged(i);
                        return;
                    }
                }

            
            {
                this$0 = GLContext.this;
                super(context);
            }
            };
            return;
        }
    }

    private void startFrameHandlerThread()
    {
        mFrameHandlerThread = new HandlerThread("GLContextFrameHandlerThread");
        mFrameHandlerThread.start();
        mFrameHandler = new Handler(mFrameHandlerThread.getLooper());
        mFrameHandler.post(new Runnable() {

            final GLContext this$0;

            public void run()
            {
                mChoreographer = Choreographer.getInstance();
            }

            
            {
                this$0 = GLContext.this;
                super();
            }
        });
    }

    private void updateScreenSize()
    {
        int i = 1;
        if (mGLSurfaceOrientationFixed)
        {
            if (mApplicationContext.getResources().getConfiguration().semMobileKeyboardCovered == 1)
            {
                int j = mApplicationContext.getResources().getDisplayMetrics().widthPixels;
                int k = mApplicationContext.getResources().getDisplayMetrics().heightPixels;
                if (j > k)
                {
                    mScreenWidth = j;
                    mScreenHeight = k;
                } else
                {
                    mScreenWidth = k;
                    mScreenHeight = j;
                }
            } else
            {
                Point point = new Point();
                ((WindowManager)mApplicationContext.getSystemService("window")).getDefaultDisplay().getRealSize(point);
                if (point.x >= point.y)
                {
                    mScreenWidth = point.x;
                    mScreenHeight = point.y;
                } else
                {
                    mScreenWidth = point.y;
                    mScreenHeight = point.x;
                }
            }
        } else
        {
            mScreenWidth = mWidth;
            mScreenHeight = mHeight;
        }
        j = mApplicationContext.getResources().getIdentifier("config_showNavigationBar", "bool", "android");
        if (mApplicationContext.getResources().getConfiguration().semMobileKeyboardCovered != 1)
        {
            i = 0;
        }
        if (j > 0 && mApplicationContext.getResources().getBoolean(j) && i == 0)
        {
            i = mApplicationContext.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
            mNavigatorHeight = mApplicationContext.getResources().getDimensionPixelSize(i);
        } else
        {
            mNavigatorHeight = 0;
        }
        Log.i("GLContext", (new StringBuilder()).append("updateScreenSize : w=").append(mScreenWidth).append(", h=").append(mScreenHeight).append(", navi h=").append(mNavigatorHeight).toString());
    }

    private void updateTouchExplorationEnabled()
    {
        boolean flag = true;
        if (mApplicationContext != null)
        {
            if (android.provider.Settings.Secure.getInt(mApplicationContext.getContentResolver(), "touch_exploration_enabled", 0) != 1)
            {
                flag = false;
            }
            mIsTouchExplorationEnabled = flag;
        }
    }

    public void addTextureToDelete(GLTexture gltexture)
    {
        synchronized (mDeleteTexturesLock)
        {
            mTexturesToDelete.add(gltexture);
        }
        return;
        gltexture;
        obj;
        JVM INSTR monitorexit ;
        throw gltexture;
    }

    public void clear()
    {
        if (mRootView != null)
        {
            mRootView.clear();
        }
        mRootView = null;
        mListener = null;
        synchronized (mDeleteTexturesLock)
        {
            mTexturesToDelete.clear();
        }
        mGLTextureStorage.clear();
        mGLTextureStorage = null;
        mHoverBaseView = null;
        mChoreographer = null;
        if (mFrameHandlerThread != null)
        {
            mFrameHandlerThread.quitSafely();
            mFrameHandlerThread = null;
        }
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void clearFocus()
    {
        if (mCurrentFocusedView != null)
        {
            mCurrentFocusedView.onFocusStatusChanged(0);
            mCurrentFocusedView = null;
        }
        if (mCurrentHoverFocusedView != null)
        {
            mCurrentHoverFocusedView.onHoverStatusChanged(1);
            mCurrentHoverFocusedView = null;
        }
        mIsFocusIndicatorVisible = false;
    }

    public void disableAccessibilityService(Context context)
    {
        boolean flag1;
label0:
        {
            if (!mIsAccessibilityServiceEnabled)
            {
                return;
            }
            SemLog.secV("GLContext", "disableAccessibilityService");
            android.text.TextUtils.SimpleStringSplitter simplestringsplitter = new android.text.TextUtils.SimpleStringSplitter(':');
            Object obj1 = getEnabledServicesFromSettings(context);
            Object obj = obj1;
            if (obj1 == Collections.emptySet())
            {
                obj = new HashSet();
            }
            obj1 = ComponentName.unflattenFromString("com.sec.android.app.camera/com.samsung.android.glview.AccessibilityGestureHandler");
            int j = 0;
            ((Set) (obj)).remove(obj1);
            obj1 = new HashSet();
            Iterator iterator = ((Set) (obj)).iterator();
            boolean flag;
            do
            {
                flag = j;
                if (!iterator.hasNext())
                {
                    break;
                }
                if (!((Set) (obj1)).contains((ComponentName)iterator.next()))
                {
                    continue;
                }
                flag = true;
                break;
            } while (true);
            obj1 = new StringBuilder();
            for (obj = ((Set) (obj)).iterator(); ((Iterator) (obj)).hasNext(); ((StringBuilder) (obj1)).append(':'))
            {
                ((StringBuilder) (obj1)).append(((ComponentName)((Iterator) (obj)).next()).flattenToString());
            }

            j = ((StringBuilder) (obj1)).length();
            if (j > 0)
            {
                ((StringBuilder) (obj1)).deleteCharAt(j - 1);
            }
            obj = ((StringBuilder) (obj1)).toString();
            android.provider.Settings.Secure.putString(context.getContentResolver(), "enabled_accessibility_services", ((String) (obj)));
            flag1 = flag;
            if (obj == null)
            {
                break label0;
            }
            simplestringsplitter.setString(((String) (obj)));
            do
            {
                flag1 = flag;
                if (!simplestringsplitter.hasNext())
                {
                    break label0;
                }
            } while (ComponentName.unflattenFromString(simplestringsplitter.next()) == null);
            flag1 = true;
        }
        if (GLUtil.isKNOXMode())
        {
            flag1 = false;
        }
        context = context.getContentResolver();
        int i;
        if (flag1)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        android.provider.Settings.Secure.putInt(context, "accessibility_enabled", i);
        LocalBroadcastManager.getInstance(mApplicationContext).unregisterReceiver(mHoverSwipeReceiver);
        LocalBroadcastManager.getInstance(mApplicationContext).unregisterReceiver(mAccViewFocusedReceiver);
        mIsAccessibilityServiceEnabled = false;
    }

    public void disableFocusNavigation()
    {
        mIsFocusNavigationEnabled = false;
    }

    public void doFrame(long l)
    {
        synchronized (mFrameLock)
        {
            mGLSurfaceView.requestRender();
            mRenderRequested = false;
        }
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void dumpViewHierarchy()
    {
        Log.w("GLContext", "=======================DUMP_START=======================");
        if (mRootView != null)
        {
            mRootView.dumpViewHierarchy(0);
        }
        Log.w("GLContext", "=======================DUMP_END=======================");
    }

    public void enableAccessibilityNode(boolean flag)
    {
        mIsAccessibilityNodeEnabled = flag;
    }

    public void enableAccessibilityService(Context context)
    {
        if (mIsAccessibilityServiceEnabled)
        {
            return;
        }
        mIsAccessibilityServiceEnabled = true;
        SemLog.secV("GLContext", "enableAccessibilityService");
        Object obj1 = getEnabledServicesFromSettings(context);
        Object obj = obj1;
        if (obj1 == Collections.emptySet())
        {
            obj = new HashSet();
        }
        ((Set) (obj)).add(ComponentName.unflattenFromString("com.sec.android.app.camera/com.samsung.android.glview.AccessibilityGestureHandler"));
        obj1 = new StringBuilder();
        for (obj = ((Set) (obj)).iterator(); ((Iterator) (obj)).hasNext(); ((StringBuilder) (obj1)).append(':'))
        {
            ((StringBuilder) (obj1)).append(((ComponentName)((Iterator) (obj)).next()).flattenToString());
        }

        int i = ((StringBuilder) (obj1)).length();
        if (i > 0)
        {
            ((StringBuilder) (obj1)).deleteCharAt(i - 1);
        }
        obj = ((StringBuilder) (obj1)).toString();
        android.provider.Settings.Secure.putString(context.getContentResolver(), "enabled_accessibility_services", ((String) (obj)));
        android.provider.Settings.Secure.putInt(context.getContentResolver(), "accessibility_enabled", 1);
        LocalBroadcastManager.getInstance(mApplicationContext).registerReceiver(mHoverSwipeReceiver, new IntentFilter("com.samsung.android.glview.ACCESSIBILITY_GESTURE_DETECTED"));
        LocalBroadcastManager.getInstance(mApplicationContext).registerReceiver(mAccViewFocusedReceiver, new IntentFilter("com.samsung.android.glview.ACTION_ACCESSIBILITY_VIEW_FOCUS_GONE"));
    }

    public void enableFocusNavigation()
    {
        mIsFocusNavigationEnabled = true;
    }

    protected void enableOrientationListener()
    {
        Log.d("GLContext", "enableOrientationListener");
        if (mIsSemContextListenerAvailable)
        {
            mSemContextManager.registerListener(this, 6);
            return;
        } else
        {
            mOrientationListener.enable();
            return;
        }
    }

    public void enableRippleEffect(boolean flag)
    {
        mRippleEffectEnabled = flag;
    }

    public GLView findNextFocusFromView(GLViewGroup glviewgroup, GLView glview, int i)
    {
        if (glviewgroup == null)
        {
            return mRootView.findNextFocusFromView(glview, i);
        } else
        {
            return glviewgroup.findNextFocusFromView(glview, i);
        }
    }

    public GLView findViewById(int i)
    {
        if (mRootView != null)
        {
            return mRootView.findViewById(i);
        } else
        {
            return null;
        }
    }

    public GLView findViewByObjectTag(String s)
    {
        if (mRootView != null)
        {
            return mRootView.findViewByObjectTag(s);
        } else
        {
            return null;
        }
    }

    public GLView findViewByTag(int i)
    {
        if (mRootView != null)
        {
            return mRootView.findViewByTag(i);
        } else
        {
            return null;
        }
    }

    public android.view.View.AccessibilityDelegate getAccessibilityDelegate()
    {
        return mAccessibilityDelegate;
    }

    public boolean getAlignToPixel()
    {
        return mAlignToPixel;
    }

    public float getDensity()
    {
        return mDensity;
    }

    public int getEstimatedFPS()
    {
        return mEstimatedFPS;
    }

    public int getFocusIndicatorColor()
    {
        return mFocusIndicatorColor;
    }

    public int getFocusIndicatorThickness()
    {
        return mFocusIndicatorThickness;
    }

    public GLPreviewData getGLPreviewData()
    {
        return mGLPreviewData;
    }

    public GLSurfaceView getGLSurfaceView()
    {
        return mGLSurfaceView;
    }

    public GLTextureStorage getGLTextureStorage()
    {
        return mGLTextureStorage;
    }

    public View getHoverBaseView()
    {
        return mHoverBaseView;
    }

    public int getHoverIndicatorColor()
    {
        return mHoverIndicatorColor;
    }

    public int getHoverIndicatorThickness()
    {
        return mHoverIndicatorThickness;
    }

    public GLView getLastHoverView()
    {
        return mLastHoverView;
    }

    public Handler getMainHandler()
    {
        return mMainHandler;
    }

    public GLProgramStorage getProgramStorage()
    {
        return mGLProgramStorage;
    }

    public float[] getProjMatrix()
    {
        return mProjMatrix;
    }

    public int getRippleEffectColor()
    {
        return mRippleEffectColor;
    }

    public GLViewGroup getRootView()
    {
        return mRootView;
    }

    public float getScreenAspectRatio()
    {
        return (float)mWidth / (float)mHeight;
    }

    protected final Rect getScreenGeometry()
    {
        return mClipRect;
    }

    public boolean getScrollBarAutoHide()
    {
        return mScrollBarAutoHide;
    }

    public TextToSpeech getTts()
    {
        if (mTts == null)
        {
            mTts = new TextToSpeech(mApplicationContext, this);
            mTts.setPitch((float)android.provider.Settings.Secure.getInt(mApplicationContext.getContentResolver(), "tts_default_pitch", 100) / 100F);
            mTts.setAudioAttributes((new android.media.AudioAttributes.Builder()).setUsage(11).setContentType(1).build());
        }
        return mTts;
    }

    public boolean isEnableAccessibilityNode()
    {
        if (mApplicationContext != null)
        {
            AccessibilityManager accessibilitymanager = (AccessibilityManager)mApplicationContext.getSystemService("accessibility");
            if (accessibilitymanager == null || !accessibilitymanager.isEnabled())
            {
                return false;
            }
        }
        return mIsAccessibilityNodeEnabled;
    }

    public boolean isFocusIndicatorVisible()
    {
        return mIsFocusIndicatorVisible;
    }

    public boolean isFocusNavigationEnabled()
    {
        return mIsFocusNavigationEnabled;
    }

    public boolean isHoveringEnabled()
    {
        return false;
    }

    public boolean isRippleEffectEnabled()
    {
        return mRippleEffectEnabled;
    }

    public boolean isShowButtonBackgroundEnabled()
    {
        return mShowButtonBackgroundEnabled;
    }

    public boolean isTouchExplorationEnabled()
    {
        return mIsTouchExplorationEnabled;
    }

    protected void notifyHoverEventChanged(GLView glview, MotionEvent motionevent)
    {
        Object obj = mObserversLock;
        obj;
        JVM INSTR monitorenter ;
        for (Iterator iterator = mObservers.iterator(); iterator.hasNext(); ((HoverEventChangedObserver)iterator.next()).onHoverEventChanged(glview, motionevent)) { }
        break MISSING_BLOCK_LABEL_53;
        glview;
        obj;
        JVM INSTR monitorexit ;
        throw glview;
        obj;
        JVM INSTR monitorexit ;
    }

    public void onDrawFrame(GL10 gl10)
    {
        while (GLES20.glGetError() != 0) ;
        gl10 = ((GL10) (mDeleteTexturesLock));
        gl10;
        JVM INSTR monitorenter ;
        for (Iterator iterator = mTexturesToDelete.iterator(); iterator.hasNext(); ((GLTexture)iterator.next()).clearTexture()) { }
        break MISSING_BLOCK_LABEL_50;
        Exception exception;
        exception;
        gl10;
        JVM INSTR monitorexit ;
        throw exception;
        mTexturesToDelete.clear();
        gl10;
        JVM INSTR monitorexit ;
        if (!mPaused)
        {
            mDirty = false;
            GLES20.glClear(16640);
            long l = System.currentTimeMillis();
            long l1 = l - mPrevFrameTimeStamp;
            if (mPrevFrameTimeStamp != 0L && l1 < 100L)
            {
                mFrameCountForFPS = mFrameCountForFPS + 1L;
                mAccumulatedTime = mAccumulatedTime + l1;
                if (mAccumulatedTime != 0L)
                {
                    mEstimatedFPS = (int)((1000L * mFrameCountForFPS) / mAccumulatedTime);
                }
            }
            mPrevFrameTimeStamp = l;
            l1 = mFrameNum + 1L;
            mFrameNum = l1;
            if (l1 < 5L)
            {
                l = System.currentTimeMillis();
                Log.e("GLContext", (new StringBuilder()).append("Start drawing frame #").append(mFrameNum).toString());
            }
            if (mRootView != null)
            {
                mRootView.draw(mIdentityMatrix, mClipRect);
            }
            if (mFrameNum < 5L)
            {
                Log.e("GLContext", (new StringBuilder()).append("End drawing frame #").append(mFrameNum).append(" Elapsed time: ").append(System.currentTimeMillis() - l).append("ms").toString());
                return;
            }
        }
        return;
    }

    public void onFocusChanged(GLView glview)
    {
        if (mCurrentFocusedView != null)
        {
            mCurrentFocusedView.onFocusStatusChanged(0);
        }
        if (glview != null)
        {
            glview.onFocusStatusChanged(1);
        }
        mCurrentFocusedView = glview;
        if (isTouchExplorationEnabled())
        {
            if (glview == null)
            {
                if (mCurrentHoverFocusedView != null)
                {
                    mCurrentHoverFocusedView.onHoverStatusChanged(1);
                }
                mCurrentHoverFocusedView = glview;
            } else
            {
                onHoverChanged(glview, null);
            }
        }
        setDirty(true);
    }

    public boolean onHover(View view, MotionEvent motionevent)
    {
        while (!isFocusNavigationEnabled() || mApplicationContext.getApplicationContext() == null) 
        {
            return false;
        }
        return onHoverEvent(motionevent, mLastOrientation);
    }

    public void onHoverChanged(GLView glview, MotionEvent motionevent)
    {
        if (glview != null && mApplicationContext != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (!isTalkBackEnabled() || !mIsTouchExplorationEnabled)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!glview.isFocusable()) goto _L1; else goto _L3
_L3:
        if (mCurrentHoverFocusedView != null)
        {
            mCurrentHoverFocusedView.onHoverStatusChanged(1);
        }
        glview.onHoverStatusChanged(0);
        if (mAccNode != null)
        {
            mAccNode.performAction(128);
            mAccNode.recycle();
            mAccNode = null;
        }
        if (glview.getVisibility() != 4 && getTts() != null)
        {
            getTts().speak(glview.getTtsString(), 0, null, null);
            ((Vibrator)mApplicationContext.getSystemService("vibrator")).semVibrate(50025, -1, null, android.os.Vibrator.SemMagnitudeTypes.TYPE_TOUCH);
        }
        mCurrentHoverFocusedView = glview;
        mLastHoverView = glview;
        setDirty(true);
        return;
        if (!isHoveringEnabled()) goto _L1; else goto _L4
_L4:
        if (mCurrentHoverFocusedView != null)
        {
            mCurrentHoverFocusedView.onHoverStatusChanged(1);
        }
        glview.onHoverStatusChanged(0);
        mCurrentHoverFocusedView = glview;
        return;
    }

    public boolean onHoverEvent(MotionEvent motionevent, int i)
    {
        if (android.os.Build.VERSION.SEM_INT <= 2403)
        {
            if ((SemDesktopModeManager)getApplicationContext().getSystemService("desktopmode") == null || !SemDesktopModeManager.isDesktopMode())
            {
                GLUtil.transformEventByGLOrientation(motionevent, i, mWidth, mHeight);
            }
        } else
        if (getApplicationContext().getResources().getConfiguration().semDesktopModeEnabled != 1)
        {
            GLUtil.transformEventByGLOrientation(motionevent, i, mWidth, mHeight);
        }
        if (mRootView == null) goto _L2; else goto _L1
_L1:
        if (motionevent.getAction() != 9) goto _L4; else goto _L3
_L3:
        mLastHoverView = mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY());
        if (mLastHoverView != null)
        {
            notifyHoverEventChanged(mLastHoverView, motionevent);
            onHoverChanged(mLastHoverView, motionevent);
        } else
        if (isTouchExplorationEnabled() && mCurrentHoverFocusedView != null)
        {
            mCurrentHoverFocusedView.onHoverStatusChanged(1);
        }
_L2:
        if (mLastHoverView != null)
        {
            if (!mLastHoverView.isClickable());
        }
_L6:
        return true;
_L4:
        if (motionevent.getAction() != 7)
        {
            break; /* Loop/switch isn't completed */
        }
        GLView glview = mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY());
        if (glview != mLastHoverView)
        {
            mLastHoverView = glview;
            if (mLastHoverView != null)
            {
                onHoverChanged(mLastHoverView, motionevent);
            } else
            if (isHoveringEnabled() && mCurrentHoverFocusedView != null)
            {
                mCurrentHoverFocusedView.onHoverStatusChanged(1);
            }
            continue; /* Loop/switch isn't completed */
        }
        if (true) goto _L6; else goto _L5
_L5:
        if (motionevent.getAction() == 10)
        {
            if (isHoveringEnabled())
            {
                if (mCurrentHoverFocusedView != null)
                {
                    mCurrentHoverFocusedView.onHoverStatusChanged(1);
                }
            } else
            if (mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY()) == null && isTouchExplorationEnabled())
            {
                motionevent = MotionEvent.obtain(motionevent);
                notifyHoverEventChanged(null, motionevent);
                motionevent.recycle();
            }
        }
        if (true) goto _L2; else goto _L7
_L7:
    }

    public void onHoverSwipeEvent(int i)
    {
        if (mCurrentHoverFocusedView != null) goto _L2; else goto _L1
_L1:
        i;
        JVM INSTR lookupswitch 4: default 52
    //                   49: 110
    //                   65: 110
    //                   82: 110
    //                   98: 110;
           goto _L2 _L3 _L3 _L3 _L3
_L2:
        if (mCurrentHoverFocusedView == null) goto _L5; else goto _L4
_L4:
        i;
        JVM INSTR lookupswitch 4: default 104
    //                   49: 130
    //                   65: 339
    //                   82: 443
    //                   98: 235;
           goto _L6 _L7 _L8 _L9 _L10
_L5:
        setDirty(true);
        return;
_L3:
        if (mRootView != null)
        {
            mRootView.requestFocus(82);
        }
        continue; /* Loop/switch isn't completed */
_L7:
        switch (mLastOrientation)
        {
        case 0: // '\0'
            mCurrentHoverFocusedView.requestFocus(49, mCurrentHoverFocusedView);
            break;

        case 2: // '\002'
            mCurrentHoverFocusedView.requestFocus(98, mCurrentHoverFocusedView);
            break;

        case 1: // '\001'
            mCurrentHoverFocusedView.requestFocus(65, mCurrentHoverFocusedView);
            break;

        case 3: // '\003'
            mCurrentHoverFocusedView.requestFocus(82, mCurrentHoverFocusedView);
            break;
        }
_L6:
        if (true) goto _L5; else goto _L11
_L11:
_L10:
        switch (mLastOrientation)
        {
        case 0: // '\0'
            mCurrentHoverFocusedView.requestFocus(98, mCurrentHoverFocusedView);
            break;

        case 2: // '\002'
            mCurrentHoverFocusedView.requestFocus(49, mCurrentHoverFocusedView);
            break;

        case 1: // '\001'
            mCurrentHoverFocusedView.requestFocus(82, mCurrentHoverFocusedView);
            break;

        case 3: // '\003'
            mCurrentHoverFocusedView.requestFocus(65, mCurrentHoverFocusedView);
            break;
        }
        if (true) goto _L5; else goto _L12
_L12:
_L8:
        switch (mLastOrientation)
        {
        case 0: // '\0'
            mCurrentHoverFocusedView.requestFocus(65, mCurrentHoverFocusedView);
            break;

        case 2: // '\002'
            mCurrentHoverFocusedView.requestFocus(82, mCurrentHoverFocusedView);
            break;

        case 1: // '\001'
            mCurrentHoverFocusedView.requestFocus(98, mCurrentHoverFocusedView);
            break;

        case 3: // '\003'
            mCurrentHoverFocusedView.requestFocus(49, mCurrentHoverFocusedView);
            break;
        }
        if (true) goto _L5; else goto _L13
_L13:
_L9:
        switch (mLastOrientation)
        {
        case 0: // '\0'
            mCurrentHoverFocusedView.requestFocus(82, mCurrentHoverFocusedView);
            break;

        case 2: // '\002'
            mCurrentHoverFocusedView.requestFocus(65, mCurrentHoverFocusedView);
            break;

        case 1: // '\001'
            mCurrentHoverFocusedView.requestFocus(49, mCurrentHoverFocusedView);
            break;

        case 3: // '\003'
            mCurrentHoverFocusedView.requestFocus(98, mCurrentHoverFocusedView);
            break;
        }
        if (true) goto _L5; else goto _L14
_L14:
        if (true) goto _L2; else goto _L15
_L15:
    }

    public boolean onHoverTouchEvent(MotionEvent motionevent)
    {
        if (!mPaused) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        int i = motionevent.getActionMasked();
        if (mCurrentHoverFocusedView == null || mCurrentHoverFocusedView.isVisible() != 0 || !mCurrentHoverFocusedView.getClass().equals(com/samsung/android/glview/GLSlider)) goto _L4; else goto _L3
_L3:
        if (!mCurrentHoverFocusedView.equals(mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY()))) goto _L6; else goto _L5
_L5:
        onTouchEvent(motionevent);
_L7:
        return true;
_L6:
        if (i == 1)
        {
            onTouchEvent(motionevent);
        }
        if (true) goto _L7; else goto _L4
_L4:
        if (i == 0)
        {
            mLastMotionEvent = MotionEvent.obtain(motionevent);
            return false;
        }
        if (i == 2)
        {
            if (mLastMotionEvent != null && mLastMotionEvent.getAction() == 0)
            {
                onTouchEvent(mLastMotionEvent);
            }
            onTouchEvent(motionevent);
            mLastMotionEvent = MotionEvent.obtain(motionevent);
            if (mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY()) == null)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                return true;
            }
        } else
        {
            if (i == 1)
            {
                if (mLastMotionEvent == null)
                {
                    onTouchEvent(motionevent);
                    return true;
                }
                if (mLastMotionEvent.getAction() == 0)
                {
                    if (mCurrentHoverFocusedView != null && mCurrentHoverFocusedView.isVisible() == 0 && mLastHoverView != null)
                    {
                        float f = (mCurrentHoverFocusedView.getClipRectArea().left + mCurrentHoverFocusedView.getClipRectArea().right) / 2.0F;
                        float f1 = (mCurrentHoverFocusedView.getClipRectArea().top + mCurrentHoverFocusedView.getClipRectArea().bottom) / 2.0F;
                        mLastMotionEvent.setLocation(f, f1);
                        motionevent.setLocation(f, f1);
                        onTouchEvent(mLastMotionEvent);
                        onTouchEvent(motionevent);
                        mLastMotionEvent.recycle();
                        mLastMotionEvent = null;
                        return true;
                    } else
                    {
                        mLastMotionEvent.recycle();
                        mLastMotionEvent = null;
                        return false;
                    }
                } else
                {
                    onTouchEvent(motionevent);
                    return false;
                }
            }
            if (i == 6)
            {
                mLastMotionEvent = MotionEvent.obtain(motionevent);
                return false;
            } else
            {
                mLastMotionEvent = MotionEvent.obtain(motionevent);
                return true;
            }
        }
        if (true) goto _L1; else goto _L8
_L8:
    }

    public void onInit(int i)
    {
    }

    public boolean onKeyDown(int i, KeyEvent keyevent)
    {
        boolean flag2;
        boolean flag3;
        boolean flag4;
        if (mPaused || !isFocusNavigationEnabled())
        {
            return false;
        }
        flag3 = false;
        flag2 = false;
        flag4 = false;
        if (mCurrentFocusedView != null) goto _L2; else goto _L1
_L1:
        i;
        JVM INSTR lookupswitch 8: default 108
    //                   19: 484
    //                   20: 484
    //                   21: 484
    //                   22: 484
    //                   23: 484
    //                   61: 484
    //                   62: 484
    //                   66: 484;
           goto _L2 _L3 _L3 _L3 _L3 _L3 _L3 _L3 _L3
_L2:
        if (mCurrentFocusedView == null) goto _L5; else goto _L4
_L4:
        if (mIsFocusIndicatorVisible) goto _L7; else goto _L6
_L6:
        i;
        JVM INSTR lookupswitch 8: default 196
    //                   19: 508
    //                   20: 508
    //                   21: 508
    //                   22: 508
    //                   23: 508
    //                   61: 508
    //                   62: 508
    //                   66: 508;
           goto _L7 _L8 _L8 _L8 _L8 _L8 _L8 _L8 _L8
_L7:
        boolean flag;
        boolean flag1;
        flag2 = mCurrentFocusedView.keyDownEvent(i, keyevent);
        flag1 = flag4;
        flag = flag2;
        if (flag2) goto _L10; else goto _L9
_L9:
        i;
        JVM INSTR lookupswitch 7: default 288
    //                   19: 871
    //                   20: 1027
    //                   21: 560
    //                   22: 715
    //                   23: 558
    //                   61: 546
    //                   62: 525;
           goto _L11 _L12 _L13 _L14 _L15 _L16 _L17 _L18
_L11:
        flag = flag2;
        flag1 = flag4;
_L10:
        flag2 = flag1;
        flag3 = flag;
        if (mCurrentFocusedView.isVisible() != 4) goto _L5; else goto _L19
_L19:
        i;
        JVM INSTR lookupswitch 8: default 388
    //                   19: 1183
    //                   20: 1183
    //                   21: 1183
    //                   22: 1183
    //                   23: 1183
    //                   61: 1183
    //                   62: 1183
    //                   66: 1183;
           goto _L20 _L21 _L21 _L21 _L21 _L21 _L21 _L21 _L21
_L20:
        flag3 = flag;
        flag2 = flag1;
_L5:
        if (!flag3 && !flag2) goto _L23; else goto _L22
_L22:
        keyevent = (AudioManager)mApplicationContext.getSystemService("audio");
        i;
        JVM INSTR lookupswitch 6: default 476
    //                   19: 1238
    //                   20: 1246
    //                   21: 1222
    //                   22: 1230
    //                   61: 1254
    //                   62: 1270;
           goto _L23 _L24 _L25 _L26 _L27 _L28 _L29
_L23:
        setDirty(true);
        return flag3;
_L3:
        if (mRootView.requestFocus())
        {
            mIsFocusIndicatorVisible = true;
            mFocusIndicatorVisibilityChanged = true;
            return false;
        } else
        {
            return false;
        }
_L8:
        mIsFocusIndicatorVisible = true;
        mFocusIndicatorVisibilityChanged = true;
        setDirty(true);
        return true;
_L18:
        mTapDir = (mTapDir + 1) % 2;
        flag1 = true;
        flag = flag2;
          goto _L10
_L17:
        flag1 = handlingKeyEventTap();
        flag = flag2;
          goto _L10
_L16:
        return true;
_L14:
        if (mGLSurfaceOrientationFixed) goto _L31; else goto _L30
_L30:
        flag = mCurrentFocusedView.requestFocus(17, mCurrentFocusedView);
        flag1 = flag4;
          goto _L10
_L31:
        switch (mLastOrientation)
        {
        default:
            flag1 = flag4;
            flag = flag2;
            break;

        case 0: // '\0'
            flag = mCurrentFocusedView.requestFocus(17, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 2: // '\002'
            flag = mCurrentFocusedView.requestFocus(66, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 1: // '\001'
            flag = mCurrentFocusedView.requestFocus(33, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 3: // '\003'
            flag = mCurrentFocusedView.requestFocus(130, mCurrentFocusedView);
            flag1 = flag4;
            break;
        }
        if (true) goto _L10; else goto _L32
_L32:
_L15:
        if (mGLSurfaceOrientationFixed) goto _L34; else goto _L33
_L33:
        flag = mCurrentFocusedView.requestFocus(66, mCurrentFocusedView);
        flag1 = flag4;
          goto _L10
_L34:
        switch (mLastOrientation)
        {
        default:
            flag1 = flag4;
            flag = flag2;
            break;

        case 0: // '\0'
            flag = mCurrentFocusedView.requestFocus(66, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 2: // '\002'
            flag = mCurrentFocusedView.requestFocus(17, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 1: // '\001'
            flag = mCurrentFocusedView.requestFocus(130, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 3: // '\003'
            flag = mCurrentFocusedView.requestFocus(33, mCurrentFocusedView);
            flag1 = flag4;
            break;
        }
        if (true) goto _L10; else goto _L35
_L35:
_L12:
        if (mGLSurfaceOrientationFixed) goto _L37; else goto _L36
_L36:
        flag = mCurrentFocusedView.requestFocus(33, mCurrentFocusedView);
        flag1 = flag4;
          goto _L10
_L37:
        switch (mLastOrientation)
        {
        default:
            flag1 = flag4;
            flag = flag2;
            break;

        case 0: // '\0'
            flag = mCurrentFocusedView.requestFocus(33, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 2: // '\002'
            flag = mCurrentFocusedView.requestFocus(130, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 1: // '\001'
            flag = mCurrentFocusedView.requestFocus(66, mCurrentFocusedView);
            flag1 = flag4;
            break;

        case 3: // '\003'
            flag = mCurrentFocusedView.requestFocus(17, mCurrentFocusedView);
            flag1 = flag4;
            break;
        }
        if (true) goto _L10; else goto _L38
_L38:
_L13:
        if (!mGLSurfaceOrientationFixed)
        {
            flag = mCurrentFocusedView.requestFocus(130, mCurrentFocusedView);
            flag1 = flag4;
        } else
        {
            switch (mLastOrientation)
            {
            default:
                flag1 = flag4;
                flag = flag2;
                break;

            case 0: // '\0'
                flag = mCurrentFocusedView.requestFocus(130, mCurrentFocusedView);
                flag1 = flag4;
                break;

            case 2: // '\002'
                flag = mCurrentFocusedView.requestFocus(33, mCurrentFocusedView);
                flag1 = flag4;
                break;

            case 1: // '\001'
                flag = mCurrentFocusedView.requestFocus(17, mCurrentFocusedView);
                flag1 = flag4;
                break;

            case 3: // '\003'
                flag = mCurrentFocusedView.requestFocus(66, mCurrentFocusedView);
                flag1 = flag4;
                break;
            }
            continue; /* Loop/switch isn't completed */
        }
          goto _L10
_L21:
        keyevent = mRootView.findViewFromLeftMostTop();
        flag2 = flag1;
        flag3 = flag;
        if (keyevent != null)
        {
            keyevent.requestFocus();
            mCurrentFocusedView = keyevent;
            flag2 = flag1;
            flag3 = flag;
        }
          goto _L5
_L26:
        keyevent.playSoundEffect(3);
          goto _L23
_L27:
        keyevent.playSoundEffect(4);
          goto _L23
_L24:
        keyevent.playSoundEffect(1);
          goto _L23
_L25:
        keyevent.playSoundEffect(2);
          goto _L23
_L28:
        if (flag2)
        {
            keyevent.playSoundEffect(getAudioSoundOfTapDirection());
        }
          goto _L23
_L29:
        keyevent.playSoundEffect(0);
          goto _L23
        if (true) goto _L10; else goto _L39
_L39:
    }

    public boolean onKeyUp(int i, KeyEvent keyevent)
    {
        boolean flag;
        if (mPaused || !isFocusNavigationEnabled())
        {
            return false;
        }
        flag = false;
        if (!hasHardwareKeyPad()) goto _L2; else goto _L1
_L1:
        if (mCurrentFocusedView != null) goto _L4; else goto _L3
_L3:
        i;
        JVM INSTR lookupswitch 8: default 108
    //                   19: 243
    //                   20: 243
    //                   21: 243
    //                   22: 243
    //                   23: 243
    //                   61: 243
    //                   62: 243
    //                   66: 243;
           goto _L4 _L5 _L5 _L5 _L5 _L5 _L5 _L5 _L5
_L4:
        if (mCurrentFocusedView == null || mIsFocusIndicatorVisible) goto _L7; else goto _L6
_L6:
        i;
        JVM INSTR lookupswitch 8: default 196
    //                   19: 267
    //                   20: 267
    //                   21: 267
    //                   22: 267
    //                   23: 267
    //                   61: 267
    //                   62: 267
    //                   66: 267;
           goto _L7 _L8 _L8 _L8 _L8 _L8 _L8 _L8 _L8
_L7:
        if (mCurrentFocusedView != null)
        {
            flag = mCurrentFocusedView.keyUpEvent(i, keyevent);
        }
        if (flag) goto _L10; else goto _L9
_L9:
        i;
        JVM INSTR tableswitch 32 32: default 236
    //                   32 298;
           goto _L10 _L11
_L10:
        setDirty(true);
        return flag;
_L5:
        if (mRootView.requestFocus())
        {
            mIsFocusIndicatorVisible = true;
            mFocusIndicatorVisibilityChanged = true;
            return false;
        } else
        {
            return false;
        }
_L8:
        mIsFocusIndicatorVisible = true;
        mFocusIndicatorVisibilityChanged = true;
        setDirty(true);
        return true;
_L2:
        if (mFocusIndicatorVisibilityChanged)
        {
            mFocusIndicatorVisibilityChanged = false;
            return false;
        }
          goto _L7
_L11:
        dumpViewHierarchy();
          goto _L10
    }

    public void onPause()
    {
        mPaused = true;
        mChoreographer.removeFrameCallback(this);
        disableAccessibilityService(mApplicationContext);
        if (!mGLSurfaceView.getPreserveEGLContextOnPause())
        {
            synchronized (mDeleteTexturesLock)
            {
                mTexturesToDelete.clear();
            }
            GLProgramStorage.releaseInstance(mGLProgramStorage);
            if (mRootView != null)
            {
                mRootView.reset();
            }
        }
        GLPreviewData.releaseInstance();
        if (mMainHandlerThread != null)
        {
            mMainHandlerThread.quitSafely();
            mMainHandlerThread = null;
        }
        if (mTts != null)
        {
            mTts.stop();
            mTts.shutdown();
            mTts = null;
        }
        mFrameNum = 0L;
        mFrameCountForFPS = 0L;
        mAccumulatedTime = 0L;
        mHoverBaseView.setOnHoverListener(null);
        disableOrientationListener();
        mApplicationContext.getContentResolver().unregisterContentObserver(mTouchExplorationEnabledContentObserver);
        mApplicationContext.getContentResolver().unregisterContentObserver(mEnabledAccessibilityServicesContentObserver);
        mApplicationContext.getContentResolver().unregisterContentObserver(mSettingInteractionControlObserver);
        mApplicationContext.getContentResolver().unregisterContentObserver(mCursorColorObserver);
        mApplicationContext.getContentResolver().unregisterContentObserver(mDisplaySizeObserver);
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void onResume()
    {
        updateScreenSize();
        mMainHandlerThread = new HandlerThread("GLContextHandlerThread");
        mMainHandlerThread.start();
        mMainHandler = new Handler(mMainHandlerThread.getLooper());
        mRenderRequested = false;
        mPaused = false;
        if (mResources.getConfiguration().semMobileKeyboardCovered != 1 && android.provider.Settings.System.getInt(mApplicationContext.getContentResolver(), "access_control_enabled", 0) == 0)
        {
            enableOrientationListener();
        }
        mHoverBaseView.setOnHoverListener(this);
        if (android.provider.Settings.Secure.getInt(mApplicationContext.getContentResolver(), "accessibility_enabled", 0) == 1 && android.provider.Settings.Secure.getString(mApplicationContext.getContentResolver(), "enabled_accessibility_services") != null && android.provider.Settings.Secure.getString(mApplicationContext.getContentResolver(), "enabled_accessibility_services").matches("(?i).*talkback.*"))
        {
            mTts = new TextToSpeech(mApplicationContext, this);
            mTts.setPitch((float)android.provider.Settings.Secure.getInt(mApplicationContext.getContentResolver(), "tts_default_pitch", 100) / 100F);
            mTts.setAudioAttributes((new android.media.AudioAttributes.Builder()).setUsage(11).setContentType(1).build());
        }
        if (mGLSurfaceView != null)
        {
            mGLSurfaceView.requestRender();
        }
        updateTouchExplorationEnabled();
        if (mIsTouchExplorationEnabled)
        {
            enableAccessibilityService(mApplicationContext);
        }
        android.net.Uri uri = android.provider.Settings.Secure.getUriFor("touch_exploration_enabled");
        if (uri != null)
        {
            mApplicationContext.getContentResolver().registerContentObserver(uri, true, mTouchExplorationEnabledContentObserver);
        }
        uri = android.provider.Settings.Secure.getUriFor("enabled_accessibility_services");
        if (uri != null)
        {
            mApplicationContext.getContentResolver().registerContentObserver(uri, true, mEnabledAccessibilityServicesContentObserver);
        }
        uri = android.provider.Settings.System.getUriFor("access_control_enabled");
        if (uri != null)
        {
            mApplicationContext.getContentResolver().registerContentObserver(uri, true, mSettingInteractionControlObserver);
        }
        uri = android.provider.Settings.Secure.getUriFor("accessibility_cursor_color");
        if (uri != null)
        {
            mApplicationContext.getContentResolver().registerContentObserver(uri, true, mCursorColorObserver);
        }
        if (mHoverIndicatorColor != android.provider.Settings.Secure.getInt(getApplicationContext().getContentResolver(), "accessibility_cursor_color", FOCUS_INDICATOR_DEFAULT_COLOR))
        {
            mHoverIndicatorColor = android.provider.Settings.Secure.getInt(getApplicationContext().getContentResolver(), "accessibility_cursor_color", FOCUS_INDICATOR_DEFAULT_COLOR);
            mCursorColorObserver.onChange(false);
        }
        if (android.provider.Settings.System.getInt(mApplicationContext.getContentResolver(), "show_button_background", 0) == 1)
        {
            mShowButtonBackgroundEnabled = true;
        }
        uri = android.provider.Settings.Global.getUriFor("display_size_forced");
        if (uri != null)
        {
            mApplicationContext.getContentResolver().registerContentObserver(uri, true, mDisplaySizeObserver);
        }
    }

    public void onSemContextChanged(SemContextEvent semcontextevent)
    {
        int i;
        int j;
        if (mPaused)
        {
            return;
        }
        switch (semcontextevent.semContext.getType())
        {
        default:
            return;

        case 6: // '\006'
            j = semcontextevent.getAutoRotationContext().getAngle();
            break;
        }
        Log.d("GLContext", (new StringBuilder()).append("onSemContextChanged - angle : ").append(j).toString());
        i = 0;
        j;
        JVM INSTR tableswitch -1 3: default 104
    //                   -1 136
    //                   0 141
    //                   1 146
    //                   2 153
    //                   3 160;
           goto _L1 _L2 _L3 _L4 _L5 _L6
_L1:
        Log.d("GLContext", (new StringBuilder()).append("This value is not defined : ").append(j).toString());
_L8:
        handleOrientationChanged(i);
        return;
_L2:
        i = -1;
        continue; /* Loop/switch isn't completed */
_L3:
        i = 0;
        continue; /* Loop/switch isn't completed */
_L4:
        i = 270;
        continue; /* Loop/switch isn't completed */
_L5:
        i = 180;
        continue; /* Loop/switch isn't completed */
_L6:
        i = 90;
        if (true) goto _L8; else goto _L7
_L7:
    }

    public void onSurfaceChanged(GL10 gl10, int i, int j)
    {
        SemLog.secV("GLContext", (new StringBuilder()).append("onSurfaceChanged width=").append(i).append(" height=").append(j).toString());
        Log.e("AXLOG", (new StringBuilder()).append("GLSurfaceChanged**EndU[").append(System.currentTimeMillis()).append("]**").toString());
        mWidth = i;
        mHeight = j;
        updateScreenSize();
        Matrix.orthoM(mProjMatrix, 0, 0.0F, mWidth, mHeight, 0.0F, -mWidth, mWidth);
        GLES20.glViewport(0, 0, i, j);
        mClipRect.set(0, 0, i, j);
        if (mRootView != null)
        {
            mRootView.setSize(i, j);
            mRootView.refreshClipRect();
        }
        if (mListener != null && mRootView != null)
        {
            mListener.onGLInitialized(mRootView);
        }
        setDirty(true);
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eglconfig)
    {
        SemLog.secV("GLContext", "onSurfaceCreated");
        GLES20.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
        GLES20.glEnable(3089);
        GLES20.glEnable(3042);
        GLES20.glBlendFunc(1, 771);
        GLES20.glClearDepthf(1.0F);
        GLES20.glEnable(2929);
        GLES20.glDepthFunc(515);
        mGLPreviewData = GLPreviewData.getInstance(this);
        mGLProgramStorage = GLProgramStorage.getInstance();
        mGLProgramStorage.addProgram(1001);
        mGLProgramStorage.addProgram(1002);
        mGLProgramStorage.addProgram(1003);
        mGLProgramStorage.addProgram(1005);
        mGLProgramStorage.addProgram(1006);
        mGLProgramStorage.addProgram(1007);
        mGLProgramStorage.addProgram(1004);
        mGLProgramStorage.addProgram(1008);
        mGLProgramStorage.addProgram(1009);
        mGLProgramStorage.addProgram(1010);
        if (mRootView == null)
        {
            mRootView = new GLViewGroup(this, 0.0F, 0.0F);
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        boolean flag;
        boolean flag1;
        if (mPaused)
        {
            motionevent.setAction(3);
        }
        flag1 = false;
        if (!isTouchExplorationEnabled())
        {
            mIsFocusIndicatorVisible = false;
        }
        flag = flag1;
        if (mRootView == null) goto _L2; else goto _L1
_L1:
        if (motionevent.getAction() != 0) goto _L4; else goto _L3
_L3:
        mLastTouchView = mRootView.findViewByCoordinate(motionevent.getX(), motionevent.getY());
        flag = flag1;
        if (mLastTouchView != null)
        {
            if (isTalkBackEnabled() && mIsTouchExplorationEnabled)
            {
                flag = flag1;
                if (mCurrentHoverFocusedView != null)
                {
                    flag = mLastTouchView.touchEvent(motionevent);
                }
            } else
            {
                flag = mLastTouchView.touchEvent(motionevent);
            }
        }
_L2:
        setDirty(true);
        return flag;
_L4:
        if (motionevent.getAction() == 1)
        {
            flag = flag1;
            if (mLastTouchView != null)
            {
                flag = flag1;
                if (mLastTouchView.isVisible() == 0)
                {
                    if (isTalkBackEnabled() && mIsTouchExplorationEnabled)
                    {
                        flag = flag1;
                        if (mCurrentHoverFocusedView != null)
                        {
                            flag = mLastTouchView.touchEvent(motionevent);
                            mLastTouchView = null;
                        }
                    } else
                    {
                        flag = mLastTouchView.touchEvent(motionevent);
                        mLastTouchView = null;
                    }
                }
            }
        } else
        {
            flag = flag1;
            if (mLastTouchView != null)
            {
                flag = flag1;
                if (mLastTouchView.isVisible() == 0)
                {
                    if (isTalkBackEnabled() && mIsTouchExplorationEnabled)
                    {
                        flag = flag1;
                        if (mCurrentHoverFocusedView != null)
                        {
                            flag = mLastTouchView.touchEvent(motionevent);
                        }
                    } else
                    {
                        flag = mLastTouchView.touchEvent(motionevent);
                    }
                }
            }
        }
        if (true) goto _L2; else goto _L5
_L5:
    }

    public void queueGLEvent(Runnable runnable)
    {
        mGLSurfaceView.queueEvent(runnable);
    }

    public void refreshOrientation()
    {
        if (mRootView != null && mAutoOrientationStatus)
        {
            mRootView.onOrientationChanged(mLastOrientation);
            setDirty(true);
        }
    }

    public void registerHoverEventChangedObserver(HoverEventChangedObserver hovereventchangedobserver)
    {
        synchronized (mObserversLock)
        {
            mObservers.add(hovereventchangedobserver);
        }
        return;
        hovereventchangedobserver;
        obj;
        JVM INSTR monitorexit ;
        throw hovereventchangedobserver;
    }

    public void rotationFocusView()
    {
        if (mCurrentFocusedView != null)
        {
            mCurrentFocusedView.onFocusStatusChanged(1);
        }
        if (isTouchExplorationEnabled() && mCurrentHoverFocusedView != null)
        {
            mCurrentHoverFocusedView.onHoverStatusChanged(0);
        }
    }

    public void setAlignToPixel(boolean flag)
    {
        mAlignToPixel = flag;
    }

    public void setDirty(boolean flag)
    {
label0:
        {
            synchronized (mFrameLock)
            {
                if (!mPaused)
                {
                    break label0;
                }
            }
            return;
        }
        mDirty = flag;
        if (mChoreographer != null && mDirty && !mRenderRequested && mGLSurfaceView.getRenderMode() == 0)
        {
            mChoreographer.postFrameCallback(this);
            mRenderRequested = true;
        }
        obj;
        JVM INSTR monitorexit ;
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void setFirstOrientation(int i)
    {
        setLastOrientation(GLUtil.getGLOrientationByDisplayOrientation(i));
        if (mRootView != null)
        {
            mRootView.onOrientationChanged(mLastOrientation);
        }
    }

    public void setHoverBaseView(View view)
    {
        mHoverBaseView = view;
    }

    public void setPreviewData(int i, int j, byte abyte0[])
    {
        this;
        JVM INSTR monitorenter ;
        if (mGLPreviewData == null || abyte0 == null)
        {
            break MISSING_BLOCK_LABEL_23;
        }
        mGLPreviewData.setPreviewData(i, j, abyte0);
        this;
        JVM INSTR monitorexit ;
        return;
        abyte0;
        throw abyte0;
    }

    public void setRenderMode(int i)
    {
        mGLSurfaceView.setRenderMode(i);
    }

    public void setRippleEffectColor(int i)
    {
        mRippleEffectColor = i;
    }

    public void setScrollBarAutoHide(boolean flag)
    {
        mScrollBarAutoHide = flag;
    }

    public void unregisterHoverEventChangedObserver(HoverEventChangedObserver hovereventchangedobserver)
    {
        synchronized (mObserversLock)
        {
            mObservers.remove(hovereventchangedobserver);
        }
        return;
        hovereventchangedobserver;
        obj;
        JVM INSTR monitorexit ;
        throw hovereventchangedobserver;
    }




/*
    static AccessibilityNodeInfo access$102(GLContext glcontext, AccessibilityNodeInfo accessibilitynodeinfo)
    {
        glcontext.mAccNode = accessibilitynodeinfo;
        return accessibilitynodeinfo;
    }

*/








/*
    static Choreographer access$802(GLContext glcontext, Choreographer choreographer)
    {
        glcontext.mChoreographer = choreographer;
        return choreographer;
    }

*/
}
