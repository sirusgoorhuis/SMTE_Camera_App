// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            R

public static final class 
{

    public static final int overscroll_landscape_left = 0x7f02024a;
    public static final int overscroll_landscape_right = 0x7f02024b;
    public static final int overscroll_portrait_bottom = 0x7f02024c;
    public static final int overscroll_portrait_top = 0x7f02024d;

    public ()
    {
    }
}
