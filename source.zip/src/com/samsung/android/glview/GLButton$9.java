// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.speech.tts.TextToSpeech;
import android.util.Log;

// Referenced classes of package com.samsung.android.glview:
//            GLButton, GLContext

class this._cls0 extends Thread
{

    final GLButton this$0;

    public void run()
    {
        try
        {
            Thread.sleep(700L);
            getContext().getTts().speak(getTtsString(), 0, null, null);
            return;
        }
        catch (InterruptedException interruptedexception)
        {
            Log.e("GLButton", (new StringBuilder()).append("onTouchEvent : ").append(interruptedexception.toString()).toString());
        }
    }

    ()
    {
        this$0 = GLButton.this;
        super();
    }
}
