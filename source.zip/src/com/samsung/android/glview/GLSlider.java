// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.PointF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import com.samsung.android.feature.SemCscFeature;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLNinePatch, GLImage, GLButton, 
//            GLContext

public class GLSlider extends GLView
    implements GLView.TouchListener, GLView.KeyListener
{
    public static interface GaugeMarkerPositionUpdatedListener
    {

        public abstract void onGaugeMarkerPositionUpdated();
    }

    public static interface SliderChangeListener
    {

        public abstract void onStepChanged(int i);
    }


    private static final int ORDER_ASCENDING = 10;
    private static final int ORDER_DESCENDING = 11;
    private static final int ORIENTATION_HORIZONTAL = 1;
    private static final int ORIENTATION_VERTICAL = 2;
    private static final String TAG = "GLSlider";
    public static final int UNMARKED_STEP = -1;
    protected int mCurrentStep;
    protected GLNinePatch mGaugeBar;
    protected GLButton mGaugeMarker;
    private float mGaugeMarkerBasePositionX;
    private float mGaugeMarkerBasePositionY;
    protected PointF mGaugeMarkerPos;
    protected GaugeMarkerPositionUpdatedListener mGaugeMarkerPositionUpdatedListener;
    private int mGaugeMarkerVisible;
    private boolean mIsNonZeroBase;
    protected int mNumOfStep;
    private int mOrder;
    protected int mOrientation;
    protected GLView mSliderBackground;
    protected SliderChangeListener mSliderChangeListener;
    protected List mStepPosition;

    public GLSlider(GLContext glcontext, float f, float f1, float f2, float f3, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mNumOfStep = -1;
        mCurrentStep = 0;
        mStepPosition = new ArrayList();
        mOrientation = 1;
        mGaugeMarkerPos = new PointF(0.0F, 0.0F);
        mSliderChangeListener = null;
        mGaugeMarkerPositionUpdatedListener = null;
        mGaugeMarkerVisible = 0;
        mIsNonZeroBase = false;
        mGaugeMarkerBasePositionX = 0.0F;
        mGaugeMarkerBasePositionY = 0.0F;
        if (i > 0)
        {
            mNumOfStep = i;
        }
        if (f2 >= f3)
        {
            mOrientation = 1;
            mOrder = 10;
        } else
        {
            mOrientation = 2;
            mOrder = 11;
        }
        setFocusable(true);
        setKeyListener(this);
        setDraggable(false);
    }

    public GLSlider(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mNumOfStep = -1;
        mCurrentStep = 0;
        mStepPosition = new ArrayList();
        mOrientation = 1;
        mGaugeMarkerPos = new PointF(0.0F, 0.0F);
        mSliderChangeListener = null;
        mGaugeMarkerPositionUpdatedListener = null;
        mGaugeMarkerVisible = 0;
        mIsNonZeroBase = false;
        mGaugeMarkerBasePositionX = 0.0F;
        mGaugeMarkerBasePositionY = 0.0F;
        if (flag)
        {
            mSliderBackground = new GLNinePatch(glcontext, 0.0F, 0.0F, f2, f3, i);
        } else
        {
            mSliderBackground = new GLImage(glcontext, 0.0F, 0.0F, i);
        }
        mGaugeBar = new GLNinePatch(glcontext, 0.0F, 0.0F, j);
        mGaugeBar.setVisibility(4);
        if (k > 0)
        {
            mNumOfStep = k;
        }
        if (f2 >= f3)
        {
            mOrientation = 1;
            mOrder = 10;
        } else
        {
            mOrientation = 2;
            mOrder = 11;
        }
        init();
        setFocusable(true);
        setKeyListener(this);
        setDraggable(false);
    }

    public GLSlider(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mNumOfStep = -1;
        mCurrentStep = 0;
        mStepPosition = new ArrayList();
        mOrientation = 1;
        mGaugeMarkerPos = new PointF(0.0F, 0.0F);
        mSliderChangeListener = null;
        mGaugeMarkerPositionUpdatedListener = null;
        mGaugeMarkerVisible = 0;
        mIsNonZeroBase = false;
        mGaugeMarkerBasePositionX = 0.0F;
        mGaugeMarkerBasePositionY = 0.0F;
        if (flag)
        {
            mSliderBackground = new GLNinePatch(glcontext, 0.0F, 0.0F, f2, f3, i);
        } else
        {
            mSliderBackground = new GLImage(glcontext, 0.0F, 0.0F, f2, f3, true, i);
        }
        if (j > 0)
        {
            mNumOfStep = j;
        }
        if (f2 >= f3)
        {
            mOrientation = 1;
            mOrder = 10;
        } else
        {
            mOrientation = 2;
            mOrder = 11;
        }
        init();
        setFocusable(true);
        setKeyListener(this);
        setDraggable(false);
    }

    public GLSlider(GLContext glcontext, float f, float f1, float f2, float f3, GLView glview, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mNumOfStep = -1;
        mCurrentStep = 0;
        mStepPosition = new ArrayList();
        mOrientation = 1;
        mGaugeMarkerPos = new PointF(0.0F, 0.0F);
        mSliderChangeListener = null;
        mGaugeMarkerPositionUpdatedListener = null;
        mGaugeMarkerVisible = 0;
        mIsNonZeroBase = false;
        mGaugeMarkerBasePositionX = 0.0F;
        mGaugeMarkerBasePositionY = 0.0F;
        mSliderBackground = glview;
        if (i > 0)
        {
            mNumOfStep = i;
        }
        if (f2 >= f3)
        {
            mOrientation = 1;
            mOrder = 10;
        } else
        {
            mOrientation = 2;
            mOrder = 11;
        }
        init();
        setFocusable(true);
        setKeyListener(this);
        setDraggable(false);
    }

    public GLSlider(GLContext glcontext, float f, float f1, int i)
    {
        super(glcontext, f, f1);
        mNumOfStep = -1;
        mCurrentStep = 0;
        mStepPosition = new ArrayList();
        mOrientation = 1;
        mGaugeMarkerPos = new PointF(0.0F, 0.0F);
        mSliderChangeListener = null;
        mGaugeMarkerPositionUpdatedListener = null;
        mGaugeMarkerVisible = 0;
        mIsNonZeroBase = false;
        mGaugeMarkerBasePositionX = 0.0F;
        mGaugeMarkerBasePositionY = 0.0F;
        if (i > 0)
        {
            mNumOfStep = i;
        }
    }

    private void init()
    {
        if (mSliderBackground != null)
        {
            mSliderBackground.mParent = this;
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.mParent = this;
        }
    }

    private void setStepIndicatorPosition()
    {
        if (mOrientation == 1)
        {
            if (mStepPosition.isEmpty())
            {
                for (int i = 0; i < mNumOfStep; i++)
                {
                    mStepPosition.add(new PointF((getWidth() / (float)(mNumOfStep - 1)) * (float)i, getHeight() / 2.0F - mGaugeMarker.getHeight() / 2.0F));
                }

            } else
            {
                for (int j = 0; j < mNumOfStep; j++)
                {
                    ((PointF)mStepPosition.get(j)).set((getWidth() / (float)(mNumOfStep - 1)) * (float)j, getHeight() / 2.0F - mGaugeMarker.getHeight() / 2.0F);
                }

            }
        } else
        if (mOrientation == 2)
        {
            if (mStepPosition.isEmpty())
            {
                for (int k = 0; k < mNumOfStep; k++)
                {
                    mStepPosition.add(new PointF(getWidth() / 2.0F, (getHeight() / (float)(mNumOfStep - 1)) * (float)k));
                }

            } else
            {
                for (int l = 0; l < mNumOfStep; l++)
                {
                    ((PointF)mStepPosition.get(l)).set(getWidth() / 2.0F, (getHeight() / (float)(mNumOfStep - 1)) * (float)l);
                }

            }
        }
    }

    private void setStepIndicatorPosition(List list)
    {
        if (mOrientation == 1)
        {
            if (mStepPosition.isEmpty())
            {
                for (int i = 0; i < mNumOfStep; i++)
                {
                    List list1 = mStepPosition;
                    float f = getWidth();
                    float f4 = mGaugeMarker.getWidth();
                    list1.add(new PointF(((Float[])list.get(i))[1].floatValue() * (f - f4), getHeight() / 2.0F - mGaugeMarker.getHeight() / 2.0F));
                }

            } else
            {
                for (int j = 0; j < mNumOfStep; j++)
                {
                    PointF pointf = (PointF)mStepPosition.get(j);
                    float f1 = getWidth();
                    float f5 = mGaugeMarker.getWidth();
                    pointf.set(((Float[])list.get(j))[1].floatValue() * (f1 - f5), getHeight() / 2.0F - mGaugeMarker.getHeight() / 2.0F);
                }

            }
        } else
        if (mOrientation == 2)
        {
            if (mStepPosition.isEmpty())
            {
                for (int k = 0; k < mNumOfStep; k++)
                {
                    List list2 = mStepPosition;
                    float f2 = getWidth() / 2.0F;
                    float f6 = getHeight();
                    list2.add(new PointF(f2, ((Float[])list.get(k))[1].floatValue() * f6));
                }

            } else
            {
                for (int l = 0; l < mNumOfStep; l++)
                {
                    PointF pointf1 = (PointF)mStepPosition.get(l);
                    float f3 = getWidth() / 2.0F;
                    float f7 = getHeight();
                    pointf1.set(f3, ((Float[])list.get(l))[1].floatValue() * f7);
                }

            }
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        if (mGaugeMarker != null)
        {
            mGaugeMarker.clear();
            mGaugeMarker = null;
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.clear();
            mGaugeBar = null;
        }
        if (mSliderBackground != null)
        {
            mSliderBackground.clear();
            mSliderBackground = null;
        }
        mGaugeMarkerPositionUpdatedListener = null;
        mSliderChangeListener = null;
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void enableGaugeMarkerRippleEffect(boolean flag)
    {
        mGaugeMarker.enableRippleEffect(flag);
    }

    public void expandTouchAreaFromCenter(float f, float f1)
    {
        super.moveLayout(-f, -f1);
        super.setSize(getWidth() + f * 2.0F, getHeight() + 2.0F * f1);
        if (mSliderBackground != null)
        {
            mSliderBackground.moveLayout(f, f1);
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.moveLayout(f, f1);
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.moveLayout(f, f1);
        }
    }

    protected int findNearestStepId(float f, float f1)
    {
        float f2;
        float f3;
        f2 = getHeight();
        f3 = (int)mGaugeMarker.getHeight();
        if (mOrientation != 1) goto _L2; else goto _L1
_L1:
        int i;
        f1 = getWidth() / (float)(mNumOfStep - 1);
        i = 0;
_L13:
        if (i >= mNumOfStep - 1) goto _L4; else goto _L3
_L3:
        if (f < ((PointF)mStepPosition.get(i)).x || f > ((PointF)mStepPosition.get(i + 1)).x) goto _L6; else goto _L5
_L5:
        if (f > ((PointF)mStepPosition.get(i)).x + f1 / 2.0F) goto _L8; else goto _L7
_L7:
        int j = i;
_L10:
        return j;
_L8:
        return i + 1;
_L6:
        i++;
        continue; /* Loop/switch isn't completed */
_L4:
        if (f < ((PointF)mStepPosition.get(0)).x)
        {
            return 0;
        }
        if (f > ((PointF)mStepPosition.get(0)).x)
        {
            return mNumOfStep - 1;
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (mOrientation != 2)
        {
            break; /* Loop/switch isn't completed */
        }
        f = (f2 - f3) / (float)(mNumOfStep - 1);
        i = 0;
_L11:
label0:
        {
            if (i >= mNumOfStep - 1)
            {
                break MISSING_BLOCK_LABEL_320;
            }
            if (f1 < ((PointF)mStepPosition.get(i)).y || f1 > ((PointF)mStepPosition.get(i + 1)).y)
            {
                break label0;
            }
            j = i;
            if (f1 > ((PointF)mStepPosition.get(i)).y + f / 2.0F)
            {
                return i + 1;
            }
        }
        if (true) goto _L10; else goto _L9
        i++;
          goto _L11
        if (f1 < ((PointF)mStepPosition.get(0)).y)
        {
            return 0;
        }
        if (f1 > ((PointF)mStepPosition.get(0)).y)
        {
            return mNumOfStep - 1;
        }
_L9:
        return -1;
        if (true) goto _L13; else goto _L12
_L12:
    }

    public int getCurrentStep()
    {
        return translateStepByOrdering(mCurrentStep);
    }

    public boolean getLoaded()
    {
        if (mSliderBackground != null)
        {
            return mSliderBackground.load();
        }
        if (mGaugeBar != null)
        {
            return mGaugeBar.load();
        }
        if (mGaugeMarker != null)
        {
            return mGaugeMarker.load();
        } else
        {
            return false;
        }
    }

    public int getMarkerVisible()
    {
        return mGaugeMarkerVisible;
    }

    public int getNumOfStep()
    {
        return mNumOfStep;
    }

    public PointF getStepPosition(int i)
    {
        return (PointF)mStepPosition.get(i);
    }

    public void initSize()
    {
    }

    public boolean isMarkerFocused()
    {
        if (mGaugeMarker != null)
        {
            return mGaugeMarker.isFocused();
        } else
        {
            return false;
        }
    }

    public boolean isMarkerPressed()
    {
        if (mGaugeMarker != null)
        {
            return mGaugeMarker.isPressed();
        } else
        {
            return false;
        }
    }

    public boolean moveStep(int i)
    {
        if (i < 0 || i >= mNumOfStep) goto _L2; else goto _L1
_L1:
        Object obj;
        i = translateStepByOrdering(i);
        if (mCurrentStep == i)
        {
            return true;
        }
        obj = new PointF();
        ((PointF) (obj)).set(((PointF)mStepPosition.get(mCurrentStep)).x, ((PointF)mStepPosition.get(mCurrentStep)).y);
        mCurrentStep = i;
        mGaugeMarkerPos.set(((PointF)mStepPosition.get(mCurrentStep)).x, ((PointF)mStepPosition.get(mCurrentStep)).y);
        if (mGaugeMarker == null) goto _L4; else goto _L3
_L3:
        if (mOrientation != 1) goto _L6; else goto _L5
_L5:
        mGaugeMarker.translateAbsolute(mGaugeMarkerPos.x, 0.0F, false);
        obj = new TranslateAnimation(((PointF) (obj)).x - mGaugeMarker.getTranslateX(), mGaugeMarkerPos.x - mGaugeMarker.getTranslateX(), 0.0F, 0.0F);
        ((Animation) (obj)).initialize((int)mGaugeMarker.getWidth(), (int)mGaugeMarker.getHeight(), (int)getWidth(), (int)getHeight());
        ((Animation) (obj)).setDuration(0L);
        ((Animation) (obj)).setFillAfter(true);
        mGaugeMarker.setAnimation(((Animation) (obj)));
        mGaugeMarker.startAnimation();
        setGaugeBarSize();
_L7:
        if (mGaugeMarkerPositionUpdatedListener != null)
        {
            mGaugeMarkerPositionUpdatedListener.onGaugeMarkerPositionUpdated();
        }
        if (mSliderChangeListener != null)
        {
            mSliderChangeListener.onStepChanged(getCurrentStep());
        }
_L4:
        return true;
_L6:
        if (mOrientation == 2)
        {
            mGaugeMarker.translateAbsolute(0.0F, mGaugeMarkerPos.y, false);
            obj = new TranslateAnimation(0.0F, 0.0F, ((PointF) (obj)).y - mGaugeMarker.getTranslateY(), mGaugeMarkerPos.y - mGaugeMarker.getTranslateY());
            ((Animation) (obj)).initialize((int)mGaugeMarker.getWidth(), (int)mGaugeMarker.getHeight(), (int)getWidth(), (int)getHeight());
            ((Animation) (obj)).setDuration(0L);
            ((Animation) (obj)).setFillAfter(false);
            mGaugeMarker.setAnimation(((Animation) (obj)));
            mGaugeMarker.startAnimation();
            setGaugeBarSize();
        }
        if (true) goto _L7; else goto _L2
_L2:
        return false;
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        if (mSliderBackground != null)
        {
            mSliderBackground.onAlphaUpdated();
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.onAlphaUpdated();
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.onAlphaUpdated();
        }
    }

    protected void onDraw()
    {
        if (mSliderBackground != null)
        {
            mSliderBackground.draw(getMatrix(), getClipRect());
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.draw(getMatrix(), getClipRect());
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.draw(getMatrix(), getClipRect());
        }
    }

    public boolean onKeyDown(GLView glview, KeyEvent keyevent)
    {
        int i = GLContext.getLastOrientation();
        if ((i != 0 || keyevent.getKeyCode() != 20) && (i != 1 || keyevent.getKeyCode() != 22) && (i != 2 || keyevent.getKeyCode() != 19) && (i != 3 || keyevent.getKeyCode() != 21)) goto _L2; else goto _L1
_L1:
        if (mGaugeMarker != null)
        {
            mGaugeMarker.requestFocus();
            int k = getCurrentStep() - 1;
            i = k;
            if (k < 0)
            {
                i = 0;
            }
            setCurrentStep(i);
            setGaugeBarSize();
        }
        if (mSliderChangeListener != null)
        {
            mSliderChangeListener.onStepChanged(getCurrentStep());
        }
_L4:
        return true;
_L2:
        if ((i != 0 || keyevent.getKeyCode() != 19) && (i != 1 || keyevent.getKeyCode() != 21) && (i != 2 || keyevent.getKeyCode() != 20) && (i != 3 || keyevent.getKeyCode() != 22))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.requestFocus();
            int l = getCurrentStep() + 1;
            int j = l;
            if (l > mNumOfStep - 1)
            {
                j = mNumOfStep - 1;
            }
            setCurrentStep(j);
            setGaugeBarSize();
        }
        if (mSliderChangeListener == null) goto _L4; else goto _L3
_L3:
        mSliderChangeListener.onStepChanged(getCurrentStep());
        return true;
        if (keyevent.getKeyCode() == 4 || keyevent.getKeyCode() == 111 || keyevent.getKeyCode() == 23 || keyevent.getKeyCode() == 66) goto _L4; else goto _L5
_L5:
        requestFocus();
        return false;
    }

    public boolean onKeyUp(GLView glview, KeyEvent keyevent)
    {
        return keyevent.getKeyCode() != 4 && keyevent.getKeyCode() != 111;
    }

    protected void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        if (mSliderBackground != null)
        {
            mSliderBackground.onLayoutUpdated();
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.onLayoutUpdated();
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.onLayoutUpdated();
        }
    }

    protected boolean onLoad()
    {
        boolean flag1 = true;
        if (mSliderBackground != null)
        {
            flag1 = true & mSliderBackground.load();
        }
        boolean flag = flag1;
        if (mGaugeBar != null)
        {
            flag = flag1 & mGaugeBar.load();
        }
        flag1 = flag;
        if (mGaugeMarker != null)
        {
            flag1 = flag & mGaugeMarker.load();
        }
        return flag1;
    }

    public void onReset()
    {
        if (mGaugeBar != null)
        {
            mGaugeBar.reset();
        }
        if (mSliderBackground != null)
        {
            mSliderBackground.reset();
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.reset();
        }
    }

    public boolean onTouch(GLView glview, MotionEvent motionevent)
    {
        return touchEvent(motionevent);
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        float f;
        final float posX;
        final float posY;
        float f1;
        float f2;
        MotionEvent motionevent1;
        motionevent1 = MotionEvent.obtain(motionevent);
        mapPointReverse(mTransformedScreenCoordinate, motionevent.getX(), motionevent.getY());
        motionevent1.setLocation(mTransformedScreenCoordinate[0], mTransformedScreenCoordinate[1]);
        if (mGaugeMarker == null)
        {
            motionevent1.recycle();
            return true;
        }
        f = getTop() + (float)(int)(mGaugeMarker.getHeight() / 2.0F);
        posX = getHeight();
        posY = (int)mGaugeMarker.getHeight();
        f1 = getLeft() + (float)(int)mGaugeMarker.getWidth();
        f2 = getWidth() - (float)(int)(mGaugeMarker.getWidth() * 2.0F);
        if (motionevent1.getAction() != 0) goto _L2; else goto _L1
_L1:
        mGaugeMarker.setPressed(true);
        if (mOrientation != 1) goto _L4; else goto _L3
_L3:
        if (motionevent1.getX() - getLeft() < 0.0F || motionevent1.getX() - getLeft() > getWidth())
        {
            motionevent1.recycle();
            return false;
        }
        mGaugeMarkerPos.x = motionevent1.getX() - getLeft();
        mGaugeMarker.translateAbsolute(mGaugeMarkerPos.x, 0.0F);
        setGaugeBarSize();
_L5:
        if (mSliderChangeListener != null)
        {
            int i = findNearestStepId(motionevent1.getX() - getLeft(), motionevent1.getY() - getTop());
            if (i != mCurrentStep)
            {
                mSliderChangeListener.onStepChanged(translateStepByOrdering(i));
                mCurrentStep = i;
            }
        }
        motionevent1.recycle();
        return true;
_L4:
        if (mOrientation == 2)
        {
            if (motionevent1.getY() - f < 0.0F || motionevent1.getY() - f > posX - posY)
            {
                motionevent1.recycle();
                return false;
            }
            if (motionevent1.getY() - f > ((PointF)mStepPosition.get(mNumOfStep - 1)).y)
            {
                mGaugeMarkerPos.y = ((PointF)mStepPosition.get(mNumOfStep - 1)).y;
            } else
            {
                mGaugeMarkerPos.y = motionevent1.getY() - f;
            }
            mGaugeMarker.translateAbsolute(0.0F, mGaugeMarkerPos.y);
            setGaugeBarSize();
        }
        if (true) goto _L5; else goto _L2
_L2:
        if (motionevent1.getAction() != 2) goto _L7; else goto _L6
_L6:
        mGaugeMarker.setPressed(true);
        if (mOrientation != 1) goto _L9; else goto _L8
_L8:
        if (SemCscFeature.getInstance().getBoolean("CscFeature_Framework_DisableCompensationTouchAreaInScrollBar") && (motionevent1.getY() < getTop() || motionevent1.getY() > getBottom()))
        {
            motionevent1.recycle();
            return false;
        }
        if (motionevent1.getX() - f1 < 0.0F)
        {
            mGaugeMarkerPos.x = 0.0F;
        } else
        if (motionevent1.getX() - f1 > f2)
        {
            mGaugeMarkerPos.x = f2;
        } else
        {
            mGaugeMarkerPos.x = motionevent1.getX() - f1;
        }
        mGaugeMarker.translateAbsolute(mGaugeMarkerPos.x, 0.0F);
        setGaugeBarSize();
        if (mSliderChangeListener != null)
        {
            int j = findNearestStepId(motionevent1.getX() - getLeft(), motionevent1.getY() - getTop());
            if (j != mCurrentStep)
            {
                mSliderChangeListener.onStepChanged(translateStepByOrdering(j));
                mCurrentStep = j;
            }
        }
_L10:
        motionevent1.recycle();
        return true;
_L9:
        if (mOrientation == 2)
        {
            if (SemCscFeature.getInstance().getBoolean("CscFeature_Framework_DisableCompensationTouchAreaInScrollBar") && (motionevent1.getX() < getLeft() || motionevent1.getX() > getRight()))
            {
                motionevent1.recycle();
                return false;
            }
            if (motionevent1.getY() - f < 0.0F)
            {
                mGaugeMarkerPos.y = ((PointF)mStepPosition.get(0)).y;
            } else
            if (motionevent1.getY() - f > ((PointF)mStepPosition.get(mNumOfStep - 1)).y)
            {
                mGaugeMarkerPos.y = ((PointF)mStepPosition.get(mNumOfStep - 1)).y;
            } else
            {
                mGaugeMarkerPos.y = motionevent1.getY() - f;
            }
            mGaugeMarker.translateAbsolute(0.0F, mGaugeMarkerPos.y);
            setGaugeBarSize();
            if (mSliderChangeListener != null)
            {
                int k = findNearestStepId(motionevent1.getX() - getLeft(), motionevent1.getY() - f);
                if (k != mCurrentStep)
                {
                    mSliderChangeListener.onStepChanged(translateStepByOrdering(k));
                    mCurrentStep = k;
                }
            }
        }
        if (true) goto _L10; else goto _L7
_L7:
        if (motionevent1.getAction() != 1 && motionevent1.getAction() != 3) goto _L12; else goto _L11
_L11:
        final int nearestId;
        mGaugeMarker.setPressed(false);
        posX = motionevent1.getX();
        posY = motionevent1.getY();
        nearestId = findNearestStepId(posX - getLeft(), posY - f);
        if (SemCscFeature.getInstance().getBoolean("CscFeature_Framework_DisableCompensationTouchAreaInScrollBar"))
        {
            if (mOrientation == 1)
            {
                if (motionevent1.getY() < getTop() || motionevent1.getY() > getBottom())
                {
                    setDraggable(false);
                    motionevent1.recycle();
                    return false;
                }
            } else
            if (mOrientation == 2 && (motionevent1.getX() < getLeft() || motionevent1.getX() > getRight()))
            {
                setDraggable(false);
                motionevent1.recycle();
                return false;
            }
        }
        if (mSliderChangeListener != null && nearestId != mCurrentStep)
        {
            mSliderChangeListener.onStepChanged(translateStepByOrdering(nearestId));
        }
        mCurrentStep = nearestId;
        if (mOrientation != 1) goto _L14; else goto _L13
_L13:
        motionevent = new Thread(new Runnable() {

            final GLSlider this$0;
            final int val$nearestId;
            final float val$posX;
            final float val$posY;

            public void run()
            {
                if (mGaugeMarkerPos.x >= ((PointF)mStepPosition.get(nearestId)).x)
                {
                    for (; mGaugeMarkerPos.x > ((PointF)mStepPosition.get(nearestId)).x; mGaugeMarker.translate(-0.1F, 0.0F))
                    {
                        PointF pointf = mGaugeMarkerPos;
                        pointf.x = pointf.x - 0.1F;
                    }

                } else
                {
                    for (; mGaugeMarkerPos.x < ((PointF)mStepPosition.get(findNearestStepId(posX - getLeft(), posY - getTop()))).x; mGaugeMarker.translate(0.1F, 0.0F))
                    {
                        PointF pointf1 = mGaugeMarkerPos;
                        pointf1.x = pointf1.x + 0.1F;
                    }

                }
                float f3 = ((PointF)mStepPosition.get(mCurrentStep)).x - mGaugeMarker.getTranslateX();
                PointF pointf2 = mGaugeMarkerPos;
                pointf2.x = pointf2.x + f3;
                mGaugeMarker.translate(f3, 0.0F);
                if (f3 == 0.0F)
                {
                    getContext().setDirty(true);
                }
                if (mGaugeMarkerPositionUpdatedListener != null)
                {
                    mGaugeMarkerPositionUpdatedListener.onGaugeMarkerPositionUpdated();
                }
                setGaugeBarSize();
            }

            
            {
                this$0 = GLSlider.this;
                nearestId = i;
                posX = f;
                posY = f1;
                super();
            }
        });
        motionevent.setName("GaugeTranslationThread");
        motionevent.start();
_L16:
        if (mSliderChangeListener != null && nearestId != mCurrentStep)
        {
            mSliderChangeListener.onStepChanged(translateStepByOrdering(nearestId));
        }
        mCurrentStep = nearestId;
        setDraggable(false);
_L12:
        motionevent1.recycle();
        return true;
_L14:
        if (mOrientation == 2)
        {
            motionevent = new Thread(new Runnable() {

                final GLSlider this$0;
                final int val$nearestId;

                public void run()
                {
                    if (mGaugeMarkerPos.y >= ((PointF)mStepPosition.get(translateStepByOrdering(nearestId))).y)
                    {
                        for (; mGaugeMarkerPos.y > ((PointF)mStepPosition.get(nearestId)).y; mGaugeMarker.translate(0.0F, -0.1F))
                        {
                            PointF pointf = mGaugeMarkerPos;
                            pointf.y = pointf.y - 0.1F;
                        }

                    } else
                    {
                        for (; mGaugeMarkerPos.y < ((PointF)mStepPosition.get(nearestId)).y; mGaugeMarker.translate(0.0F, 0.1F))
                        {
                            PointF pointf1 = mGaugeMarkerPos;
                            pointf1.y = pointf1.y + 0.1F;
                        }

                    }
                    float f3 = ((PointF)mStepPosition.get(mCurrentStep)).y - mGaugeMarker.getTranslateY();
                    PointF pointf2 = mGaugeMarkerPos;
                    pointf2.y = pointf2.y + f3;
                    mGaugeMarker.translate(0.0F, f3);
                    if (f3 == 0.0F)
                    {
                        getContext().setDirty(true);
                    }
                    if (mGaugeMarkerPositionUpdatedListener != null)
                    {
                        mGaugeMarkerPositionUpdatedListener.onGaugeMarkerPositionUpdated();
                    }
                    setGaugeBarSize();
                }

            
            {
                this$0 = GLSlider.this;
                nearestId = i;
                super();
            }
            });
            motionevent.setName("GaugeTranslationThread");
            motionevent.start();
        }
        if (true) goto _L16; else goto _L15
_L15:
    }

    protected void onVisibilityChanged(int i)
    {
        super.onVisibilityChanged(i);
        if (mSliderBackground != null)
        {
            mSliderBackground.onVisibilityChanged(i);
        }
        if (mGaugeBar != null)
        {
            mGaugeBar.onVisibilityChanged(i);
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.onVisibilityChanged(i);
        }
    }

    public boolean setCurrentStep(int i)
    {
        int j;
label0:
        {
            boolean flag1 = false;
            boolean flag = flag1;
            if (i >= -1)
            {
                flag = flag1;
                if (i < mNumOfStep)
                {
                    j = translateStepByOrdering(i);
                    SemLog.secV("GLSlider", (new StringBuilder()).append("setCurrentStep=").append(i).append(", currentStep=").append(mCurrentStep).toString());
                    if (mCurrentStep != j)
                    {
                        break label0;
                    }
                    flag = true;
                }
            }
            return flag;
        }
        mCurrentStep = j;
        if (j == -1)
        {
            if (mGaugeMarker != null)
            {
                mGaugeMarker.setVisibility(4);
                mGaugeMarkerVisible = 4;
            }
            return true;
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.setVisibility(0);
            mGaugeMarkerVisible = 0;
        }
        mGaugeMarkerPos.set(((PointF)mStepPosition.get(mCurrentStep)).x, ((PointF)mStepPosition.get(mCurrentStep)).y);
        if (mGaugeMarker == null) goto _L2; else goto _L1
_L1:
        if (mOrientation != 1) goto _L4; else goto _L3
_L3:
        mGaugeMarker.translateAbsolute(mGaugeMarkerPos.x, 0.0F);
_L2:
        return true;
_L4:
        if (mOrientation == 2)
        {
            mGaugeMarker.translateAbsolute(0.0F, mGaugeMarkerPos.y);
        }
        if (true) goto _L2; else goto _L5
_L5:
    }

    public void setGaugeBar(float f, float f1, int i)
    {
        mGaugeBar = new GLNinePatch(getContext(), f, f1, i);
        mGaugeBar.mParent = this;
    }

    public void setGaugeBarSize()
    {
        if (mGaugeBar == null) goto _L2; else goto _L1
_L1:
        float f;
        float f1;
        float f2;
        float f3;
        mGaugeBar.setVisibility(0);
        f = mGaugeMarker.getTranslateX();
        f1 = mGaugeMarker.getTranslateY();
        f2 = mSliderBackground.getWidth();
        f3 = mSliderBackground.getHeight();
        if (mOrientation != 1) goto _L4; else goto _L3
_L3:
        if (!mIsNonZeroBase) goto _L6; else goto _L5
_L5:
        if (f > mGaugeMarkerBasePositionX)
        {
            mGaugeBar.translateAbsolute(mGaugeMarkerBasePositionX, 0.0F, false);
            mGaugeBar.setSize(f - mGaugeMarkerBasePositionX, f3);
        } else
        {
            mGaugeBar.translateAbsolute(f, 0.0F, false);
            mGaugeBar.setSize(mGaugeMarkerBasePositionX - f, f3);
        }
        if (Math.abs(mGaugeMarkerBasePositionX - f) < (float)mGaugeBar.getIntrinsicWidth())
        {
            mGaugeBar.setVisibility(4);
        }
_L2:
        return;
_L6:
        mGaugeBar.setSize((int)(f + 0.5F), f3);
        if (f < (float)mGaugeBar.getIntrinsicWidth())
        {
            mGaugeBar.setVisibility(4);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (mOrientation != 2)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!mIsNonZeroBase)
        {
            break; /* Loop/switch isn't completed */
        }
        if (f1 < mGaugeMarkerBasePositionY)
        {
            mGaugeBar.translateAbsolute(0.0F, f1, false);
            mGaugeBar.setSize(f2, mGaugeMarkerBasePositionY - f1);
        } else
        {
            mGaugeBar.translateAbsolute(0.0F, mGaugeMarkerBasePositionY, false);
            mGaugeBar.setSize(f2, f1 - mGaugeMarkerBasePositionY);
        }
        if (Math.abs(mGaugeMarkerBasePositionY - f1) < (float)mGaugeBar.getIntrinsicHeight())
        {
            mGaugeBar.setVisibility(4);
            return;
        }
        if (true) goto _L2; else goto _L7
_L7:
        mGaugeBar.translateAbsolute(0.0F, f1, false);
        mGaugeBar.setSize(f2, f3 - (float)(int)(f1 + 0.5F));
        if (f3 - f1 < (float)mGaugeBar.getIntrinsicHeight())
        {
            mGaugeBar.setVisibility(4);
            return;
        }
        if (true) goto _L2; else goto _L8
_L8:
    }

    public void setGaugeMarker(float f, float f1, int i, int j)
    {
        setGaugeMarker(f, f1, i, j, null);
    }

    public void setGaugeMarker(float f, float f1, int i, int j, List list)
    {
        mGaugeMarker = new GLButton(getContext(), f, f1, i, j, 0, 0);
        mGaugeMarker.mParent = this;
        mGaugeMarker.setPressed(false);
        if (list == null)
        {
            setStepIndicatorPosition();
        } else
        {
            setStepIndicatorPosition(list);
        }
        mGaugeMarkerPos.x = ((PointF)mStepPosition.get(0)).x;
        mGaugeMarkerPos.y = ((PointF)mStepPosition.get(0)).y;
        mGaugeMarkerBasePositionX = mGaugeMarkerPos.x;
        mGaugeMarkerBasePositionY = mGaugeMarkerPos.y;
        if (mOrientation != 1) goto _L2; else goto _L1
_L1:
        mGaugeMarker.moveLayout(mGaugeMarkerPos.x - mGaugeMarker.getWidth() / 2.0F, mGaugeMarkerPos.y);
_L4:
        mGaugeMarker.setFocusable(true);
        mGaugeMarker.setKeyListener(this);
        return;
_L2:
        if (mOrientation == 2)
        {
            mGaugeMarker.moveLayout(mGaugeMarkerPos.x - mGaugeMarker.getWidth() / 2.0F, mGaugeMarkerPos.y - mGaugeMarker.getHeight() / 2.0F);
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void setGaugeMarker(int i, int j)
    {
        setGaugeMarker(0.0F, 0.0F, i, j, null);
    }

    public void setGaugeMarkerPositionUpdatedListener(GaugeMarkerPositionUpdatedListener gaugemarkerpositionupdatedlistener)
    {
        mGaugeMarkerPositionUpdatedListener = gaugemarkerpositionupdatedlistener;
    }

    public void setGaugeZeroStep(int i)
    {
        if (mStepPosition != null)
        {
            if (i >= 0 && i <= mStepPosition.size())
            {
                mGaugeMarkerBasePositionX = ((PointF)mStepPosition.get(i)).x;
                mGaugeMarkerBasePositionY = ((PointF)mStepPosition.get(i)).y;
            }
            if (i > 0)
            {
                mIsNonZeroBase = true;
            }
        }
    }

    public void setMarkerPressed(boolean flag)
    {
        if (mGaugeMarker != null)
        {
            mGaugeMarker.setPressed(flag);
        }
    }

    public void setMarkerVisible(int i)
    {
        if (mGaugeMarker != null)
        {
            mGaugeMarker.setVisibility(i);
            mGaugeMarkerVisible = i;
        }
    }

    public boolean setOrder(int i)
    {
        if (i == 10 || i == 11)
        {
            mOrder = i;
            return true;
        } else
        {
            return false;
        }
    }

    public void setSliderBackground(float f, float f1, float f2, float f3, int i, boolean flag)
    {
        if (flag)
        {
            mSliderBackground = new GLNinePatch(getContext(), f, f1, f2, f3, i);
        } else
        {
            mSliderBackground = new GLImage(getContext(), f, f1, i);
        }
        mSliderBackground.mParent = this;
    }

    public void setSliderChangeListener(SliderChangeListener sliderchangelistener)
    {
        mSliderChangeListener = sliderchangelistener;
    }

    public void setTint(int i)
    {
        super.setTint(i);
        if (mGaugeBar != null)
        {
            mGaugeBar.setTint(i);
        }
        if (mGaugeMarker != null)
        {
            mGaugeMarker.setTint(i);
        }
    }

    protected int translateStepByOrdering(int i)
    {
        if (mOrder == 10 || i == -1)
        {
            return i;
        } else
        {
            return mNumOfStep - 1 - i;
        }
    }
}
