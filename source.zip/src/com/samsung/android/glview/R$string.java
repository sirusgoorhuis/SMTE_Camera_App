// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            R

public static final class 
{

    public static final int button = 0x7f090142;
    public static final int disable = 0x7f09018b;
    public static final int tts_hour = 0x7f0902c4;
    public static final int tts_hours = 0x7f0902c5;
    public static final int tts_minute = 0x7f0902c6;
    public static final int tts_minutes = 0x7f0902c7;
    public static final int tts_not_selected = 0x7f0902c8;
    public static final int tts_second = 0x7f0902ca;
    public static final int tts_seconds = 0x7f0902cb;
    public static final int tts_selected = 0x7f0902cc;

    public ()
    {
    }
}
