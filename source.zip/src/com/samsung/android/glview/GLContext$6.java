// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.database.ContentObserver;
import android.os.Handler;
import com.samsung.android.util.SemLog;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

class  extends ContentObserver
{

    final GLContext this$0;

    public void onChange(boolean flag)
    {
        super.onChange(flag);
        SemLog.secV("GLContext", "Enabled Accessibility Services ContentObserver onChange");
        if (!GLContext.isTalkBackEnabled())
        {
            disableAccessibilityService(GLContext.mApplicationContext);
        }
    }

    (Handler handler)
    {
        this$0 = GLContext.this;
        super(handler);
    }
}
