// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

class > extends BroadcastReceiver
{

    final GLContext this$0;

    public void onReceive(Context context, Intent intent)
    {
        if (!isFocusNavigationEnabled() || intent.getExtras() == null)
        {
            return;
        }
        switch (intent.getExtras().getInt("gestureId"))
        {
        default:
            return;

        case 1: // '\001'
            onHoverSwipeEvent(65);
            return;

        case 3: // '\003'
            onHoverSwipeEvent(49);
            return;

        case 4: // '\004'
            onHoverSwipeEvent(98);
            return;

        case 2: // '\002'
            onHoverSwipeEvent(82);
            return;
        }
    }

    ()
    {
        this$0 = GLContext.this;
        super();
    }
}
