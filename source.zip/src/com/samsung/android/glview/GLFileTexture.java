// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLContext

public class GLFileTexture extends GLTexture
{

    private final String mFilePath;
    private int mSampleSize;

    public GLFileTexture(GLContext glcontext, float f, float f1, float f2, float f3, String s)
    {
        super(glcontext, f, f1, f2, f3);
        mSampleSize = 2;
        mFilePath = s;
    }

    public GLFileTexture(GLContext glcontext, float f, float f1, String s)
    {
        super(glcontext, f, f1);
        mSampleSize = 2;
        mFilePath = s;
    }

    protected Bitmap loadBitmap()
    {
        this;
        JVM INSTR monitorenter ;
        Object obj;
        obj = new android.graphics.BitmapFactory.Options();
        obj.inSampleSize = mSampleSize;
        obj.inDither = false;
        obj.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
        obj = BitmapFactory.decodeFile(mFilePath, ((android.graphics.BitmapFactory.Options) (obj)));
        this;
        JVM INSTR monitorexit ;
        return ((Bitmap) (obj));
        Exception exception;
        exception;
        throw exception;
    }

    public void setSampleSize(int i)
    {
        mSampleSize = i;
    }
}
