// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            R

public static final class 
{

    public static final int Activity_WithActionBar_FullScreen = 0x7f0e0000;
    public static final int AppActionBar = 0x7f0e0001;
    public static final int CustomTheme = 0x7f0e0002;

    public ()
    {
    }
}
