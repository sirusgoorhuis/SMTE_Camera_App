// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLAbsList, GLView, GLUtil, GLContext

public class GLGridList extends GLAbsList
{

    public static final int AUTO_FIT = -1;
    private float mColumnWidth;
    private int mDefaultNumColumns;
    private float mHorizontalSpacing;
    private int mItemCount;
    private float mLeftPadding;
    private boolean mNeedToChangeLeftPadding;
    private boolean mNeedToChangeTopPadding;
    private int mNumColumns;
    private float mTopPadding;
    private float mVerticalSpacing;

    public GLGridList(GLContext glcontext, float f, float f1, float f2, float f3, float f4, float f5, 
            float f6, float f7, float f8, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mColumnWidth = 0.0F;
        mHorizontalSpacing = 0.0F;
        mVerticalSpacing = 0.0F;
        mLeftPadding = 0.0F;
        mNeedToChangeLeftPadding = false;
        mTopPadding = 0.0F;
        mNeedToChangeTopPadding = false;
        mNumColumns = -1;
        mDefaultNumColumns = -1;
        mColumnWidth = f4;
        mHorizontalSpacing = f5;
        mVerticalSpacing = f6;
        mNumColumns = i;
        mDefaultNumColumns = i;
        mLeftPadding = f7;
        mTopPadding = f8;
    }

    public GLGridList(GLContext glcontext, float f, float f1, float f2, float f3, float f4, float f5, 
            float f6, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mColumnWidth = 0.0F;
        mHorizontalSpacing = 0.0F;
        mVerticalSpacing = 0.0F;
        mLeftPadding = 0.0F;
        mNeedToChangeLeftPadding = false;
        mTopPadding = 0.0F;
        mNeedToChangeTopPadding = false;
        mNumColumns = -1;
        mDefaultNumColumns = -1;
        mColumnWidth = f4;
        mHorizontalSpacing = f5;
        mVerticalSpacing = f6;
        mNumColumns = i;
        mDefaultNumColumns = i;
        mNeedToChangeLeftPadding = true;
        mNeedToChangeTopPadding = true;
    }

    private void updateContentArea(float f)
    {
        if (mGLViews.isEmpty() || mGLViews.get(0) == null)
        {
            mContentWidth = getContentAreaWidth();
            mContentHeight = getContentAreaHeight();
            return;
        }
        float f1 = ((GLView)mGLViews.get(0)).getWidth();
        float f2 = ((GLView)mGLViews.get(0)).getHeight();
        if (mScrollOrientation == 1)
        {
            mContentHeight = f + f2;
            return;
        } else
        {
            mContentWidth = f + f1;
            return;
        }
    }

    private void updateListPadding()
    {
        if (mScrollOrientation == 1)
        {
            if (mNeedToChangeLeftPadding)
            {
                mLeftPadding = (getContentAreaWidth() - (float)mNumColumns * mColumnWidth - (float)(mNumColumns - 1) * mHorizontalSpacing) / 2.0F;
            }
        } else
        if (mNeedToChangeTopPadding)
        {
            mTopPadding = (getContentAreaHeight() - (float)mNumColumns * mColumnWidth - (float)(mNumColumns - 1) * mVerticalSpacing) / 2.0F;
            return;
        }
    }

    public int getNumColumns()
    {
        this;
        JVM INSTR monitorenter ;
        int i = mNumColumns;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public void refreshList()
    {
        this;
        JVM INSTR monitorenter ;
        super.refreshList();
        if (mNumColumns != -1) goto _L2; else goto _L1
_L1:
        if (mScrollOrientation != 1) goto _L4; else goto _L3
_L3:
        mNumColumns = (int)((getContentAreaWidth() + mHorizontalSpacing) / (mColumnWidth + mHorizontalSpacing));
_L11:
        if (mNumColumns <= 0)
        {
            mNumColumns = 1;
        }
        updateListPadding();
        float f = 0.0F;
        int j = mNumColumns;
        int i = 0;
        Iterator iterator = mGLViews.iterator();
_L13:
        if (!iterator.hasNext()) goto _L6; else goto _L5
_L5:
        GLView glview;
        glview = (GLView)iterator.next();
        glview.resetTranslate();
        int k = i % j;
        int l = i / j;
        if (mScrollOrientation != 1) goto _L8; else goto _L7
_L7:
        if (!GLUtil.isLocaleRTL()) goto _L10; else goto _L9
_L9:
        f = (glview.getWidth() + mHorizontalSpacing) * (float)(j - k - 1) + mLeftPadding;
_L12:
        float f1;
        f1 = (glview.getHeight() + mVerticalSpacing) * (float)l;
        glview.moveLayoutAbsolute(f, f1);
        f = f1;
        break MISSING_BLOCK_LABEL_363;
_L4:
        mNumColumns = (int)((getContentAreaHeight() + mVerticalSpacing) / (mColumnWidth + mVerticalSpacing));
          goto _L11
        Exception exception;
        exception;
        throw exception;
_L2:
label0:
        {
            mItemCount = mAdapter.getCount();
            if (mItemCount >= mDefaultNumColumns)
            {
                break label0;
            }
            mNumColumns = mItemCount;
        }
          goto _L11
        mNumColumns = mDefaultNumColumns;
          goto _L11
_L10:
        f = (glview.getWidth() + mHorizontalSpacing) * (float)k + mLeftPadding;
          goto _L12
_L8:
        float f2;
        f1 = glview.getHeight();
        f2 = mVerticalSpacing;
        float f3 = k;
        float f4 = mTopPadding;
        f = (glview.getWidth() + mHorizontalSpacing) * (float)l;
        glview.moveLayoutAbsolute(f, (f1 + f2) * f3 + f4);
        break MISSING_BLOCK_LABEL_363;
_L6:
        getContext().setDirty(true);
        updateContentArea(f);
        this;
        JVM INSTR monitorexit ;
        return;
        i++;
          goto _L13
    }

    public void setAdapter(GLAbsList.Adapter adapter, int i)
    {
        this;
        JVM INSTR monitorenter ;
        if (adapter != null)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        throw new IllegalArgumentException();
        adapter;
        this;
        JVM INSTR monitorexit ;
        throw adapter;
        mAdapter = adapter;
        mItemCount = mAdapter.getCount();
        mScrollOrientation = i;
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).clear()) { }
        if (mNumColumns != -1) goto _L2; else goto _L1
_L1:
        if (mScrollOrientation != 1) goto _L4; else goto _L3
_L3:
        mNumColumns = (int)((getContentAreaWidth() + mHorizontalSpacing) / (mColumnWidth + mHorizontalSpacing));
_L12:
        if (mNumColumns <= 0)
        {
            mNumColumns = 1;
        }
        updateListPadding();
        float f1 = 0.0F;
        int l = mNumColumns;
        int j = 0;
_L22:
        if (j >= mItemCount) goto _L6; else goto _L5
_L5:
        if (mScrollOrientation != 1) goto _L8; else goto _L7
_L7:
        float f = mLeftPadding;
_L13:
        int i1 = Math.min(j + l, mItemCount);
        int k = j;
_L21:
        if (k >= i1) goto _L10; else goto _L9
_L9:
        GLView glview = mAdapter.getView(k, null);
        if (glview == null)
        {
            continue; /* Loop/switch isn't completed */
        }
          goto _L11
_L4:
        mNumColumns = (int)((getContentAreaHeight() + mVerticalSpacing) / (mColumnWidth + mVerticalSpacing));
          goto _L12
_L2:
label0:
        {
            if (mItemCount >= mDefaultNumColumns)
            {
                break label0;
            }
            mNumColumns = mItemCount;
        }
          goto _L12
        mNumColumns = mDefaultNumColumns;
          goto _L12
_L8:
        f = mTopPadding;
          goto _L13
_L11:
        float f3;
        if (mScrollOrientation != 1)
        {
            break MISSING_BLOCK_LABEL_470;
        }
        if (glview.getScrollHint())
        {
            mScrollSumY = -f1;
        }
        int j1 = k / l;
        f3 = (glview.getHeight() + mVerticalSpacing) * (float)j1;
        f1 = f;
        if (!GLUtil.isLocaleRTL())
        {
            break MISSING_BLOCK_LABEL_368;
        }
        f1 = f;
        if (k % l != 0)
        {
            break MISSING_BLOCK_LABEL_368;
        }
        f1 = f + (float)(l - 1) * (glview.getWidth() + mHorizontalSpacing);
        glview.moveLayoutAbsolute(f1, f3);
        if (!GLUtil.isLocaleRTL()) goto _L15; else goto _L14
_L14:
        float f2 = f1 - glview.getWidth();
_L20:
        f = f2;
        f1 = f3;
        if (k >= i1 - 1) goto _L17; else goto _L16
_L16:
        if (!GLUtil.isLocaleRTL()) goto _L19; else goto _L18
_L18:
        f = f2 - mHorizontalSpacing;
        f1 = f3;
_L17:
        glview.setFocusListener(this);
        addView(glview);
        continue; /* Loop/switch isn't completed */
_L15:
        f2 = f1 + glview.getWidth();
          goto _L20
_L19:
        f = f2 + mHorizontalSpacing;
        f1 = f3;
          goto _L17
        if (glview.getScrollHint())
        {
            mScrollSumX = -f1;
        }
        int k1 = k / l;
        f = (glview.getHeight() + mVerticalSpacing) * (float)(k % l) + mTopPadding;
        f1 = (glview.getWidth() + mHorizontalSpacing) * (float)k1;
        glview.moveLayoutAbsolute(f1, f);
          goto _L17
_L6:
        updateContentArea(f1);
        super.setAdapter(adapter, i);
        this;
        JVM INSTR monitorexit ;
        return;
          goto _L21
_L10:
        j += l;
          goto _L22
    }

    public void setColumnWidth(float f, boolean flag)
    {
        if (mColumnWidth != f)
        {
            mColumnWidth = f;
            if (flag)
            {
                refreshList();
            }
        }
    }

    public void setHeight(float f)
    {
        super.setHeight(f);
        refreshList();
    }

    public void setNumColumns(int i, boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        int j = mNumColumns;
        if (j != -1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (mNumColumns == i) goto _L1; else goto _L3
_L3:
        mItemCount = mAdapter.getCount();
        if (mItemCount >= i)
        {
            break MISSING_BLOCK_LABEL_75;
        }
        mNumColumns = mItemCount;
_L5:
        mDefaultNumColumns = i;
        if (!flag) goto _L1; else goto _L4
_L4:
        refreshList();
          goto _L1
        Exception exception;
        exception;
        throw exception;
        mNumColumns = i;
          goto _L5
    }

    public void setSize(float f, float f1)
    {
        super.setSize(f, f1);
    }

    public void setSize(float f, float f1, boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        setSize(f, f1);
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_43;
        }
        refreshList();
        if (checkBoundary())
        {
            setBouncing(true);
        }
        setVisibleArea();
        if (mScrollBar != null)
        {
            setScrollBarLayout();
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setSpacing(float f, float f1, boolean flag)
    {
        if (mHorizontalSpacing != f || mVerticalSpacing != f1)
        {
            mHorizontalSpacing = f;
            mVerticalSpacing = f1;
            if (flag)
            {
                refreshList();
            }
        }
    }

    public void setWidth(float f)
    {
        super.setWidth(f);
        refreshList();
    }

    public void updateEndOffset(float f)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mGLViews.isEmpty();
        if (!flag && f >= 0.0F) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (mScrollOrientation != 1)
        {
            break; /* Loop/switch isn't completed */
        }
        mContentHeight = mContentHeight + f;
_L4:
        if (isScrollable())
        {
            setScrollBarLayout();
        }
        if (true) goto _L1; else goto _L3
        Exception exception;
        exception;
        throw exception;
_L3:
        mContentWidth = mContentWidth + f;
          goto _L4
    }

    public void updateStartOffset(float f, int i)
    {
        boolean flag1 = true;
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        boolean flag2 = mGLViews.isEmpty();
        if (!flag2 && f >= 0.0F) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (mScrollOrientation != 1) goto _L4; else goto _L3
_L3:
        float f1;
        Iterator iterator;
        Exception exception;
        if (Float.compare(getHeight(), mContentHeight + f) >= 0)
        {
            flag = false;
        }
          goto _L5
_L8:
        for (iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).moveLayout(0.0F, f1)) { }
          goto _L6
        exception;
        throw exception;
_L19:
        f = (float)(int)((mParent.getHeight() - mContentHeight) / 2.0F + 0.5F) - getLayoutY();
label0:
        {
            if (f >= 0.0F)
            {
                break label0;
            }
            f1 = 0.0F;
        }
        if (true) goto _L8; else goto _L7
_L7:
        f1 = f;
        if (mContentHeight + f <= getHeight()) goto _L8; else goto _L9
_L9:
        f1 = getHeight() - mContentHeight;
          goto _L8
_L20:
        f1 = (int)(getHeight() - mContentHeight);
          goto _L8
_L6:
        mContentHeight = mContentHeight + f1;
_L10:
        if (isScrollable())
        {
            setScrollBarLayout();
        }
          goto _L1
_L17:
        for (exception = mGLViews.iterator(); exception.hasNext(); ((GLView)exception.next()).moveLayout(0.0F, f)) { }
        mContentHeight = mContentHeight + f;
          goto _L10
_L4:
        if (Float.compare(getWidth(), mContentWidth + f) < 0)
        {
            flag = flag1;
        } else
        {
            flag = false;
        }
          goto _L11
_L14:
        for (exception = mGLViews.iterator(); exception.hasNext(); ((GLView)exception.next()).moveLayout(f1, 0.0F)) { }
          goto _L12
_L24:
        f = (float)(int)((mParent.getWidth() - mContentWidth) / 2.0F + 0.5F) - getLayoutX();
label1:
        {
            if (f >= 0.0F)
            {
                break label1;
            }
            f1 = 0.0F;
        }
        if (true) goto _L14; else goto _L13
_L13:
        f1 = f;
        if (mContentWidth + f <= getWidth()) goto _L14; else goto _L15
_L15:
        f1 = getWidth() - mContentWidth;
          goto _L14
_L25:
        f1 = (int)(getWidth() - mContentWidth);
          goto _L14
_L12:
        mContentWidth = mContentWidth + f1;
          goto _L10
_L22:
        for (Iterator iterator1 = mGLViews.iterator(); iterator1.hasNext(); ((GLView)iterator1.next()).moveLayout(f, 0.0F)) { }
        mContentWidth = mContentWidth + f;
          goto _L10
_L5:
        if (flag) goto _L17; else goto _L16
_L16:
        f1 = f;
        i;
        JVM INSTR tableswitch 1 3: default 500
    //                   1 58
    //                   2 108
    //                   3 173;
           goto _L18 _L8 _L19 _L20
_L18:
        f1 = f;
          goto _L8
_L11:
        if (flag) goto _L22; else goto _L21
_L21:
        f1 = f;
        i;
        JVM INSTR tableswitch 1 3: default 540
    //                   1 285
    //                   2 322
    //                   3 387;
           goto _L23 _L14 _L24 _L25
_L23:
        f1 = f;
          goto _L14
    }
}
