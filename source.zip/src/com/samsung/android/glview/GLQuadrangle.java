// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Log;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLUtil, GLContext, GLProgramStorage, 
//            GLProgram, GLView

public class GLQuadrangle extends GLTexture
{

    private static final float DEFAULT_THICKNESS = 1F;
    private static final String TAG = "GLQuadrangle";
    public static final int TYPE_RECTANGLE_CORRECTION_STROKE = 2;
    public static final int TYPE_RECTANGLE_FILL = 3;
    public static final int TYPE_RECTANGLE_STROKE = 1;
    private float mColor[];
    private GLProgram.NameIndexerObj mObjPointSize;
    private GLProgram.NameIndexerObj mObjSampler;
    private float mPoints[];
    private int mRectangleType;
    private float mThickness[];
    private FloatBuffer mThicknessBuffer;

    public GLQuadrangle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4)
    {
        super(glcontext, 0.0F, 0.0F);
        mPoints = new float[8];
        mRectangleType = 1;
        mThickness = new float[4];
        mObjSampler = null;
        mObjPointSize = null;
        mColor = new float[4];
        mRectangleType = 2;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness[0] = 1.0F;
            mThickness[1] = 1.0F;
            mThickness[2] = 1.0F;
            mThickness[3] = 1.0F;
        } else
        {
            mThickness[0] = f4;
            mThickness[1] = f4;
            mThickness[2] = f4;
            mThickness[3] = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    public GLQuadrangle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4, 
            int j, int k)
    {
        super(glcontext, 0.0F, 0.0F);
        mPoints = new float[8];
        mRectangleType = 1;
        mThickness = new float[4];
        mObjSampler = null;
        mObjPointSize = null;
        mColor = new float[4];
        mRectangleType = j;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness[0] = 1.0F;
            mThickness[1] = 1.0F;
            mThickness[2] = 1.0F;
            mThickness[3] = 1.0F;
        } else
        {
            mThickness[0] = f4;
            mThickness[1] = f4;
            mThickness[2] = f4;
            mThickness[3] = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    protected void clearBuffers()
    {
        if (mThicknessBuffer != null)
        {
            mThicknessBuffer.clear();
        }
        super.clearBuffers();
    }

    public boolean contains(float f, float f1)
    {
        return false;
    }

    public GLView findViewByCoordinate(float f, float f1)
    {
        return null;
    }

    public int getColor()
    {
        return Color.argb((int)(mColor[0] * 255F), (int)(mColor[1] * 255F), (int)(mColor[2] * 255F), (int)(mColor[3] * 255F));
    }

    public float[] getPoints()
    {
        return mPoints;
    }

    public float getThickness()
    {
        return mThickness[0];
    }

    protected void initBuffers()
    {
        this;
        JVM INSTR monitorenter ;
        byte abyte0[];
        clearBuffers();
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        mThicknessBuffer = GLUtil.getFloatBufferFromFloatArray(mThickness);
        if (mIndices == null)
        {
            mIndices = new byte[4];
        }
        abyte0 = mIndices;
        int i;
        i = 0 + 1;
        abyte0[0] = 0;
        abyte0 = mIndices;
        int j;
        j = i + 1;
        abyte0[i] = 1;
        mIndices[j] = 3;
        mIndices[j + 1] = 2;
        mIndexBuffer = GLUtil.getByteBufferFromByteArray(mIndices);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void initSize()
    {
        setSize(getWidth(), getHeight());
    }

    protected Bitmap loadBitmap()
    {
        return null;
    }

    public void onDraw()
    {
        if (!mTextureLoaded)
        {
            return;
        }
        if (mLayoutUpdated)
        {
            setVertices();
            if (mVertexBuffer != null)
            {
                mVertexBuffer.clear();
            }
            mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
            mLayoutUpdated = false;
        } else
        if (mVertexBuffer == null || mIndexBuffer == null || mThicknessBuffer == null)
        {
            Log.e("GLQuadrangle", "init buffers on onDraw");
            setVertices();
            initBuffers();
        }
        GLES20.glLineWidth(mThickness[0]);
        GLES20.glUseProgram(mProgramID);
        GLES20.glUniform4fv(mObjSampler.mHandle, 1, mColor, 0);
        Matrix.multiplyMM(mViewMatrix, 0, getContext().getProjMatrix(), 0, getMatrix(), 0);
        GLES20.glUniformMatrix4fv(mObjMVPMatrix.mHandle, 1, false, mViewMatrix, 0);
        GLES20.glUniform1f(mObjAlpha.mHandle, getAlpha());
        GLES20.glEnableVertexAttribArray(mObjPointSize.mHandle);
        GLES20.glEnableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glDisable(2929);
        GLES20.glVertexAttribPointer(mObjPointSize.mHandle, 1, 5126, false, 0, mThicknessBuffer);
        GLES20.glVertexAttribPointer(mObjPosition.mHandle, 3, 5126, false, 0, mVertexBuffer);
        if (mTextureReloaded)
        {
            mTextureReloaded = false;
        }
        if (mRectangleType == 2)
        {
            GLES20.glDrawElements(0, mIndices.length, 5121, mIndexBuffer);
        }
        if (mRectangleType == 3)
        {
            GLES20.glDrawElements(6, mIndices.length, 5121, mIndexBuffer);
        } else
        {
            GLES20.glDrawElements(2, mIndices.length, 5121, mIndexBuffer);
        }
        GLES20.glDisableVertexAttribArray(mObjPointSize.mHandle);
        GLES20.glDisableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glEnable(2929);
    }

    protected boolean onLoad()
    {
        initSize();
        setVertices();
        initBuffers();
        GLProgram glprogram = getContext().getProgramStorage().getProgram(1003);
        if (glprogram != null)
        {
            mProgramID = glprogram.getProgramID();
            mObjPosition = glprogram.getNameIndexer("a_position");
            mObjPointSize = glprogram.getNameIndexer("a_pointsize");
            mObjSampler = glprogram.getNameIndexer("tex_sampler");
            mObjMVPMatrix = glprogram.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram.getNameIndexer("u_alpha");
        }
        mTextureLoaded = true;
        return true;
    }

    public void setColor(int i)
    {
        mColor[0] = (float)Color.red(i) / 255F;
        mColor[1] = (float)Color.green(i) / 255F;
        mColor[2] = (float)Color.blue(i) / 255F;
        mColor[3] = (float)Color.alpha(i) / 255F;
    }

    public void setPoint(float f, float f1, float f2, float f3, float f4, float f5, int i)
    {
        mPoints[i * 2] = f;
        mPoints[i * 2 + 1] = f1;
        translateAbsolute(f2, f3);
        setSize(f4, f5);
        setVertices();
        initBuffers();
    }

    public void setPoints(float af[], float f, float f1, float f2, float f3)
    {
        mPoints[0] = af[0];
        mPoints[1] = af[1];
        mPoints[2] = af[2];
        mPoints[3] = af[3];
        mPoints[4] = af[4];
        mPoints[5] = af[5];
        mPoints[6] = af[6];
        mPoints[7] = af[7];
        translateAbsolute(f, f1);
        setSize(f2, f3);
        setVertices();
        initBuffers();
    }

    public void setThickness(float f)
    {
        mThickness[0] = f;
        mThickness[1] = f;
        mThickness[2] = f;
        mThickness[3] = f;
        initBuffers();
    }

    protected void setVertices()
    {
        if (mVertices == null)
        {
            mVertices = new float[12];
        }
        mVertices[0] = mPoints[0] - getTranslateX();
        mVertices[1] = mPoints[1] - getTranslateY();
        mVertices[2] = 0.0F;
        mVertices[3] = mPoints[6] - getTranslateX();
        mVertices[4] = mPoints[7] - getTranslateY();
        mVertices[5] = 0.0F;
        mVertices[6] = mPoints[2] - getTranslateX();
        mVertices[7] = mPoints[3] - getTranslateY();
        mVertices[8] = 0.0F;
        mVertices[9] = mPoints[4] - getTranslateX();
        mVertices[10] = mPoints[5] - getTranslateY();
        mVertices[11] = 0.0F;
    }
}
