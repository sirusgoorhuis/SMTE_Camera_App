// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            GLContext

public class GLPreviewData
{

    private static final Object mLock = new Object();
    private static GLPreviewData sGLPreview = null;
    private boolean mFrameAvailable;
    private final GLContext mGLContext;
    private int mHeight;
    private byte mPreviewData[];
    private int mWidth;

    private GLPreviewData(GLContext glcontext)
    {
        mPreviewData = null;
        mFrameAvailable = false;
        mGLContext = glcontext;
        mWidth = 0;
        mHeight = 0;
    }

    public static GLPreviewData getInstance(GLContext glcontext)
    {
        synchronized (mLock)
        {
            if (sGLPreview == null)
            {
                sGLPreview = new GLPreviewData(glcontext);
            }
            glcontext = sGLPreview;
        }
        return glcontext;
        glcontext;
        obj;
        JVM INSTR monitorexit ;
        throw glcontext;
    }

    private void release()
    {
        synchronized (mLock)
        {
            mPreviewData = null;
            sGLPreview = null;
        }
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public static void releaseInstance()
    {
        synchronized (mLock)
        {
            if (sGLPreview != null)
            {
                sGLPreview.release();
                sGLPreview = null;
            }
        }
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    private void setNewFrame()
    {
        mGLContext.setDirty(true);
    }

    public void clearPreviewFrame()
    {
        mFrameAvailable = false;
    }

    public boolean getFrameAvailable()
    {
        if (mPreviewData == null)
        {
            return false;
        } else
        {
            return mFrameAvailable;
        }
    }

    public int getHeight()
    {
        return mHeight;
    }

    public byte[] getPreviewDataByte()
    {
        return mPreviewData;
    }

    public float getSurfaceCoordXOffset()
    {
        return ((float)mHeight / (float)mWidth) * 1.0F;
    }

    public int getWidth()
    {
        this;
        JVM INSTR monitorenter ;
        int i = mWidth;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public void setPreviewData(int i, int j, byte abyte0[])
    {
        this;
        JVM INSTR monitorenter ;
        mWidth = i;
        mHeight = j;
        mPreviewData = abyte0;
        mFrameAvailable = true;
        setNewFrame();
        this;
        JVM INSTR monitorexit ;
        return;
        abyte0;
        throw abyte0;
    }

}
