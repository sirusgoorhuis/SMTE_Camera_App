// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

class > extends BroadcastReceiver
{

    final GLContext this$0;

    public void onReceive(Context context, Intent intent)
    {
        if (!isFocusNavigationEnabled())
        {
            return;
        }
        clearFocus();
        setDirty(true);
        context = intent.getBundleExtra("accessibilityeventid");
        if (context == null)
        {
            GLContext.access$000(GLContext.this).sendAccessibilityEvent(32768);
            return;
        } else
        {
            GLContext.access$102(GLContext.this, (AccessibilityNodeInfo)context.getParcelable("accessibilitynodeinfoid"));
            return;
        }
    }

    yNodeInfo()
    {
        this$0 = GLContext.this;
        super();
    }
}
