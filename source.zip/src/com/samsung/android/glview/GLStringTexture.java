// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLContext, GLText, GLUtil

public class GLStringTexture extends GLTexture
{

    private static final float DEFAULT_FADING_EDGE_WIDTH_DIP = 20F;
    private static int DEFAULT_LINE_SPACE = 0;
    private static int DEFAULT_PADDING = 0;
    private static final int DEFAULT_SHADOW_COLOR;
    private static final float DEFAULT_SHADOW_OFFSET_X_DIP = 1F;
    private static final float DEFAULT_SHADOW_OFFSET_Y_DIP = 1F;
    private static final float DEFAULT_SHADOW_RADIUS_DIP = 1F;
    private static final int DEFAULT_STROKE_COLOR;
    private static final float DEFAULT_STROKE_WIDTH = 1F;
    private static final int DEFAULT_TEXT_COLOR;
    private static int NUM_OF_ELLIPSIS_CHARACTER = 0;
    private static final String TAG = "GLStringTexture";
    private boolean mBold;
    private int mColor;
    private boolean mFadingEdge;
    private float mFadingEdgeWidth;
    private int mHAlign;
    private int mHeight;
    private int mLineSpace;
    private android.graphics.Paint.FontMetricsInt mMetrics;
    private Paint mPaint;
    private boolean mShadow;
    private int mShadowColor;
    private float mShadowOffsetX;
    private float mShadowOffsetY;
    private float mShadowRadius;
    private float mSize;
    private int mStringHeight;
    private int mStringWidth;
    private boolean mStroke;
    private int mStrokeColor;
    private float mStrokeWidth;
    private String mText;
    private int mVAlign;
    private int mWidth;

    public GLStringTexture(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            String s, float f4, int k, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mWidth = 0;
        mHeight = 0;
        mStringWidth = 0;
        mStringHeight = 0;
        mHAlign = 1;
        mVAlign = 1;
        mColor = DEFAULT_TEXT_COLOR;
        mShadow = true;
        mStroke = false;
        mBold = false;
        mSize = 0.0F;
        mFadingEdgeWidth = 0.0F;
        mFadingEdge = true;
        mShadowColor = DEFAULT_SHADOW_COLOR;
        mStrokeWidth = 1.0F;
        mStrokeColor = DEFAULT_STROKE_COLOR;
        mLineSpace = DEFAULT_LINE_SPACE;
        mText = s;
        mSize = f4;
        mColor = k;
        mShadow = flag;
        mHAlign = i;
        mVAlign = j;
        mPaint = new Paint();
        if (f4 != 0.0F)
        {
            mPaint.setTextSize(f4);
        }
        mPaint.setColor(k);
        mPaint.setAntiAlias(true);
        mMetrics = mPaint.getFontMetricsInt();
        mWidth = (int)f2;
        mHeight = (int)f3;
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).append(", mText : ").append(mText).toString());
        }
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        mStringHeight = (mMetrics.descent - mMetrics.ascent) + DEFAULT_PADDING * 2;
        mSizeSpecified = true;
        init();
    }

    public GLStringTexture(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            String s, float f4, Typeface typeface, int k, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mWidth = 0;
        mHeight = 0;
        mStringWidth = 0;
        mStringHeight = 0;
        mHAlign = 1;
        mVAlign = 1;
        mColor = DEFAULT_TEXT_COLOR;
        mShadow = true;
        mStroke = false;
        mBold = false;
        mSize = 0.0F;
        mFadingEdgeWidth = 0.0F;
        mFadingEdge = true;
        mShadowColor = DEFAULT_SHADOW_COLOR;
        mStrokeWidth = 1.0F;
        mStrokeColor = DEFAULT_STROKE_COLOR;
        mLineSpace = DEFAULT_LINE_SPACE;
        mText = s;
        mSize = f4;
        mColor = k;
        mShadow = flag;
        mHAlign = i;
        mVAlign = j;
        mPaint = new Paint();
        if (f4 != 0.0F)
        {
            mPaint.setTextSize(f4);
        }
        mPaint.setColor(k);
        mPaint.setAntiAlias(true);
        mPaint.setTypeface(typeface);
        mMetrics = mPaint.getFontMetricsInt();
        mWidth = (int)f2;
        mHeight = (int)f3;
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).append(", mText : ").append(mText).toString());
        }
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        mStringHeight = (mMetrics.descent - mMetrics.ascent) + DEFAULT_PADDING * 2;
        mSizeSpecified = true;
        init();
    }

    public GLStringTexture(GLContext glcontext, float f, float f1, String s, float f2, int i, boolean flag)
    {
        super(glcontext, f, f1);
        mWidth = 0;
        mHeight = 0;
        mStringWidth = 0;
        mStringHeight = 0;
        mHAlign = 1;
        mVAlign = 1;
        mColor = DEFAULT_TEXT_COLOR;
        mShadow = true;
        mStroke = false;
        mBold = false;
        mSize = 0.0F;
        mFadingEdgeWidth = 0.0F;
        mFadingEdge = true;
        mShadowColor = DEFAULT_SHADOW_COLOR;
        mStrokeWidth = 1.0F;
        mStrokeColor = DEFAULT_STROKE_COLOR;
        mLineSpace = DEFAULT_LINE_SPACE;
        mText = s;
        mSize = f2;
        mColor = i;
        mShadow = flag;
        mPaint = new Paint();
        if (f2 != 0.0F)
        {
            mPaint.setTextSize(f2);
        }
        mPaint.setColor(i);
        mPaint.setAntiAlias(true);
        mMetrics = mPaint.getFontMetricsInt();
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        mStringHeight = (mMetrics.descent - mMetrics.ascent) + DEFAULT_PADDING * 2;
        mWidth = mStringWidth;
        mHeight = mStringHeight;
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).append(", mText : ").append(mText).toString());
        }
        mSizeSpecified = true;
        init();
    }

    private int getBreakIndex(String s, int i)
    {
        int j = s.length();
        if ((int)Math.ceil(mPaint.measureText(s)) < i)
        {
            return s.length();
        }
        int k;
        do
        {
            k = j - 1;
            s = mText.substring(0, k);
            j = k;
        } while ((int)Math.ceil(mPaint.measureText(s)) > i);
        return k;
    }

    private int getDynamicHeight()
    {
        int i;
        boolean flag;
        int i1;
        int j1;
        j1 = 0;
        i = 0;
        i1 = 1;
        flag = false;
_L3:
        int j;
        int k;
        int l;
        boolean flag1;
        j = mText.indexOf(" ", i + 1);
        String s;
        if (j != -1)
        {
            s = mText.substring(j1, j);
            i = (int)Math.ceil(mPaint.measureText(s));
        } else
        {
            j = mText.length();
            s = mText.substring(j1, j);
            i = (int)Math.ceil(mPaint.measureText(s));
        }
        l = s.indexOf('\n');
        if (l == -1) goto _L2; else goto _L1
_L1:
        k = i1 + 1;
        l = j1 + (l + 1);
        flag1 = flag;
        i = j;
_L6:
        flag = flag1;
        i1 = k;
        j1 = l;
        if (flag1)
        {
            return mStringHeight * k + mLineSpace * (k - 1);
        }
          goto _L3
_L2:
        if (i <= mWidth)
        {
            break MISSING_BLOCK_LABEL_314;
        }
        if (j != mText.length()) goto _L5; else goto _L4
_L4:
label0:
        {
            j = mText.lastIndexOf(" ", j - 1);
            if (j != -1)
            {
                i = j;
                if (j1 < j + 1)
                {
                    break label0;
                }
            }
            i = (j1 + getBreakIndex(mText.substring(j1, mText.length()), mWidth)) - 1;
        }
_L9:
        l = i + 1;
        k = i1 + 1;
        flag1 = flag;
          goto _L6
_L5:
        k = mText.lastIndexOf(" ", j - 1);
        if (k == -1) goto _L8; else goto _L7
_L7:
        i = k;
        if (j1 < k + 1) goto _L9; else goto _L8
_L8:
        i = (j1 + getBreakIndex(mText.substring(j1, j), mWidth)) - 1;
          goto _L9
        i = j;
        flag1 = flag;
        k = i1;
        l = j1;
        if (j == mText.length())
        {
            flag1 = true;
            i = j;
            k = i1;
            l = j1;
        }
          goto _L6
    }

    private int getNumOfNewLineChar(String s)
    {
        int j = 0;
        int k = 0;
        int i;
        int l;
        do
        {
            k = mText.indexOf('\n', k);
            l = j;
            i = k;
            if (k != -1)
            {
                l = j + 1;
                i = k + 1;
            }
            j = l;
            k = i;
        } while (i != -1);
        return l;
    }

    private void init()
    {
        mShadowOffsetX = getContext().getDensity() * 1.0F;
        mShadowOffsetY = getContext().getDensity() * 1.0F;
        mShadowRadius = getContext().getDensity() * 1.0F;
        mFadingEdgeWidth = getContext().getDensity() * 20F;
    }

    private String insertEllipsis(String s, int i)
    {
        int l = s.length() - NUM_OF_ELLIPSIS_CHARACTER;
        String s1 = "";
        if ((int)Math.ceil(mPaint.measureText(s)) < i || l < 0)
        {
            return s;
        }
        for (int j = 0; j < NUM_OF_ELLIPSIS_CHARACTER; j++)
        {
            s1 = s1.concat(".");
        }

        int k = l;
        if ((int)Math.ceil(mPaint.measureText(s1)) >= i)
        {
            return s1;
        }
        String s2;
        do
        {
            s2 = s.substring(0, k).concat(s1);
            l = (int)Math.ceil(mPaint.measureText(s2));
            k--;
        } while (i < l);
        return s2;
    }

    private boolean isFadingNeeded(String s, int i)
    {
        return Math.ceil(mPaint.measureText(s)) > (double)i;
    }

    private List wordBreak(int i)
    {
        ArrayList arraylist = new ArrayList();
        int k2 = 0;
        boolean flag = false;
        int l = getNumOfNewLineChar(mText);
        int j = 0;
        if (i == l + 1)
        {
            i = j;
            int i1;
            do
            {
                i1 = mText.indexOf('\n', i);
                j = i;
                if (i1 != -1)
                {
                    arraylist.add(mText.substring(i, i1));
                    j = i1 + 1;
                }
                i = j;
            } while (i1 != -1);
            if (mFadingEdge)
            {
                arraylist.add(mText.substring(j, mText.length()));
                return arraylist;
            } else
            {
                arraylist.add(insertEllipsis(mText.substring(j, mText.length()), mWidth));
                return arraylist;
            }
        }
        int l2 = 0;
        int j2 = 0;
        do
        {
            int i2 = GLText.getIndexOfDelimiters(mText, j2 + 1);
            String s;
            int k;
            int j1;
            int l1;
            if (i2 != -1)
            {
                String s1 = mText.substring(l2, i2);
                int k1 = (int)Math.ceil(mPaint.measureText(s1));
                k = i2;
                j1 = k1;
                s = s1;
                if (mText.charAt(i2) != ' ')
                {
                    k = i2 - 1;
                    s = s1;
                    j1 = k1;
                }
            } else
            {
                k = mText.length();
                s = mText.substring(l2, k);
                j1 = (int)Math.ceil(mPaint.measureText(s));
            }
            l1 = s.indexOf('\n');
            if (l1 != -1)
            {
                k = l2 + l1;
                s = mText.substring(l2, k);
                j1 = (int)Math.ceil(mPaint.measureText(s));
            }
            if (j1 > mWidth)
            {
                if (k == mText.length())
                {
                    l1 = GLText.getLastIndexOfDelimiters(mText, k - 1);
                    if (l1 == -1 || l2 >= l1)
                    {
                        if (i > k2 + 1)
                        {
                            k = l2 + GLText.getBreakIndex(mPaint, mText.substring(l2, mText.length()), mWidth);
                            arraylist.add(mText.substring(l2, k));
                            k--;
                            j1 = ((flag) ? 1 : 0);
                        } else
                        {
                            if (mFadingEdge)
                            {
                                arraylist.add(mText.substring(l2, mText.length()));
                            } else
                            {
                                arraylist.add(insertEllipsis(mText.substring(l2, mText.length()), mWidth));
                            }
                            j1 = 1;
                            k = l1;
                        }
                    } else
                    {
                        k = l1;
                        j1 = ((flag) ? 1 : 0);
                        if (l2 != l1)
                        {
                            if (i > k2 + 1)
                            {
                                arraylist.add(mText.substring(l2, l1));
                                k = l1;
                                j1 = ((flag) ? 1 : 0);
                                if (mText.charAt(l1) != ' ')
                                {
                                    k = l1 - 1;
                                    j1 = ((flag) ? 1 : 0);
                                }
                            } else
                            {
                                if (mFadingEdge)
                                {
                                    arraylist.add(mText.substring(l2, mText.length()));
                                } else
                                {
                                    arraylist.add(insertEllipsis(mText.substring(l2, mText.length()), mWidth));
                                }
                                j1 = 1;
                                k = l1;
                            }
                        }
                    }
                } else
                {
                    l1 = GLText.getLastIndexOfDelimiters(mText, k - 1);
                    if (l1 == -1 || l2 >= l1)
                    {
                        if (i > k2 + 1)
                        {
                            k = l2 + GLText.getBreakIndex(mPaint, mText.substring(l2, k), mWidth);
                            arraylist.add(mText.substring(l2, k));
                            k--;
                            j1 = ((flag) ? 1 : 0);
                        } else
                        {
                            if (mFadingEdge)
                            {
                                arraylist.add(mText.substring(l2, mText.length()));
                            } else
                            {
                                arraylist.add(insertEllipsis(mText.substring(l2, mText.length()), mWidth));
                            }
                            j1 = 1;
                        }
                    } else
                    if (i > k2 + 1)
                    {
                        arraylist.add(mText.substring(l2, l1));
                        k = l1;
                        j1 = ((flag) ? 1 : 0);
                        if (mText.charAt(l1) != ' ')
                        {
                            k = l1 - 1;
                            j1 = ((flag) ? 1 : 0);
                        }
                    } else
                    {
                        if (mFadingEdge)
                        {
                            arraylist.add(mText.substring(l2, mText.length()));
                        } else
                        {
                            arraylist.add(insertEllipsis(mText.substring(l2, mText.length()), mWidth));
                        }
                        j1 = 1;
                        k = l1;
                    }
                }
                i2 = k + 1;
                l1 = k2 + 1;
                j2 = k;
            } else
            if (l1 != -1)
            {
                arraylist.add(mText.substring(l2, l2 + l1));
                i2 = l2 + (l1 + 1);
                l1 = k2 + 1;
                j2 = k;
                j1 = ((flag) ? 1 : 0);
            } else
            {
                j2 = k;
                j1 = ((flag) ? 1 : 0);
                l1 = k2;
                i2 = l2;
                if (k == mText.length())
                {
                    arraylist.add(s);
                    j1 = 1;
                    j2 = k;
                    l1 = k2;
                    i2 = l2;
                }
            }
            flag = j1;
            k2 = l1;
            l2 = i2;
            if (j1 != 0)
            {
                return arraylist;
            }
        } while (true);
    }

    public int getAvailableRows()
    {
        return mHeight / mStringHeight;
    }

    public int getStringHeight()
    {
        return mStringHeight;
    }

    public int getStringWidth()
    {
        return mStringWidth;
    }

    public String getText()
    {
        return mText;
    }

    protected Bitmap loadBitmap()
    {
        this;
        JVM INSTR monitorenter ;
        float f;
        float f1;
        f1 = 0.0F;
        f = 0.0F;
        Object obj;
        Canvas canvas;
        mPaint.setFakeBoldText(mBold);
        mPaint.setColor(mColor);
        mPaint.setShader(null);
        if (mShadow)
        {
            mPaint.setShadowLayer(mShadowRadius, mShadowOffsetX, mShadowOffsetY, mShadowColor);
        }
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("loadBitmap - mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).append(getText()).toString());
        }
        obj = Bitmap.createBitmap(mWidth, mHeight, android.graphics.Bitmap.Config.ARGB_8888);
        canvas = new Canvas(((Bitmap) (obj)));
        if (mWidth >= mStringWidth && getNumOfNewLineChar(mText) <= 0) goto _L2; else goto _L1
_L1:
        List list = wordBreak(getAvailableRows());
        if (list == null) goto _L4; else goto _L3
_L3:
        int k1;
        int l1;
        int i = mStringHeight;
        int k = list.size();
        int i1 = DEFAULT_LINE_SPACE;
        k1 = list.size();
        k1 = (mHeight - (i * k + i1 * (k1 - 1))) / 2;
        l1 = (mHeight - mStringHeight * list.size()) / (list.size() + 1);
        int j = 0;
_L79:
        if (j >= list.size()) goto _L4; else goto _L5
_L5:
        mVAlign;
        JVM INSTR tableswitch 1 3: default 2376
    //                   1 512
    //                   2 566
    //                   3 632;
           goto _L6 _L7 _L8 _L9
_L6:
        int l;
        int j1;
        j1 = 0;
        l = j1;
        if (j != list.size() - 1) goto _L11; else goto _L10
_L10:
        l = j1;
        if (!mFadingEdge) goto _L11; else goto _L12
_L12:
        l = j1;
        if (!isFadingNeeded((String)list.get(j), mWidth)) goto _L11; else goto _L13
_L13:
        mPaint.clearShadowLayer();
        if (!GLUtil.isLocaleRTL()) goto _L15; else goto _L14
_L14:
        f1 = mFadingEdgeWidth;
        if (!mStroke) goto _L17; else goto _L16
_L16:
        l = mStrokeColor;
_L30:
        if (!mStroke) goto _L19; else goto _L18
_L18:
        j1 = mStrokeColor;
_L31:
        LinearGradient lineargradient = new LinearGradient(0.0F, 0.0F, f1, 0.0F, l & 0xffffff, j1 | 0xff000000, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient);
_L36:
        mPaint.setXfermode(new PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC));
        l = 1;
_L11:
        mHAlign;
        JVM INSTR tableswitch 1 3: default 2379
    //                   1 855
    //                   2 1143
    //                   3 1489;
           goto _L20 _L21 _L22 _L23
_L7:
        if (j != 0) goto _L25; else goto _L24
_L24:
        f = mStringHeight * j - mMetrics.ascent;
          goto _L6
_L25:
        f = (mStringHeight * j + DEFAULT_LINE_SPACE * (j - 1)) - mMetrics.ascent;
          goto _L6
_L8:
        if (l1 <= DEFAULT_LINE_SPACE) goto _L27; else goto _L26
_L26:
        f = (mStringHeight * j + k1 + DEFAULT_LINE_SPACE * j) - mMetrics.ascent;
          goto _L6
_L27:
        f = ((j + 1) * l1 + mStringHeight * j) - mMetrics.ascent;
          goto _L6
_L9:
        if (j != 0) goto _L29; else goto _L28
_L28:
        f = mHeight - mStringHeight * (list.size() - 1 - j) - mMetrics.descent - DEFAULT_PADDING;
          goto _L6
_L29:
        f = mHeight - mStringHeight * (list.size() - 1 - j) - DEFAULT_LINE_SPACE * (j - 1) - mMetrics.descent - DEFAULT_PADDING;
          goto _L6
_L17:
        l = mColor;
          goto _L30
_L19:
        j1 = mColor;
          goto _L31
_L15:
        float f2;
        float f3;
        f1 = mWidth;
        f2 = mFadingEdgeWidth;
        f3 = mWidth;
        if (!mStroke) goto _L33; else goto _L32
_L32:
        l = mStrokeColor;
_L37:
        if (!mStroke) goto _L35; else goto _L34
_L34:
        j1 = mStrokeColor;
_L38:
        LinearGradient lineargradient1 = new LinearGradient(f1 - f2, 0.0F, f3, 0.0F, l | 0xff000000, j1 & 0xffffff, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient1);
          goto _L36
        obj;
        throw obj;
_L33:
        l = mColor;
          goto _L37
_L35:
        j1 = mColor;
          goto _L38
_L21:
        mPaint.setTextAlign(android.graphics.Paint.Align.LEFT);
        if (!mShadow || mShadowOffsetX + mShadowRadius >= 0.0F) goto _L40; else goto _L39
_L39:
        f1 = (float)DEFAULT_PADDING + Math.abs(mShadowOffsetX + mShadowRadius);
_L46:
        if (!mStroke) goto _L42; else goto _L41
_L41:
        mPaint.setColor(mStrokeColor);
        android.graphics.Paint.Style style3 = mPaint.getStyle();
        mPaint.setStyle(android.graphics.Paint.Style.STROKE);
        mPaint.setStrokeWidth(mStrokeWidth);
        canvas.drawText((String)list.get(j), f1, f, mPaint);
        mPaint.setStyle(style3);
        mPaint.setColor(mColor);
        if (l == 0) goto _L42; else goto _L43
_L43:
        if (!GLUtil.isLocaleRTL()) goto _L45; else goto _L44
_L44:
        LinearGradient lineargradient2 = new LinearGradient(0.0F, 0.0F, mFadingEdgeWidth, 0.0F, mColor & 0xffffff, mColor | 0xff000000, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient2);
_L42:
        canvas.drawText((String)list.get(j), f1, f, mPaint);
          goto _L20
_L40:
        f1 = DEFAULT_PADDING;
          goto _L46
_L45:
        LinearGradient lineargradient3 = new LinearGradient((float)mWidth - mFadingEdgeWidth, 0.0F, mWidth, 0.0F, mColor | 0xff000000, mColor & 0xffffff, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient3);
          goto _L42
_L22:
        mPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        if (mWidth >= (int)Math.ceil(mPaint.measureText((String)list.get(j))) + DEFAULT_PADDING * 2) goto _L48; else goto _L47
_L47:
        mPaint.setTextAlign(android.graphics.Paint.Align.LEFT);
        if (!mShadow || mShadowOffsetX + mShadowRadius >= 0.0F) goto _L50; else goto _L49
_L49:
        f1 = (float)DEFAULT_PADDING + Math.abs(mShadowOffsetX + mShadowRadius);
_L56:
        if (!mStroke) goto _L52; else goto _L51
_L51:
        mPaint.setColor(mStrokeColor);
        android.graphics.Paint.Style style4 = mPaint.getStyle();
        mPaint.setStyle(android.graphics.Paint.Style.STROKE);
        mPaint.setStrokeWidth(mStrokeWidth);
        canvas.drawText((String)list.get(j), f1, f, mPaint);
        mPaint.setStyle(style4);
        mPaint.setColor(mColor);
        if (l == 0) goto _L52; else goto _L53
_L53:
        if (!GLUtil.isLocaleRTL()) goto _L55; else goto _L54
_L54:
        LinearGradient lineargradient4 = new LinearGradient(0.0F, 0.0F, mFadingEdgeWidth, 0.0F, mColor & 0xffffff, mColor | 0xff000000, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient4);
_L52:
        canvas.drawText((String)list.get(j), f1, f, mPaint);
          goto _L20
_L50:
        f1 = DEFAULT_PADDING;
          goto _L56
_L48:
        f1 = (float)mWidth / 2.0F;
          goto _L56
_L55:
        LinearGradient lineargradient5 = new LinearGradient((float)mWidth - mFadingEdgeWidth, 0.0F, mWidth, 0.0F, mColor | 0xff000000, mColor & 0xffffff, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient5);
          goto _L52
_L23:
        mPaint.setTextAlign(android.graphics.Paint.Align.RIGHT);
        if (!mShadow || mShadowOffsetX + mShadowRadius <= 0.0F) goto _L58; else goto _L57
_L57:
        f1 = (float)(mWidth - DEFAULT_PADDING) - (mShadowOffsetX + mShadowRadius);
_L64:
        if (!mStroke) goto _L60; else goto _L59
_L59:
        mPaint.setColor(mStrokeColor);
        android.graphics.Paint.Style style5 = mPaint.getStyle();
        mPaint.setStyle(android.graphics.Paint.Style.STROKE);
        mPaint.setStrokeWidth(mStrokeWidth);
        canvas.drawText((String)list.get(j), f1, f, mPaint);
        mPaint.setStyle(style5);
        mPaint.setColor(mColor);
        if (l == 0) goto _L60; else goto _L61
_L61:
        if (!GLUtil.isLocaleRTL()) goto _L63; else goto _L62
_L62:
        LinearGradient lineargradient6 = new LinearGradient(0.0F, 0.0F, mFadingEdgeWidth, 0.0F, mColor & 0xffffff, mColor | 0xff000000, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient6);
_L60:
        canvas.drawText((String)list.get(j), f1, f, mPaint);
          goto _L20
_L58:
        f1 = mWidth - DEFAULT_PADDING;
          goto _L64
_L63:
        LinearGradient lineargradient7 = new LinearGradient((float)mWidth - mFadingEdgeWidth, 0.0F, mWidth, 0.0F, mColor | 0xff000000, mColor & 0xffffff, android.graphics.Shader.TileMode.CLAMP);
        mPaint.setShader(lineargradient7);
          goto _L60
_L2:
        mVAlign;
        JVM INSTR tableswitch 1 3: default 2388
    //                   1 1857
    //                   2 1870
    //                   3 1905;
           goto _L65 _L66 _L67 _L68
_L72:
        j = mHAlign;
        j;
        JVM INSTR tableswitch 1 3: default 1852
    //                   1 1922
    //                   2 2080
    //                   3 2203;
           goto _L4 _L69 _L70 _L71
_L4:
        this;
        JVM INSTR monitorexit ;
        return ((Bitmap) (obj));
_L66:
        f = -mMetrics.ascent;
          goto _L72
_L67:
        f = (mHeight - (mMetrics.descent - mMetrics.ascent)) / 2 - mMetrics.ascent;
          goto _L72
_L68:
        f = mHeight - mMetrics.descent;
          goto _L72
_L69:
        mPaint.setTextAlign(android.graphics.Paint.Align.LEFT);
        if (!mShadow || mShadowOffsetX + mShadowRadius >= 0.0F) goto _L74; else goto _L73
_L73:
        f1 = (float)DEFAULT_PADDING + Math.abs(mShadowOffsetX + mShadowRadius);
_L75:
        if (mStroke)
        {
            mPaint.setColor(mStrokeColor);
            android.graphics.Paint.Style style = mPaint.getStyle();
            mPaint.setStyle(android.graphics.Paint.Style.STROKE);
            mPaint.setStrokeWidth(mStrokeWidth);
            canvas.drawText(mText, f1, f, mPaint);
            mPaint.setStyle(style);
            mPaint.setColor(mColor);
        }
        canvas.drawText(mText, f1, f, mPaint);
          goto _L4
_L74:
        f1 = DEFAULT_PADDING;
          goto _L75
_L70:
        mPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        if (mStroke)
        {
            mPaint.setColor(mStrokeColor);
            android.graphics.Paint.Style style1 = mPaint.getStyle();
            mPaint.setStyle(android.graphics.Paint.Style.STROKE);
            mPaint.setStrokeWidth(mStrokeWidth);
            canvas.drawText(mText, (float)mWidth / 2.0F, f, mPaint);
            mPaint.setStyle(style1);
            mPaint.setColor(mColor);
        }
        canvas.drawText(mText, (float)mWidth / 2.0F, f, mPaint);
          goto _L4
_L71:
        mPaint.setTextAlign(android.graphics.Paint.Align.RIGHT);
        if (!mShadow || mShadowOffsetX + mShadowRadius <= 0.0F) goto _L77; else goto _L76
_L76:
        f1 = (float)(mWidth - DEFAULT_PADDING) - (mShadowOffsetX + mShadowRadius);
_L78:
        if (mStroke)
        {
            mPaint.setColor(mStrokeColor);
            android.graphics.Paint.Style style2 = mPaint.getStyle();
            mPaint.setStyle(android.graphics.Paint.Style.STROKE);
            mPaint.setStrokeWidth(mStrokeWidth);
            canvas.drawText(mText, f1, f, mPaint);
            mPaint.setStyle(style2);
            mPaint.setColor(mColor);
        }
        canvas.drawText(mText, f1, f, mPaint);
          goto _L4
_L77:
        j = mWidth;
        l = DEFAULT_PADDING;
        f1 = j - l;
          goto _L78
_L20:
        j++;
          goto _L79
_L65:
        f = f1;
          goto _L72
    }

    public void setAlign(int i, int j)
    {
        this;
        JVM INSTR monitorenter ;
        mHAlign = i;
        mVAlign = j;
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setBold(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        mBold = flag;
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setBoldColor(boolean flag, int i)
    {
        this;
        JVM INSTR monitorenter ;
        mBold = flag;
        mColor = i;
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setColor(int i)
    {
        this;
        JVM INSTR monitorenter ;
        mColor = i;
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setDynamicHeight(float f)
    {
        this;
        JVM INSTR monitorenter ;
        int i = (int)f;
        mWidth = i;
        mHeight = getDynamicHeight();
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("setDynamicHeight - mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).toString());
        }
        super.setSize(f, mHeight);
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setFadingEdge(boolean flag)
    {
        mFadingEdge = flag;
    }

    public void setFadingEdgeWidth(float f)
    {
        mFadingEdgeWidth = f;
        reLoad();
    }

    public void setFontSize(float f)
    {
        this;
        JVM INSTR monitorenter ;
        mSize = f;
        mPaint.setTextSize(mSize);
        mMetrics = mPaint.getFontMetricsInt();
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        mStringHeight = (mMetrics.descent - mMetrics.ascent) + DEFAULT_PADDING * 2;
        if (!getSizeSpecified())
        {
            mWidth = mStringWidth;
            mHeight = mStringHeight;
            if (mWidth <= 0 || mHeight <= 0)
            {
                Log.d("GLStringTexture", (new StringBuilder()).append("setFontSize - mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).toString());
            }
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setHeight(float f)
    {
        this;
        JVM INSTR monitorenter ;
        super.setHeight(f);
        mHeight = (int)f;
        if (mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("setHeight - mHeight : ").append(mHeight).toString());
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setLayout(int i, int j)
    {
        i;
        JVM INSTR tableswitch 1 3: default 28
    //                   1 71
    //                   2 71
    //                   3 71;
           goto _L1 _L2 _L2 _L2
_L1:
        mHAlign = 1;
_L5:
        j;
        JVM INSTR tableswitch 1 3: default 60
    //                   1 79
    //                   2 79
    //                   3 79;
           goto _L3 _L4 _L4 _L4
_L3:
        mVAlign = 2;
_L6:
        reLoad();
        return;
_L2:
        mHAlign = i;
          goto _L5
_L4:
        mVAlign = j;
          goto _L6
    }

    public void setLineSpace(int i)
    {
        mLineSpace = i;
    }

    public void setShadowColor(int i)
    {
        if (mShadowColor != i)
        {
            mShadowColor = i;
            reLoad();
        }
    }

    public void setShadowLayer(boolean flag, float f, float f1, float f2, int i)
    {
        boolean flag1 = false;
        if (mShadow != flag)
        {
            mShadow = flag;
            flag1 = true;
        }
        if (!GLUtil.floatEquals(mShadowRadius, f))
        {
            mShadowRadius = f;
            flag1 = true;
        }
        if (!GLUtil.floatEquals(mShadowOffsetX, f1))
        {
            mShadowOffsetX = f1;
            flag1 = true;
        }
        if (!GLUtil.floatEquals(mShadowOffsetY, f2))
        {
            mShadowOffsetY = f2;
            flag1 = true;
        }
        if (mShadowColor != i)
        {
            mShadowColor = i;
            flag1 = true;
        }
        if (flag1)
        {
            reLoad();
        }
    }

    public void setShadowOffset(float f, float f1)
    {
        boolean flag = false;
        if (!GLUtil.floatEquals(mShadowOffsetX, f))
        {
            mShadowOffsetX = f;
            flag = true;
        }
        if (!GLUtil.floatEquals(mShadowOffsetY, f1))
        {
            mShadowOffsetY = f1;
            flag = true;
        }
        if (flag)
        {
            reLoad();
        }
    }

    public void setShadowRadius(float f)
    {
        if (!GLUtil.floatEquals(mShadowRadius, f))
        {
            mShadowRadius = f;
            reLoad();
        }
    }

    public void setShadowVisibility(boolean flag)
    {
        mShadow = flag;
        reLoad();
    }

    public void setSize(float f, float f1)
    {
        this;
        JVM INSTR monitorenter ;
        super.setSize(f, f1);
        mWidth = (int)f;
        mHeight = (int)f1;
        if (mWidth <= 0 || mHeight <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("setSize - mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).toString());
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setStroke(boolean flag, float f, int i)
    {
        boolean flag1 = false;
        if (mStroke != flag)
        {
            mStroke = flag;
            flag1 = true;
        }
        if (!GLUtil.floatEquals(mStrokeWidth, f))
        {
            mStrokeWidth = f;
            flag1 = true;
        }
        if (mStrokeColor != i)
        {
            mStrokeColor = i;
            flag1 = true;
        }
        if (flag1)
        {
            reLoad();
        }
    }

    public void setStrokeColor(int i)
    {
        if (mStrokeColor != i)
        {
            mStrokeColor = i;
            reLoad();
        }
    }

    public void setStrokeVisibility(boolean flag)
    {
        if (mStroke != flag)
        {
            mStroke = flag;
            reLoad();
        }
    }

    public void setStrokeWidth(float f)
    {
        if (!GLUtil.floatEquals(mStrokeWidth, f))
        {
            mStrokeWidth = f;
            reLoad();
        }
    }

    public void setText(String s)
    {
        this;
        JVM INSTR monitorenter ;
        mText = s;
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        if (!getSizeGiven())
        {
            mWidth = mStringWidth;
            if (mWidth <= 0)
            {
                Log.d("GLStringTexture", (new StringBuilder()).append("setText - mWidth : ").append(mWidth).toString());
            }
            super.setSize(mWidth, mHeight);
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        s;
        throw s;
    }

    public void setText(String s, float f, int i)
    {
        this;
        JVM INSTR monitorenter ;
        mText = s;
        mSize = f;
        mColor = i;
        mPaint.setTextSize(mSize);
        mMetrics = mPaint.getFontMetricsInt();
        mStringWidth = (int)Math.ceil(mPaint.measureText(mText)) + DEFAULT_PADDING * 2;
        mStringHeight = (mMetrics.descent - mMetrics.ascent) + DEFAULT_PADDING * 2;
        if (!getSizeSpecified())
        {
            mWidth = mStringWidth;
            mHeight = mStringHeight;
            if (mWidth <= 0 || mHeight <= 0)
            {
                Log.d("GLStringTexture", (new StringBuilder()).append("setText - mWidth : ").append(mWidth).append(", mHeight : ").append(mHeight).toString());
            }
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        s;
        throw s;
    }

    public void setTextScaleX(float f)
    {
        this;
        JVM INSTR monitorenter ;
        mPaint.setTextScaleX(f);
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setTypeface(Typeface typeface)
    {
        this;
        JVM INSTR monitorenter ;
        mPaint.setTypeface(typeface);
        this;
        JVM INSTR monitorexit ;
        return;
        typeface;
        throw typeface;
    }

    public void setUnderline(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        mPaint.setUnderlineText(flag);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setWidth(float f)
    {
        this;
        JVM INSTR monitorenter ;
        super.setWidth(f);
        mWidth = (int)f;
        if (mWidth <= 0)
        {
            Log.d("GLStringTexture", (new StringBuilder()).append("setWidth - mWidth : ").append(mWidth).toString());
        }
        reLoad();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    static 
    {
        DEFAULT_TEXT_COLOR = GLContext.getColor(R.color.default_text_color);
        DEFAULT_SHADOW_COLOR = GLContext.getColor(R.color.default_black_color);
        DEFAULT_STROKE_COLOR = GLContext.getColor(R.color.default_black_color);
        DEFAULT_PADDING = 1;
        DEFAULT_LINE_SPACE = 5;
        NUM_OF_ELLIPSIS_CHARACTER = 3;
    }
}
