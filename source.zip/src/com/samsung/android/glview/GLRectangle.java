// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Log;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLUtil, GLContext, GLProgramStorage, 
//            GLProgram

public class GLRectangle extends GLTexture
{

    private static final float DEFAULT_THICKNESS = 1F;
    private static final int ROUNDDOWN_DIGIT = 0x186a0;
    private static final String TAG = "GLRectangle";
    public static final int TYPE_FILL = 1;
    public static final int TYPE_STROKE = 0;
    private float mColor[];
    private float mFillColor[];
    private GLProgram.NameIndexerObj mObjFillColor;
    private GLProgram.NameIndexerObj mObjSampler;
    private GLProgram.NameIndexerObj mObjThickness;
    private GLProgram.NameIndexerObj mObjType;
    private int mRectangleType;
    private float mThickness;

    public GLRectangle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4)
    {
        super(glcontext, 0.0F, 0.0F);
        mRectangleType = 0;
        mThickness = 1.0F;
        mObjType = null;
        mObjSampler = null;
        mObjThickness = null;
        mObjFillColor = null;
        mColor = new float[4];
        mRectangleType = 0;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness = 1.0F;
        } else
        {
            mThickness = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    public GLRectangle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4, 
            int j)
    {
        super(glcontext, 0.0F, 0.0F);
        mRectangleType = 0;
        mThickness = 1.0F;
        mObjType = null;
        mObjSampler = null;
        mObjThickness = null;
        mObjFillColor = null;
        mColor = new float[4];
        mRectangleType = j;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness = 1.0F;
        } else
        {
            mThickness = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    public int getColor()
    {
        return Color.argb((int)(mColor[0] * 255F), (int)(mColor[1] * 255F), (int)(mColor[2] * 255F), (int)(mColor[3] * 255F));
    }

    public float getThickness()
    {
        return mThickness;
    }

    public void initSize()
    {
        setSize(getWidth(), getHeight());
    }

    protected Bitmap loadBitmap()
    {
        return null;
    }

    public void onDraw()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mTextureLoaded;
        if (flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (!mLayoutUpdated) goto _L4; else goto _L3
_L3:
        setVertices();
        if (mVertexBuffer != null)
        {
            mVertexBuffer.clear();
        }
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        mLayoutUpdated = false;
_L7:
        GLES20.glUseProgram(mProgramID);
        GLES20.glUniform4fv(mObjSampler.mHandle, 1, mColor, 0);
        GLES20.glUniform4fv(mObjFillColor.mHandle, 1, mFillColor, 0);
        Matrix.multiplyMM(mViewMatrix, 0, getContext().getProjMatrix(), 0, getMatrix(), 0);
        GLES20.glUniformMatrix4fv(mObjMVPMatrix.mHandle, 1, false, mViewMatrix, 0);
        GLES20.glUniform1f(mObjAlpha.mHandle, getAlpha());
        GLES20.glUniform1f(mObjThickness.mHandle, (float)(int)((1.0F / getWidth()) * mThickness * 100000F) / 100000F);
        GLES20.glUniform1f(mObjType.mHandle, mRectangleType);
        GLES20.glUniform1f(mObjParam.mHandle, getWidth() / getHeight());
        GLES20.glEnableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glEnableVertexAttribArray(mObjTextureCoord.mHandle);
        GLES20.glDisable(2929);
        GLES20.glVertexAttribPointer(mObjPosition.mHandle, 3, 5126, false, 0, mVertexBuffer);
        GLES20.glVertexAttribPointer(mObjTextureCoord.mHandle, 2, 5126, false, 0, mTexCoordBuffer);
        if (mTextureReloaded)
        {
            mTextureReloaded = false;
        }
        GLES20.glDrawElements(4, mIndices.length, 5121, mIndexBuffer);
        GLES20.glDisableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glDisableVertexAttribArray(mObjTextureCoord.mHandle);
        GLES20.glEnable(2929);
        if (true) goto _L1; else goto _L5
_L5:
        Exception exception;
        exception;
        throw exception;
_L4:
        if (mVertexBuffer != null && mIndexBuffer != null && mTexCoordBuffer != null) goto _L7; else goto _L6
_L6:
        Log.e("GLRectangle", "init buffers on onDraw");
        setVertices();
        initBuffers();
          goto _L7
    }

    protected boolean onLoad()
    {
        initSize();
        setVertices();
        initBuffers();
        GLProgram glprogram = getContext().getProgramStorage().getProgram(1008);
        if (glprogram != null)
        {
            mProgramID = glprogram.getProgramID();
            mObjMVPMatrix = glprogram.getNameIndexer("u_MVPMatrix");
            mObjPosition = glprogram.getNameIndexer("a_position");
            mObjTextureCoord = glprogram.getNameIndexer("a_texcoord");
            mObjSampler = glprogram.getNameIndexer("tex_sampler");
            mObjFillColor = glprogram.getNameIndexer("fill_color");
            mObjAlpha = glprogram.getNameIndexer("u_alpha");
            mObjThickness = glprogram.getNameIndexer("u_thickness");
            mObjParam = glprogram.getNameIndexer("u_param");
            mObjType = glprogram.getNameIndexer("u_type");
        }
        mTextureLoaded = true;
        return true;
    }

    public void setColor(int i)
    {
        mColor[0] = (float)Color.red(i) / 255F;
        mColor[1] = (float)Color.green(i) / 255F;
        mColor[2] = (float)Color.blue(i) / 255F;
        mColor[3] = (float)Color.alpha(i) / 255F;
        if (mFillColor == null)
        {
            mFillColor = new float[4];
            mFillColor[0] = (float)Color.red(i) / 255F;
            mFillColor[1] = (float)Color.green(i) / 255F;
            mFillColor[2] = (float)Color.blue(i) / 255F;
            mFillColor[3] = (float)Color.alpha(i) / 255F;
        }
    }

    public void setFillColor(int i)
    {
        if (mFillColor == null)
        {
            mFillColor = new float[4];
        }
        mFillColor[0] = (float)Color.red(i) / 255F;
        mFillColor[1] = (float)Color.green(i) / 255F;
        mFillColor[2] = (float)Color.blue(i) / 255F;
        mFillColor[3] = (float)Color.alpha(i) / 255F;
    }

    public void setRect(float f, float f1, float f2, float f3)
    {
        translateAbsolute(f, f1);
        setSize(f2, f3);
        setVertices();
        initBuffers();
    }

    public void setRect(RectF rectf)
    {
        setRect(rectf.left, rectf.top, rectf.width(), rectf.height());
    }

    public void setThickness(float f)
    {
        mThickness = f;
    }
}
