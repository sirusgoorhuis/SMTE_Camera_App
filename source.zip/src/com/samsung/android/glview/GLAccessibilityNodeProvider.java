// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Rect;
import android.opengl.GLSurfaceView;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.ArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLContext, GLViewGroup, GLView, GLAbsList

public class GLAccessibilityNodeProvider extends AccessibilityNodeProvider
{

    private GLContext mGLContext;
    private GLSurfaceView mGLSurfaceView;
    private ArrayList mListChildViewNode;

    public GLAccessibilityNodeProvider(GLContext glcontext, GLSurfaceView glsurfaceview)
    {
        mGLContext = null;
        mGLSurfaceView = null;
        mListChildViewNode = null;
        mGLContext = glcontext;
        mGLSurfaceView = glsurfaceview;
    }

    public AccessibilityNodeInfo createAccessibilityNodeInfo(int i)
    {
        Object obj;
        Object obj2;
        AccessibilityNodeInfo accessibilitynodeinfo;
label0:
        {
            obj = null;
            if (i == -1)
            {
                obj = AccessibilityNodeInfo.obtain(mGLSurfaceView);
                mGLSurfaceView.onInitializeAccessibilityNodeInfo(((AccessibilityNodeInfo) (obj)));
                mGLSurfaceView.setImportantForAccessibility(2);
                if (mListChildViewNode != null)
                {
                    mListChildViewNode.clear();
                    mListChildViewNode = null;
                }
                if (mGLContext != null && mGLContext.getRootView() != null)
                {
                    i = GLContext.getLastOrientation();
                    Object obj1 = new Rect();
                    ((AccessibilityNodeInfo) (obj)).getBoundsInScreen(((Rect) (obj1)));
                    ((AccessibilityNodeInfo) (obj)).setBoundsInScreen(getDimensionByOrientation(i, ((Rect) (obj1))));
                    mGLContext.enableAccessibilityNode(true);
                    obj1 = new ArrayList();
                    mGLContext.getRootView().addAccessibilityBaseViewNode(((ArrayList) (obj1)));
                    if (!((ArrayList) (obj1)).isEmpty())
                    {
                        for (i = 0; i < ((ArrayList) (obj1)).size(); i++)
                        {
                            ((AccessibilityNodeInfo) (obj)).addChild(mGLSurfaceView, ((GLView)((ArrayList) (obj1)).get(i)).getId());
                        }

                    }
                }
                return ((AccessibilityNodeInfo) (obj));
            }
            obj2 = obj;
            if (mGLContext != null)
            {
                obj2 = obj;
                if (mGLContext.getRootView() != null)
                {
                    obj2 = mGLContext.getRootView().findViewById(i);
                }
            }
            if (obj2 == null)
            {
                return AccessibilityNodeInfo.obtain(mGLSurfaceView);
            }
            accessibilitynodeinfo = AccessibilityNodeInfo.obtain(mGLSurfaceView, ((GLView) (obj2)).getId());
            mGLSurfaceView.onInitializeAccessibilityNodeInfo(accessibilitynodeinfo);
            int ai[] = new int[2];
            mGLSurfaceView.getLocationInWindow(ai);
            if (((GLView) (obj2)).getVisibility() != 0)
            {
                return accessibilitynodeinfo;
            }
            ai = new Rect();
            ai.top = ((GLView) (obj2)).getClipRect().top;
            ai.left = ((GLView) (obj2)).getClipRect().left;
            ai.right = ((GLView) (obj2)).getClipRect().right;
            ai.bottom = ((GLView) (obj2)).getClipRect().bottom;
            ai = getDimensionByOrientation(GLContext.getLastOrientation(), ai);
            accessibilitynodeinfo.setBoundsInParent(ai);
            accessibilitynodeinfo.setText(((GLView) (obj2)).getTitle());
            accessibilitynodeinfo.setBoundsInScreen(ai);
            accessibilitynodeinfo.setSource(mGLSurfaceView, ((GLView) (obj2)).getId());
            String s1 = obj2.getClass().getSimpleName();
            String s = "";
            accessibilitynodeinfo.setClassName(s1);
            ai = s;
            if (s1 == null)
            {
                break label0;
            }
            if (!s1.equals("GLList"))
            {
                ai = s;
                if (!s1.equals("GLGridList"))
                {
                    break label0;
                }
            }
            ai = (GLAbsList)obj2;
            accessibilitynodeinfo.setCheckable(true);
            accessibilitynodeinfo.setScrollable(ai.isScrollable());
            if (ai.getScrollOrientation() == 1)
            {
                ai = ":SCROLL_PORTRAIT";
            } else
            {
                ai = ":SCROLL_LANDSCAPE";
            }
        }
        if (((GLView) (obj2)).getContentDescription() != null)
        {
            accessibilitynodeinfo.setContentDescription((new StringBuilder()).append(((GLView) (obj2)).getContentDescription()).append(ai).toString());
        } else
        {
            accessibilitynodeinfo.setContentDescription((new StringBuilder()).append(((GLView) (obj2)).getObjectTag()).append(ai).toString());
        }
        accessibilitynodeinfo.setViewIdResourceName(((GLView) (obj2)).getObjectTag());
        accessibilitynodeinfo.setEnabled(true);
        if (((GLView) (obj2)).isClickable() && !((GLView) (obj2)).getBypassTouch())
        {
            accessibilitynodeinfo.setClickable(true);
        }
        if (mListChildViewNode == null)
        {
            mListChildViewNode = new ArrayList();
            mGLContext.getRootView().addAccessibilityChildViewNode(mListChildViewNode);
        }
        if (!mListChildViewNode.isEmpty())
        {
            ai = new ArrayList();
            for (i = 0; i < mListChildViewNode.size(); i++)
            {
                if (((GLView)mListChildViewNode.get(i)).getParentId() == ((GLView) (obj2)).getId())
                {
                    accessibilitynodeinfo.addChild(mGLSurfaceView, ((GLView)mListChildViewNode.get(i)).getId());
                    ai.add(mListChildViewNode.get(i));
                }
            }

            if (!ai.isEmpty())
            {
                for (i = 0; i < ai.size(); i++)
                {
                    mListChildViewNode.remove(ai.get(i));
                }

            }
        }
        return accessibilitynodeinfo;
    }

    public Rect getDimensionByOrientation(int i, Rect rect)
    {
        Rect rect1 = new Rect();
        int j = GLContext.getScreenWidthPixels();
        int k = GLContext.getScreenHeightPixels();
        switch (i)
        {
        default:
            rect1.top = rect.top;
            rect1.left = rect.left;
            rect1.right = rect.right;
            rect1.bottom = rect.bottom;
            return rect1;

        case 1: // '\001'
            rect1.top = j - rect.right;
            rect1.left = rect.top;
            rect1.right = rect.bottom;
            rect1.bottom = j - rect.left;
            return rect1;

        case 2: // '\002'
            rect1.top = k - rect.bottom;
            rect1.left = j - rect.right;
            rect1.right = j - rect.left;
            rect1.bottom = k - rect.top;
            return rect1;

        case 3: // '\003'
            rect1.top = rect.left;
            break;
        }
        rect1.left = k - rect.bottom;
        rect1.right = k - rect.top;
        rect1.bottom = rect.right;
        return rect1;
    }
}
