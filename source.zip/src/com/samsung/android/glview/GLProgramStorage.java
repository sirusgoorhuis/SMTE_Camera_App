// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

// Referenced classes of package com.samsung.android.glview:
//            GLProgram

public class GLProgramStorage
{

    public static final String BASE_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n}\n";
    public static final String BASE_TINT_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nuniform lowp vec4  u_tint_color;\nvarying vec2 v_texcoord;\nvoid main() {\n  lowp vec4 color = texture2D(tex_sampler, v_texcoord);\n  gl_FragColor = (u_tint_color * color.a) * u_alpha;\n}\n";
    public static final String BASE_VERTEX_SHADER = "precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n";
    public static final String CIRCLE_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp vec4 tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_thickness;\nuniform float u_type;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  if (abs(distance(v_texcoord, vec2(center, center))) <= center) {\n     if (u_type == 1.0 || pow(v_texcoord.x - center, 2.0) / pow(center - u_thickness, 2.0) + pow((1.0 - v_texcoord.y - center), 2.0) / pow(center - u_thickness * u_param, 2.0) >= 1.0) {\n         gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n     } else {\n      discard;\n     }\n  } else {\n      discard;\n  }\n}\n";
    public static final String CIRCULAR_CLIP_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nconst float diameter = 0.9999;\nconst float center = 0.5;\nvoid main() {\n  vec2 coord = v_texcoord - vec2(center, center);\n  float dist = length(coord / diameter);\n  if ((dist < center) && (dist > center * u_step)) {\n      gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n  } else {\n      gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n  }\n}\n";
    public static final String FADE_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nuniform float u_param;\nuniform float u_alpha;\nconst float accel_pos = 0.2;\nvoid main() {\n    float orientation_pos = sign(u_step);\n    float direction = sign(1.0 - abs(u_step));\n    float alpha = 1.0;\n    float pos = ((1.0 - direction) + direction * abs(u_step)) * (1.0 + u_param);\n    if (pos < accel_pos) {\n        pos = sin(radians(90.0 * (1.0 / accel_pos) * pos)) * accel_pos;\n    }\n    orientation_pos = v_texcoord.x * sign(1.0 - orientation_pos) + v_texcoord.y * sign(1.0 + orientation_pos);\n    if (orientation_pos < pos) {\n        alpha = max(0.0, (orientation_pos - (pos - u_param)) / u_param);\n    }\n    direction = sign(direction + 0.5);\n    alpha = sign(1.0 - direction) + direction * alpha;\n    gl_FragColor = texture2D(tex_sampler, v_texcoord) * (alpha * u_alpha);\n}\n";
    public static final String LINE_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp vec4 tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n}\n";
    public static final String LINE_VERTEX_SHADER = "precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute float a_pointsize;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  gl_PointSize = a_pointsize;\n}\n";
    public static final String RECTANGLE_FRAGMENT_SHADER = "precision highp float;\nuniform lowp vec4 tex_sampler;\nuniform lowp vec4 fill_color;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_thickness;\nuniform float u_type;\nuniform float u_param;\nvoid main() {\n  if (v_texcoord.x <= u_thickness || v_texcoord.x >= (1.0 - u_thickness) || v_texcoord.y <= u_thickness * u_param || v_texcoord.y >= (1.0 - u_thickness * u_param)) {\n     gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n  } else if (u_type == 1.0) {\n     gl_FragColor = vec4(fill_color.rgb, 1.0) * u_alpha * fill_color.a;\n  } else {\n     discard;\n  }\n}\n";
    public static final String ROUND_RECT_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  vec2 new_center = vec2(center * u_param, center);\n  vec2 new_texcoord = v_texcoord * vec2(u_param, 1.0);\n  vec2 coord = new_texcoord - new_center;\n  float fix_pos = max(0.0, sign(u_param - 1.0));\n  vec2 mini_circle_pos = new_center + sign(coord) * ( u_step * min(1.0, u_param) * vec2(center, center) + vec2(fix_pos, 1.0 - fix_pos) * center * abs(u_param - 1.0) );\n  float dist = center * min(1.0, u_param) * (1.0 - u_step);\n  float mini_dist = length(new_texcoord - mini_circle_pos);\n  if ( sign(new_texcoord - mini_circle_pos) == sign(coord) && mini_dist > dist) {\n      gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n  } else {\n      gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n  }\n}\n";
    public static final String SCALE_CIRCLE_TEXTURE_FRAGMENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  float dist = distance(vec2(center, center), v_texcoord);\n  float delta = 0.009;\n  float alpha = smoothstep(0.5 - delta, 0.5, dist);\n  vec2 new_texcoord = v_texcoord - vec2(center);\n  new_texcoord = new_texcoord * u_param;\n  new_texcoord = new_texcoord + vec2(center);\n  gl_FragColor = mix(texture2D(tex_sampler, new_texcoord), vec4(0.0, 0.0, 0.0, 0.0), alpha) * u_alpha;\n}\n";
    public static final String SIDE_GRADIENT_SHADER = "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nuniform float u_param;\nvarying vec2 v_texcoord;\nvoid main() {\n    float y_pos = abs((gl_FragCoord.y / u_param) - 0.5);\n    if (y_pos > 0.4) {\n        float offset = (0.5 - y_pos) * 10.0;\n        gl_FragColor = mix(texture2D(tex_sampler, v_texcoord), vec4(0.0, 0.0, 0.0, 0.0), 1.0 - offset) * u_alpha;\n    } else {\n        gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n    }\n}\n";
    public static final int TYPE_PROGRAM_BASIC = 1001;
    public static final int TYPE_PROGRAM_CIRCLE = 1004;
    public static final int TYPE_PROGRAM_CIRCULAR_CLIP = 1006;
    public static final int TYPE_PROGRAM_FADE = 1007;
    public static final int TYPE_PROGRAM_LINE = 1003;
    public static final int TYPE_PROGRAM_RECTANGLE = 1008;
    public static final int TYPE_PROGRAM_ROUND_RECT = 1005;
    public static final int TYPE_PROGRAM_SCALE_CIRCLE_TEXTURE = 1009;
    public static final int TYPE_PROGRAM_SIDE_GRADIENT = 1010;
    public static final int TYPE_PROGRAM_TINT_BASIC = 1002;
    private final Hashtable mProgramObjMap = new Hashtable();

    private GLProgramStorage()
    {
    }

    private void deleteStorage()
    {
        Iterator iterator = mProgramObjMap.values().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            GLProgram glprogram = (GLProgram)iterator.next();
            if (glprogram instanceof GLProgram)
            {
                glprogram.release();
            }
        } while (true);
        mProgramObjMap.clear();
    }

    public static GLProgramStorage getInstance()
    {
        return new GLProgramStorage();
    }

    public static void releaseInstance(GLProgramStorage glprogramstorage)
    {
        if (glprogramstorage != null)
        {
            glprogramstorage.deleteStorage();
        }
    }

    public boolean addProgram(int i)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mProgramObjMap.containsKey(Integer.valueOf(i));
        if (!flag) goto _L2; else goto _L1
_L1:
        flag = false;
_L16:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        Object obj = null;
        i;
        JVM INSTR tableswitch 1001 1010: default 80
    //                   1001 100
    //                   1002 168
    //                   1003 243
    //                   1004 441
    //                   1005 627
    //                   1006 714
    //                   1007 801
    //                   1008 318
    //                   1009 552
    //                   1010 888;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13
_L3:
        if (obj == null)
        {
            break; /* Loop/switch isn't completed */
        }
        mProgramObjMap.put(Integer.valueOf(i), obj);
        break; /* Loop/switch isn't completed */
_L4:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        continue; /* Loop/switch isn't completed */
        obj;
        throw obj;
_L5:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nuniform lowp vec4  u_tint_color;\nvarying vec2 v_texcoord;\nvoid main() {\n  lowp vec4 color = texture2D(tex_sampler, v_texcoord);\n  gl_FragColor = (u_tint_color * color.a) * u_alpha;\n}\n");
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_tint_color", 103, 207);
        continue; /* Loop/switch isn't completed */
_L6:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute float a_pointsize;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  gl_PointSize = a_pointsize;\n}\n", "precision mediump float;\nuniform lowp vec4 tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_pointsize", 102, 204);
        ((GLProgram) (obj)).addNameIndexer("tex_sampler", 103, 207);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        continue; /* Loop/switch isn't completed */
_L11:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision highp float;\nuniform lowp vec4 tex_sampler;\nuniform lowp vec4 fill_color;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_thickness;\nuniform float u_type;\nuniform float u_param;\nvoid main() {\n  if (v_texcoord.x <= u_thickness || v_texcoord.x >= (1.0 - u_thickness) || v_texcoord.y <= u_thickness * u_param || v_texcoord.y >= (1.0 - u_thickness * u_param)) {\n     gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n  } else if (u_type == 1.0) {\n     gl_FragColor = vec4(fill_color.rgb, 1.0) * u_alpha * fill_color.a;\n  } else {\n     discard;\n  }\n}\n");
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("tex_sampler", 103, 207);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_thickness", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_type", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("fill_color", 103, 207);
        continue; /* Loop/switch isn't completed */
_L7:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp vec4 tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_thickness;\nuniform float u_type;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  if (abs(distance(v_texcoord, vec2(center, center))) <= center) {\n     if (u_type == 1.0 || pow(v_texcoord.x - center, 2.0) / pow(center - u_thickness, 2.0) + pow((1.0 - v_texcoord.y - center), 2.0) / pow(center - u_thickness * u_param, 2.0) >= 1.0) {\n         gl_FragColor = vec4(tex_sampler.rgb, 1.0) * u_alpha * tex_sampler.a;\n     } else {\n      discard;\n     }\n  } else {\n      discard;\n  }\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("tex_sampler", 103, 207);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_thickness", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_type", 103, 204);
        continue; /* Loop/switch isn't completed */
_L12:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying vec2 v_texcoord;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  float dist = distance(vec2(center, center), v_texcoord);\n  float delta = 0.009;\n  float alpha = smoothstep(0.5 - delta, 0.5, dist);\n  vec2 new_texcoord = v_texcoord - vec2(center);\n  new_texcoord = new_texcoord * u_param;\n  new_texcoord = new_texcoord + vec2(center);\n  gl_FragColor = mix(texture2D(tex_sampler, new_texcoord), vec4(0.0, 0.0, 0.0, 0.0), alpha) * u_alpha;\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        continue; /* Loop/switch isn't completed */
_L8:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nuniform float u_param;\nconst float center = 0.5;\nvoid main() {\n  vec2 new_center = vec2(center * u_param, center);\n  vec2 new_texcoord = v_texcoord * vec2(u_param, 1.0);\n  vec2 coord = new_texcoord - new_center;\n  float fix_pos = max(0.0, sign(u_param - 1.0));\n  vec2 mini_circle_pos = new_center + sign(coord) * ( u_step * min(1.0, u_param) * vec2(center, center) + vec2(fix_pos, 1.0 - fix_pos) * center * abs(u_param - 1.0) );\n  float dist = center * min(1.0, u_param) * (1.0 - u_step);\n  float mini_dist = length(new_texcoord - mini_circle_pos);\n  if ( sign(new_texcoord - mini_circle_pos) == sign(coord) && mini_dist > dist) {\n      gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n  } else {\n      gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n  }\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_step", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        continue; /* Loop/switch isn't completed */
_L9:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nconst float diameter = 0.9999;\nconst float center = 0.5;\nvoid main() {\n  vec2 coord = v_texcoord - vec2(center, center);\n  float dist = length(coord / diameter);\n  if ((dist < center) && (dist > center * u_step)) {\n      gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n  } else {\n      gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n  }\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_step", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        continue; /* Loop/switch isn't completed */
_L10:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nvarying lowp vec2 v_texcoord;\nuniform float u_step;\nuniform float u_param;\nuniform float u_alpha;\nconst float accel_pos = 0.2;\nvoid main() {\n    float orientation_pos = sign(u_step);\n    float direction = sign(1.0 - abs(u_step));\n    float alpha = 1.0;\n    float pos = ((1.0 - direction) + direction * abs(u_step)) * (1.0 + u_param);\n    if (pos < accel_pos) {\n        pos = sin(radians(90.0 * (1.0 / accel_pos) * pos)) * accel_pos;\n    }\n    orientation_pos = v_texcoord.x * sign(1.0 - orientation_pos) + v_texcoord.y * sign(1.0 + orientation_pos);\n    if (orientation_pos < pos) {\n        alpha = max(0.0, (orientation_pos - (pos - u_param)) / u_param);\n    }\n    direction = sign(direction + 0.5);\n    alpha = sign(1.0 - direction) + direction * alpha;\n    gl_FragColor = texture2D(tex_sampler, v_texcoord) * (alpha * u_alpha);\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_step", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        continue; /* Loop/switch isn't completed */
_L13:
        obj = new GLProgram("precision highp float;\nuniform mat4 u_MVPMatrix;\nattribute vec4 a_position;\nattribute vec2 a_texcoord;\nvarying vec2 v_texcoord;\nvoid main() {\n  gl_Position = u_MVPMatrix * a_position;\n  v_texcoord = a_texcoord;\n}\n", "precision mediump float;\nuniform lowp sampler2D tex_sampler;\nuniform lowp float u_alpha;\nuniform float u_param;\nvarying vec2 v_texcoord;\nvoid main() {\n    float y_pos = abs((gl_FragCoord.y / u_param) - 0.5);\n    if (y_pos > 0.4) {\n        float offset = (0.5 - y_pos) * 10.0;\n        gl_FragColor = mix(texture2D(tex_sampler, v_texcoord), vec4(0.0, 0.0, 0.0, 0.0), 1.0 - offset) * u_alpha;\n    } else {\n        gl_FragColor = texture2D(tex_sampler, v_texcoord) * u_alpha;\n    }\n}\n");
        ((GLProgram) (obj)).addNameIndexer("a_position", 102, 207);
        ((GLProgram) (obj)).addNameIndexer("a_texcoord", 102, 205);
        ((GLProgram) (obj)).addNameIndexer("u_MVPMatrix", 103, 216);
        ((GLProgram) (obj)).addNameIndexer("u_alpha", 103, 204);
        ((GLProgram) (obj)).addNameIndexer("u_param", 103, 204);
        if (true) goto _L3; else goto _L14
_L14:
        flag = true;
        if (true) goto _L16; else goto _L15
_L15:
    }

    public GLProgram getProgram(int i)
    {
        this;
        JVM INSTR monitorenter ;
        GLProgram glprogram = (GLProgram)mProgramObjMap.get(Integer.valueOf(i));
        this;
        JVM INSTR monitorexit ;
        return glprogram;
        Exception exception;
        exception;
        throw exception;
    }
}
