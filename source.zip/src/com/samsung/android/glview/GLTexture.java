// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLU;
import android.opengl.GLUtils;
import android.util.Log;
import com.samsung.android.util.SemLog;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLContext, GLUtil, GLProgramStorage, 
//            GLProgram

public abstract class GLTexture extends GLView
{

    private static final String TAG = "GLTexture";
    private boolean mAsyncLoadingInProgress;
    protected Bitmap mBitmap;
    private boolean mBitmapSizeChanged;
    private boolean mBitmapUpdated;
    protected float mCoordBuffer[];
    protected boolean mFlip;
    protected ByteBuffer mIndexBuffer;
    byte mIndices[];
    protected int mNewProgramType;
    protected GLProgram.NameIndexerObj mObjAlpha;
    protected GLProgram.NameIndexerObj mObjMVPMatrix;
    protected GLProgram.NameIndexerObj mObjParam;
    protected GLProgram.NameIndexerObj mObjPosition;
    protected GLProgram.NameIndexerObj mObjStep;
    protected GLProgram.NameIndexerObj mObjTextureCoord;
    protected GLProgram.NameIndexerObj mObjTintColor;
    protected int mProgramID;
    protected int mProgramType;
    protected ByteBuffer mTexCoordBuffer;
    protected ByteBuffer mTexFlipCoordBuffer;
    protected boolean mTextureLoaded;
    protected boolean mTextureReloaded;
    protected boolean mTextureSharing;
    protected int mTextures[];
    protected FloatBuffer mVertexBuffer;
    float mVertices[];
    protected float mViewMatrix[];

    public GLTexture(GLContext glcontext, float f, float f1)
    {
        super(glcontext, f, f1);
        mFlip = false;
        mTextureReloaded = false;
        mProgramID = 0;
        mProgramType = 1001;
        mNewProgramType = 1001;
        mObjPosition = null;
        mObjTextureCoord = null;
        mObjMVPMatrix = null;
        mObjAlpha = null;
        mObjStep = null;
        mObjParam = null;
        mObjTintColor = null;
        mViewMatrix = new float[16];
        mTextureLoaded = false;
        mTextureSharing = false;
        mAsyncLoadingInProgress = false;
        mBitmapUpdated = false;
        mBitmapSizeChanged = false;
    }

    public GLTexture(GLContext glcontext, float f, float f1, float f2)
    {
        super(glcontext, f, f1, f2);
        mFlip = false;
        mTextureReloaded = false;
        mProgramID = 0;
        mProgramType = 1001;
        mNewProgramType = 1001;
        mObjPosition = null;
        mObjTextureCoord = null;
        mObjMVPMatrix = null;
        mObjAlpha = null;
        mObjStep = null;
        mObjParam = null;
        mObjTintColor = null;
        mViewMatrix = new float[16];
        mTextureLoaded = false;
        mTextureSharing = false;
        mAsyncLoadingInProgress = false;
        mBitmapUpdated = false;
        mBitmapSizeChanged = false;
    }

    public GLTexture(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        super(glcontext, f, f1, f2, f3);
        mFlip = false;
        mTextureReloaded = false;
        mProgramID = 0;
        mProgramType = 1001;
        mNewProgramType = 1001;
        mObjPosition = null;
        mObjTextureCoord = null;
        mObjMVPMatrix = null;
        mObjAlpha = null;
        mObjStep = null;
        mObjParam = null;
        mObjTintColor = null;
        mViewMatrix = new float[16];
        mTextureLoaded = false;
        mTextureSharing = false;
        mAsyncLoadingInProgress = false;
        mBitmapUpdated = false;
        mBitmapSizeChanged = false;
    }

    public GLTexture(GLContext glcontext, float f, float f1, float f2, float f3, float f4)
    {
        super(glcontext, f, f1, f2, f3, f4);
        mFlip = false;
        mTextureReloaded = false;
        mProgramID = 0;
        mProgramType = 1001;
        mNewProgramType = 1001;
        mObjPosition = null;
        mObjTextureCoord = null;
        mObjMVPMatrix = null;
        mObjAlpha = null;
        mObjStep = null;
        mObjParam = null;
        mObjTintColor = null;
        mViewMatrix = new float[16];
        mTextureLoaded = false;
        mTextureSharing = false;
        mAsyncLoadingInProgress = false;
        mBitmapUpdated = false;
        mBitmapSizeChanged = false;
    }

    private void doUpdate()
    {
        if (mBitmap != null)
        {
            GLES20.glBindTexture(3553, mTextures[0]);
            if (mBitmapSizeChanged)
            {
                GLUtils.texImage2D(3553, 0, mBitmap, 0);
            } else
            {
                GLUtils.texSubImage2D(3553, 0, 0, 0, mBitmap);
            }
            mBitmap.recycle();
            mBitmap = null;
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        super.clear();
        mCoordBuffer = null;
        clearBuffers();
        if (mBitmap != null)
        {
            mBitmap.recycle();
            mBitmap = null;
        }
        if (mTextures != null)
        {
            getContext().addTextureToDelete(this);
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected void clearBitmap()
    {
        if (mBitmap != null)
        {
            mBitmap.recycle();
            mBitmap = null;
        }
    }

    protected void clearBuffers()
    {
        if (mVertexBuffer != null)
        {
            mVertexBuffer.clear();
        }
        mVertexBuffer = null;
        if (mIndexBuffer != null)
        {
            mIndexBuffer.clear();
        }
        mIndexBuffer = null;
        if (mTexCoordBuffer != null)
        {
            mTexCoordBuffer.clear();
        }
        mTexCoordBuffer = null;
        if (mTexFlipCoordBuffer != null)
        {
            mTexFlipCoordBuffer.clear();
        }
        mTexFlipCoordBuffer = null;
    }

    public void clearTexture()
    {
        if (mTextures != null)
        {
            GLES20.glDeleteTextures(1, new int[] {
                mTextures[0]
            }, 0);
            mTextures = null;
        }
    }

    protected void generateTexture()
    {
        if (mTextures == null)
        {
            mTextures = new int[1];
        }
        GLES20.glGenTextures(1, mTextures, 0);
    }

    public boolean getLoaded()
    {
        return mTextureLoaded;
    }

    protected void initBuffers()
    {
        this;
        JVM INSTR monitorenter ;
        byte abyte0[];
        clearBuffers();
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        if (mIndices == null)
        {
            mIndices = new byte[6];
        }
        abyte0 = mIndices;
        int j;
        j = 0 + 1;
        abyte0[0] = 0;
        abyte0 = mIndices;
        int i;
        i = j + 1;
        abyte0[j] = 1;
        abyte0 = mIndices;
        j = i + 1;
        abyte0[i] = 3;
        abyte0 = mIndices;
        i = j + 1;
        abyte0[j] = 0;
        mIndices[i] = 3;
        mIndices[i + 1] = 2;
        mIndexBuffer = GLUtil.getByteBufferFromByteArray(mIndices);
        mTexCoordBuffer = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder());
        mTexFlipCoordBuffer = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder());
        if (mCoordBuffer == null)
        {
            mCoordBuffer = new float[8];
        }
        initCoordBuffer();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected void initCoordBuffer()
    {
        mCoordBuffer[0] = 0.0F;
        float af[] = mCoordBuffer;
        int i = 0 + 1;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 1.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 1.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 1.0F;
        mCoordBuffer[i + 1] = 1.0F;
        mTexCoordBuffer.asFloatBuffer().put(mCoordBuffer).position(0);
        mCoordBuffer[0] = 1.0F;
        af = mCoordBuffer;
        i = 0 + 1;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 1.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 1.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 0.0F;
        af = mCoordBuffer;
        i++;
        af[i] = 0.0F;
        mCoordBuffer[i + 1] = 1.0F;
        mTexFlipCoordBuffer.asFloatBuffer().put(mCoordBuffer).position(0);
    }

    public void initSize()
    {
        this;
        JVM INSTR monitorenter ;
        if (mBitmap == null)
        {
            mBitmap = loadBitmap();
        }
        if (mBitmap == null) goto _L2; else goto _L1
_L1:
        if (getSizeSpecified()) goto _L4; else goto _L3
_L3:
        setSize(mBitmap.getWidth(), mBitmap.getHeight());
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        setSize(getWidth(), getHeight());
        if (true) goto _L2; else goto _L5
_L5:
        Exception exception;
        exception;
        throw exception;
    }

    protected abstract Bitmap loadBitmap();

    protected void loadGLTexture()
    {
        this;
        JVM INSTR monitorenter ;
        Bitmap bitmap = mBitmap;
        if (bitmap != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        int i;
        GLUtils.texImage2D(3553, 0, mBitmap, 0);
        i = GLES20.glGetError();
        if (i == 0)
        {
            break MISSING_BLOCK_LABEL_85;
        }
        Log.e("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : texImage2D - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        clearBitmap();
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    protected void loadProgram()
    {
        mProgramType;
        JVM INSTR tableswitch 1002 1010: default 56
    //                   1002 522
    //                   1003 56
    //                   1004 56
    //                   1005 142
    //                   1006 240
    //                   1007 332
    //                   1008 56
    //                   1009 430
    //                   1010 614;
           goto _L1 _L2 _L1 _L1 _L3 _L4 _L5 _L1 _L6 _L7
_L1:
        GLProgram glprogram = getContext().getProgramStorage().getProgram(1001);
        if (glprogram != null)
        {
            mProgramID = glprogram.getProgramID();
            mObjPosition = glprogram.getNameIndexer("a_position");
            mObjTextureCoord = glprogram.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram.getNameIndexer("u_alpha");
            mObjStep = null;
            mObjParam = null;
            mObjTintColor = null;
        }
_L9:
        return;
_L3:
        GLProgram glprogram1 = getContext().getProgramStorage().getProgram(1005);
        if (glprogram1 != null)
        {
            mProgramID = glprogram1.getProgramID();
            mObjPosition = glprogram1.getNameIndexer("a_position");
            mObjTextureCoord = glprogram1.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram1.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram1.getNameIndexer("u_alpha");
            mObjStep = glprogram1.getNameIndexer("u_step");
            mObjParam = glprogram1.getNameIndexer("u_param");
            mObjTintColor = null;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        GLProgram glprogram2 = getContext().getProgramStorage().getProgram(1006);
        if (glprogram2 != null)
        {
            mProgramID = glprogram2.getProgramID();
            mObjPosition = glprogram2.getNameIndexer("a_position");
            mObjTextureCoord = glprogram2.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram2.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram2.getNameIndexer("u_alpha");
            mObjStep = glprogram2.getNameIndexer("u_step");
            mObjParam = null;
            mObjTintColor = null;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L5:
        GLProgram glprogram3 = getContext().getProgramStorage().getProgram(1007);
        if (glprogram3 != null)
        {
            mProgramID = glprogram3.getProgramID();
            mObjPosition = glprogram3.getNameIndexer("a_position");
            mObjTextureCoord = glprogram3.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram3.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram3.getNameIndexer("u_alpha");
            mObjStep = glprogram3.getNameIndexer("u_step");
            mObjParam = glprogram3.getNameIndexer("u_param");
            mObjTintColor = null;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L6:
        GLProgram glprogram4 = getContext().getProgramStorage().getProgram(1009);
        if (glprogram4 != null)
        {
            mProgramID = glprogram4.getProgramID();
            mObjPosition = glprogram4.getNameIndexer("a_position");
            mObjTextureCoord = glprogram4.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram4.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram4.getNameIndexer("u_alpha");
            mObjStep = null;
            mObjParam = glprogram4.getNameIndexer("u_param");
            mObjTintColor = null;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        GLProgram glprogram5 = getContext().getProgramStorage().getProgram(1002);
        if (glprogram5 != null)
        {
            mProgramID = glprogram5.getProgramID();
            mObjPosition = glprogram5.getNameIndexer("a_position");
            mObjTextureCoord = glprogram5.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram5.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram5.getNameIndexer("u_alpha");
            mObjStep = null;
            mObjParam = null;
            mObjTintColor = glprogram5.getNameIndexer("u_tint_color");
            return;
        }
        continue; /* Loop/switch isn't completed */
_L7:
        GLProgram glprogram6 = getContext().getProgramStorage().getProgram(1010);
        if (glprogram6 != null)
        {
            mProgramID = glprogram6.getProgramID();
            mObjPosition = glprogram6.getNameIndexer("a_position");
            mObjTextureCoord = glprogram6.getNameIndexer("a_texcoord");
            mObjMVPMatrix = glprogram6.getNameIndexer("u_MVPMatrix");
            mObjAlpha = glprogram6.getNameIndexer("u_alpha");
            mObjStep = null;
            mObjParam = glprogram6.getNameIndexer("u_param");
            mObjTintColor = null;
            return;
        }
        if (true) goto _L9; else goto _L8
_L8:
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
    }

    public void onDraw()
    {
        if (mTextures != null && mTextureLoaded) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (!mLayoutUpdated)
        {
            break MISSING_BLOCK_LABEL_541;
        }
        setVertices();
        if (mVertexBuffer != null)
        {
            mVertexBuffer.clear();
        }
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        if (mVertexBuffer == null || mTexFlipCoordBuffer == null) goto _L1; else goto _L3
_L3:
        mLayoutUpdated = false;
_L4:
        if (mNewProgramType != mProgramType)
        {
            mProgramType = mNewProgramType;
            loadProgram();
        }
        GLES20.glUseProgram(mProgramID);
        GLES20.glActiveTexture(33984);
        int i = GLES20.glGetError();
        if (i != 0)
        {
            Log.v("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glActiveTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        }
        GLES20.glBindTexture(3553, mTextures[0]);
        i = GLES20.glGetError();
        if (i != 0)
        {
            Log.v("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glBindTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        }
        if (mObjTintColor != null)
        {
            GLES20.glUniform4fv(mObjTintColor.mHandle, 1, mTintColor, 0);
        }
        GLUtil.multiplyMM(mViewMatrix, getContext().getProjMatrix(), getMatrix());
        GLES20.glUniformMatrix4fv(mObjMVPMatrix.mHandle, 1, false, mViewMatrix, 0);
        GLES20.glUniform1f(mObjAlpha.mHandle, getAlpha());
        if (mObjStep != null)
        {
            GLES20.glUniform1f(mObjStep.mHandle, mShaderStep);
        }
        if (mObjParam != null)
        {
            GLES20.glUniform1f(mObjParam.mHandle, mShaderParameter);
        }
        GLES20.glEnableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glEnableVertexAttribArray(mObjTextureCoord.mHandle);
        GLES20.glVertexAttribPointer(mObjPosition.mHandle, 3, 5126, false, 0, mVertexBuffer);
        if (mFlip)
        {
            GLES20.glVertexAttribPointer(mObjTextureCoord.mHandle, 2, 5126, false, 0, mTexFlipCoordBuffer);
        } else
        {
            GLES20.glVertexAttribPointer(mObjTextureCoord.mHandle, 2, 5126, false, 0, mTexCoordBuffer);
        }
        if (mTextureReloaded)
        {
            loadGLTexture();
            mTextureReloaded = false;
        }
        if (mBitmapUpdated)
        {
            doUpdate();
        }
        GLES20.glDrawElements(4, mIndices.length, 5121, mIndexBuffer);
        i = GLES20.glGetError();
        if (i != 0)
        {
            Log.v("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glDrawElements  - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
        }
        GLES20.glDisableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glDisableVertexAttribArray(mObjTextureCoord.mHandle);
        return;
        if (mVertexBuffer == null || mTexFlipCoordBuffer == null || mTexCoordBuffer == null || mIndexBuffer == null)
        {
            SemLog.secE("GLTexture", "init buffers on onDraw");
            setVertices();
            initBuffers();
        }
          goto _L4
    }

    public void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        mLayoutUpdated = true;
    }

    protected boolean onLoad()
    {
label0:
        {
label1:
            {
                if (!mAsyncLoad)
                {
                    break label0;
                }
                if (!mAsyncLoadingInProgress)
                {
                    Thread thread = new Thread(new Runnable() {

                        final GLTexture this$0;

                        public void run()
                        {
                            mAsyncLoadingInProgress = true;
                            initSize();
                            if (mBitmap == null)
                            {
                                return;
                            }
                            setVertices();
                            initBuffers();
                            generateTexture();
                            int i = GLES20.glGetError();
                            if (i != 0)
                            {
                                Log.e("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glGenTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
                            }
                            GLES20.glBindTexture(3553, mTextures[0]);
                            i = GLES20.glGetError();
                            if (i != 0)
                            {
                                Log.e("GLTexture", (new StringBuilder()).append("Error [").append(getTag()).append("] : glBindTexture - ").append(i).append(" : ").append(GLU.gluErrorString(i)).toString());
                            }
                            GLES20.glTexParameterf(3553, 10241, 9729F);
                            GLES20.glTexParameterf(3553, 10240, 9729F);
                            GLES20.glTexParameterf(3553, 10242, 33071F);
                            GLES20.glTexParameterf(3553, 10243, 33071F);
                            if (mNewProgramType != mProgramType)
                            {
                                mProgramType = mNewProgramType;
                            }
                            loadProgram();
                            loadGLTexture();
                            mTextureLoaded = true;
                            mAsyncLoadingInProgress = false;
                        }

            
            {
                this$0 = GLTexture.this;
                super();
            }
                    });
                    thread.setName("AsyncLoadingThread");
                    thread.start();
                    if (!mTextureLoaded || mAsyncLoadingInProgress)
                    {
                        break label1;
                    }
                }
                return true;
            }
            return false;
        }
        initSize();
        generateTexture();
        if (mBitmap == null && !mTextureSharing)
        {
            return false;
        }
        setVertices();
        initBuffers();
        GLES20.glBindTexture(3553, mTextures[0]);
        GLES20.glTexParameterf(3553, 10241, 9729F);
        GLES20.glTexParameterf(3553, 10240, 9729F);
        GLES20.glTexParameterf(3553, 10242, 33071F);
        GLES20.glTexParameterf(3553, 10243, 33071F);
        if (mNewProgramType != mProgramType)
        {
            mProgramType = mNewProgramType;
        }
        loadProgram();
        loadGLTexture();
        mTextureLoaded = true;
        return true;
    }

    public void onReset()
    {
        this;
        JVM INSTR monitorenter ;
        if (mBitmap != null)
        {
            mBitmap.recycle();
            mBitmap = null;
        }
        mTextureLoaded = false;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected boolean reLoad()
    {
        boolean flag = false;
        this;
        JVM INSTR monitorenter ;
        boolean flag1 = mTextureLoaded;
        if (flag1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        mTextureLoaded = false;
        if (mBitmap != null)
        {
            mBitmap.recycle();
            mBitmap = null;
        }
        mBitmap = loadBitmap();
        setVertices();
        initBuffers();
        mTextureLoaded = true;
        mTextureReloaded = true;
        getContext().setDirty(true);
        flag = true;
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void resetTint()
    {
        super.setTint(0);
        setShaderProgram(1001);
    }

    public void setFlip(boolean flag)
    {
        mFlip = flag;
    }

    public void setShaderProgram(int i)
    {
        mNewProgramType = i;
    }

    public void setTint(int i)
    {
        super.setTint(i);
        setShaderProgram(1002);
    }

    protected void setVertices()
    {
        if (mVertices == null)
        {
            mVertices = new float[12];
        }
        if (getContext().getAlignToPixel())
        {
            mVertices[0] = (int)(getLeft() + 0.5F);
            mVertices[1] = (int)(getTop() + 0.5F);
            mVertices[2] = 0.0F;
            mVertices[3] = (int)(getLeft() + 0.5F);
            mVertices[4] = (int)(getBottom() + 0.5F);
            mVertices[5] = 0.0F;
            mVertices[6] = (int)(getRight() + 0.5F);
            mVertices[7] = (int)(getTop() + 0.5F);
            mVertices[8] = 0.0F;
            mVertices[9] = (int)(getRight() + 0.5F);
            mVertices[10] = (int)(getBottom() + 0.5F);
            mVertices[11] = 0.0F;
            return;
        } else
        {
            mVertices[0] = getLeft();
            mVertices[1] = getTop();
            mVertices[2] = 0.0F;
            mVertices[3] = getLeft();
            mVertices[4] = getBottom();
            mVertices[5] = 0.0F;
            mVertices[6] = getRight();
            mVertices[7] = getTop();
            mVertices[8] = 0.0F;
            mVertices[9] = getRight();
            mVertices[10] = getBottom();
            mVertices[11] = 0.0F;
            return;
        }
    }

    public boolean updateTexture(Bitmap bitmap, boolean flag)
    {
        boolean flag1 = true;
        this;
        JVM INSTR monitorenter ;
        if (bitmap == null) goto _L2; else goto _L1
_L1:
        if ((float)bitmap.getWidth() != getWidth()) goto _L2; else goto _L3
_L3:
        float f;
        float f1;
        f = bitmap.getHeight();
        f1 = getHeight();
        if (f == f1) goto _L4; else goto _L2
_L2:
        flag = false;
_L6:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L4:
        mBitmapUpdated = true;
        mBitmapSizeChanged = flag;
        if (mBitmap != null)
        {
            mBitmap.recycle();
            mBitmap = null;
        }
        mBitmap = Bitmap.createBitmap(bitmap);
        getContext().setDirty(true);
        flag = flag1;
        if (true) goto _L6; else goto _L5
_L5:
        bitmap;
        throw bitmap;
    }


/*
    static boolean access$002(GLTexture gltexture, boolean flag)
    {
        gltexture.mAsyncLoadingInProgress = flag;
        return flag;
    }

*/
}
