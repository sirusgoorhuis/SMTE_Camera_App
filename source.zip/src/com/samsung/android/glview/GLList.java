// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLAbsList, GLView, GLContext, GLUtil

public class GLList extends GLAbsList
{

    public GLList(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        super(glcontext, f, f1, f2, f3);
    }

    public void addView(GLView glview)
    {
        if (glview instanceof GLList)
        {
            throw new IllegalArgumentException();
        }
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        mContentHeight = mContentHeight + glview.getHeight();
        if (glview.getWidth() > mContentWidth)
        {
            mContentWidth = glview.getWidth();
        }
_L4:
        super.addView(glview);
        return;
_L2:
        mContentWidth = mContentWidth + glview.getWidth();
        if (glview.getHeight() > mContentHeight)
        {
            mContentHeight = glview.getHeight();
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void refreshList()
    {
        float f;
        super.refreshList();
        f = 0.0F;
        Iterator iterator = mGLViews.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            GLView glview = (GLView)iterator.next();
            glview.resetTranslate();
            if (mScrollOrientation == 1)
            {
                glview.moveLayoutAbsolute(0.0F, f, false);
                f += glview.getHeight();
            } else
            if (mScrollOrientation == 2)
            {
                glview.moveLayoutAbsolute(f, 0.0F, false);
                f += glview.getWidth();
            }
        } while (true);
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        mContentHeight = f;
_L4:
        getContext().setDirty(true);
        return;
_L2:
        if (mScrollOrientation == 2)
        {
            mContentWidth = f;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void removeView(GLView glview)
    {
        if (mGLViews.contains(glview))
        {
            if (mScrollOrientation == 1)
            {
                mContentHeight = mContentHeight - glview.getHeight();
            } else
            {
                mContentWidth = mContentWidth - glview.getWidth();
            }
        }
        super.removeView(glview);
    }

    public void setAdapter(GLAbsList.Adapter adapter, int i)
    {
        float f;
        if (adapter == null)
        {
            throw new IllegalArgumentException();
        }
        mAdapter = adapter;
        mScrollOrientation = i;
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).clear()) { }
        setScrollOrientation(mScrollOrientation);
        f = 0.0F;
        int k = mAdapter.getCount();
        int j = 0;
        while (j < k) 
        {
            GLView glview = mAdapter.getView(j, null);
            if (glview != null)
            {
                if (mScrollOrientation == 1)
                {
                    if (glview.getScrollHint())
                    {
                        mScrollSumY = -f;
                    }
                    glview.moveLayoutAbsolute(0.0F, f);
                    f += glview.getHeight();
                } else
                {
                    if (glview.getScrollHint())
                    {
                        mScrollSumX = -f;
                    }
                    glview.moveLayoutAbsolute(f, 0.0F);
                    f += glview.getWidth();
                }
                glview.setFocusListener(this);
                glview.setForcedClipping(true);
                addView(glview);
            }
            j++;
        }
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        if (f < getHeight())
        {
            setSize(getWidth(), f);
        }
_L4:
        super.setAdapter(adapter, i);
        return;
_L2:
        if (f < getWidth())
        {
            setSize(f, getHeight());
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void setHeight(float f)
    {
        this;
        JVM INSTR monitorenter ;
        super.setHeight(f);
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        if (checkBoundary())
        {
            setBouncing(true);
        }
        setVisibleArea();
        if (mScrollBar != null)
        {
            setScrollBarLayout();
        }
_L4:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (mScrollOrientation == 2)
        {
            Iterator iterator = mGLViews.iterator();
            while (iterator.hasNext()) 
            {
                ((GLView)iterator.next()).setHeight(f);
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void setSize(float f, float f1)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag;
        boolean flag1;
        flag = false;
        flag1 = false;
        if (!GLUtil.floatEquals(getWidth(), f))
        {
            flag = true;
        }
        if (!GLUtil.floatEquals(getHeight(), f1))
        {
            flag1 = true;
        }
        super.setSize(f, f1);
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_93;
        }
        if (mScrollOrientation == 1)
        {
            for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setWidth(f)) { }
            break MISSING_BLOCK_LABEL_106;
        }
        break MISSING_BLOCK_LABEL_93;
        Exception exception;
        exception;
        throw exception;
        if (!flag1)
        {
            break MISSING_BLOCK_LABEL_106;
        }
        if (mScrollOrientation != 2);
        refreshList();
        if (checkBoundary())
        {
            setBouncing(true);
        }
        setVisibleArea();
        if (mScrollBar != null)
        {
            setScrollBarLayout();
        }
        this;
        JVM INSTR monitorexit ;
    }

    public void setWidth(float f)
    {
        this;
        JVM INSTR monitorenter ;
        super.setWidth(f);
        if (mScrollOrientation == 1)
        {
            for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setWidth(f)) { }
            break MISSING_BLOCK_LABEL_88;
        }
        break MISSING_BLOCK_LABEL_53;
        Exception exception;
        exception;
        throw exception;
        if (mScrollOrientation == 2)
        {
            if (checkBoundary())
            {
                setBouncing(true);
            }
            setVisibleArea();
            if (mScrollBar != null)
            {
                setScrollBarLayout();
            }
        }
        refreshList();
        this;
        JVM INSTR monitorexit ;
    }
}
