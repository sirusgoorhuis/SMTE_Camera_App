// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            GLView, GLContext

class this._cls0
    implements Runnable
{

    final GLView this$0;

    public void run()
    {
        while (mGLContext == null || GLContext.getApplicationContext() == null || mDragListener == null || !GLView.access$000(GLView.this)) 
        {
            return;
        }
        mDragging = true;
        mDragListener.onDragStart(mThis, GLView.access$100(GLView.this), GLView.access$200(GLView.this));
    }

    agListener()
    {
        this$0 = GLView.this;
        super();
    }
}
