// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.util.Log;
import android.view.OrientationEventListener;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

class init> extends OrientationEventListener
{

    final GLContext this$0;

    public void onOrientationChanged(int i)
    {
        if (i == -1)
        {
            Log.v("GLContext", "android onOrientationChanged - ORIENTATION_UNKNOWN");
            return;
        } else
        {
            GLContext.access$700(GLContext.this, i);
            return;
        }
    }

    (Context context)
    {
        this$0 = GLContext.this;
        super(context);
    }
}
