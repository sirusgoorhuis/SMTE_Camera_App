// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.Transformation;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.samsung.android.glview:
//            GLUtil, GLContext, GLRectangle, GLViewGroup, 
//            GLResourceTexture, GLNinePatch

public abstract class GLView
{
    public static interface AnimationEventListener
    {

        public abstract void onAnimationEnd(GLView glview, Animation animation);

        public abstract void onAnimationStart(GLView glview, Animation animation);
    }

    public static interface ClickListener
    {

        public abstract boolean onClick(GLView glview);
    }

    public static interface DragListener
    {

        public abstract void onDrag(GLView glview, float f, float f1, float f2, float f3);

        public abstract void onDragEnd(GLView glview, float f, float f1);

        public abstract void onDragStart(GLView glview, float f, float f1);
    }

    public static interface FocusListener
    {

        public abstract boolean onFocusChanged(GLView glview, int i);
    }

    public static interface KeyListener
    {

        public abstract boolean onKeyDown(GLView glview, KeyEvent keyevent);

        public abstract boolean onKeyUp(GLView glview, KeyEvent keyevent);
    }

    public static interface LoadListener
    {

        public abstract void onLoaded();
    }

    public static interface LongClickListener
    {

        public abstract boolean onLongClick(GLView glview);
    }

    public static interface OrientationChangeListener
    {

        public abstract void onOrientationChanged(int i);
    }

    public static interface TouchListener
    {

        public abstract boolean onTouch(GLView glview, MotionEvent motionevent);
    }


    public static final int ALIGN_END = 3;
    public static final int ALIGN_MIDDLE = 2;
    public static final int ALIGN_START = 1;
    private static final int ANIMATION_PENDING_TIMEOUT = 100;
    public static final int CLICKABLE = 16384;
    private static final int DEFAULT_REPEAT_CLICK_INTERVAL = 100;
    public static final float DIM_ALPHA_VALUE = 0.45F;
    public static final int DISABLED = 32;
    private static final int DRAG_HOLD_TIME_ABSOLUTE = 0;
    private static final int DRAG_HOLD_TIME_HIGH = 300;
    private static final int DRAG_HOLD_TIME_NORMAL = 500;
    public static final int DRAG_SENSITIVITY_ABSOLUTE = 0;
    public static final int DRAG_SENSITIVITY_HIGH = 1;
    public static final int DRAG_SENSITIVITY_NORMAL = 2;
    private static final int FOCUSABLE = 1;
    private static final int FOCUSABLE_MASK = 1;
    public static final int FOCUS_BACKWARD = 1;
    public static final int FOCUS_DOWN = 130;
    public static final int FOCUS_FORWARD = 2;
    public static final int FOCUS_LEFT = 17;
    public static final int FOCUS_RIGHT = 66;
    public static final int FOCUS_UP = 33;
    public static final int GONE = 8;
    public static final int HOVER_DOWN = 82;
    public static final int HOVER_LEFT = 49;
    public static final int HOVER_RIGHT = 98;
    public static final int HOVER_UP = 65;
    public static final int H_ALIGN_CENTER = 2;
    public static final int H_ALIGN_LEFT = 1;
    public static final int H_ALIGN_NONE = 0;
    public static final int H_ALIGN_RIGHT = 3;
    public static final int INVISIBLE = 4;
    private static final int LONG_CLICK_TIME = 500;
    private static final int NOT_FOCUSABLE = 0;
    private static final int NO_ID = -1;
    public static final int ORIENTATION_0 = 0;
    public static final int ORIENTATION_180 = 2;
    public static final int ORIENTATION_270 = 3;
    public static final int ORIENTATION_90 = 1;
    public static final int VISIBLE = 0;
    public static final int V_ALIGN_BOTTOM = 3;
    public static final int V_ALIGN_MIDDLE = 2;
    public static final int V_ALIGN_NONE = 0;
    public static final int V_ALIGN_TOP = 1;
    private float glCoordinate[];
    private float glTransformedCoordinate[];
    protected float mAlpha;
    private float mAnimGLMatrix[];
    private float mAnimMatrix[];
    private Animation mAnimation;
    protected AnimationEventListener mAnimationEventListener;
    private boolean mAnimationFinished;
    private boolean mAnimationPending;
    private boolean mAnimationStarted;
    private boolean mAnimationStartedEvent;
    protected boolean mAsyncLoad;
    private GLView mBackground;
    private int mBackgroundResId;
    protected float mBaseDepth;
    protected float mBaseLeft;
    protected float mBaseTop;
    private RectF mBound;
    private boolean mBypassTouch;
    private boolean mCenterPivot;
    protected ClickListener mClickListener;
    private Rect mClipRect;
    private boolean mClipping;
    private float mCombinedMatrix[];
    public String mContentDescription;
    private boolean mContinuousDrawMode;
    protected int mDefaultOrientation;
    private boolean mDimmed;
    protected DragListener mDragListener;
    private int mDragSensitivity;
    private boolean mDraggable;
    protected boolean mDragging;
    protected boolean mDrawFirstTime;
    private GLRectangle mFocusIndicator;
    protected FocusListener mFocusListener;
    private boolean mFocused;
    private boolean mForcedClipping;
    protected final GLContext mGLContext;
    private boolean mHideAfterAnimation;
    private boolean mHoverFocused;
    private GLRectangle mHoverIndicator;
    protected boolean mInScreen;
    private boolean mInternalFocus;
    protected boolean mIsClipped;
    private boolean mIsTouchCanceled;
    protected KeyListener mKeyListener;
    private int mLastOrientation;
    protected boolean mLayoutUpdated;
    private float mLeft;
    private float mLeftBottom[];
    private float mLeftTop[];
    private RectF mLeftTopCoordinates[];
    private LoadListener mLoadListener;
    private boolean mLoaded;
    private boolean mLoading;
    protected LongClickListener mLongClickListener;
    private boolean mLongClickable;
    protected boolean mManualClip;
    private Rect mManualClipRect;
    private float mMatrix[];
    private int mNextFocusDownId;
    private int mNextFocusForwardId;
    private int mNextFocusLeftId;
    private int mNextFocusRightId;
    private int mNextFocusUpId;
    private String mObjectTag;
    private float mOldAlpha;
    private int mOrientation;
    private OrientationChangeListener mOrientationChangeListener;
    private Rect mOriginalClipRect;
    protected float mOriginalDepth;
    protected float mOriginalLeft;
    protected float mOriginalTop;
    protected Rect mPaddings;
    public GLView mParent;
    private int mParentHAlign;
    private int mParentVAlign;
    private int mParentViewId;
    protected boolean mPositionChanged;
    private float mPreviousDragX;
    private float mPreviousDragY;
    private int mRepeatClickInterval;
    private boolean mRepeatClickWhenLongClicked;
    private float mRightBottom[];
    private float mRightTop[];
    private boolean mRotatable;
    private boolean mRotateAnimation;
    private int mRotateAnimationDuration;
    private Interpolator mRotateAnimationInterpolator;
    protected int mRotateDegree;
    private float mRotationMatrix[];
    protected boolean mScaleChanged;
    private float mScaleMatrix[];
    private float mScaleX;
    private float mScaleY;
    protected float mShaderParameter;
    protected float mShaderStep;
    protected boolean mSizeGiven;
    protected boolean mSizeSpecified;
    public String mSubTitle;
    private float mTempMatrix[];
    private int mTempOrientation;
    protected GLView mThis;
    protected float mTintColor[];
    public String mTitle;
    private float mTop;
    protected TouchListener mTouchListener;
    private Transformation mTransformation;
    protected float mTransformedScreenCoordinate[];
    private float mTranslateX;
    private float mTranslateY;
    private float mTranslateZ;
    private float mTranslationMatrix[];
    private boolean mUpdateMatrixAfterAnimation;
    private int mViewFlags;
    private int mViewId;
    private int mViewTag;
    private int mVisibility;
    private float mZCoordinate;
    private final Runnable repeatClick;
    private final Runnable setDragging;
    private final Runnable setLongClick;

    public GLView(GLContext glcontext, float f, float f1)
    {
        mInScreen = false;
        mIsClipped = false;
        mTransformedScreenCoordinate = new float[2];
        mDefaultOrientation = 0;
        mRotateDegree = 0;
        mSizeGiven = false;
        mLayoutUpdated = true;
        mPositionChanged = true;
        mScaleChanged = false;
        mPaddings = new Rect();
        mAlpha = 1.0F;
        mTintColor = new float[4];
        mShaderStep = 1.0F;
        mShaderParameter = 1.0F;
        mOriginalLeft = 0.0F;
        mOriginalTop = 0.0F;
        mOriginalDepth = 0.0F;
        mBaseLeft = 0.0F;
        mBaseTop = 0.0F;
        mBaseDepth = 0.0F;
        mManualClip = false;
        mDragging = false;
        mDrawFirstTime = true;
        mAsyncLoad = false;
        mDragListener = null;
        mTouchListener = null;
        mKeyListener = null;
        mFocusListener = null;
        mAnimationEventListener = null;
        mClickListener = null;
        mLongClickListener = null;
        mViewId = -1;
        mObjectTag = "NONE";
        mParentViewId = -1;
        mLoaded = false;
        mLoading = false;
        mAnimationPending = false;
        mAnimationFinished = true;
        mAnimationStarted = false;
        mAnimationStartedEvent = false;
        mHideAfterAnimation = false;
        mUpdateMatrixAfterAnimation = false;
        mVisibility = 0;
        mDimmed = false;
        mFocused = false;
        mHoverFocused = false;
        mRotationMatrix = new float[16];
        mTranslationMatrix = new float[16];
        mScaleMatrix = new float[16];
        mTempMatrix = new float[16];
        mCombinedMatrix = new float[16];
        mAnimMatrix = new float[16];
        mAnimGLMatrix = new float[16];
        mMatrix = new float[16];
        glCoordinate = new float[4];
        glTransformedCoordinate = new float[4];
        mTransformation = new Transformation();
        mScaleX = 1.0F;
        mScaleY = 1.0F;
        mTranslateX = 0.0F;
        mTranslateY = 0.0F;
        mTranslateZ = 0.0F;
        mAnimation = null;
        mContinuousDrawMode = false;
        mOrientation = 0;
        mLastOrientation = 0;
        mRotatable = false;
        mCenterPivot = false;
        mRotateAnimation = false;
        mRotateAnimationInterpolator = null;
        mRotateAnimationDuration = 300;
        mParentHAlign = 0;
        mParentVAlign = 0;
        mLeftTopCoordinates = new RectF[4];
        mBackgroundResId = 0;
        mOldAlpha = 1.0F;
        mLeftTop = new float[2];
        mLeftBottom = new float[2];
        mRightTop = new float[2];
        mRightBottom = new float[2];
        mClipping = true;
        mForcedClipping = false;
        mDraggable = true;
        setDragging = new Runnable() {

            final GLView this$0;

            public void run()
            {
                while (mGLContext == null || GLContext.getApplicationContext() == null || mDragListener == null || !mDraggable) 
                {
                    return;
                }
                mDragging = true;
                mDragListener.onDragStart(mThis, mPreviousDragX, mPreviousDragY);
            }

            
            {
                this$0 = GLView.this;
                super();
            }
        };
        mBypassTouch = false;
        mTempOrientation = 0;
        mInternalFocus = false;
        mNextFocusLeftId = -1;
        mNextFocusRightId = -1;
        mNextFocusUpId = -1;
        mNextFocusDownId = -1;
        mNextFocusForwardId = -1;
        mFocusIndicator = null;
        mHoverIndicator = null;
        mLongClickable = false;
        mRepeatClickWhenLongClicked = false;
        mRepeatClickInterval = 100;
        repeatClick = new Runnable() {

            final GLView this$0;

            public void run()
            {
                while (mGLContext == null || GLContext.getApplicationContext() == null || !mLongClickable || !mRepeatClickWhenLongClicked) 
                {
                    return;
                }
                if (mClickListener != null)
                {
                    mClickListener.onClick(mThis);
                }
                mGLContext.getMainHandler().postDelayed(this, mRepeatClickInterval);
            }

            
            {
                this$0 = GLView.this;
                super();
            }
        };
        setLongClick = new Runnable() {

            final GLView this$0;

            public void run()
            {
                if (mGLContext != null && GLContext.getApplicationContext() != null && mLongClickable)
                {
                    if (mLongClickListener != null)
                    {
                        mLongClickListener.onLongClick(mThis);
                    }
                    if (mRepeatClickWhenLongClicked)
                    {
                        mGLContext.getMainHandler().postDelayed(repeatClick, mRepeatClickInterval);
                        return;
                    }
                }
            }

            
            {
                this$0 = GLView.this;
                super();
            }
        };
        mIsTouchCanceled = false;
        mDragSensitivity = 2;
        for (int i = 0; i < 4; i++)
        {
            mLeftTopCoordinates[i] = new RectF();
        }

        mBound = new RectF();
        mBound.left = f;
        mBound.top = f1;
        mZCoordinate = 0.0F;
        mOriginalLeft = f;
        mOriginalTop = f1;
        mOriginalDepth = 0.0F;
        mBaseLeft = f;
        mBaseTop = f1;
        mBaseDepth = 0.0F;
        mGLContext = glcontext;
        resetTransformMatrix();
        mSizeSpecified = false;
        mSizeGiven = false;
        setLeftTop(0, f, f1);
        setLeftTop(1, f, f1);
        setLeftTop(2, f, f1);
        setLeftTop(3, f, f1);
        mThis = this;
        mViewId = hashCode();
    }

    public GLView(GLContext glcontext, float f, float f1, float f2)
    {
        mInScreen = false;
        mIsClipped = false;
        mTransformedScreenCoordinate = new float[2];
        mDefaultOrientation = 0;
        mRotateDegree = 0;
        mSizeGiven = false;
        mLayoutUpdated = true;
        mPositionChanged = true;
        mScaleChanged = false;
        mPaddings = new Rect();
        mAlpha = 1.0F;
        mTintColor = new float[4];
        mShaderStep = 1.0F;
        mShaderParameter = 1.0F;
        mOriginalLeft = 0.0F;
        mOriginalTop = 0.0F;
        mOriginalDepth = 0.0F;
        mBaseLeft = 0.0F;
        mBaseTop = 0.0F;
        mBaseDepth = 0.0F;
        mManualClip = false;
        mDragging = false;
        mDrawFirstTime = true;
        mAsyncLoad = false;
        mDragListener = null;
        mTouchListener = null;
        mKeyListener = null;
        mFocusListener = null;
        mAnimationEventListener = null;
        mClickListener = null;
        mLongClickListener = null;
        mViewId = -1;
        mObjectTag = "NONE";
        mParentViewId = -1;
        mLoaded = false;
        mLoading = false;
        mAnimationPending = false;
        mAnimationFinished = true;
        mAnimationStarted = false;
        mAnimationStartedEvent = false;
        mHideAfterAnimation = false;
        mUpdateMatrixAfterAnimation = false;
        mVisibility = 0;
        mDimmed = false;
        mFocused = false;
        mHoverFocused = false;
        mRotationMatrix = new float[16];
        mTranslationMatrix = new float[16];
        mScaleMatrix = new float[16];
        mTempMatrix = new float[16];
        mCombinedMatrix = new float[16];
        mAnimMatrix = new float[16];
        mAnimGLMatrix = new float[16];
        mMatrix = new float[16];
        glCoordinate = new float[4];
        glTransformedCoordinate = new float[4];
        mTransformation = new Transformation();
        mScaleX = 1.0F;
        mScaleY = 1.0F;
        mTranslateX = 0.0F;
        mTranslateY = 0.0F;
        mTranslateZ = 0.0F;
        mAnimation = null;
        mContinuousDrawMode = false;
        mOrientation = 0;
        mLastOrientation = 0;
        mRotatable = false;
        mCenterPivot = false;
        mRotateAnimation = false;
        mRotateAnimationInterpolator = null;
        mRotateAnimationDuration = 300;
        mParentHAlign = 0;
        mParentVAlign = 0;
        mLeftTopCoordinates = new RectF[4];
        mBackgroundResId = 0;
        mOldAlpha = 1.0F;
        mLeftTop = new float[2];
        mLeftBottom = new float[2];
        mRightTop = new float[2];
        mRightBottom = new float[2];
        mClipping = true;
        mForcedClipping = false;
        mDraggable = true;
        setDragging = new _cls1();
        mBypassTouch = false;
        mTempOrientation = 0;
        mInternalFocus = false;
        mNextFocusLeftId = -1;
        mNextFocusRightId = -1;
        mNextFocusUpId = -1;
        mNextFocusDownId = -1;
        mNextFocusForwardId = -1;
        mFocusIndicator = null;
        mHoverIndicator = null;
        mLongClickable = false;
        mRepeatClickWhenLongClicked = false;
        mRepeatClickInterval = 100;
        repeatClick = new _cls2();
        setLongClick = new _cls3();
        mIsTouchCanceled = false;
        mDragSensitivity = 2;
        for (int i = 0; i < 4; i++)
        {
            mLeftTopCoordinates[i] = new RectF();
        }

        mBound = new RectF();
        mBound.left = f;
        mBound.top = f1;
        mZCoordinate = f2;
        mOriginalLeft = f;
        mOriginalTop = f1;
        mOriginalDepth = f2;
        mBaseLeft = f;
        mBaseTop = f1;
        mBaseDepth = f2;
        mGLContext = glcontext;
        resetTransformMatrix();
        mSizeSpecified = false;
        mSizeGiven = false;
        setLeftTop(0, f, f1);
        setLeftTop(1, f, f1);
        setLeftTop(2, f, f1);
        setLeftTop(3, f, f1);
        mThis = this;
        mViewId = hashCode();
    }

    public GLView(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        mInScreen = false;
        mIsClipped = false;
        mTransformedScreenCoordinate = new float[2];
        mDefaultOrientation = 0;
        mRotateDegree = 0;
        mSizeGiven = false;
        mLayoutUpdated = true;
        mPositionChanged = true;
        mScaleChanged = false;
        mPaddings = new Rect();
        mAlpha = 1.0F;
        mTintColor = new float[4];
        mShaderStep = 1.0F;
        mShaderParameter = 1.0F;
        mOriginalLeft = 0.0F;
        mOriginalTop = 0.0F;
        mOriginalDepth = 0.0F;
        mBaseLeft = 0.0F;
        mBaseTop = 0.0F;
        mBaseDepth = 0.0F;
        mManualClip = false;
        mDragging = false;
        mDrawFirstTime = true;
        mAsyncLoad = false;
        mDragListener = null;
        mTouchListener = null;
        mKeyListener = null;
        mFocusListener = null;
        mAnimationEventListener = null;
        mClickListener = null;
        mLongClickListener = null;
        mViewId = -1;
        mObjectTag = "NONE";
        mParentViewId = -1;
        mLoaded = false;
        mLoading = false;
        mAnimationPending = false;
        mAnimationFinished = true;
        mAnimationStarted = false;
        mAnimationStartedEvent = false;
        mHideAfterAnimation = false;
        mUpdateMatrixAfterAnimation = false;
        mVisibility = 0;
        mDimmed = false;
        mFocused = false;
        mHoverFocused = false;
        mRotationMatrix = new float[16];
        mTranslationMatrix = new float[16];
        mScaleMatrix = new float[16];
        mTempMatrix = new float[16];
        mCombinedMatrix = new float[16];
        mAnimMatrix = new float[16];
        mAnimGLMatrix = new float[16];
        mMatrix = new float[16];
        glCoordinate = new float[4];
        glTransformedCoordinate = new float[4];
        mTransformation = new Transformation();
        mScaleX = 1.0F;
        mScaleY = 1.0F;
        mTranslateX = 0.0F;
        mTranslateY = 0.0F;
        mTranslateZ = 0.0F;
        mAnimation = null;
        mContinuousDrawMode = false;
        mOrientation = 0;
        mLastOrientation = 0;
        mRotatable = false;
        mCenterPivot = false;
        mRotateAnimation = false;
        mRotateAnimationInterpolator = null;
        mRotateAnimationDuration = 300;
        mParentHAlign = 0;
        mParentVAlign = 0;
        mLeftTopCoordinates = new RectF[4];
        mBackgroundResId = 0;
        mOldAlpha = 1.0F;
        mLeftTop = new float[2];
        mLeftBottom = new float[2];
        mRightTop = new float[2];
        mRightBottom = new float[2];
        mClipping = true;
        mForcedClipping = false;
        mDraggable = true;
        setDragging = new _cls1();
        mBypassTouch = false;
        mTempOrientation = 0;
        mInternalFocus = false;
        mNextFocusLeftId = -1;
        mNextFocusRightId = -1;
        mNextFocusUpId = -1;
        mNextFocusDownId = -1;
        mNextFocusForwardId = -1;
        mFocusIndicator = null;
        mHoverIndicator = null;
        mLongClickable = false;
        mRepeatClickWhenLongClicked = false;
        mRepeatClickInterval = 100;
        repeatClick = new _cls2();
        setLongClick = new _cls3();
        mIsTouchCanceled = false;
        mDragSensitivity = 2;
        for (int i = 0; i < 4; i++)
        {
            mLeftTopCoordinates[i] = new RectF();
        }

        mBound = new RectF(f, f1, f + f2, f1 + f3);
        mZCoordinate = 0.0F;
        mGLContext = glcontext;
        resetTransformMatrix();
        mOriginalLeft = f;
        mOriginalTop = f1;
        mOriginalDepth = 0.0F;
        mBaseLeft = f;
        mBaseTop = f1;
        mBaseDepth = 0.0F;
        mSizeSpecified = true;
        mSizeGiven = true;
        setLeftTop(0, f, f1);
        setLeftTop(1, f, f1);
        setLeftTop(2, f, f1);
        setLeftTop(3, f, f1);
        mThis = this;
        mViewId = hashCode();
    }

    public GLView(GLContext glcontext, float f, float f1, float f2, float f3, float f4)
    {
        mInScreen = false;
        mIsClipped = false;
        mTransformedScreenCoordinate = new float[2];
        mDefaultOrientation = 0;
        mRotateDegree = 0;
        mSizeGiven = false;
        mLayoutUpdated = true;
        mPositionChanged = true;
        mScaleChanged = false;
        mPaddings = new Rect();
        mAlpha = 1.0F;
        mTintColor = new float[4];
        mShaderStep = 1.0F;
        mShaderParameter = 1.0F;
        mOriginalLeft = 0.0F;
        mOriginalTop = 0.0F;
        mOriginalDepth = 0.0F;
        mBaseLeft = 0.0F;
        mBaseTop = 0.0F;
        mBaseDepth = 0.0F;
        mManualClip = false;
        mDragging = false;
        mDrawFirstTime = true;
        mAsyncLoad = false;
        mDragListener = null;
        mTouchListener = null;
        mKeyListener = null;
        mFocusListener = null;
        mAnimationEventListener = null;
        mClickListener = null;
        mLongClickListener = null;
        mViewId = -1;
        mObjectTag = "NONE";
        mParentViewId = -1;
        mLoaded = false;
        mLoading = false;
        mAnimationPending = false;
        mAnimationFinished = true;
        mAnimationStarted = false;
        mAnimationStartedEvent = false;
        mHideAfterAnimation = false;
        mUpdateMatrixAfterAnimation = false;
        mVisibility = 0;
        mDimmed = false;
        mFocused = false;
        mHoverFocused = false;
        mRotationMatrix = new float[16];
        mTranslationMatrix = new float[16];
        mScaleMatrix = new float[16];
        mTempMatrix = new float[16];
        mCombinedMatrix = new float[16];
        mAnimMatrix = new float[16];
        mAnimGLMatrix = new float[16];
        mMatrix = new float[16];
        glCoordinate = new float[4];
        glTransformedCoordinate = new float[4];
        mTransformation = new Transformation();
        mScaleX = 1.0F;
        mScaleY = 1.0F;
        mTranslateX = 0.0F;
        mTranslateY = 0.0F;
        mTranslateZ = 0.0F;
        mAnimation = null;
        mContinuousDrawMode = false;
        mOrientation = 0;
        mLastOrientation = 0;
        mRotatable = false;
        mCenterPivot = false;
        mRotateAnimation = false;
        mRotateAnimationInterpolator = null;
        mRotateAnimationDuration = 300;
        mParentHAlign = 0;
        mParentVAlign = 0;
        mLeftTopCoordinates = new RectF[4];
        mBackgroundResId = 0;
        mOldAlpha = 1.0F;
        mLeftTop = new float[2];
        mLeftBottom = new float[2];
        mRightTop = new float[2];
        mRightBottom = new float[2];
        mClipping = true;
        mForcedClipping = false;
        mDraggable = true;
        setDragging = new _cls1();
        mBypassTouch = false;
        mTempOrientation = 0;
        mInternalFocus = false;
        mNextFocusLeftId = -1;
        mNextFocusRightId = -1;
        mNextFocusUpId = -1;
        mNextFocusDownId = -1;
        mNextFocusForwardId = -1;
        mFocusIndicator = null;
        mHoverIndicator = null;
        mLongClickable = false;
        mRepeatClickWhenLongClicked = false;
        mRepeatClickInterval = 100;
        repeatClick = new _cls2();
        setLongClick = new _cls3();
        mIsTouchCanceled = false;
        mDragSensitivity = 2;
        for (int i = 0; i < 4; i++)
        {
            mLeftTopCoordinates[i] = new RectF();
        }

        mBound = new RectF(f, f1, f + f2, f1 + f3);
        mGLContext = glcontext;
        resetTransformMatrix();
        mOriginalLeft = f;
        mOriginalTop = f1;
        mBaseLeft = f;
        mBaseTop = f1;
        mSizeSpecified = true;
        mSizeGiven = true;
        mZCoordinate = f4;
        setLeftTop(0, f, f1);
        setLeftTop(1, f, f1);
        setLeftTop(2, f, f1);
        setLeftTop(3, f, f1);
        mThis = this;
        mViewId = hashCode();
    }

    private void combineMatrices()
    {
        this;
        JVM INSTR monitorenter ;
        Exception exception;
        try
        {
            GLUtil.multiplyMM(mTempMatrix, mRotationMatrix, mScaleMatrix);
            GLUtil.multiplyMM(mCombinedMatrix, mTranslationMatrix, mTempMatrix);
        }
        catch (IllegalArgumentException illegalargumentexception) { }
        finally
        {
            this;
        }
        return;
        throw exception;
    }

    private void transformScreenCoordinates(int i, int j, int k, int l)
    {
        mLeftTop[0] = mMatrix[0] * (float)i + mMatrix[4] * (float)j + mMatrix[12];
        mLeftTop[1] = mMatrix[1] * (float)i + mMatrix[5] * (float)j + mMatrix[13];
        mLeftBottom[0] = mMatrix[0] * (float)i + mMatrix[4] * (float)l + mMatrix[12];
        mLeftBottom[1] = mMatrix[1] * (float)i + mMatrix[5] * (float)l + mMatrix[13];
        mRightTop[0] = mMatrix[0] * (float)k + mMatrix[4] * (float)j + mMatrix[12];
        mRightTop[1] = mMatrix[1] * (float)k + mMatrix[5] * (float)j + mMatrix[13];
        mRightBottom[0] = mMatrix[0] * (float)k + mMatrix[4] * (float)l + mMatrix[12];
        mRightBottom[1] = mMatrix[1] * (float)k + mMatrix[5] * (float)l + mMatrix[13];
    }

    public void addAccessibilityChildViewNode(ArrayList arraylist)
    {
        this;
        JVM INSTR monitorenter ;
        if (!mInScreen) goto _L2; else goto _L1
_L1:
        int i = getVisibility();
        if (i == 0) goto _L3; else goto _L2
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
_L3:
        if (isClickable() && !getBypassTouch() && (!mIsClipped || getDepth() >= 0.0F))
        {
            arraylist.add(this);
        }
        if (true) goto _L2; else goto _L4
_L4:
        arraylist;
        throw arraylist;
    }

    public void addView(int i, GLView glview)
    {
    }

    public void addView(GLView glview)
    {
    }

    public final void bringToFront()
    {
        if (mParent != null)
        {
            mParent.removeView(this);
            mParent.addView(this);
        }
    }

    public final void cancelAnimation()
    {
        if (mAnimation == null)
        {
            return;
        }
        mAnimation.cancel();
        if (mTransformation != null)
        {
            mTransformation.getMatrix().reset();
        }
        mAnimation.reset();
        mAnimationPending = false;
        mAnimationFinished = true;
        mAnimationStarted = false;
        mGLContext.setDirty(true);
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        mRotatable = false;
        mRotationMatrix = null;
        mAnimation = null;
        if (mBackground != null)
        {
            mBackground.clear();
            mBackground = null;
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.clear();
            mFocusIndicator = null;
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.clear();
            mHoverIndicator = null;
        }
        mTouchListener = null;
        if (mDragListener != null)
        {
            mDragListener = null;
        }
        if (mFocusListener != null)
        {
            mFocusListener = null;
        }
        if (mClickListener != null)
        {
            mClickListener = null;
        }
        if (mLeftTopCoordinates == null)
        {
            break MISSING_BLOCK_LABEL_148;
        }
        int i = 0;
_L2:
        if (i >= 4)
        {
            break; /* Loop/switch isn't completed */
        }
        mLeftTopCoordinates[i] = null;
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        mLeftTopCoordinates = null;
        if (mParent != null)
        {
            mParent.removeView(this);
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected final void clearClip()
    {
        GLES20.glScissor(0, 0, GLContext.getScreenWidthPixels(), GLContext.getScreenHeightPixels());
    }

    protected final void clip()
    {
        if (isParentClippingForced())
        {
            Rect rect = getParentForcedClipRect();
            if (rect != null)
            {
                GLES20.glScissor(rect.left, GLContext.getScreenHeightPixels() - rect.bottom, rect.right - rect.left, rect.bottom - rect.top);
            }
            return;
        }
        if (mClipping)
        {
            GLES20.glScissor(mClipRect.left, GLContext.getScreenHeightPixels() - mClipRect.bottom, mClipRect.right - mClipRect.left, mClipRect.bottom - mClipRect.top);
            return;
        } else
        {
            clearClip();
            return;
        }
    }

    public boolean contains(float f, float f1)
    {
        boolean flag = false;
        if (mManualClip && mClipRect == null)
        {
            flag = mManualClipRect.contains((int)f, (int)f1);
        } else
        {
            if (mClipRect == null)
            {
                refreshClipRect();
            }
            if (mInScreen)
            {
                if (mRotateDegree != 0)
                {
                    float af[] = new float[2];
                    float af1[] = getLeftTop((mOrientation + mDefaultOrientation) % 4);
                    af1[0] = (getLeft() + getRight()) / 2.0F;
                    af1[1] = (getTop() + getBottom()) / 2.0F;
                    GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, af1[0], af1[1]);
                    PointF pointf = GLUtil.rotatePoint(f, f1, -((getOrientation() + mDefaultOrientation) % 4) * 90 - getRotateDegree(), af1[0], af1[1]);
                    return mClipRect.contains((int)pointf.x, (int)pointf.y);
                } else
                {
                    return mClipRect.contains((int)f, (int)f1);
                }
            }
        }
        return flag;
    }

    public final void draw(float af[], Rect rect)
    {
        this;
        JVM INSTR monitorenter ;
        if (mLoaded || load()) goto _L2; else goto _L1
_L1:
        mGLContext.setDirty(true);
_L4:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (mVisibility == 4) goto _L4; else goto _L3
_L3:
        float af2[];
        if (mDrawFirstTime && mRotatable)
        {
            setOrientation(GLContext.getLastOrientation());
        }
        if (mContinuousDrawMode)
        {
            mGLContext.setDirty(true);
        }
        af2 = mCombinedMatrix;
        float af1[] = af2;
        if (mAnimation == null) goto _L6; else goto _L5
_L5:
        af1 = af2;
        if (mAnimationFinished) goto _L8; else goto _L7
_L7:
        long l;
        mGLContext.setDirty(true);
        l = AnimationUtils.currentAnimationTimeMillis();
        if (!mAnimationPending)
        {
            break MISSING_BLOCK_LABEL_129;
        }
        startAnimation();
          goto _L4
        af;
        throw af;
        if (mAnimationStarted)
        {
            mAnimationStarted = false;
            mAnimationStartedEvent = true;
            mAnimation.reset();
            mAnimation.setStartTime(l);
        }
        if (!mAnimation.getTransformation(l, mTransformation)) goto _L10; else goto _L9
_L9:
        mTransformation.getMatrix().getValues(mAnimMatrix);
        GLUtil.toGLMatrix(mAnimMatrix);
        GLUtil.multiplyMM(mAnimGLMatrix, mAnimMatrix, mCombinedMatrix);
        mAlpha = mTransformation.getAlpha();
        af1 = mAnimGLMatrix;
_L8:
        af2 = af1;
        if (!mAnimationFinished) goto _L12; else goto _L11
_L11:
        if (mUpdateMatrixAfterAnimation)
        {
            mUpdateMatrixAfterAnimation = false;
            updateLayout(false);
        }
        mLayoutUpdated = true;
        if (!mAnimation.getFillAfter()) goto _L14; else goto _L13
_L13:
        mTransformation.getMatrix().getValues(mAnimMatrix);
        GLUtil.toGLMatrix(mAnimMatrix);
        GLUtil.multiplyMM(mAnimGLMatrix, mAnimMatrix, mCombinedMatrix);
        af2 = mAnimGLMatrix;
        mAlpha = mTransformation.getAlpha();
        mOldAlpha = mAlpha;
_L12:
        af1 = af2;
        if (!mAnimationStartedEvent) goto _L6; else goto _L15
_L15:
        mAnimationStartedEvent = false;
        af1 = af2;
        if (mAnimationEventListener == null) goto _L6; else goto _L16
_L16:
        mGLContext.getMainHandler().post(new Runnable() {

            final GLView this$0;

            public void run()
            {
                mAnimationEventListener.onAnimationStart(GLView.this, mAnimation);
            }

            
            {
                this$0 = GLView.this;
                super();
            }
        });
        af1 = af2;
_L6:
        GLUtil.multiplyMM(mMatrix, af, af1);
        if (!mLayoutUpdated) goto _L18; else goto _L17
_L17:
        refreshClipRect();
        if (!mManualClip) goto _L20; else goto _L19
_L19:
        if (mClipRect.setIntersect(mManualClipRect, mGLContext.getScreenGeometry()) || !mClipping) goto _L22; else goto _L21
_L21:
        mInScreen = false;
        mIsClipped = true;
        onOutOfScreen();
          goto _L4
_L10:
        mAnimationFinished = true;
        mUpdateMatrixAfterAnimation = true;
        if (mAnimationEventListener != null)
        {
            mGLContext.getMainHandler().post(new Runnable() {

                final GLView this$0;

                public void run()
                {
                    mAnimationEventListener.onAnimationEnd(GLView.this, mAnimation);
                }

            
            {
                this$0 = GLView.this;
                super();
            }
            });
        }
        af1 = af2;
        if (!mHideAfterAnimation) goto _L8; else goto _L23
_L23:
        setVisibility(4);
          goto _L4
_L14:
        mAlpha = mOldAlpha;
        af2 = af1;
          goto _L12
_L22:
        if (!rect.contains(mManualClipRect)) goto _L25; else goto _L24
_L24:
        mIsClipped = false;
_L26:
        mInScreen = true;
_L18:
        if (mBackground != null)
        {
            mBackground.draw(mMatrix, mClipRect);
        }
        onDraw();
        mDrawFirstTime = false;
        if (getContext().isTouchExplorationEnabled() && mHoverFocused && mHoverIndicator != null)
        {
            mHoverIndicator.draw(mMatrix, mClipRect);
        }
        if (getContext().isFocusIndicatorVisible() && mFocused && mFocusIndicator != null)
        {
            mFocusIndicator.draw(mMatrix, mClipRect);
        }
          goto _L4
_L25:
label0:
        {
            if (!mClipRect.setIntersect(mManualClipRect, rect))
            {
                break label0;
            }
            mIsClipped = true;
        }
          goto _L26
        mClipRect.set(0, 0, 0, 0);
        mIsClipped = true;
          goto _L26
_L20:
label1:
        {
            if (mClipRect.setIntersect(mOriginalClipRect, mGLContext.getScreenGeometry()) || !mClipping || getRotateDegree() != 0)
            {
                break label1;
            }
            mInScreen = false;
            mIsClipped = true;
            onOutOfScreen();
        }
          goto _L4
label2:
        {
            if (!rect.contains(mOriginalClipRect))
            {
                break label2;
            }
            mIsClipped = false;
        }
          goto _L26
label3:
        {
            if (!mClipRect.setIntersect(mOriginalClipRect, rect))
            {
                break label3;
            }
            mIsClipped = true;
        }
          goto _L26
        mClipRect.set(0, 0, 0, 0);
        mIsClipped = true;
          goto _L26
    }

    public void dumpViewHierarchy(int i)
    {
        StringBuilder stringbuilder = new StringBuilder();
        for (int j = 0; j < i; j++)
        {
            stringbuilder.append("| ");
        }

        if (mClipRect != null)
        {
            if (getTitle() != null)
            {
                SemLog.secE("DUMP", (new StringBuilder()).append(stringbuilder.toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append(") Title : ").append(getTitle()).append(", Visible=").append(isVisible()).append(", Clip(Manual:").append(mManualClip).append(",").append(mClipRect.left).append(",").append(mClipRect.top).append(",").append(mClipRect.width()).append(",").append(mClipRect.height()).append(")").toString());
                return;
            } else
            {
                SemLog.secE("DUMP", (new StringBuilder()).append(stringbuilder.toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append(")").append(", Visible=").append(isVisible()).append(", Clip(Manual:").append(mManualClip).append(",").append(mClipRect.left).append(",").append(mClipRect.top).append(",").append(mClipRect.width()).append(",").append(mClipRect.height()).append(")").toString());
                return;
            }
        }
        if (getTitle() != null)
        {
            SemLog.secE("DUMP", (new StringBuilder()).append(stringbuilder.toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append(") Title : ").append(getTitle()).append(", Visible=").append(isVisible()).toString());
            return;
        } else
        {
            SemLog.secE("DUMP", (new StringBuilder()).append(stringbuilder.toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append("), Visible=").append(isVisible()).toString());
            return;
        }
    }

    public GLView findNextFocusFromView(GLView glview, int i)
    {
        if (isFocusable() && glview != null) goto _L2; else goto _L1
_L1:
        return null;
_L2:
        float f;
        float f1;
        float f2;
        float f3;
        float f4;
        float f5;
        f = (float)(getOriginalClipRect().left + getOriginalClipRect().right) / 2.0F;
        f1 = (float)(getOriginalClipRect().top + getOriginalClipRect().bottom) / 2.0F;
        f2 = (float)(glview.getOriginalClipRect().left + glview.getOriginalClipRect().right) / 2.0F;
        f3 = (float)(glview.getOriginalClipRect().top + glview.getOriginalClipRect().bottom) / 2.0F;
        f4 = Math.abs(f2 - f);
        f5 = Math.abs(f3 - f1);
        i;
        JVM INSTR lookupswitch 8: default 188
    //                   17: 190
    //                   33: 224
    //                   49: 190
    //                   65: 224
    //                   66: 207
    //                   82: 242
    //                   98: 207
    //                   130: 242;
           goto _L3 _L4 _L5 _L4 _L5 _L6 _L7 _L6 _L7
_L7:
        continue; /* Loop/switch isn't completed */
_L3:
        return null;
_L4:
        if (f2 <= f || f4 <= f5) goto _L1; else goto _L8
_L8:
        return this;
_L6:
        if (f2 >= f || f4 <= f5) goto _L1; else goto _L9
_L9:
        return this;
_L5:
        if (f3 <= f1 || f4 >= f5) goto _L1; else goto _L10
_L10:
        return this;
        if (f3 >= f1 || f4 >= f5) goto _L1; else goto _L11
_L11:
        return this;
    }

    public GLView findViewByCoordinate(float f, float f1)
    {
        GLView glview;
        if (mVisibility != 0)
        {
            glview = null;
        } else
        {
            if (mBypassTouch)
            {
                return null;
            }
            glview = this;
            if (!contains(f, f1))
            {
                return null;
            }
        }
        return glview;
    }

    public GLView findViewById(int i)
    {
        if (mViewId == i)
        {
            return this;
        } else
        {
            return null;
        }
    }

    public GLView findViewByObjectTag(String s)
    {
        if (s.equals(mObjectTag))
        {
            return this;
        } else
        {
            return null;
        }
    }

    public GLView findViewByTag(int i)
    {
        if (mViewTag == i)
        {
            return this;
        } else
        {
            return null;
        }
    }

    public GLView findViewFromLeftMostTop()
    {
        GLView glview;
        if (mVisibility != 0)
        {
            glview = null;
        } else
        {
            glview = this;
            if (mBypassTouch)
            {
                return null;
            }
        }
        return glview;
    }

    public GLView findViewFromLeftMostTop(int i, float f, float f1)
    {
        float f2;
        float f3;
        if (mVisibility != 0)
        {
            return null;
        }
        if (mBypassTouch)
        {
            return null;
        }
        f2 = (float)(getOriginalClipRect().left + getOriginalClipRect().right) / 2.0F;
        f3 = (float)(getOriginalClipRect().top + getOriginalClipRect().bottom) / 2.0F;
        i;
        JVM INSTR tableswitch 0 3: default 88
    //                   0 90
    //                   1 122
    //                   2 106
    //                   3 138;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return null;
_L2:
        if (f2 >= f && f3 >= f1)
        {
            return this;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (f2 <= f && f3 <= f1)
        {
            return this;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (f2 <= f && f3 >= f1)
        {
            return this;
        }
        continue; /* Loop/switch isn't completed */
_L5:
        if (f2 >= f && f3 <= f1)
        {
            return this;
        }
        if (true) goto _L1; else goto _L6
_L6:
    }

    public GLView findViewOnSameLine(GLView glview, int i)
    {
        if (isFocusable() && glview != null) goto _L2; else goto _L1
_L1:
        return null;
_L2:
        float f;
        float f1;
        float f2;
        float f3;
        f = (float)(getOriginalClipRect().left + getOriginalClipRect().right) / 2.0F;
        f1 = (float)(getOriginalClipRect().top + getOriginalClipRect().bottom) / 2.0F;
        f2 = (float)(glview.getOriginalClipRect().left + glview.getOriginalClipRect().right) / 2.0F;
        f3 = (float)(glview.getOriginalClipRect().top + glview.getOriginalClipRect().bottom) / 2.0F;
        i;
        JVM INSTR lookupswitch 8: default 168
    //                   17: 170
    //                   33: 208
    //                   49: 170
    //                   65: 208
    //                   66: 189
    //                   82: 227
    //                   98: 189
    //                   130: 227;
           goto _L3 _L4 _L5 _L4 _L5 _L6 _L7 _L6 _L7
_L7:
        continue; /* Loop/switch isn't completed */
_L3:
        return null;
_L4:
        if (f >= f2 || !GLUtil.floatEquals(f1, f3)) goto _L1; else goto _L8
_L8:
        return this;
_L6:
        if (f <= f2 || !GLUtil.floatEquals(f1, f3)) goto _L1; else goto _L9
_L9:
        return this;
_L5:
        if (f1 >= f3 || !GLUtil.floatEquals(f, f2)) goto _L1; else goto _L10
_L10:
        return this;
        if (f1 <= f3 || !GLUtil.floatEquals(f, f2)) goto _L1; else goto _L11
_L11:
        return this;
    }

    public float getAlpha()
    {
        float f = 0.45F;
        if (mParent != null)
        {
            float f1 = mAlpha;
            float f3 = mParent.getAlpha();
            if (!mDimmed)
            {
                f = 1.0F;
            }
            return f * (f1 * f3);
        }
        float f2 = mAlpha;
        if (!mDimmed)
        {
            f = 1.0F;
        }
        return f * f2;
    }

    public RectF getArea()
    {
        return new RectF(getLeft(), getTop(), getRight(), getBottom());
    }

    public final float getBottom()
    {
        if (!mSizeSpecified)
        {
            initSize();
        }
        if (mParent != null)
        {
            return mBound.bottom + mParent.getTop();
        } else
        {
            return mBound.bottom;
        }
    }

    public boolean getBypassTouch()
    {
        return mBypassTouch;
    }

    public final boolean getCenterPivot()
    {
        return mCenterPivot;
    }

    public ClickListener getClickListener()
    {
        return mClickListener;
    }

    public Rect getClipRect()
    {
        if (mClipRect == null)
        {
            refreshClipRect();
        }
        return mClipRect;
    }

    public RectF getClipRectArea()
    {
        return new RectF(getClipRect().left, getClipRect().top, getClipRect().right, getClipRect().bottom);
    }

    public RectF getContentArea()
    {
        float f = getContentAreaLeft();
        float f1 = getContentAreaTop();
        return new RectF(f, f1, getContentAreaWidth() + f, getContentAreaHeight() + f1);
    }

    public float getContentAreaHeight()
    {
        return getHeight() - (float)mPaddings.top - (float)mPaddings.bottom;
    }

    public float getContentAreaLeft()
    {
        return getLeft() + (float)mPaddings.left;
    }

    public float getContentAreaTop()
    {
        return getTop() + (float)mPaddings.top;
    }

    public float getContentAreaWidth()
    {
        return getWidth() - (float)mPaddings.left - (float)mPaddings.right;
    }

    public String getContentDescription()
    {
        return mContentDescription;
    }

    public final GLContext getContext()
    {
        return mGLContext;
    }

    public RectF getCurrentArea()
    {
        float f1 = getTranslateX();
        float f = getTranslateY();
        f1 = getLeft() + f1;
        f = getTop() + f;
        return new RectF(f1, f, f1 + getWidth(), f + getHeight());
    }

    public float getCurrentBottom()
    {
        return getBottom() + getTranslateY();
    }

    public RectF getCurrentContentArea()
    {
        RectF rectf = getCurrentArea();
        return new RectF(rectf.left + (float)mPaddings.left, rectf.top + (float)mPaddings.top, rectf.right - (float)mPaddings.right, rectf.bottom - (float)mPaddings.bottom);
    }

    public float getCurrentDepth()
    {
        return getDepth() + getTranslateZ();
    }

    public float getCurrentLeft()
    {
        return getLeft() + getTranslateX();
    }

    public float getCurrentRight()
    {
        return getRight() + getTranslateX();
    }

    public float getCurrentTop()
    {
        return getTop() + getTranslateY();
    }

    public final float getDepth()
    {
        if (mParent != null)
        {
            return mZCoordinate + mParent.getDepth();
        } else
        {
            return mZCoordinate;
        }
    }

    public boolean getDraggable()
    {
        return mDraggable;
    }

    public FocusListener getFocusListener()
    {
        return mFocusListener;
    }

    public final float getHeight()
    {
        if (!mSizeSpecified)
        {
            initSize();
        }
        return mBound.bottom - mBound.top;
    }

    public final int getId()
    {
        return mViewId;
    }

    public boolean getInternalFocus()
    {
label0:
        {
            boolean flag1 = mInternalFocus;
            boolean flag = flag1;
            if (mParent != null)
            {
                if (!mParent.getInternalFocus() && !flag1)
                {
                    break label0;
                }
                flag = true;
            }
            return flag;
        }
        return false;
    }

    public GLView getInternalFocusParent()
    {
        if (mInternalFocus)
        {
            return this;
        }
        if (mParent != null)
        {
            return mParent.getInternalFocusParent();
        } else
        {
            return null;
        }
    }

    public float getLayoutX()
    {
        return mBound.left;
    }

    public float getLayoutY()
    {
        return mBound.top;
    }

    public float getLayoutZ()
    {
        return mZCoordinate;
    }

    public final float getLeft()
    {
        if (mPositionChanged)
        {
            if (mParent != null)
            {
                mLeft = mBound.left + mParent.getLeft();
                mTop = mBound.top + mParent.getTop();
            } else
            {
                mLeft = mBound.left;
                mTop = mBound.top;
            }
            mPositionChanged = false;
            return mLeft;
        } else
        {
            return mLeft;
        }
    }

    public final float[] getLeftTop(int i)
    {
        if (i > 3 || i < 0)
        {
            throw new IllegalArgumentException();
        }
        if (!mCenterPivot) goto _L2; else goto _L1
_L1:
        float f;
        float f1;
        f = (getLeft() + getRight()) / 2.0F;
        f1 = (getTop() + getBottom()) / 2.0F;
        i;
        JVM INSTR tableswitch 0 3: default 80
    //                   0 85
    //                   1 108
    //                   2 139
    //                   3 172;
           goto _L3 _L4 _L5 _L6 _L7
_L3:
        return mLeftTop;
_L4:
        mLeftTop[0] = getLeft();
        mLeftTop[1] = getTop();
        continue; /* Loop/switch isn't completed */
_L5:
        mLeftTop[0] = getHeight() / 2.0F + f;
        mLeftTop[1] = f1 - getWidth() / 2.0F;
        continue; /* Loop/switch isn't completed */
_L6:
        mLeftTop[0] = getLeft() + getWidth();
        mLeftTop[1] = getTop() + getHeight();
        continue; /* Loop/switch isn't completed */
_L7:
        mLeftTop[0] = f - getHeight() / 2.0F;
        mLeftTop[1] = getWidth() / 2.0F + f1;
        continue; /* Loop/switch isn't completed */
_L2:
        if (mLeftTopCoordinates != null)
        {
            mLeftTop[0] = mLeftTopCoordinates[i].left;
            mLeftTop[1] = mLeftTopCoordinates[i].top;
        }
        if (true) goto _L3; else goto _L8
_L8:
    }

    public boolean getLoaded()
    {
        return mLoaded;
    }

    public LongClickListener getLongClickListener()
    {
        return mLongClickListener;
    }

    protected float[] getMatrix()
    {
        return mMatrix;
    }

    public final float getMoveLayoutX()
    {
        if (mParent != null)
        {
            return (mBound.left - mBaseLeft) + mParent.getMoveLayoutX();
        } else
        {
            return mBound.left - mBaseLeft;
        }
    }

    public final float getMoveLayoutY()
    {
        if (mParent != null)
        {
            return (mBound.top - mBaseTop) + mParent.getMoveLayoutY();
        } else
        {
            return mBound.top - mBaseTop;
        }
    }

    public final float getMoveLayoutZ()
    {
        if (mParent != null)
        {
            return (mZCoordinate - mBaseDepth) + mParent.getMoveLayoutZ();
        } else
        {
            return mZCoordinate - mBaseDepth;
        }
    }

    public final int getNextFocusDownId()
    {
        return mNextFocusDownId;
    }

    public int getNextFocusForwardId()
    {
        return mNextFocusForwardId;
    }

    public final int getNextFocusLeftId()
    {
        return mNextFocusLeftId;
    }

    public final int getNextFocusRightId()
    {
        return mNextFocusRightId;
    }

    public final int getNextFocusUpId()
    {
        return mNextFocusUpId;
    }

    public final String getObjectTag()
    {
        return mObjectTag;
    }

    public final int getOrientation()
    {
        if (mParent != null)
        {
            return (mOrientation + mParent.getOrientation()) % 4;
        } else
        {
            return mOrientation;
        }
    }

    public Rect getOriginalClipRect()
    {
        if (mOriginalClipRect == null)
        {
            refreshClipRect();
        }
        return mOriginalClipRect;
    }

    public Rect getPaddings()
    {
        return mPaddings;
    }

    public Rect getParentForcedClipRect()
    {
        if (mParent == null)
        {
            return null;
        }
        if (mParent.isClippingForced())
        {
            return mParent.getClipRect();
        } else
        {
            return mParent.getParentForcedClipRect();
        }
    }

    public final int getParentHAlign()
    {
        return mParentHAlign;
    }

    public int getParentId()
    {
        return mParentViewId;
    }

    public final int getParentVAlign()
    {
        return mParentVAlign;
    }

    public int getRepeatClickInterval()
    {
        return mRepeatClickInterval;
    }

    public final float getRight()
    {
        if (!mSizeSpecified)
        {
            initSize();
        }
        if (mParent != null)
        {
            return mBound.right + mParent.getLeft();
        } else
        {
            return mBound.right;
        }
    }

    public final boolean getRotatable()
    {
        return mRotatable;
    }

    public final boolean getRotateAnimation()
    {
        return mRotateAnimation;
    }

    public int getRotateDegree()
    {
        if (mParent != null)
        {
            return mRotateDegree + mParent.getRotateDegree();
        } else
        {
            return mRotateDegree;
        }
    }

    public boolean getScrollHint()
    {
        return false;
    }

    public final boolean getSizeGiven()
    {
        return mSizeGiven;
    }

    protected final boolean getSizeSpecified()
    {
        return mSizeSpecified;
    }

    public String getSubTitle()
    {
        return mSubTitle;
    }

    public final int getTag()
    {
        return mViewTag;
    }

    public int getTint()
    {
        return Color.argb((int)(mTintColor[3] * 255F), (int)(mTintColor[0] * 255F), (int)(mTintColor[1] * 255F), (int)(mTintColor[2] * 255F));
    }

    public final String getTitle()
    {
        return mTitle;
    }

    public final float getTop()
    {
        if (mPositionChanged)
        {
            if (mParent != null)
            {
                mLeft = mBound.left + mParent.getLeft();
                mTop = mBound.top + mParent.getTop();
            } else
            {
                mLeft = mBound.left;
                mTop = mBound.top;
            }
            mPositionChanged = false;
            return mTop;
        } else
        {
            return mTop;
        }
    }

    public final float getTranslateX()
    {
        if (mParent != null)
        {
            return mTranslateX + mParent.getTranslateX();
        } else
        {
            return mTranslateX;
        }
    }

    public final float getTranslateY()
    {
        if (mParent != null)
        {
            return mTranslateY + mParent.getTranslateY();
        } else
        {
            return mTranslateY;
        }
    }

    public final float getTranslateZ()
    {
        if (mParent != null)
        {
            return mTranslateZ + mParent.getTranslateZ();
        } else
        {
            return mTranslateZ;
        }
    }

    public String getTtsString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (mContentDescription == null) goto _L2; else goto _L1
_L1:
        stringbuilder.append(mContentDescription);
_L4:
        if (GLUtil.isTimeInfo(stringbuilder.toString()))
        {
            String s = GLUtil.convertTimeInfoForTTS(GLContext.getApplicationContext(), stringbuilder.toString());
            stringbuilder.setLength(0);
            stringbuilder.append(s);
        }
        if (mSubTitle != null)
        {
            stringbuilder.append(",");
            stringbuilder.append(mSubTitle);
        }
        if (isDim())
        {
            stringbuilder.append(",");
            stringbuilder.append(GLContext.getApplicationContext().getString(R.string.disable));
        }
        return stringbuilder.toString();
_L2:
        if (mTitle != null)
        {
            stringbuilder.append(mTitle);
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public final int getVisibility()
    {
        return mVisibility;
    }

    public final float getWidth()
    {
        if (!mSizeSpecified)
        {
            initSize();
        }
        return mBound.right - mBound.left;
    }

    public abstract void initSize();

    public boolean isAnimationFinished()
    {
        return mAnimationFinished;
    }

    public final boolean isClickable()
    {
        return (mViewFlags & 0x4000) == 16384;
    }

    protected boolean isClipped()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mIsClipped;
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isClippingForced()
    {
        return mForcedClipping;
    }

    public boolean isDim()
    {
        if (mParent != null)
        {
            return mParent.isDim() || mDimmed;
        } else
        {
            return mDimmed;
        }
    }

    public boolean isDragging()
    {
        return mDragging;
    }

    public final boolean isFocusable()
    {
        return (mViewFlags & 1) == 1 && mParent != null && isVisible() == 0;
    }

    public final boolean isFocused()
    {
        return mFocused;
    }

    public boolean isHoverSwipeEvent(int i)
    {
        return i == 65 || i == 82 || i == 49 || i == 98;
    }

    public boolean isInScreen()
    {
        return mInScreen;
    }

    public boolean isLongClickable()
    {
        return mLongClickable;
    }

    public boolean isParentClippingForced()
    {
        if (mParent == null)
        {
            return false;
        }
        if (mParent.isClippingForced())
        {
            return true;
        } else
        {
            return mParent.isParentClippingForced();
        }
    }

    public boolean isParentRotatable()
    {
        if (mParent != null)
        {
            if (mParent.getRotatable())
            {
                return true;
            } else
            {
                return mParent.isParentRotatable();
            }
        } else
        {
            return false;
        }
    }

    public boolean isRepeatClickWhenLongClicked()
    {
        return mRepeatClickWhenLongClicked;
    }

    public final int isVisible()
    {
        if (mParent != null)
        {
            if (mParent.isVisible() == 0)
            {
                return mVisibility;
            } else
            {
                return 4;
            }
        } else
        {
            return mVisibility;
        }
    }

    public boolean keyDownEvent(int i, KeyEvent keyevent)
    {
        if (mKeyListener != null && mKeyListener.onKeyDown(this, keyevent))
        {
            return true;
        } else
        {
            return onKeyDownEvent(i, keyevent);
        }
    }

    public boolean keyUpEvent(int i, KeyEvent keyevent)
    {
        if (mKeyListener != null && mKeyListener.onKeyUp(this, keyevent))
        {
            return true;
        } else
        {
            return onKeyUpEvent(i, keyevent);
        }
    }

    public final boolean load()
    {
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        if (!mLoading) goto _L2; else goto _L1
_L1:
        if (!getLoaded()) goto _L4; else goto _L3
_L3:
        mLoaded = true;
        mLoading = false;
_L6:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L4:
        flag = false;
        continue; /* Loop/switch isn't completed */
_L2:
        if (mLoaded)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (onLoad())
        {
            mLoaded = true;
            mLoading = false;
            if (mLoadListener != null)
            {
                mLoadListener.onLoaded();
            }
            if (mBackground != null)
            {
                mBackground.load();
            }
            flag = mLoaded;
            continue; /* Loop/switch isn't completed */
        }
        mLoading = true;
        flag = false;
        if (true) goto _L6; else goto _L5
_L5:
        Exception exception;
        exception;
        throw exception;
    }

    protected Rect mClipRect()
    {
        return mClipRect;
    }

    public final void mapPoint(float af[], float f, float f1)
    {
        glCoordinate[0] = f;
        glCoordinate[1] = f1;
        glCoordinate[3] = 1.0F;
        glTransformedCoordinate[3] = 1.0F;
        android.opengl.Matrix.multiplyMV(glTransformedCoordinate, 0, mMatrix, 0, glCoordinate, 0);
        af[0] = glTransformedCoordinate[0];
        af[1] = glTransformedCoordinate[1];
    }

    protected final void mapPointReverse(float af[], float f, float f1)
    {
        int i = (getOrientation() + mDefaultOrientation) % 4;
        if (i == 0)
        {
            af[0] = f;
            af[1] = f1;
            return;
        }
        float af1[] = new float[16];
        float af2[] = getLeftTop(i);
        if (mParent != null)
        {
            af2[0] = af2[0] + mParent.getLeft();
            af2[1] = af2[1] + mParent.getTop();
        }
        float af3[] = new float[4];
        af3[3] = 1.0F;
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af3, getLeft(), getTop());
        float af4[] = new float[4];
        af4[3] = 1.0F;
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af4, af2[0], af2[1]);
        android.opengl.Matrix.setIdentityM(af1, 0);
        android.opengl.Matrix.translateM(af1, 0, af3[0], af3[1], 0.0F);
        android.opengl.Matrix.rotateM(af1, 0, i * 90, 0.0F, 0.0F, -1F);
        android.opengl.Matrix.translateM(af1, 0, -af4[0], -af4[1], 0.0F);
        af2 = new float[4];
        af2[3] = 1.0F;
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af2, f, f1);
        af3 = new float[4];
        af3[3] = 1.0F;
        android.opengl.Matrix.multiplyMV(af3, 0, af1, 0, af2, 0);
        GLUtil.getScreenCoordinateFromGLCoordinate(mGLContext, af, af3[0], af3[1]);
    }

    public final void moveBaseDepthLayout(float f)
    {
        mBaseDepth = mBaseDepth + f;
        mZCoordinate = mZCoordinate + f;
        updateLayout(true);
    }

    public final void moveBaseDepthLayout(float f, boolean flag)
    {
        mBaseDepth = mBaseDepth + f;
        mZCoordinate = mZCoordinate + f;
        if (flag)
        {
            updateLayout(true);
        }
    }

    public final void moveBaseDepthLayoutAbsolute(float f)
    {
        float f1 = getMoveLayoutZ();
        mBaseDepth = mOriginalDepth + f;
        mZCoordinate = mBaseDepth + f1;
        updateLayout(true);
    }

    public final void moveBaseDepthLayoutAbsolute(float f, boolean flag)
    {
        float f1 = getMoveLayoutZ();
        mBaseDepth = mOriginalDepth + f;
        mZCoordinate = mBaseDepth + f1;
        if (flag)
        {
            updateLayout(true);
        }
    }

    public final void moveBaseLayout(float f, float f1)
    {
        float f2 = getWidth();
        float f3 = getHeight();
        mBaseLeft = mBaseLeft + f;
        mBaseTop = mBaseTop + f1;
        RectF rectf = mBound;
        rectf.left = rectf.left + f;
        rectf = mBound;
        rectf.top = rectf.top + f1;
        mBound.right = mBound.left + f2;
        mBound.bottom = mBound.top + f3;
        updateLayout(false);
    }

    public final void moveBaseLayoutAbsolute(float f, float f1)
    {
        float f2 = getWidth();
        float f3 = getHeight();
        float f4 = getMoveLayoutX();
        float f5 = getMoveLayoutY();
        mBaseLeft = mOriginalLeft + f;
        mBaseTop = mOriginalTop + f1;
        mBound.left = mBaseLeft + f4;
        mBound.top = mBaseTop + f5;
        mBound.right = mBound.left + f2;
        mBound.bottom = mBound.top + f3;
        updateLayout(false);
    }

    public final void moveBaseLayoutAbsolute(float f, float f1, boolean flag)
    {
        float f2 = getWidth();
        float f3 = getHeight();
        float f4 = getMoveLayoutX();
        float f5 = getMoveLayoutY();
        mBaseLeft = mOriginalLeft + f;
        mBaseTop = mOriginalTop + f1;
        mBound.left = mBaseLeft + f4;
        mBound.top = mBaseTop + f5;
        mBound.right = mBound.left + f2;
        mBound.bottom = mBound.top + f3;
        if (flag)
        {
            updateLayout(false);
        }
    }

    public void moveDepthLayout(float f)
    {
        mZCoordinate = mZCoordinate + f;
        updateLayout(true);
    }

    public void moveDepthLayoutAbsolute(float f)
    {
        mZCoordinate = mBaseDepth + f;
        updateLayout(true);
    }

    public void moveLayout(float f, float f1)
    {
        RectF rectf = mBound;
        rectf.left = rectf.left + f;
        rectf = mBound;
        rectf.top = rectf.top + f1;
        rectf = mBound;
        rectf.right = rectf.right + f;
        rectf = mBound;
        rectf.bottom = rectf.bottom + f1;
        updateLayout(false);
    }

    public final void moveLayoutAbsolute(float f, float f1)
    {
        float f2 = getWidth();
        float f3 = getHeight();
        mBound.left = mBaseLeft + f;
        mBound.top = mBaseTop + f1;
        mBound.right = mBound.left + f2;
        mBound.bottom = mBound.top + f3;
        updateLayout(false);
    }

    public final void moveLayoutAbsolute(float f, float f1, boolean flag)
    {
        float f2 = getWidth();
        float f3 = getHeight();
        mBound.left = mBaseLeft + f;
        mBound.top = mBaseTop + f1;
        mBound.right = mBound.left + f2;
        mBound.bottom = mBound.top + f3;
        if (flag)
        {
            updateLayout(false);
        }
    }

    protected void onAlphaUpdated()
    {
    }

    protected void onDepthUpdated()
    {
    }

    protected abstract void onDraw();

    public void onFocusStatusChanged(int i)
    {
        if (i == 1)
        {
            mFocused = true;
            if (mFocusIndicator == null)
            {
                mFocusIndicator = new GLRectangle(getContext(), mPaddings.left, mPaddings.top, getWidth() - (float)mPaddings.right - (float)mPaddings.left, getHeight() - (float)mPaddings.bottom - (float)mPaddings.top, getContext().getFocusIndicatorColor(), getContext().getFocusIndicatorThickness());
                mFocusIndicator.setBypassTouch(true);
                mFocusIndicator.setClipping(false);
                mFocusIndicator.mParent = this;
            }
        } else
        {
            mFocused = false;
        }
        if (mFocusListener != null)
        {
            mFocusListener.onFocusChanged(this, i);
        }
    }

    public void onHoverIndicatorColorChanged()
    {
        if (mHoverIndicator != null)
        {
            mHoverIndicator.setColor(getContext().getHoverIndicatorColor());
        }
    }

    public void onHoverStatusChanged(int i)
    {
        if (i == 0)
        {
            mHoverFocused = true;
            if (mHoverIndicator == null)
            {
                mHoverIndicator = new GLRectangle(getContext(), mPaddings.left, mPaddings.top, getWidth() - (float)mPaddings.right - (float)mPaddings.left, getHeight() - (float)mPaddings.bottom - (float)mPaddings.top, getContext().getHoverIndicatorColor(), getContext().getHoverIndicatorThickness());
                mHoverIndicator.setBypassTouch(true);
                mHoverIndicator.setClipping(false);
                mHoverIndicator.mParent = this;
            }
            return;
        } else
        {
            mHoverFocused = false;
            return;
        }
    }

    public boolean onKeyDownEvent(int i, KeyEvent keyevent)
    {
        return false;
    }

    public boolean onKeyUpEvent(int i, KeyEvent keyevent)
    {
        return false;
    }

    protected void onLayoutUpdated()
    {
        mPositionChanged = true;
    }

    protected abstract boolean onLoad();

    protected void onOrientationChanged(int i)
    {
        if (mRotatable)
        {
            mLastOrientation = mOrientation;
            if (mLastOrientation == i)
            {
                return;
            }
            int k = i;
            int j;
            if (k == 0 && mLastOrientation == 3)
            {
                j = 4;
            } else
            {
                j = k;
                if (k == 3)
                {
                    j = k;
                    if (mLastOrientation == 0)
                    {
                        mLastOrientation = 4;
                        j = k;
                    }
                }
            }
            k = mLastOrientation;
            setOrientation(i);
            if (!mDrawFirstTime && isVisible() == 0 && isAnimationFinished())
            {
                if (!mRotateAnimation)
                {
                    if (mAnimation != null && mTransformation != null)
                    {
                        mTransformation.getMatrix().reset();
                    }
                    if (mHideAfterAnimation)
                    {
                        setVisibility(4);
                    }
                    setAnimation(GLUtil.getAlphaOnAnimation(mAlpha));
                    startAnimation();
                } else
                {
                    float f = (k - j) * 90;
                    float f1 = getLeft();
                    float f2 = getWidth() / 2.0F;
                    float f3 = getTop();
                    RotateAnimation rotateanimation = new RotateAnimation(f, 0.0F, 0, f1 + f2, 0, getHeight() / 2.0F + f3);
                    rotateanimation.initialize((int)getWidth(), (int)getHeight(), GLContext.getScreenWidthPixels(), GLContext.getScreenHeightPixels());
                    rotateanimation.setDuration(mRotateAnimationDuration);
                    if (mRotateAnimationInterpolator != null)
                    {
                        rotateanimation.setInterpolator(mRotateAnimationInterpolator);
                    }
                    setAnimation(rotateanimation);
                    startAnimation();
                }
            }
        }
        mGLContext.getMainHandler().removeCallbacks(setLongClick);
    }

    protected void onOutOfScreen()
    {
        mInScreen = false;
    }

    protected abstract void onReset();

    protected boolean onTouchEvent(MotionEvent motionevent)
    {
        return false;
    }

    protected void onVisibilityChanged(int i)
    {
        if (i != 0 && mLongClickable)
        {
            mGLContext.getMainHandler().removeCallbacks(setLongClick);
            if (mRepeatClickWhenLongClicked)
            {
                mGLContext.getMainHandler().removeCallbacks(repeatClick);
            }
        }
    }

    protected Rect parentClipRect()
    {
        if (mParent != null)
        {
            return mParent.mClipRect();
        } else
        {
            return null;
        }
    }

    protected void refreshClipRect()
    {
        int i;
        int j;
        int k;
        int l;
        transformScreenCoordinates((int)(getLeft() + 0.5F) + mPaddings.left, (int)(getTop() + 0.5F) + mPaddings.top, (int)(getRight() + 0.5F) - mPaddings.right, (int)(getBottom() + 0.5F) - mPaddings.bottom);
        j = (int)(mLeftTop[0] + 0.5F);
        l = (int)(mLeftTop[1] + 0.5F);
        k = (int)(mRightBottom[0] + 0.5F);
        i = (int)(mRightBottom[1] + 0.5F);
        (getOrientation() + mDefaultOrientation) % 4;
        JVM INSTR tableswitch 1 3: default 160
    //                   1 364
    //                   2 416
    //                   3 312;
           goto _L1 _L2 _L3 _L4
_L1:
        if (j > k || l > i || getRotateDegree() != 0)
        {
            j = (int)(getLeft() + 0.5F) + mPaddings.left;
            l = (int)(getTop() + 0.5F) + mPaddings.top;
            k = (int)(getRight() + 0.5F) - mPaddings.right;
            i = (int)(getBottom() + 0.5F) - mPaddings.bottom;
        }
        if (mClipRect == null)
        {
            mClipRect = new Rect();
        }
        mClipRect.set(j, l, k, i);
        if (mOriginalClipRect == null)
        {
            mOriginalClipRect = new Rect();
        }
        mOriginalClipRect.set(j, l, k, i);
        return;
_L4:
        j = (int)(mRightTop[0] + 0.5F);
        l = (int)(mRightTop[1] + 0.5F);
        k = (int)(mLeftBottom[0] + 0.5F);
        i = (int)(mLeftBottom[1] + 0.5F);
        continue; /* Loop/switch isn't completed */
_L2:
        j = (int)(mLeftBottom[0] + 0.5F);
        l = (int)(mLeftBottom[1] + 0.5F);
        k = (int)(mRightTop[0] + 0.5F);
        i = (int)(mRightTop[1] + 0.5F);
        continue; /* Loop/switch isn't completed */
_L3:
        j = (int)(mRightBottom[0] + 0.5F);
        l = (int)(mRightBottom[1] + 0.5F);
        k = (int)(mLeftTop[0] + 0.5F);
        i = (int)(mLeftTop[1] + 0.5F);
        if (true) goto _L1; else goto _L5
_L5:
    }

    public void removeView(GLView glview)
    {
    }

    public final boolean requestFocus()
    {
        return requestFocus(130);
    }

    public final boolean requestFocus(int i)
    {
        return requestFocus(i, null);
    }

    public boolean requestFocus(int i, GLView glview)
    {
        GLView glview1;
        if (glview == null)
        {
            if ((mViewFlags & 1) == 1)
            {
                if (isHoverSwipeEvent(i))
                {
                    getContext().onHoverChanged(this, null);
                } else
                {
                    getContext().onFocusChanged(this);
                }
                return true;
            }
            break MISSING_BLOCK_LABEL_297;
        }
        glview1 = null;
        i;
        JVM INSTR lookupswitch 8: default 120
    //                   17: 147
    //                   33: 193
    //                   49: 147
    //                   65: 193
    //                   66: 170
    //                   82: 216
    //                   98: 170
    //                   130: 216;
           goto _L1 _L2 _L3 _L2 _L3 _L4 _L5 _L4 _L5
_L1:
        GLView glview2;
        glview2 = glview1;
        if (glview1 != null)
        {
            break MISSING_BLOCK_LABEL_267;
        }
        if (glview.getId() == getId() && mInternalFocus)
        {
            return false;
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (mNextFocusLeftId != -1)
        {
            glview1 = getContext().findViewById(mNextFocusLeftId);
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (mNextFocusRightId != -1)
        {
            glview1 = getContext().findViewById(mNextFocusRightId);
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (mNextFocusUpId != -1)
        {
            glview1 = getContext().findViewById(mNextFocusUpId);
        }
        continue; /* Loop/switch isn't completed */
_L5:
        if (mNextFocusDownId != -1)
        {
            glview1 = getContext().findViewById(mNextFocusDownId);
        }
        if (true) goto _L1; else goto _L6
_L6:
        if (mParent.getInternalFocus())
        {
            glview2 = getContext().findNextFocusFromView((GLViewGroup)getInternalFocusParent(), glview, i);
        } else
        {
            glview2 = getContext().findNextFocusFromView(null, glview, i);
        }
        if (glview2 != null)
        {
            glview2.requestFocus(i, null);
            return true;
        }
        return false;
    }

    public final void reset()
    {
        this;
        JVM INSTR monitorenter ;
        mLoaded = false;
        mLoading = false;
        if (mBackground != null)
        {
            mBackground.reset();
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.reset();
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.reset();
        }
        onReset();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public final void resetBaseDepth()
    {
        mZCoordinate = mOriginalDepth;
        updateLayout(true);
    }

    public final void resetBaseLayout()
    {
        float f = getWidth();
        float f1 = getHeight();
        mBound.left = mOriginalLeft;
        mBound.top = mOriginalTop;
        mBound.right = mBound.left + f;
        mBound.bottom = mBound.top + f1;
        updateLayout(false);
    }

    public void resetClipRect()
    {
        mManualClip = false;
        refreshClipRect();
    }

    public final void resetDepth()
    {
        mZCoordinate = mBaseDepth;
        updateLayout(true);
    }

    public void resetDrag()
    {
        mDragging = false;
        mGLContext.getMainHandler().removeCallbacks(setDragging);
    }

    public final void resetLayout()
    {
        float f = getWidth();
        float f1 = getHeight();
        mBound.left = mBaseLeft;
        mBound.top = mBaseTop;
        mBound.right = mBound.left + f;
        mBound.bottom = mBound.top + f1;
        updateLayout(false);
    }

    public void resetNextFocusId()
    {
        mNextFocusDownId = -1;
        mNextFocusUpId = -1;
        mNextFocusLeftId = -1;
        mNextFocusRightId = -1;
    }

    public final void resetScale()
    {
        mScaleChanged = false;
        android.opengl.Matrix.setIdentityM(mScaleMatrix, 0);
        combineMatrices();
        mScaleX = 1.0F;
        mScaleY = 1.0F;
    }

    public final void resetTransformMatrix()
    {
        this;
        JVM INSTR monitorenter ;
        float af[] = mRotationMatrix;
        if (af != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        android.opengl.Matrix.setIdentityM(mRotationMatrix, 0);
        android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
        android.opengl.Matrix.setIdentityM(mCombinedMatrix, 0);
        android.opengl.Matrix.setIdentityM(mScaleMatrix, 0);
        android.opengl.Matrix.setIdentityM(mTempMatrix, 0);
        android.opengl.Matrix.setIdentityM(mMatrix, 0);
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public final void resetTranslate()
    {
        if (mTranslateX == 0.0F && mTranslateY == 0.0F && mTranslateZ == 0.0F)
        {
            return;
        } else
        {
            android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
            combineMatrices();
            mTranslateX = 0.0F;
            mTranslateY = 0.0F;
            mTranslateZ = 0.0F;
            updateLayout(true);
            return;
        }
    }

    public void rotateDegree(int i)
    {
        this;
        JVM INSTR monitorenter ;
        mRotateDegree = i % 360;
        updateLayout(false);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public final void scale(float f, float f1)
    {
        if (mLeftTop == null)
        {
            return;
        } else
        {
            mLeftTop[0] = (getLeft() + getRight()) / 2.0F;
            mLeftTop[1] = (getTop() + getBottom()) / 2.0F;
            float af[] = new float[2];
            GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, mLeftTop[0], mLeftTop[1]);
            android.opengl.Matrix.translateM(mScaleMatrix, 0, af[0], af[1], 0.0F);
            android.opengl.Matrix.scaleM(mScaleMatrix, 0, f, f1, 1.0F);
            android.opengl.Matrix.translateM(mScaleMatrix, 0, -af[0], -af[1], 0.0F);
            mScaleX = mScaleX * f;
            mScaleY = mScaleY * f1;
            combineMatrices();
            return;
        }
    }

    public void sendAccessibilityEvent(int i)
    {
        if (mGLContext != null && mGLContext.isEnableAccessibilityNode())
        {
            AccessibilityEvent accessibilityevent = AccessibilityEvent.obtain(i);
            accessibilityevent.setSource(mGLContext.getGLSurfaceView(), mViewId);
            accessibilityevent.setClassName(getClass().getSimpleName());
            accessibilityevent.setPackageName(GLContext.getApplicationContext().getPackageName());
            if (getTitle() != null)
            {
                accessibilityevent.getText().add(getTitle());
            } else
            {
                accessibilityevent.getText().add(getObjectTag());
            }
            mGLContext.getGLSurfaceView().getParent().requestSendAccessibilityEvent(mGLContext.getGLSurfaceView(), accessibilityevent);
        }
    }

    public void setAlpha(float f)
    {
        if (!GLUtil.floatEquals(mAlpha, f))
        {
            mAlpha = f;
            mOldAlpha = f;
            updateAlpha();
        }
    }

    public final void setAnimation(Animation animation)
    {
        setAnimation(animation, false);
    }

    public final void setAnimation(Animation animation, boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        mHideAfterAnimation = flag;
        mAnimation = animation;
        this;
        JVM INSTR monitorexit ;
        return;
        animation;
        throw animation;
    }

    public void setAnimationEventListener(AnimationEventListener animationeventlistener)
    {
        mAnimationEventListener = animationeventlistener;
    }

    public void setAsyncLoad(boolean flag)
    {
        mAsyncLoad = flag;
    }

    public boolean setBackground(int i)
    {
        if (mBackgroundResId == i)
        {
            return false;
        }
        if (mBackground != null)
        {
            mBackground.clear();
            mBackground = null;
        }
        mBackgroundResId = i;
        mBackground = new GLResourceTexture(mGLContext, 0.0F, 0.0F, getWidth(), getHeight(), i);
        mBackground.mParent = this;
        return true;
    }

    public boolean setBackgroundAlpha(float f)
    {
        if (mBackground == null)
        {
            return false;
        } else
        {
            mBackground.setAlpha(f);
            return true;
        }
    }

    public void setBypassTouch(boolean flag)
    {
        mBypassTouch = flag;
    }

    public void setCenterPivot(boolean flag)
    {
        mCenterPivot = flag;
    }

    public void setClickListener(ClickListener clicklistener)
    {
        mClickListener = clicklistener;
    }

    public void setClickable(boolean flag)
    {
        int i = mViewFlags;
        char c;
        if (flag)
        {
            c = '\u4000';
        } else
        {
            c = '\0';
        }
        mViewFlags = c | i & 0xffffbfff;
    }

    public void setClipRect(Rect rect)
    {
        if (mManualClipRect == null)
        {
            mManualClipRect = new Rect(rect);
        } else
        {
            mManualClipRect.set(rect);
        }
        mManualClip = true;
    }

    public void setClipping(boolean flag)
    {
        mClipping = flag;
        if (mClipping)
        {
            refreshClipRect();
        }
    }

    public void setContentDescription(String s)
    {
        mContentDescription = s;
    }

    public final void setContinuousDrawMode(boolean flag)
    {
        mContinuousDrawMode = flag;
    }

    public final void setDefaultOrientation(int i)
    {
        mDefaultOrientation = i;
        updateRotationMatrix();
        mGLContext.setDirty(true);
    }

    public void setDim(boolean flag)
    {
        if (mDimmed != flag)
        {
            mDimmed = flag;
            mGLContext.setDirty(true);
        }
    }

    public void setDragListener(DragListener draglistener)
    {
        mDragListener = draglistener;
    }

    public void setDragSensitivity(int i)
    {
        if (i != 0 && i != 1 && i != 2)
        {
            throw new IllegalArgumentException();
        } else
        {
            mDragSensitivity = i;
            return;
        }
    }

    public void setDraggable(boolean flag)
    {
        mDraggable = flag;
    }

    public void setFocusListener(FocusListener focuslistener)
    {
        mFocusListener = focuslistener;
    }

    public void setFocusable(boolean flag)
    {
        int i = mViewFlags;
        boolean flag1;
        if (flag)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        mViewFlags = flag1 | i & -2;
    }

    public void setForcedClipping(boolean flag)
    {
        mForcedClipping = flag;
    }

    public void setHeight(float f)
    {
        if (!mSizeSpecified)
        {
            return;
        }
        mBound.bottom = mBound.top + f;
        if (mBackground != null)
        {
            mBackground.setHeight(f);
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.setHeight(f - (float)mPaddings.top - (float)mPaddings.bottom);
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.setHeight(f - (float)mPaddings.top - (float)mPaddings.bottom);
        }
        updateLayout(false);
    }

    public void setInternalFocus(boolean flag)
    {
        mInternalFocus = flag;
    }

    public void setKeyListener(KeyListener keylistener)
    {
        mKeyListener = keylistener;
    }

    public final void setLeftTop(int i, float f, float f1)
    {
        if (i > 3 || i < 0)
        {
            throw new IllegalArgumentException();
        }
        if (mLeftTopCoordinates != null)
        {
            mLeftTopCoordinates[i].left = f;
            mLeftTopCoordinates[i].top = f1;
        }
    }

    public final void setLeftTop(int i, float f, float f1, boolean flag)
    {
        if (i > 3 || i < 0)
        {
            throw new IllegalArgumentException();
        }
        if (mLeftTopCoordinates != null)
        {
            mLeftTopCoordinates[i].left = f;
            mLeftTopCoordinates[i].top = f1;
        }
        if (flag)
        {
            setRotatable(true);
            updateLayout(true);
        }
    }

    public final void setLeftTop(int i, float af[])
    {
        if (i > 3 || i < 0)
        {
            throw new IllegalArgumentException();
        } else
        {
            mLeftTopCoordinates[i].left = af[0];
            mLeftTopCoordinates[i].top = af[1];
            return;
        }
    }

    public void setLoadListener(LoadListener loadlistener)
    {
        mLoadListener = loadlistener;
    }

    public void setLongClickListener(LongClickListener longclicklistener)
    {
        mLongClickable = true;
        mLongClickListener = longclicklistener;
    }

    public void setLongClickable(boolean flag)
    {
        mLongClickable = flag;
    }

    public void setNextFocusDownId(int i)
    {
        mNextFocusDownId = i;
    }

    public boolean setNextFocusDownView(GLView glview)
    {
        if (glview != null)
        {
            mNextFocusDownId = glview.getId();
            return true;
        } else
        {
            return false;
        }
    }

    public void setNextFocusForwardId(int i)
    {
        mNextFocusForwardId = i;
    }

    public void setNextFocusLeftId(int i)
    {
        mNextFocusLeftId = i;
    }

    public boolean setNextFocusLeftView(GLView glview)
    {
        if (glview != null)
        {
            mNextFocusLeftId = glview.getId();
            return true;
        } else
        {
            return false;
        }
    }

    public void setNextFocusRightId(int i)
    {
        mNextFocusRightId = i;
    }

    public boolean setNextFocusRightView(GLView glview)
    {
        if (glview != null)
        {
            mNextFocusRightId = glview.getId();
            return true;
        } else
        {
            return false;
        }
    }

    public void setNextFocusUpId(int i)
    {
        mNextFocusUpId = i;
    }

    public boolean setNextFocusUpView(GLView glview)
    {
        if (glview != null)
        {
            mNextFocusUpId = glview.getId();
            return true;
        } else
        {
            return false;
        }
    }

    public boolean setNinePatchBackground(int i)
    {
        if (mBackgroundResId == i)
        {
            return false;
        }
        if (mBackground != null)
        {
            mBackground.clear();
            mBackground = null;
        }
        mBackgroundResId = i;
        mBackground = new GLNinePatch(mGLContext, 0.0F, 0.0F, getWidth(), getHeight(), i);
        mBackground.mParent = this;
        setPaddings(mBackground.getPaddings());
        return true;
    }

    public boolean setNinePatchBackground(int i, float f)
    {
        if (mBackgroundResId == i)
        {
            return false;
        }
        if (mBackground != null)
        {
            mBackground.clear();
            mBackground = null;
        }
        mBackgroundResId = i;
        mBackground = new GLNinePatch(mGLContext, 0.0F, 0.0F, getWidth(), getHeight(), i, f);
        mBackground.mParent = this;
        setPaddings(mBackground.getPaddings());
        return true;
    }

    public final void setObjectTag(String s)
    {
        mObjectTag = s;
    }

    public final void setOrientation(int i)
    {
        this;
        JVM INSTR monitorenter ;
        if (i == 0 || i == 1 || i == 2 || i == 3)
        {
            break MISSING_BLOCK_LABEL_34;
        }
        throw new IllegalArgumentException();
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        float af[] = mRotationMatrix;
        if (af != null)
        {
            break MISSING_BLOCK_LABEL_46;
        }
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        mLastOrientation = mOrientation;
        mOrientation = i;
        updateRotationMatrix();
        if (mOrientationChangeListener != null)
        {
            mOrientationChangeListener.onOrientationChanged(mOrientation);
        }
        mGLContext.setDirty(true);
          goto _L1
    }

    public void setOrientationChangeListener(OrientationChangeListener orientationchangelistener)
    {
        mOrientationChangeListener = orientationchangelistener;
    }

    public void setPaddings(Rect rect)
    {
        mPaddings = rect;
        if (mFocusIndicator != null)
        {
            mFocusIndicator.setSize(getWidth() - (float)mPaddings.left - (float)mPaddings.right, getHeight() - (float)mPaddings.top - (float)mPaddings.bottom);
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.setSize(getWidth() - (float)mPaddings.left - (float)mPaddings.right, getHeight() - (float)mPaddings.top - (float)mPaddings.bottom);
        }
    }

    public final void setParentHAlign(int i)
    {
        mParentHAlign = i;
    }

    public void setParentId(int i)
    {
        mParentViewId = i;
    }

    public final void setParentVAlign(int i)
    {
        mParentVAlign = i;
    }

    public void setRepeatClickInterval(int i)
    {
        mRepeatClickInterval = i;
    }

    public void setRepeatClickWhenLongClicked(boolean flag)
    {
        if (flag)
        {
            mLongClickable = flag;
        }
        mRepeatClickWhenLongClicked = flag;
    }

    public void setRotatable(boolean flag)
    {
        mRotatable = flag;
    }

    public void setRotateAnimation(boolean flag)
    {
        mRotateAnimation = flag;
    }

    public void setRotateAnimationDuration(int i)
    {
        mRotateAnimationDuration = i;
    }

    public void setRotateAnimationInterpolator(Interpolator interpolator)
    {
        if (interpolator != null)
        {
            mRotateAnimationInterpolator = interpolator;
        }
    }

    public void setShaderParameter(float f)
    {
        mShaderParameter = f;
    }

    public void setShaderProgram(int i)
    {
    }

    public void setShaderStep(float f)
    {
        mShaderStep = f;
    }

    public void setSize(float f, float f1)
    {
        mBound.right = mBound.left + f;
        mBound.bottom = mBound.top + f1;
        mSizeSpecified = true;
        mSizeGiven = true;
        if (mBackground != null)
        {
            mBackground.setSize(f, f1);
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.setSize(f - (float)mPaddings.right - (float)mPaddings.left, f1 - (float)mPaddings.bottom - (float)mPaddings.top);
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.setSize(f - (float)mPaddings.right - (float)mPaddings.left, f1 - (float)mPaddings.bottom - (float)mPaddings.top);
        }
        updateLayout(false);
    }

    public void setSubTitle(String s)
    {
        mSubTitle = s;
    }

    public final void setTag(int i)
    {
        mViewTag = i;
    }

    public void setTint(int i)
    {
        mTintColor[0] = (float)Color.red(i) / 255F;
        mTintColor[1] = (float)Color.green(i) / 255F;
        mTintColor[2] = (float)Color.blue(i) / 255F;
        mTintColor[3] = (float)Color.alpha(i) / 255F;
    }

    public void setTitle(String s)
    {
        mTitle = s;
    }

    public void setTouchListener(TouchListener touchlistener)
    {
        mTouchListener = touchlistener;
    }

    public void setVisibility(int i)
    {
        if (mVisibility != i)
        {
            mVisibility = i;
            if (mGLContext != null)
            {
                mGLContext.setDirty(true);
            }
            onVisibilityChanged(i);
        }
    }

    public void setVisibility(int i, boolean flag)
    {
        if (mVisibility == i)
        {
            return;
        }
        mVisibility = i;
        if (flag && mGLContext != null)
        {
            mGLContext.setDirty(true);
        }
        onVisibilityChanged(i);
    }

    public void setWidth(float f)
    {
        if (!mSizeSpecified)
        {
            return;
        }
        mBound.right = mBound.left + f;
        if (mBackground != null)
        {
            mBackground.setWidth(f);
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.setWidth(f - (float)mPaddings.right - (float)mPaddings.left);
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.setWidth(f - (float)mPaddings.right - (float)mPaddings.left);
        }
        updateLayout(false);
    }

    public final void startAnimation()
    {
        if (mAnimation == null)
        {
            return;
        }
        if (mLoaded)
        {
            mAnimation.reset();
            mAnimationPending = false;
            mAnimationStarted = true;
        } else
        {
            mAnimationPending = true;
            mAnimationStarted = false;
        }
        mAnimationFinished = false;
        mGLContext.setDirty(true);
    }

    public boolean touchEvent(MotionEvent motionevent)
    {
        mDragSensitivity;
        JVM INSTR tableswitch 0 1: default 28
    //                   0 161
    //                   1 166;
           goto _L1 _L2 _L3
_L1:
        int i = 500;
_L14:
        if (motionevent.getAction() != 0) goto _L5; else goto _L4
_L4:
        mIsTouchCanceled = false;
        mPreviousDragX = motionevent.getX();
        mPreviousDragY = motionevent.getY();
        resetDrag();
        if (mDraggable)
        {
            mTempOrientation = getOrientation();
            if (mDragSensitivity == 0)
            {
                setDragging.run();
            } else
            {
                mGLContext.getMainHandler().postDelayed(setDragging, i);
            }
        }
        if (mLongClickable)
        {
            mGLContext.getMainHandler().postDelayed(setLongClick, 500L);
        }
_L12:
        if (mTouchListener != null && mTouchListener.onTouch(this, motionevent))
        {
            if (mDraggable && !mDragging)
            {
                resetDrag();
            }
            return true;
        }
        break; /* Loop/switch isn't completed */
_L2:
        i = 0;
        continue; /* Loop/switch isn't completed */
_L3:
        i = 300;
        continue; /* Loop/switch isn't completed */
_L5:
        if (motionevent.getAction() == 2)
        {
            if (mDraggable)
            {
                if (mDragging)
                {
                    if (mTempOrientation != getOrientation())
                    {
                        if (mDragListener != null)
                        {
                            mDragListener.onDragEnd(this, motionevent.getX(), motionevent.getY());
                        }
                        motionevent.setAction(3);
                        resetDrag();
                        return true;
                    }
                    if (mDragListener != null)
                    {
                        mDragListener.onDrag(this, motionevent.getX(), motionevent.getY(), motionevent.getX() - mPreviousDragX, motionevent.getY() - mPreviousDragY);
                    }
                    mPreviousDragX = motionevent.getX();
                    mPreviousDragY = motionevent.getY();
                    if (i != 0)
                    {
                        return true;
                    }
                } else
                if (!contains(motionevent.getX(), motionevent.getY()))
                {
                    resetDrag();
                } else
                {
                    mPreviousDragX = motionevent.getX();
                    mPreviousDragY = motionevent.getY();
                }
            } else
            if (!contains(motionevent.getX(), motionevent.getY()) && mLongClickable)
            {
                mGLContext.getMainHandler().removeCallbacks(setLongClick);
                if (mRepeatClickWhenLongClicked)
                {
                    mGLContext.getMainHandler().removeCallbacks(repeatClick);
                }
            }
            continue; /* Loop/switch isn't completed */
        }
        if (motionevent.getAction() != 1) goto _L7; else goto _L6
_L6:
        if (!mDraggable) goto _L9; else goto _L8
_L8:
        if (mDragging)
        {
            if (mDragListener != null)
            {
                mDragListener.onDragEnd(this, motionevent.getX(), motionevent.getY());
            }
            motionevent.setAction(3);
        }
        resetDrag();
_L10:
        if (mLongClickable)
        {
            mGLContext.getMainHandler().removeCallbacks(setLongClick);
            if (mRepeatClickWhenLongClicked)
            {
                mGLContext.getMainHandler().removeCallbacks(repeatClick);
            }
        }
        sendAccessibilityEvent(1);
        continue; /* Loop/switch isn't completed */
_L9:
        if (!contains(motionevent.getX(), motionevent.getY()))
        {
            motionevent.setAction(3);
        }
        if (true) goto _L10; else goto _L7
_L7:
        if (motionevent.getAction() == 3)
        {
            if (mDraggable)
            {
                if (mDragging && mDragListener != null)
                {
                    mDragListener.onDragEnd(this, motionevent.getX(), motionevent.getY());
                }
                resetDrag();
            }
            if (mLongClickable)
            {
                mGLContext.getMainHandler().removeCallbacks(setLongClick);
                if (mRepeatClickWhenLongClicked)
                {
                    mGLContext.getMainHandler().removeCallbacks(repeatClick);
                }
            }
        }
        if (true) goto _L12; else goto _L11
_L11:
        if (motionevent.getAction() == 1 && !contains(motionevent.getX(), motionevent.getY()))
        {
            motionevent.setAction(3);
        }
        if (motionevent.getAction() == 3)
        {
            if (mIsTouchCanceled)
            {
                return true;
            }
            mIsTouchCanceled = true;
        }
        return onTouchEvent(motionevent);
        if (true) goto _L14; else goto _L13
_L13:
    }

    public final void translate(float f, float f1)
    {
        if (f == 0.0F && f1 == 0.0F)
        {
            return;
        }
        float f3 = f;
        float f2 = f1;
        if (getContext().getAlignToPixel())
        {
            f3 = (float)(int)(mTranslateX + f + 0.5F) - (float)(int)(mTranslateX + 0.5F);
            f2 = (float)(int)(mTranslateY + f1 + 0.5F) - (float)(int)(mTranslateY + 0.5F);
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f3), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f2), 0.0F);
        combineMatrices();
        updateLayout(false);
        mTranslateX = mTranslateX + f;
        mTranslateY = mTranslateY + f1;
    }

    public final void translate(float f, float f1, float f2)
    {
        if (f == 0.0F && f1 == 0.0F)
        {
            return;
        }
        float f4 = f;
        float f3 = f1;
        if (getContext().getAlignToPixel())
        {
            f4 = (float)(int)(mTranslateX + f + 0.5F) - (float)(int)(mTranslateX + 0.5F);
            f3 = (float)(int)(mTranslateY + f1 + 0.5F) - (float)(int)(mTranslateY + 0.5F);
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, f4, f3, f2);
        combineMatrices();
        if (f2 != 0.0F)
        {
            updateLayout(true);
        } else
        {
            updateLayout(false);
        }
        mTranslateX = mTranslateX + f;
        mTranslateY = mTranslateY + f1;
        mTranslateZ = mTranslateZ + f2;
    }

    public final void translate(float f, float f1, float f2, boolean flag)
    {
        if (f == 0.0F && f1 == 0.0F && f2 == 0.0F)
        {
            return;
        }
        float f4 = f;
        float f3 = f1;
        if (getContext().getAlignToPixel())
        {
            f4 = (float)(int)(mTranslateX + f + 0.5F) - (float)(int)(mTranslateX + 0.5F);
            f3 = (float)(int)(mTranslateY + f1 + 0.5F) - (float)(int)(mTranslateY + 0.5F);
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, f4, f3, f2);
        combineMatrices();
        if (flag)
        {
            if (f2 != 0.0F)
            {
                updateLayout(true);
            } else
            {
                updateLayout(false);
            }
        }
        mTranslateX = mTranslateX + f;
        mTranslateY = mTranslateY + f1;
        mTranslateZ = mTranslateZ + f2;
    }

    public final void translate(float f, float f1, boolean flag)
    {
        if (f == 0.0F && f1 == 0.0F)
        {
            return;
        }
        float f3 = f;
        float f2 = f1;
        if (getContext().getAlignToPixel())
        {
            f3 = (float)(int)(mTranslateX + f + 0.5F) - (float)(int)(mTranslateX + 0.5F);
            f2 = (float)(int)(mTranslateY + f1 + 0.5F) - (float)(int)(mTranslateY + 0.5F);
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f3), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f2), 0.0F);
        combineMatrices();
        if (flag)
        {
            updateLayout(false);
        }
        mTranslateX = mTranslateX + f;
        mTranslateY = mTranslateY + f1;
    }

    public final void translateAbsolute(float f, float f1)
    {
        if (GLUtil.floatEquals(mTranslateX, f) && GLUtil.floatEquals(mTranslateY, f1))
        {
            return;
        }
        float f5 = f;
        float f4 = f1;
        android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
        combineMatrices();
        float f2 = f5;
        float f3 = f4;
        if (getContext().getAlignToPixel())
        {
            if (f5 >= 0.0F)
            {
                f2 = (int)(f + 0.5F);
            } else
            {
                f2 = (int)(f - 0.5F);
            }
            if (f4 >= 0.0F)
            {
                f3 = (int)(f1 + 0.5F);
            } else
            {
                f3 = (int)(f1 - 0.5F);
            }
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f2), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f3), 0.0F);
        combineMatrices();
        updateLayout(false);
        mTranslateX = f;
        mTranslateY = f1;
    }

    public final void translateAbsolute(float f, float f1, float f2)
    {
        if (GLUtil.floatEquals(mTranslateX, f) && GLUtil.floatEquals(mTranslateY, f1) && GLUtil.floatEquals(mTranslateZ, f2))
        {
            return;
        }
        float f6 = f;
        float f5 = f1;
        android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
        combineMatrices();
        float f3 = f6;
        float f4 = f5;
        if (getContext().getAlignToPixel())
        {
            if (f6 >= 0.0F)
            {
                f3 = (int)(f + 0.5F);
            } else
            {
                f3 = (int)(f - 0.5F);
            }
            if (f5 >= 0.0F)
            {
                f4 = (int)(f1 + 0.5F);
            } else
            {
                f4 = (int)(f1 - 0.5F);
            }
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f3), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f4), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f2));
        combineMatrices();
        if (!GLUtil.floatEquals(mTranslateZ, f2))
        {
            updateLayout(true);
        } else
        {
            updateLayout(false);
        }
        mTranslateX = f;
        mTranslateY = f1;
        mTranslateZ = f2;
    }

    public final void translateAbsolute(float f, float f1, float f2, boolean flag)
    {
        if (GLUtil.floatEquals(mTranslateX, f) && GLUtil.floatEquals(mTranslateY, f1) && GLUtil.floatEquals(mTranslateZ, f2))
        {
            return;
        }
        float f6 = f;
        float f5 = f1;
        android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
        combineMatrices();
        float f3 = f6;
        float f4 = f5;
        if (getContext().getAlignToPixel())
        {
            if (f6 >= 0.0F)
            {
                f3 = (int)(f + 0.5F);
            } else
            {
                f3 = (int)(f - 0.5F);
            }
            if (f5 >= 0.0F)
            {
                f4 = (int)(f1 + 0.5F);
            } else
            {
                f4 = (int)(f1 - 0.5F);
            }
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f3), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f4), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f2));
        combineMatrices();
        if (flag)
        {
            if (!GLUtil.floatEquals(mTranslateZ, f2))
            {
                updateLayout(true);
            } else
            {
                updateLayout(false);
            }
        }
        mTranslateX = f;
        mTranslateY = f1;
        mTranslateZ = f2;
    }

    public final void translateAbsolute(float f, float f1, boolean flag)
    {
        if (GLUtil.floatEquals(mTranslateX, f) && GLUtil.floatEquals(mTranslateY, f1))
        {
            return;
        }
        float f5 = f;
        float f4 = f1;
        android.opengl.Matrix.setIdentityM(mTranslationMatrix, 0);
        combineMatrices();
        float f2 = f5;
        float f3 = f4;
        if (getContext().getAlignToPixel())
        {
            if (f5 >= 0.0F)
            {
                f2 = (int)(f + 0.5F);
            } else
            {
                f2 = (int)(f - 0.5F);
            }
            if (f4 >= 0.0F)
            {
                f3 = (int)(f1 + 0.5F);
            } else
            {
                f3 = (int)(f1 - 0.5F);
            }
        }
        android.opengl.Matrix.translateM(mTranslationMatrix, 0, GLUtil.getGLDistanceFromScreenDistanceX(mGLContext, f2), GLUtil.getGLDistanceFromScreenDistanceY(mGLContext, f3), 0.0F);
        combineMatrices();
        if (flag)
        {
            updateLayout(false);
        }
        mTranslateX = f;
        mTranslateY = f1;
    }

    public void updateAlpha()
    {
        mGLContext.setDirty(true);
        onAlphaUpdated();
        if (mBackground != null)
        {
            mBackground.onAlphaUpdated();
        }
    }

    public void updateLayout(boolean flag)
    {
        mLayoutUpdated = true;
        onLayoutUpdated();
        if (mBackground != null)
        {
            mBackground.onLayoutUpdated();
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.onLayoutUpdated();
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.onLayoutUpdated();
        }
        if (flag && mParent != null)
        {
            mParent.onDepthUpdated();
        }
        mGLContext.setDirty(true);
        if (mRotatable)
        {
            updateRotationMatrix();
        }
        if (mScaleChanged)
        {
            updateScaleMatrix();
        }
    }

    public final void updateRotationMatrix()
    {
        this;
        JVM INSTR monitorenter ;
        float af[];
        float af1[];
        float af2[];
        android.opengl.Matrix.setIdentityM(mRotationMatrix, 0);
        af = new float[2];
        af1 = new float[2];
        af2 = getLeftTop((mOrientation + mDefaultOrientation) % 4);
        if (!mCenterPivot)
        {
            break MISSING_BLOCK_LABEL_156;
        }
        af2[0] = (getLeft() + getRight()) / 2.0F;
        af2[1] = (getTop() + getBottom()) / 2.0F;
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, af2[0], af2[1]);
        android.opengl.Matrix.translateM(mRotationMatrix, 0, af[0], af[1], 0.0F);
        android.opengl.Matrix.rotateM(mRotationMatrix, 0, -((mOrientation + mDefaultOrientation) % 4) * 90 - getRotateDegree(), 0.0F, 0.0F, -1F);
        android.opengl.Matrix.translateM(mRotationMatrix, 0, -af[0], -af[1], 0.0F);
_L1:
        combineMatrices();
        this;
        JVM INSTR monitorexit ;
        return;
        if (mParent != null)
        {
            af2[0] = af2[0] + mParent.getLeft();
            af2[1] = af2[1] + mParent.getTop();
        }
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, getLeft(), getTop());
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af1, af2[0], af2[1]);
        android.opengl.Matrix.translateM(mRotationMatrix, 0, af1[0], af1[1], 0.0F);
        android.opengl.Matrix.rotateM(mRotationMatrix, 0, -((mOrientation + mDefaultOrientation) % 4) * 90 - getRotateDegree(), 0.0F, 0.0F, -1F);
        android.opengl.Matrix.translateM(mRotationMatrix, 0, -af[0], -af[1], 0.0F);
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    public final void updateScaleMatrix()
    {
        mScaleChanged = true;
        float af[] = new float[2];
        mLeftTop[0] = (getLeft() + getRight()) / 2.0F;
        mLeftTop[1] = (getTop() + getBottom()) / 2.0F;
        GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, mLeftTop[0], mLeftTop[1]);
        android.opengl.Matrix.translateM(mScaleMatrix, 0, af[0], af[1], 0.0F);
        android.opengl.Matrix.scaleM(mScaleMatrix, 0, mScaleX, mScaleY, 1.0F);
        android.opengl.Matrix.translateM(mScaleMatrix, 0, -af[0], -af[1], 0.0F);
        combineMatrices();
    }

    protected void updateSize(float f, float f1)
    {
        mBound.right = mBound.left + f;
        mBound.bottom = mBound.top + f1;
        mSizeSpecified = true;
        if (mBackground != null)
        {
            mBackground.updateSize(f, f1);
        }
        if (mFocusIndicator != null)
        {
            mFocusIndicator.updateSize(f - (float)mPaddings.right - (float)mPaddings.left, f1 - (float)mPaddings.bottom - (float)mPaddings.top);
        }
        if (mHoverIndicator != null)
        {
            mHoverIndicator.updateSize(f - (float)mPaddings.right - (float)mPaddings.left, f1 - (float)mPaddings.bottom - (float)mPaddings.top);
        }
        updateLayout(false);
    }








}
