// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            GLButton, GLContext

class this._cls0
    implements Runnable
{

    final GLButton this$0;

    public void run()
    {
        setButtonPressed(false);
        getContext().setDirty(true);
    }

    ()
    {
        this$0 = GLButton.this;
        super();
    }
}
