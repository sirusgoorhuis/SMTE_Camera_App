// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Rect;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLViewGroup, GLView, GLUtil, GLContext

public class GLTitleDecorator extends GLViewGroup
{

    private GLView mTitleView;

    public GLTitleDecorator(GLContext glcontext)
    {
        super(glcontext);
        mTitleView = null;
    }

    public GLTitleDecorator(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        super(glcontext, f, f1, f2, f3);
        mTitleView = null;
    }

    public void addView(GLView glview)
    {
        if (glview == null)
        {
            throw new IllegalArgumentException();
        }
        Rect rect = getPaddings();
        Rect rect1 = new Rect(0, 0, 0, 0);
        if (glview.getLeft() == 0.0F)
        {
            rect1.left = rect.left;
        }
        if (glview.getTop() == 0.0F)
        {
            rect1.top = rect.top;
        }
        if (GLUtil.floatEquals(glview.getRight(), getRight() - getLeft()))
        {
            rect1.right = rect.right;
        }
        if (GLUtil.floatEquals(glview.getBottom(), getBottom() - getTop()))
        {
            rect1.bottom = rect.bottom;
        }
        glview.setPaddings(rect1);
        super.addView(glview);
        if (getHeight() > glview.getHeight())
        {
            setHeight(glview.getHeight() + mTitleView.getHeight() + mTitleView.getLayoutY() + (float)getPaddings().bottom);
        }
    }

    public float getContentAreaHeight()
    {
        if (mTitleView == null)
        {
            return getHeight() - (float)getPaddings().top - (float)getPaddings().bottom;
        } else
        {
            return getHeight() - mTitleView.getHeight() - (float)getPaddings().top - (float)getPaddings().bottom;
        }
    }

    public void setDragListener(GLView.DragListener draglistener)
    {
        mTitleView.setDragListener(draglistener);
    }

    public void setTitle(GLView glview)
    {
        if (glview == null)
        {
            throw new IllegalArgumentException();
        } else
        {
            glview.mParent = this;
            mGLViews.add(glview);
            mTitleView = glview;
            return;
        }
    }
}
