// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.animation.Animation;
import com.samsung.android.util.SemLog;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLViewGroup, GLContext, GLView, GLImage, 
//            GLNinePatch, GLUtil

public abstract class GLAbsList extends GLViewGroup
    implements GLView.TouchListener, GLView.KeyListener, GLView.DragListener, GLView.FocusListener
{
    public static interface Adapter
    {

        public abstract int getCount();

        public abstract GLView getView(int i, GLView glview);

        public abstract void reset();
    }

    public static interface ItemSelectListener
    {

        public abstract void onItemSelected(GLView glview, int i);
    }

    private static class MainHandler extends Handler
    {

        private final WeakReference mList;

        public void handleMessage(Message message)
        {
            GLAbsList glabslist;
            glabslist = (GLAbsList)mList.get();
            if (glabslist == null)
            {
                return;
            }
            switch (message.what)
            {
            default:
                return;

            case 1: // '\001'
                glabslist.hideScrollBar();
                return;

            case 2: // '\002'
                message = mList;
                break;
            }
            message;
            JVM INSTR monitorenter ;
            glabslist.enableBoundDeceleration(true);
            glabslist.mIsDecelerationHandlerMessageExecuted = true;
            message;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            message;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public MainHandler(GLAbsList glabslist)
        {
            mList = new WeakReference(glabslist);
        }
    }

    public static interface ScrollListener
    {

        public abstract void onScrollEnd();

        public abstract void onScrollStart();
    }


    private static final float BOUNCE_DECELERATION_POSITION_DIVIDE_FACTOR = 1F;
    private static final float BOUNCE_SMOOTH_LANDING_FACTOR = 0.5F;
    private static final float BOUNCING_DECELERATION_DIP = 30F;
    private static final int DEFAULT_OVER_SCROLL_START_OFFSET_DIP = -2;
    private static final int DEFAULT_SCROLLBAR_PADDING_DIP = 1;
    private static final float DEFAULT_SCROLL_THRESHOLD_DIP = 10F;
    private static final float DRAG_ATTENUATION_RATE_FACTOR = 0.2F;
    private static final float DRAG_OUT_DISTANCE_LIMIT_DIP = 25F;
    private static final int ENABLE_DECELERATION_TIMEOUT = 500;
    private static final float FLING_DECELERATION_DIP = 40F;
    private static final int MESSAGE_ENABLE_DECELERATION = 2;
    private static final int MESSAGE_HIDE_SCROLLBAR = 1;
    private static final int SCROLLBAR_ID = 0xfffff;
    private static final int SCROLLBAR_TIMEOUT = 1000;
    public static final int SCROLL_LANDSCAPE = 2;
    public static final int SCROLL_PORTRAIT = 1;
    private static final String TAG = "GLAbsList";
    private static final float VELOCITY_MODERATION_RATIO = 0.01F;
    private static final float VELOCITY_REVISE_THRESHOLD_DIP = 5F;
    protected Adapter mAdapter;
    private GLImage mBounceImageBottom;
    private GLImage mBounceImageTop;
    private boolean mBouncing;
    private final float mBouncingDeceleration;
    protected float mContentHeight;
    protected float mContentWidth;
    private float mDownEventX;
    private float mDownEventY;
    private final float mDragOutDistanceLimit;
    private boolean mEnableBounceDeceleration;
    private boolean mEnableOverScrollEffect;
    private int mFirstFullyVisibleViewIndex;
    private final float mFlingDeceleration;
    private float mFlingVelocityX;
    private float mFlingVelocityY;
    private boolean mIsDecelerationHandlerMessageExecuted;
    private float mLandscapeBounceMaxOffset;
    private float mLandscapeBounceOffset;
    private float mLastEventX;
    private float mLastEventY;
    private int mLastFullyVisibleViewIndex;
    private float mListHeight;
    private float mListVisibleHeight;
    private float mListVisibleWidth;
    private float mListWidth;
    protected Handler mMainHandler;
    private float mOverScrollStartOffset;
    private float mPortraitBounceMaxOffset;
    private float mPortraitBounceOffset;
    protected GLNinePatch mScrollBar;
    private float mScrollBarAlpha;
    private boolean mScrollBarAutoHide;
    private float mScrollBarOffset;
    private float mScrollBarPadding;
    private float mScrollBarSize;
    private boolean mScrollBarVisible;
    private ScrollListener mScrollListener;
    protected int mScrollOrientation;
    private boolean mScrollRequested;
    protected float mScrollSumX;
    protected float mScrollSumY;
    private float mScrollThreshold;
    private GLView mScrollToVisibleView;
    private boolean mScrolling;
    private final float mVelocityReviseThreshold;

    public GLAbsList(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        super(glcontext, f, f1, f2, f3);
        mScrollOrientation = 1;
        mScrollSumX = 0.0F;
        mScrollSumY = 0.0F;
        mContentWidth = 0.0F;
        mContentHeight = 0.0F;
        mMainHandler = new MainHandler(this);
        mBouncing = false;
        mScrolling = false;
        mScrollThreshold = 10F;
        mLastEventX = 0.0F;
        mLastEventY = 0.0F;
        mDownEventX = 0.0F;
        mDownEventY = 0.0F;
        mListWidth = 0.0F;
        mListHeight = 0.0F;
        mPortraitBounceOffset = 0.0F;
        mLandscapeBounceOffset = 0.0F;
        mPortraitBounceMaxOffset = 0.0F;
        mLandscapeBounceMaxOffset = 0.0F;
        mScrollBarVisible = false;
        mScrollBarSize = 0.0F;
        mScrollBarOffset = 0.0F;
        mListVisibleWidth = 0.0F;
        mListVisibleHeight = 0.0F;
        mFlingVelocityX = 0.0F;
        mFlingVelocityY = 0.0F;
        mScrollRequested = false;
        mFirstFullyVisibleViewIndex = 0;
        mLastFullyVisibleViewIndex = 0;
        mScrollBarAutoHide = true;
        mScrollBarAlpha = 1.0F;
        mEnableOverScrollEffect = true;
        mEnableBounceDeceleration = true;
        mIsDecelerationHandlerMessageExecuted = false;
        mListWidth = f2;
        mListHeight = f3;
        mScrollThreshold = glcontext.getDensity() * 10F;
        mFlingDeceleration = glcontext.getDensity() * 40F;
        mBouncingDeceleration = glcontext.getDensity() * 30F;
        mVelocityReviseThreshold = glcontext.getDensity() * 5F;
        mDragOutDistanceLimit = glcontext.getDensity() * 25F;
        mScrollBarPadding = glcontext.getDensity() * 1.0F;
        mOverScrollStartOffset = glcontext.getDensity() * -2F;
    }

    private void enableBoundDeceleration(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        mEnableBounceDeceleration = flag;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void addView(GLView glview)
    {
        if (glview instanceof GLAbsList)
        {
            throw new IllegalArgumentException();
        }
        Rect rect = getPaddings();
        Rect rect1 = new Rect(0, 0, 0, 0);
        if (mScrollOrientation != 2)
        {
            if (glview.getLeft() - getLeft() < (float)rect.left && glview.getLeft() >= getLeft())
            {
                rect1.left = (int)((float)rect.left - (glview.getLeft() - getLeft()));
            } else
            {
                rect1.left = glview.getPaddings().left;
            }
            if (getRight() - glview.getRight() < (float)rect.right && getRight() >= glview.getRight())
            {
                rect1.right = (int)((float)rect.right - (getRight() - glview.getRight()));
            } else
            {
                rect1.right = glview.getPaddings().right;
            }
            rect1.top = glview.getPaddings().top;
            rect1.bottom = glview.getPaddings().bottom;
        }
        if (mScrollOrientation != 1)
        {
            if (glview.getTop() - getTop() < (float)rect.top && glview.getTop() >= getTop())
            {
                rect1.top = (int)((float)rect.top - (glview.getTop() - getTop()));
            } else
            {
                rect1.top = glview.getPaddings().top;
            }
            if (getBottom() - glview.getBottom() < (float)rect.bottom && getBottom() >= glview.getBottom())
            {
                rect1.bottom = (int)((float)rect.bottom - (getBottom() - glview.getBottom()));
            } else
            {
                rect1.bottom = glview.getPaddings().bottom;
            }
            rect1.left = glview.getPaddings().left;
            rect1.right = glview.getPaddings().right;
        }
        glview.setPaddings(rect1);
        super.addView(glview);
    }

    protected boolean checkBoundary()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag1 = false;
        boolean flag = isScrollable();
        if (flag) goto _L2; else goto _L1
_L1:
        flag = false;
_L4:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        if ((mScrollOrientation & 1) != 1)
        {
            break MISSING_BLOCK_LABEL_308;
        }
        if (mScrollSumY > 0.0F)
        {
            if (mBounceImageBottom != null)
            {
                mBounceImageBottom.setSize(getWidth(), 0.0F);
            }
            mPortraitBounceOffset = mScrollSumY;
            if (mPortraitBounceMaxOffset < mPortraitBounceOffset)
            {
                if (mPortraitBounceMaxOffset == 0.0F && mFlingVelocityY > mVelocityReviseThreshold)
                {
                    mFlingVelocityY = mVelocityReviseThreshold + mFlingVelocityY * 0.01F;
                    mScrollSumY = mOverScrollStartOffset;
                    mPortraitBounceOffset = mScrollSumY;
                }
                mPortraitBounceMaxOffset = mPortraitBounceOffset;
            }
            break MISSING_BLOCK_LABEL_594;
        }
        if (mContentHeight + mScrollSumY < getContentAreaHeight())
        {
            if (mBounceImageTop != null)
            {
                mBounceImageTop.setSize(getWidth(), 0.0F);
            }
            mPortraitBounceOffset = getContentAreaHeight() - (mContentHeight + mScrollSumY);
            if (mPortraitBounceMaxOffset < mPortraitBounceOffset)
            {
                if (mPortraitBounceMaxOffset == 0.0F && Math.abs(mFlingVelocityY) > mVelocityReviseThreshold)
                {
                    mFlingVelocityY = -(mVelocityReviseThreshold + Math.abs(mFlingVelocityY) * 0.01F);
                    mScrollSumY = getContentAreaHeight() - mContentHeight - mOverScrollStartOffset;
                    mPortraitBounceOffset = mScrollSumY;
                }
                mPortraitBounceMaxOffset = mPortraitBounceOffset;
            }
            break MISSING_BLOCK_LABEL_599;
        }
        mPortraitBounceOffset = 0.0F;
        mPortraitBounceMaxOffset = 0.0F;
        flag = flag1;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        throw exception;
        flag = flag1;
        if ((mScrollOrientation & 2) != 2)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mScrollSumX > 0.0F)
        {
            if (mBounceImageBottom != null)
            {
                mBounceImageBottom.setSize(0.0F, getHeight());
            }
            mLandscapeBounceOffset = mScrollSumX;
            if (mLandscapeBounceMaxOffset < mLandscapeBounceOffset)
            {
                if (mLandscapeBounceMaxOffset == 0.0F && mFlingVelocityX > mVelocityReviseThreshold)
                {
                    mFlingVelocityX = mVelocityReviseThreshold + mFlingVelocityX * 0.01F;
                    mScrollSumX = mOverScrollStartOffset;
                    mLandscapeBounceOffset = mScrollSumX;
                }
                mLandscapeBounceMaxOffset = mLandscapeBounceOffset;
            }
            break MISSING_BLOCK_LABEL_604;
        }
        if (mContentWidth + mScrollSumX < getContentAreaWidth())
        {
            if (mBounceImageTop != null)
            {
                mBounceImageTop.setSize(0.0F, getHeight());
            }
            mLandscapeBounceOffset = getContentAreaWidth() - (mContentWidth + mScrollSumX);
            if (mLandscapeBounceMaxOffset > mLandscapeBounceOffset)
            {
                if (mLandscapeBounceMaxOffset == 0.0F && Math.abs(mFlingVelocityX) > mVelocityReviseThreshold)
                {
                    mFlingVelocityX = -(mVelocityReviseThreshold + Math.abs(mFlingVelocityX) * 0.01F);
                    mScrollSumX = getContentAreaWidth() - mContentWidth - mOverScrollStartOffset;
                    mLandscapeBounceOffset = mScrollSumX;
                }
                mLandscapeBounceMaxOffset = mLandscapeBounceOffset;
            }
            break MISSING_BLOCK_LABEL_609;
        }
        mLandscapeBounceOffset = 0.0F;
        mLandscapeBounceMaxOffset = 0.0F;
        flag = flag1;
        continue; /* Loop/switch isn't completed */
        flag = true;
        continue; /* Loop/switch isn't completed */
        flag = true;
        continue; /* Loop/switch isn't completed */
        flag = true;
        continue; /* Loop/switch isn't completed */
        flag = true;
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        if (mScrollBar != null)
        {
            mScrollBar.clear();
            mScrollBar = null;
        }
        if (mBounceImageTop != null)
        {
            mBounceImageTop.clear();
            mBounceImageTop = null;
        }
        if (mBounceImageBottom != null)
        {
            mBounceImageBottom.clear();
            mBounceImageBottom = null;
        }
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean contains(float f, float f1)
    {
        if (getClipRect() == null)
        {
            return false;
        } else
        {
            return getClipRect().contains((int)f, (int)f1);
        }
    }

    public GLView get(int i)
    {
        return (GLView)mGLViews.get(i);
    }

    public float getContentHeight()
    {
        return mContentHeight;
    }

    public float getContentWidth()
    {
        return mContentWidth;
    }

    public int getFirstFullyVisibleViewIndex()
    {
        return mFirstFullyVisibleViewIndex;
    }

    public int getLastFullyVisibleViewIndex()
    {
        return mLastFullyVisibleViewIndex;
    }

    public boolean getScrollBarAutoHide()
    {
        return mScrollBarAutoHide;
    }

    public float getScrollBarLength()
    {
        if (mScrollOrientation == 1)
        {
            return mScrollBar.getWidth();
        }
        if (mScrollOrientation == 2)
        {
            return mScrollBar.getHeight();
        } else
        {
            Log.e("GLAbsList", "orientation value is wrong.");
            return 0.0F;
        }
    }

    public int getScrollOrientation()
    {
        return mScrollOrientation;
    }

    public float getScrollThreshold()
    {
        return mScrollThreshold;
    }

    protected void hideScrollBar()
    {
        this;
        JVM INSTR monitorenter ;
        if (!getContext().getScrollBarAutoHide() || mScrollBar == null) goto _L2; else goto _L1
_L1:
        boolean flag = mScrollBarAutoHide;
        if (flag) goto _L3; else goto _L2
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
_L3:
        if (mBouncing || mFlingVelocityX == 0.0F && mFlingVelocityY == 0.0F)
        {
            break MISSING_BLOCK_LABEL_68;
        }
        restartScrollBarTimer();
          goto _L2
        Exception exception;
        exception;
        throw exception;
        mScrollBar.setAnimation(GLUtil.getAlphaOffAnimation(mScrollBarAlpha), true);
        mScrollBar.setAnimationEventListener(new GLView.AnimationEventListener() {

            final GLAbsList this$0;

            public void onAnimationEnd(GLView glview, Animation animation)
            {
                mScrollBarVisible = false;
            }

            public void onAnimationStart(GLView glview, Animation animation)
            {
            }

            
            {
                this$0 = GLAbsList.this;
                super();
            }
        });
        mScrollBar.startAnimation();
          goto _L2
    }

    public void invalidate()
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).clear()) { }
        mGLViews.clear();
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.cancelAnimation();
            mScrollBarVisible = false;
        }
        setSize(mListWidth, mListHeight);
        mContentHeight = 0.0F;
        mContentWidth = 0.0F;
        refreshList();
        mAdapter.reset();
        setAdapter(mAdapter, mScrollOrientation);
    }

    public boolean isOverScrollEffectEnabled()
    {
        return mEnableOverScrollEffect;
    }

    public boolean isScrollable()
    {
        boolean flag = false;
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        if (Float.compare(getContentAreaHeight(), mContentHeight) >= 0) goto _L4; else goto _L3
_L3:
        flag = true;
_L6:
        return flag;
_L4:
        return false;
_L2:
        if (mScrollOrientation == 2)
        {
            return Float.compare(getContentAreaWidth(), mContentWidth) < 0;
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        if (mBounceImageTop != null)
        {
            mBounceImageTop.onAlphaUpdated();
        }
        if (mBounceImageBottom != null)
        {
            mBounceImageBottom.onAlphaUpdated();
        }
        if (mScrollBar != null)
        {
            mScrollBar.onAlphaUpdated();
        }
    }

    public void onDrag(GLView glview, float f, float f1, float f2, float f3)
    {
        translate(f2, f3);
    }

    public void onDragEnd(GLView glview, float f, float f1)
    {
    }

    public void onDragStart(GLView glview, float f, float f1)
    {
    }

    protected void onDraw()
    {
        this;
        JVM INSTR monitorenter ;
        int i;
        if (mScrollRequested)
        {
            scrollToVisible();
        }
        mScrollSumX = mScrollSumX + mFlingVelocityX;
        mScrollSumY = mScrollSumY + mFlingVelocityY;
        i = getContext().getEstimatedFPS();
        if (checkBoundary()) goto _L2; else goto _L1
_L1:
        Iterator iterator = mGLViews.iterator();
_L6:
        if (!iterator.hasNext()) goto _L4; else goto _L3
_L3:
        Object obj = (GLView)iterator.next();
        if (obj == null) goto _L6; else goto _L5
_L5:
        ((GLView) (obj)).translate(mFlingVelocityX, mFlingVelocityY, false);
          goto _L6
        Exception exception;
        exception;
        throw exception;
_L4:
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translate(-((mListVisibleWidth / mContentWidth) * mFlingVelocityX), -((mListVisibleHeight / mContentHeight) * mFlingVelocityY), false);
        }
        if (mBounceImageTop != null && mBounceImageBottom != null)
        {
            mBounceImageTop.setAlpha(0.0F);
            mBounceImageBottom.setAlpha(0.0F);
        }
        if (mFlingVelocityX > 0.0F)
        {
            mFlingVelocityX = mFlingVelocityX - mFlingDeceleration / (float)i;
            if (mFlingVelocityX < 0.0F)
            {
                mFlingVelocityX = 0.0F;
                for (Iterator iterator1 = mGLViews.iterator(); iterator1.hasNext(); ((GLView)iterator1.next()).updateLayout(false)) { }
            }
            break MISSING_BLOCK_LABEL_339;
        }
        if (mFlingVelocityX < 0.0F)
        {
            mFlingVelocityX = mFlingVelocityX + mFlingDeceleration / (float)i;
            if (mFlingVelocityX > 0.0F)
            {
                mFlingVelocityX = 0.0F;
                for (Iterator iterator2 = mGLViews.iterator(); iterator2.hasNext(); ((GLView)iterator2.next()).updateLayout(false)) { }
            }
        }
        if (mFlingVelocityY <= 0.0F) goto _L8; else goto _L7
_L7:
        mFlingVelocityY = mFlingVelocityY - mFlingDeceleration / (float)i;
        if (mFlingVelocityY < 0.0F)
        {
            mFlingVelocityY = 0.0F;
            for (Iterator iterator3 = mGLViews.iterator(); iterator3.hasNext(); ((GLView)iterator3.next()).updateLayout(false)) { }
        }
          goto _L9
_L8:
        if (mFlingVelocityY < 0.0F)
        {
            mFlingVelocityY = mFlingVelocityY + mFlingDeceleration / (float)i;
            if (mFlingVelocityY > 0.0F)
            {
                mFlingVelocityY = 0.0F;
                for (Iterator iterator4 = mGLViews.iterator(); iterator4.hasNext(); ((GLView)iterator4.next()).updateLayout(false)) { }
            }
        }
          goto _L9
_L2:
        if (!mBouncing) goto _L11; else goto _L10
_L10:
        if (mScrollOrientation != 1) goto _L13; else goto _L12
_L12:
        if (getHeight() >= mContentHeight) goto _L15; else goto _L14
_L14:
        float f = getHeight();
_L79:
        if (mPortraitBounceOffset / mDragOutDistanceLimit <= 1.0F) goto _L17; else goto _L16
_L16:
        float f1 = 1.0F;
_L21:
        if (mScrollSumY <= 0.0F) goto _L19; else goto _L18
_L18:
        for (Iterator iterator5 = mGLViews.iterator(); iterator5.hasNext(); ((GLView)iterator5.next()).translateAbsolute(0.0F, 0.0F, false)) { }
          goto _L20
_L15:
        f = mContentHeight;
        continue; /* Loop/switch isn't completed */
_L17:
        f1 = mPortraitBounceOffset / mDragOutDistanceLimit;
          goto _L21
_L20:
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(0.0F, 0.0F, false);
        }
        if (mBounceImageTop != null && mEnableOverScrollEffect)
        {
            mBounceImageTop.setAlpha(f1);
            if (mPortraitBounceOffset > mDragOutDistanceLimit)
            {
                mPortraitBounceOffset = mDragOutDistanceLimit;
                mScrollSumY = mDragOutDistanceLimit;
                mFlingVelocityY = mFlingVelocityY * -1F;
            }
            mBounceImageTop.setSize(mBounceImageTop.getWidth(), mPortraitBounceOffset);
        }
        if (!mEnableBounceDeceleration) goto _L23; else goto _L22
_L22:
        if (mMainHandler.hasMessages(2))
        {
            mMainHandler.removeMessages(2);
        }
        if (mFlingVelocityY <= 0.0F) goto _L25; else goto _L24
_L24:
        mFlingVelocityY = mFlingVelocityY - (mBouncingDeceleration / (float)i) * (mPortraitBounceOffset / mDragOutDistanceLimit);
_L23:
        if (mScrollSumY + mFlingVelocityY <= 0.0F)
        {
            mScrollSumY = 0.0F;
            mFlingVelocityY = 0.0F;
            mBouncing = false;
        }
_L29:
        if (mBouncing) goto _L9; else goto _L26
_L26:
        for (Iterator iterator6 = mGLViews.iterator(); iterator6.hasNext(); ((GLView)iterator6.next()).translateAbsolute(mScrollSumX, mScrollSumY, false)) { }
          goto _L27
_L25:
label0:
        {
            if (mPortraitBounceOffset <= mDragOutDistanceLimit / 1.0F)
            {
                break label0;
            }
            mFlingVelocityY = mFlingVelocityY - (mBouncingDeceleration / (float)i) * (mPortraitBounceOffset / mDragOutDistanceLimit);
        }
          goto _L23
        mFlingVelocityY = mFlingVelocityY * 0.5F - mBouncingDeceleration / (float)i;
          goto _L23
_L19:
        if (mContentHeight + mScrollSumY >= getContentAreaHeight()) goto _L29; else goto _L28
_L28:
        for (Iterator iterator7 = mGLViews.iterator(); iterator7.hasNext(); ((GLView)iterator7.next()).translateAbsolute(0.0F, f - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight, false)) { }
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(0.0F, -((mListVisibleHeight / mContentHeight) * (f - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight)), false);
        }
        if (mBounceImageBottom != null && mEnableOverScrollEffect)
        {
            mBounceImageBottom.setAlpha(f1);
            if (mPortraitBounceOffset > mDragOutDistanceLimit)
            {
                mPortraitBounceOffset = mDragOutDistanceLimit;
                mScrollSumY = getContentAreaHeight() - mContentHeight - mDragOutDistanceLimit;
                mFlingVelocityY = mFlingVelocityY * -1F;
            }
            mBounceImageBottom.setSize(mBounceImageBottom.getWidth(), mPortraitBounceOffset);
            mBounceImageBottom.moveLayoutAbsolute(0.0F, mListVisibleHeight - mPortraitBounceOffset);
        }
        if (!mEnableBounceDeceleration) goto _L31; else goto _L30
_L30:
        if (mMainHandler.hasMessages(2))
        {
            mMainHandler.removeMessages(2);
        }
        if (mFlingVelocityY >= 0.0F) goto _L33; else goto _L32
_L32:
        mFlingVelocityY = mFlingVelocityY + (mBouncingDeceleration / (float)i) * (mPortraitBounceOffset / mDragOutDistanceLimit);
_L31:
        if (mContentHeight + mScrollSumY + mFlingVelocityY >= f - (float)mPaddings.top - (float)mPaddings.bottom)
        {
            mScrollSumY = f - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight;
            mFlingVelocityY = 0.0F;
            mBouncing = false;
        }
          goto _L29
_L33:
label1:
        {
            if (mPortraitBounceOffset <= mDragOutDistanceLimit / 1.0F)
            {
                break label1;
            }
            mFlingVelocityY = mFlingVelocityY + (mBouncingDeceleration / (float)i) * (mPortraitBounceOffset / mDragOutDistanceLimit);
        }
          goto _L31
        mFlingVelocityY = mFlingVelocityY * 0.5F + mBouncingDeceleration / (float)i;
          goto _L31
_L13:
        if (mScrollOrientation != 2) goto _L29; else goto _L34
_L34:
        if (getWidth() >= mContentWidth) goto _L36; else goto _L35
_L35:
        f = getWidth();
_L42:
        if (mLandscapeBounceOffset / mDragOutDistanceLimit <= 1.0F) goto _L38; else goto _L37
_L37:
        f1 = 1.0F;
_L43:
        if (mScrollSumX <= 0.0F) goto _L40; else goto _L39
_L39:
        for (Iterator iterator8 = mGLViews.iterator(); iterator8.hasNext(); ((GLView)iterator8.next()).translateAbsolute(0.0F, 0.0F, false)) { }
          goto _L41
_L36:
        f = mContentWidth;
          goto _L42
_L38:
        f1 = mLandscapeBounceOffset / mDragOutDistanceLimit;
          goto _L43
_L41:
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(0.0F, 0.0F, false);
        }
        if (mBounceImageTop != null && mEnableOverScrollEffect)
        {
            mBounceImageTop.setAlpha(f1);
            if (mLandscapeBounceOffset > mDragOutDistanceLimit)
            {
                mLandscapeBounceOffset = mDragOutDistanceLimit;
                mScrollSumX = mDragOutDistanceLimit;
                mFlingVelocityX = mFlingVelocityX * -1F;
            }
            mBounceImageTop.setSize(mLandscapeBounceOffset, mBounceImageTop.getHeight());
        }
        if (!mEnableBounceDeceleration) goto _L45; else goto _L44
_L44:
        if (mMainHandler.hasMessages(2))
        {
            mMainHandler.removeMessages(2);
        }
        if (mFlingVelocityX <= 0.0F) goto _L47; else goto _L46
_L46:
        mFlingVelocityX = mFlingVelocityX - (mBouncingDeceleration / (float)i) * (mLandscapeBounceOffset / mDragOutDistanceLimit);
_L45:
        if (mScrollSumX + mFlingVelocityX <= 0.0F)
        {
            mScrollSumX = 0.0F;
            mFlingVelocityX = 0.0F;
            mBouncing = false;
        }
          goto _L29
_L47:
label2:
        {
            if (mLandscapeBounceOffset <= mDragOutDistanceLimit / 1.0F)
            {
                break label2;
            }
            mFlingVelocityX = mFlingVelocityX - (mBouncingDeceleration / (float)i) * (mLandscapeBounceOffset / mDragOutDistanceLimit);
        }
          goto _L45
        mFlingVelocityX = mFlingVelocityX * 0.5F - mBouncingDeceleration / (float)i;
          goto _L45
_L40:
        if (mContentWidth + mScrollSumX >= getContentAreaWidth()) goto _L29; else goto _L48
_L48:
        for (Iterator iterator9 = mGLViews.iterator(); iterator9.hasNext(); ((GLView)iterator9.next()).translateAbsolute(f - (float)mPaddings.left - (float)mPaddings.right - mContentWidth, 0.0F, false)) { }
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(-((mListVisibleWidth / mContentWidth) * (f - (float)mPaddings.left - (float)mPaddings.right - mContentWidth)), 0.0F, false);
        }
        if (mBounceImageBottom != null && mEnableOverScrollEffect)
        {
            mBounceImageBottom.setAlpha(f1);
            if (mLandscapeBounceOffset > mDragOutDistanceLimit)
            {
                mLandscapeBounceOffset = mDragOutDistanceLimit;
                mScrollSumX = getContentAreaWidth() - mContentWidth - mDragOutDistanceLimit;
                mFlingVelocityX = mFlingVelocityX * -1F;
            }
            mBounceImageBottom.setSize(mLandscapeBounceOffset, mBounceImageBottom.getHeight());
            mBounceImageBottom.moveLayoutAbsolute(mListVisibleWidth - mLandscapeBounceOffset, 0.0F);
        }
        if (!mEnableBounceDeceleration) goto _L50; else goto _L49
_L49:
        if (mMainHandler.hasMessages(2))
        {
            mMainHandler.removeMessages(2);
        }
        if (mFlingVelocityX >= 0.0F) goto _L52; else goto _L51
_L51:
        mFlingVelocityX = mFlingVelocityX + (mBouncingDeceleration / (float)i) * (mLandscapeBounceOffset / mDragOutDistanceLimit);
_L50:
        if (mContentWidth + mScrollSumX + mFlingVelocityX >= f - (float)mPaddings.left - (float)mPaddings.right)
        {
            mScrollSumX = f - (float)mPaddings.left - (float)mPaddings.right - mContentWidth;
            mFlingVelocityX = 0.0F;
            mBouncing = false;
        }
          goto _L29
_L52:
label3:
        {
            if (mLandscapeBounceOffset <= mDragOutDistanceLimit / 1.0F)
            {
                break label3;
            }
            mFlingVelocityX = mFlingVelocityX + (mBouncingDeceleration / (float)i) * (mLandscapeBounceOffset / mDragOutDistanceLimit);
        }
          goto _L50
        mFlingVelocityX = mFlingVelocityX * 0.5F + mBouncingDeceleration / (float)i;
          goto _L50
_L27:
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(-((mListVisibleWidth / mContentWidth) * mScrollSumX), -((mListVisibleHeight / mContentHeight) * mScrollSumY), false);
        }
        if (mBounceImageTop == null || mBounceImageBottom == null) goto _L54; else goto _L53
_L53:
        mBounceImageTop.setAlpha(0.0F);
        mBounceImageBottom.setAlpha(0.0F);
        if (mScrollOrientation != 1) goto _L56; else goto _L55
_L55:
        mBounceImageTop.setSize(getWidth(), 0.0F);
        mBounceImageBottom.setSize(getWidth(), 0.0F);
_L54:
        getContext().setDirty(true);
_L9:
        if (mFlingVelocityX != 0.0F || mFlingVelocityY != 0.0F)
        {
            getContext().setDirty(true);
        }
        boolean flag = false;
        float af[];
        CopyOnWriteArrayList copyonwritearraylist;
        int k;
        af = getMatrix();
        obj = getClipRect();
        copyonwritearraylist = (CopyOnWriteArrayList)mGLViews.clone();
        k = copyonwritearraylist.size();
        int j = 0;
_L64:
        if (j >= k) goto _L58; else goto _L57
_L57:
        GLView glview = (GLView)copyonwritearraylist.get(j);
        i = ((flag) ? 1 : 0);
        if (flag) goto _L60; else goto _L59
_L59:
        i = ((flag) ? 1 : 0);
        if (glview.isClipped()) goto _L60; else goto _L61
_L61:
        if (j != 0) goto _L63; else goto _L62
_L62:
        mFirstFullyVisibleViewIndex = 0;
        i = 1;
_L60:
        if (!i)
        {
            break MISSING_BLOCK_LABEL_2429;
        }
        if (!glview.isClipped())
        {
            mLastFullyVisibleViewIndex = j;
        }
        clip();
        glview.draw(af, ((Rect) (obj)));
        clearClip();
        j++;
        flag = i;
          goto _L64
_L56:
        mBounceImageTop.setSize(0.0F, getHeight());
        mBounceImageBottom.setSize(0.0F, getHeight());
          goto _L54
_L11:
        if (mScrollOrientation != 1) goto _L66; else goto _L65
_L65:
        if (mScrollSumY <= 0.0F) goto _L68; else goto _L67
_L67:
        mScrollSumY = 0.0F;
_L70:
        getContext().setDirty(true);
          goto _L9
_L68:
        if (mContentHeight + mScrollSumY >= getContentAreaHeight()) goto _L70; else goto _L69
_L69:
        if (getHeight() >= mContentHeight)
        {
            break MISSING_BLOCK_LABEL_2583;
        }
        f = getHeight();
_L71:
        mScrollSumY = f - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight;
          goto _L70
        f = mContentHeight;
          goto _L71
_L66:
        if (mScrollOrientation != 2) goto _L70; else goto _L72
_L72:
        if (mScrollSumX <= 0.0F) goto _L74; else goto _L73
_L73:
        mScrollSumX = 0.0F;
          goto _L70
_L74:
        if (mContentWidth + mScrollSumX >= getContentAreaWidth()) goto _L70; else goto _L75
_L75:
        if (getWidth() >= mContentWidth)
        {
            break MISSING_BLOCK_LABEL_2681;
        }
        f = getWidth();
_L76:
        mScrollSumX = f - (float)mPaddings.left - (float)mPaddings.right - mContentWidth;
          goto _L70
        f = mContentWidth;
          goto _L76
_L63:
        i = ((flag) ? 1 : 0);
        if (!((GLView)copyonwritearraylist.get(j - 1)).isClipped()) goto _L60; else goto _L77
_L77:
        mFirstFullyVisibleViewIndex = j;
        i = 1;
          goto _L60
_L58:
        if (mScrollBar != null && mScrollBarVisible)
        {
            clip();
            mScrollBar.draw(af, ((Rect) (obj)));
            clearClip();
        }
        if (mBounceImageTop != null)
        {
            clip();
            mBounceImageTop.draw(af, ((Rect) (obj)));
            clearClip();
        }
        if (mBounceImageBottom != null)
        {
            clip();
            mBounceImageBottom.draw(af, ((Rect) (obj)));
            clearClip();
        }
        mDrawFirstTime = false;
        this;
        JVM INSTR monitorexit ;
        return;
        if (true) goto _L79; else goto _L78
_L78:
    }

    public boolean onFocusChanged(GLView glview, int i)
    {
        if (i == 1)
        {
            mScrollRequested = true;
            mScrollToVisibleView = glview;
        }
        return false;
    }

    public boolean onKeyDown(GLView glview, KeyEvent keyevent)
    {
        return false;
    }

    public boolean onKeyUp(GLView glview, KeyEvent keyevent)
    {
        return false;
    }

    public void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        setScrollBarLayout();
    }

    public void onReset()
    {
        if (mScrollBar != null)
        {
            mScrollBar.reset();
        }
        if (mBounceImageTop != null)
        {
            mBounceImageTop.reset();
        }
        if (mBounceImageBottom != null)
        {
            mBounceImageBottom.reset();
        }
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).reset()) { }
    }

    public boolean onTouch(GLView glview, MotionEvent motionevent)
    {
        return touchEvent(motionevent);
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        boolean flag = false;
        this;
        JVM INSTR monitorenter ;
        MotionEvent motionevent1;
        motionevent1 = MotionEvent.obtain(motionevent);
        mapPointReverse(mTransformedScreenCoordinate, motionevent.getX(), motionevent.getY());
        motionevent1.setLocation(mTransformedScreenCoordinate[0], mTransformedScreenCoordinate[1]);
        if (isScrollable()) goto _L2; else goto _L1
_L1:
        motionevent1.recycle();
_L7:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        boolean flag1;
        flag1 = checkBoundary();
        if (motionevent1.getAction() != 0)
        {
            break MISSING_BLOCK_LABEL_263;
        }
        mEnableBounceDeceleration = false;
        mIsDecelerationHandlerMessageExecuted = false;
        mDownEventX = motionevent1.getX();
        mDownEventY = motionevent1.getY();
        mLastEventX = mDownEventX;
        mLastEventY = mDownEventY;
        mFlingVelocityY = 0.0F;
        mFlingVelocityX = 0.0F;
        if ((mScrollOrientation & 1) != 1) goto _L4; else goto _L3
_L3:
        if (mScrollSumY <= 0.0F) goto _L6; else goto _L5
_L5:
        mScrollSumY = 0.0F;
_L9:
        showScrollBar();
        motionevent1.recycle();
          goto _L7
        motionevent;
        throw motionevent;
_L6:
        if (mContentHeight + mScrollSumY >= getContentAreaHeight()) goto _L9; else goto _L8
_L8:
        mScrollSumY = getContentAreaHeight() - mContentHeight;
          goto _L9
_L4:
        if ((mScrollOrientation & 2) != 2) goto _L9; else goto _L10
_L10:
        if (mScrollSumX <= 0.0F) goto _L12; else goto _L11
_L11:
        mScrollSumX = 0.0F;
          goto _L9
_L12:
        if (mContentWidth + mScrollSumX >= getContentAreaWidth()) goto _L9; else goto _L13
_L13:
        mScrollSumX = getContentAreaWidth() - mContentWidth;
          goto _L9
label0:
        {
            if (mScrolling || mDragging || motionevent1.getAction() != 2)
            {
                break label0;
            }
            if ((mScrollOrientation & 1) == 1 && Math.abs(mLastEventY - motionevent1.getY()) > mScrollThreshold)
            {
                mLastEventY = motionevent1.getY();
                setScrolling(true);
                motionevent.setAction(3);
            }
            if ((mScrollOrientation & 2) == 2 && Math.abs(mLastEventX - motionevent1.getX()) > mScrollThreshold)
            {
                mLastEventX = motionevent1.getX();
                setScrolling(true);
                motionevent.setAction(3);
            }
            restartScrollBarTimer();
            motionevent1.recycle();
        }
          goto _L7
        if (!mScrolling || mDragging || motionevent1.getAction() != 2)
        {
            break MISSING_BLOCK_LABEL_1308;
        }
        flag = flag1;
        if ((mScrollOrientation & 1) != 1) goto _L15; else goto _L14
_L14:
        float f1 = motionevent1.getY() - mLastEventY;
        float f = f1;
        if (mScrollSumY <= 0.0F) goto _L17; else goto _L16
_L16:
        if (f1 >= 0.0F) goto _L19; else goto _L18
_L18:
        if (Math.abs(f1) <= mScrollThreshold) goto _L19; else goto _L20
_L20:
        mScrollSumY = 0.0F;
        flag = false;
_L22:
        motionevent = mGLViews.iterator();
_L21:
        GLView glview;
        if (!motionevent.hasNext())
        {
            break MISSING_BLOCK_LABEL_720;
        }
        glview = (GLView)motionevent.next();
        if (flag)
        {
            break MISSING_BLOCK_LABEL_706;
        }
        glview.translate(0.0F, f, false);
          goto _L21
_L19:
        f = 0.0F;
        mBouncing = true;
        flag = flag1;
          goto _L22
_L17:
        if (mContentHeight + mScrollSumY >= getContentAreaHeight())
        {
            break MISSING_BLOCK_LABEL_624;
        }
        if (f1 <= 0.0F)
        {
            break MISSING_BLOCK_LABEL_610;
        }
        if (f1 <= mScrollThreshold)
        {
            break MISSING_BLOCK_LABEL_610;
        }
        mScrollSumY = getHeight() - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight;
        flag = false;
          goto _L22
        f = 0.0F;
        mBouncing = true;
        flag = flag1;
          goto _L22
        if (mScrollSumY + f1 <= 0.0F)
        {
            break MISSING_BLOCK_LABEL_654;
        }
        f = f1 - mScrollSumY;
        mBouncing = true;
        flag = flag1;
          goto _L22
        flag = flag1;
        if (mContentHeight + mScrollSumY + f1 >= getContentAreaHeight()) goto _L22; else goto _L23
_L23:
        f = f1 - ((getContentAreaHeight() - mContentHeight) + mScrollSumY);
        mBouncing = true;
        flag = flag1;
          goto _L22
        glview.translate(0.0F, f * 0.2F, false);
          goto _L21
        if (!mScrollBarVisible || mScrollBar == null) goto _L25; else goto _L24
_L24:
        if (flag) goto _L27; else goto _L26
_L26:
        mScrollBarOffset = (mListVisibleHeight / mContentHeight) * f;
_L42:
        mScrollBar.translate(0.0F, -mScrollBarOffset);
_L25:
        if (flag) goto _L29; else goto _L28
_L28:
        mScrollSumY = mScrollSumY + f1;
_L44:
        mLastEventY = motionevent1.getY();
_L15:
        if ((mScrollOrientation & 2) != 2) goto _L31; else goto _L30
_L30:
        f1 = motionevent1.getX() - mLastEventX;
        f = f1;
        if (mScrollSumX <= 0.0F) goto _L33; else goto _L32
_L32:
        if (f1 >= 0.0F) goto _L35; else goto _L34
_L34:
        if (Math.abs(f1) <= mScrollThreshold) goto _L35; else goto _L36
_L36:
        mScrollSumX = 0.0F;
        flag1 = false;
_L45:
        motionevent = mGLViews.iterator();
_L41:
        if (!motionevent.hasNext()) goto _L38; else goto _L37
_L37:
        glview = (GLView)motionevent.next();
        if (flag1) goto _L40; else goto _L39
_L39:
        glview.translate(f, 0.0F, false);
          goto _L41
_L27:
        mScrollBarOffset = (mListVisibleHeight / mContentHeight) * f * 0.2F;
          goto _L42
_L29:
        if (mEnableBounceDeceleration) goto _L44; else goto _L43
_L43:
        mMainHandler.sendEmptyMessageDelayed(2, 500L);
        if (mPortraitBounceOffset < mDragOutDistanceLimit)
        {
            mScrollSumY = mScrollSumY + f1 * 0.2F;
        }
          goto _L44
_L35:
        f = 0.0F;
        mBouncing = true;
        flag1 = flag;
          goto _L45
_L33:
        if (mContentWidth + mScrollSumX >= getContentAreaWidth())
        {
            break MISSING_BLOCK_LABEL_1058;
        }
        if (f1 <= 0.0F)
        {
            break MISSING_BLOCK_LABEL_1044;
        }
        if (f1 <= mScrollThreshold)
        {
            break MISSING_BLOCK_LABEL_1044;
        }
        mScrollSumX = getWidth() - (float)mPaddings.left - (float)mPaddings.right - mContentWidth;
        flag1 = false;
          goto _L45
        f = 0.0F;
        mBouncing = true;
        flag1 = flag;
          goto _L45
        if (mScrollSumX + f1 <= 0.0F)
        {
            break MISSING_BLOCK_LABEL_1088;
        }
        f = f1 - mScrollSumX;
        mBouncing = true;
        flag1 = flag;
          goto _L45
        flag1 = flag;
        if (mContentWidth + mScrollSumX + f1 >= getContentAreaWidth()) goto _L45; else goto _L46
_L46:
        f = f1 - ((getContentAreaWidth() - mContentWidth) + mScrollSumX);
        mBouncing = true;
        flag1 = flag;
          goto _L45
_L40:
        glview.translate(f * 0.2F, 0.0F, false);
          goto _L41
_L38:
        if (!mScrollBarVisible || mScrollBar == null) goto _L48; else goto _L47
_L47:
        if (flag1) goto _L50; else goto _L49
_L49:
        mScrollBarOffset = (mListVisibleWidth / mContentWidth) * f;
_L53:
        mScrollBar.translate(-mScrollBarOffset, 0.0F);
_L48:
        if (flag1) goto _L52; else goto _L51
_L51:
        mScrollSumX = mScrollSumX + f1;
_L55:
        mLastEventX = motionevent1.getX();
_L31:
        restartScrollBarTimer();
        motionevent1.recycle();
        flag = true;
          goto _L7
_L50:
        mScrollBarOffset = (mListVisibleWidth / mContentWidth) * f * 0.2F;
          goto _L53
_L52:
        if (mEnableBounceDeceleration) goto _L55; else goto _L54
_L54:
        mMainHandler.sendEmptyMessageDelayed(2, 500L);
        if (mLandscapeBounceOffset < mDragOutDistanceLimit)
        {
            mScrollSumX = mScrollSumX + f1 * 0.2F;
        }
          goto _L55
        if (motionevent1.getAction() == 1 || motionevent1.getAction() == 3)
        {
            mEnableBounceDeceleration = true;
        }
        if (!mScrolling || motionevent1.getAction() != 1 && motionevent1.getAction() != 3)
        {
            break MISSING_BLOCK_LABEL_1575;
        }
        setScrolling(false);
        mBouncing = true;
        motionevent.setAction(3);
        restartScrollBarTimer();
        getContext().setDirty(true);
        for (motionevent = mGLViews.iterator(); motionevent.hasNext(); ((GLView)motionevent.next()).updateLayout(false)) { }
        if (flag1)
        {
            break MISSING_BLOCK_LABEL_1530;
        }
        if (!mIsDecelerationHandlerMessageExecuted)
        {
            if ((mScrollOrientation & 1) == 1)
            {
                mFlingVelocityY = -(((mDownEventY - motionevent1.getY()) * 1000F) / (float)getContext().getEstimatedFPS()) / (float)(motionevent1.getEventTime() - motionevent1.getDownTime());
            }
            if ((mScrollOrientation & 2) == 2)
            {
                mFlingVelocityX = -(((mDownEventX - motionevent1.getX()) * 1000F) / (float)getContext().getEstimatedFPS()) / (float)(motionevent1.getEventTime() - motionevent1.getDownTime());
            }
        }
        mIsDecelerationHandlerMessageExecuted = false;
        Log.v("GLAbsList", (new StringBuilder()).append("estimated fps = ").append(getContext().getEstimatedFPS()).toString());
        motionevent1.recycle();
          goto _L7
        motionevent1.recycle();
          goto _L7
    }

    public void refreshList()
    {
        this;
        JVM INSTR monitorenter ;
        mScrollSumX = 0.0F;
        mScrollSumY = 0.0F;
        mLastEventX = 0.0F;
        mLastEventY = 0.0F;
        mFlingVelocityX = 0.0F;
        mFlingVelocityY = 0.0F;
        mFirstFullyVisibleViewIndex = 0;
        mLastFullyVisibleViewIndex = 0;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void removeView(GLView glview)
    {
        super.removeView(glview);
    }

    protected void restartScrollBarTimer()
    {
        this;
        JVM INSTR monitorenter ;
        mMainHandler.removeMessages(1);
        mMainHandler.sendEmptyMessageDelayed(1, 1000L);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean scrollList(float f, float f1)
    {
        boolean flag2 = true;
        if (!isScrollable())
        {
            return false;
        }
        boolean flag = checkBoundary();
        boolean flag1;
        if ((mScrollOrientation & 1) == 1)
        {
            float f2 = f1;
            Iterator iterator;
            if (mScrollSumY > 0.0F)
            {
                if (f1 < 0.0F && Math.abs(f1) > mScrollThreshold)
                {
                    mScrollSumY = 0.0F;
                    flag = false;
                    f = f2;
                } else
                {
                    f = 0.0F;
                }
            } else
            if (mContentHeight + mScrollSumY < getContentAreaHeight())
            {
                if (f1 > 0.0F && f1 > mScrollThreshold)
                {
                    mScrollSumY = getHeight() - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight;
                    flag = false;
                    f = f2;
                } else
                {
                    f = 0.0F;
                }
            } else
            if (mScrollSumY + f1 > 0.0F)
            {
                flag = true;
                f = f2;
            } else
            {
                f = f2;
                if (mContentHeight + mScrollSumY + f1 < getContentAreaHeight())
                {
                    flag = true;
                    f = f2;
                }
            }
            if (!mScrollBarVisible)
            {
                showScrollBar();
            } else
            if (mScrollBar != null)
            {
                if (!flag)
                {
                    mScrollBarOffset = (mListVisibleHeight / mContentHeight) * f;
                    mScrollBar.translate(0.0F, -mScrollBarOffset);
                }
                restartScrollBarTimer();
            }
            iterator = mGLViews.iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                GLView glview = (GLView)iterator.next();
                if (!flag)
                {
                    glview.translate(0.0F, f, false);
                }
            } while (true);
            flag1 = flag;
            if (!flag)
            {
                mScrollSumY = mScrollSumY + f1;
                flag1 = flag;
            }
        } else
        {
            flag1 = flag;
            if ((mScrollOrientation & 2) == 2)
            {
                float f3 = f;
                Iterator iterator1;
                if (mScrollSumX > 0.0F)
                {
                    if (f < 0.0F && Math.abs(f) > mScrollThreshold)
                    {
                        mScrollSumX = 0.0F;
                        flag = false;
                        f1 = f3;
                    } else
                    {
                        f1 = 0.0F;
                    }
                } else
                if (mContentWidth + mScrollSumX < getContentAreaWidth())
                {
                    if (f > 0.0F && f > mScrollThreshold)
                    {
                        mScrollSumX = getWidth() - (float)mPaddings.left - (float)mPaddings.right - mContentWidth;
                        flag = false;
                        f1 = f3;
                    } else
                    {
                        f1 = 0.0F;
                    }
                } else
                if (mScrollSumX + f > 0.0F)
                {
                    flag = true;
                    f1 = f3;
                } else
                {
                    f1 = f3;
                    if (mContentWidth + mScrollSumX + f < getContentAreaWidth())
                    {
                        flag = true;
                        f1 = f3;
                    }
                }
                if (!mScrollBarVisible)
                {
                    showScrollBar();
                } else
                if (mScrollBar != null)
                {
                    if (!flag)
                    {
                        mScrollBarOffset = (mListVisibleWidth / mContentWidth) * f1;
                        mScrollBar.translate(-mScrollBarOffset, 0.0F);
                    }
                    restartScrollBarTimer();
                }
                iterator1 = mGLViews.iterator();
                do
                {
                    if (!iterator1.hasNext())
                    {
                        break;
                    }
                    GLView glview1 = (GLView)iterator1.next();
                    if (!flag)
                    {
                        glview1.translate(f1, 0.0F, false);
                    }
                } while (true);
                flag1 = flag;
                if (!flag)
                {
                    mScrollSumX = mScrollSumX + f;
                    flag1 = flag;
                }
            }
        }
        if (!flag1)
        {
            flag = flag2;
        } else
        {
            flag = false;
        }
        return flag;
    }

    public void scrollToVisible(GLView glview)
    {
        mScrollRequested = true;
        mScrollToVisibleView = glview;
    }

    public boolean scrollToVisible()
    {
        Object obj;
        RectF rectf;
        if (mScrollToVisibleView == null)
        {
            return false;
        }
        obj = mScrollToVisibleView.getCurrentContentArea();
        rectf = getCurrentContentArea();
        if (rectf.contains(((RectF) (obj))))
        {
            mScrollRequested = false;
            Log.v("GLAbsList", (new StringBuilder()).append("scrollToVisible : do nothing, view = ").append(mScrollToVisibleView.getTitle()).append(", visibility = ").append(mScrollToVisibleView.isVisible()).toString());
            return true;
        }
        if (mScrollOrientation != 1) goto _L2; else goto _L1
_L1:
        if (mScrollSumY <= 0.0F) goto _L4; else goto _L3
_L3:
        mScrollSumY = 0.0F;
_L6:
        if (GLUtil.floatEquals(((RectF) (obj)).top, rectf.top))
        {
            mScrollRequested = false;
            return true;
        }
        break; /* Loop/switch isn't completed */
_L4:
        if (mContentHeight + mScrollSumY < getContentAreaHeight())
        {
            float f;
            if (getHeight() < mContentHeight)
            {
                f = getHeight();
            } else
            {
                f = mContentHeight;
            }
            mScrollSumY = f - (float)mPaddings.top - (float)mPaddings.bottom - mContentHeight;
        }
        if (true) goto _L6; else goto _L5
_L5:
        if (((RectF) (obj)).top >= rectf.top) goto _L8; else goto _L7
_L7:
        float f1 = rectf.top;
        float f6 = ((RectF) (obj)).top;
        mScrollSumY = mScrollSumY + (f1 - f6);
_L14:
        mFlingVelocityX = 0.0F;
        mFlingVelocityY = 0.0F;
        for (obj = mGLViews.iterator(); ((Iterator) (obj)).hasNext(); ((GLView)((Iterator) (obj)).next()).translateAbsolute(mScrollSumX, mScrollSumY, false)) { }
        break; /* Loop/switch isn't completed */
_L8:
        if (((RectF) (obj)).bottom > rectf.bottom)
        {
            float f2 = rectf.bottom;
            float f7 = ((RectF) (obj)).bottom;
            mScrollSumY = mScrollSumY + (f2 - f7);
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (mScrollOrientation != 2)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mScrollSumX <= 0.0F) goto _L10; else goto _L9
_L9:
        mScrollSumX = 0.0F;
_L12:
        if (GLUtil.floatEquals(((RectF) (obj)).left, rectf.left))
        {
            mScrollRequested = false;
            return true;
        }
        break; /* Loop/switch isn't completed */
_L10:
        if (mContentWidth + mScrollSumX < getContentAreaWidth())
        {
            float f3;
            if (getWidth() < mContentWidth)
            {
                f3 = getWidth();
            } else
            {
                f3 = mContentWidth;
            }
            mScrollSumX = f3 - (float)mPaddings.left - (float)mPaddings.right - mContentWidth;
        }
        if (true) goto _L12; else goto _L11
_L11:
        if (((RectF) (obj)).left < rectf.left)
        {
            float f4 = rectf.left;
            float f8 = ((RectF) (obj)).left;
            mScrollSumX = mScrollSumX + (f4 - f8);
        } else
        if (((RectF) (obj)).right > rectf.right)
        {
            float f5 = rectf.right;
            float f9 = ((RectF) (obj)).right;
            mScrollSumX = mScrollSumX + (f5 - f9);
        }
        if (true) goto _L14; else goto _L13
_L13:
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translateAbsolute(-((mListVisibleWidth / mContentWidth) * mScrollSumX), -((mListVisibleHeight / mContentHeight) * mScrollSumY), false);
        }
        showScrollBar();
        mScrollRequested = false;
        getContext().setDirty(true);
        return true;
    }

    public void sendAccessibilityEvent(int i)
    {
    }

    public void setAdapter(Adapter adapter)
    {
        setAdapter(adapter, 1);
    }

    public void setAdapter(Adapter adapter, int i)
    {
        if (isScrollable())
        {
            if (mScrollOrientation == 1)
            {
                mBounceImageTop = new GLImage(getContext(), 0.0F, 0.0F, getWidth(), 0.0F, true, R.drawable.overscroll_portrait_top);
                mBounceImageBottom = new GLImage(getContext(), 0.0F, 0.0F, getWidth(), 0.0F, true, R.drawable.overscroll_portrait_bottom);
            } else
            {
                mBounceImageTop = new GLImage(getContext(), 0.0F, 0.0F, 0.0F, getHeight(), true, R.drawable.overscroll_landscape_left);
                mBounceImageBottom = new GLImage(getContext(), 0.0F, 0.0F, 0.0F, getHeight(), true, R.drawable.overscroll_landscape_right);
            }
            mBounceImageTop.mParent = this;
            mBounceImageBottom.mParent = this;
            mBounceImageTop.setAlpha(0.0F);
            mBounceImageBottom.setAlpha(0.0F);
        }
        setVisibleArea();
        if (mScrollBar != null)
        {
            setScrollBarLayout();
        }
        if (mScrollBarVisible && mScrollBar != null)
        {
            mScrollBar.translate(-((mListVisibleWidth / mContentWidth) * mScrollSumX), -((mListVisibleHeight / mContentHeight) * mScrollSumY));
        }
    }

    protected void setBouncing(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        mBouncing = flag;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setHeight(float f)
    {
        mListHeight = f;
        super.setHeight(f);
    }

    public void setOverScrollEffect(boolean flag)
    {
        mEnableOverScrollEffect = flag;
    }

    public void setPaddings(Rect rect)
    {
        mPaddings = rect;
        float f = getLeft();
        float f1 = getRight();
        float f2 = getTop();
        float f3 = getBottom();
        Iterator iterator = mGLViews.iterator();
        while (iterator.hasNext()) 
        {
            GLView glview = (GLView)iterator.next();
            Rect rect1 = new Rect(0, 0, 0, 0);
            if (mScrollOrientation != 2)
            {
                if (glview.getLeft() - f < (float)rect.left && glview.getLeft() >= f)
                {
                    rect1.left = (int)((float)rect.left - (glview.getLeft() - f));
                } else
                {
                    rect1.left = glview.getPaddings().left;
                }
                if (f1 - glview.getRight() < (float)rect.right && f1 >= glview.getRight())
                {
                    rect1.right = (int)((float)rect.right - (f1 - glview.getRight()));
                } else
                {
                    rect1.right = glview.getPaddings().right;
                }
                rect1.top = glview.mPaddings.top;
                rect1.bottom = glview.mPaddings.bottom;
            }
            if (mScrollOrientation != 1)
            {
                if (glview.getTop() - f2 < (float)rect.top && glview.getTop() >= f2)
                {
                    rect1.top = (int)((float)rect.top - (glview.getTop() - f2));
                } else
                {
                    rect1.top = glview.getPaddings().top;
                }
                if (f3 - glview.getBottom() < (float)rect.bottom && f3 >= glview.getBottom())
                {
                    rect1.bottom = (int)((float)rect.bottom - (f3 - glview.getBottom()));
                } else
                {
                    rect1.bottom = glview.getPaddings().bottom;
                }
                rect1.left = glview.mPaddings.left;
                rect1.right = glview.mPaddings.right;
            }
            glview.setPaddings(rect1);
        }
        setVisibleArea();
        if (mScrollBar != null)
        {
            setScrollBarLayout();
        }
    }

    public void setScrollBarAlpha(float f)
    {
        mScrollBarAlpha = f;
    }

    public void setScrollBarAutoHide(boolean flag)
    {
        mScrollBarAutoHide = flag;
    }

    protected void setScrollBarLayout()
    {
        if (mScrollBar != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (mScrollOrientation == 1)
        {
            if (!isScrollable())
            {
                continue; /* Loop/switch isn't completed */
            }
            if (GLUtil.isLocaleRTL())
            {
                mScrollBar.moveLayoutAbsolute(mScrollBarPadding + (float)mPaddings.left, mPaddings.top);
            } else
            if (mPaddings.right == 0)
            {
                mScrollBar.moveLayoutAbsolute(getRight() - getLeft() - mScrollBarPadding - (float)mScrollBar.getIntrinsicWidth(), mPaddings.top);
            } else
            {
                mScrollBar.moveLayoutAbsolute(getRight() - getLeft() - mScrollBarPadding - (float)mPaddings.right - (float)mScrollBar.getIntrinsicWidth(), mPaddings.top);
            }
            mScrollBarSize = (mListVisibleHeight / mContentHeight) * mListVisibleHeight;
            mScrollBar.setSize(mScrollBar.getIntrinsicWidth(), mScrollBarSize);
        } else
        if (mScrollOrientation == 2)
        {
            if (!isScrollable())
            {
                continue; /* Loop/switch isn't completed */
            }
            if (mPaddings.bottom == 0)
            {
                mScrollBar.moveLayoutAbsolute(mPaddings.left, getBottom() - getTop() - mScrollBarPadding - (float)mScrollBar.getIntrinsicHeight());
            } else
            {
                mScrollBar.moveLayoutAbsolute(mPaddings.left, getBottom() - getTop() - (float)mPaddings.bottom - mScrollBarPadding - (float)mScrollBar.getIntrinsicHeight());
            }
            mScrollBarSize = (mListVisibleWidth / mContentWidth) * mListVisibleWidth;
            mScrollBar.setSize(mScrollBarSize, mScrollBar.getIntrinsicHeight());
        }
        mScrollBar.translateAbsolute(-((mListVisibleWidth / mContentWidth) * mScrollSumX), -((mListVisibleHeight / mContentHeight) * mScrollSumY));
        mScrollBarVisible = true;
        return;
        if (true) goto _L1; else goto _L3
_L3:
    }

    public void setScrollBarPadding(float f)
    {
        mScrollBarPadding = f;
    }

    public void setScrollBarResource(int i)
    {
        if (mScrollBar != null)
        {
            mScrollBar.clear();
        }
        mScrollBar = new GLNinePatch(getContext(), 0.0F, 0.0F, i);
        mScrollBar.setTag(0xfffff);
        mScrollBar.mParent = this;
        mScrollBar.setVisibility(4);
    }

    public void setScrollBarResource(int i, int j)
    {
        if (mScrollBar != null)
        {
            mScrollBar.clear();
        }
        mScrollBar = new GLNinePatch(getContext(), 0.0F, 0.0F, i);
        mScrollBar.setTint(j);
        mScrollBar.setTag(0xfffff);
        mScrollBar.mParent = this;
        mScrollBar.setVisibility(4);
    }

    public void setScrollListener(ScrollListener scrolllistener)
    {
        mScrollListener = scrolllistener;
    }

    public void setScrollOrientation(int i)
    {
        mScrollOrientation = i;
    }

    public void setScrollThreshold(float f)
    {
        SemLog.secI("GLAbsList", (new StringBuilder()).append("setScrollThreshold : ").append(f).toString());
        mScrollThreshold = f;
    }

    public void setScrolling(boolean flag)
    {
        if (mScrolling != flag)
        {
            mScrolling = flag;
            if (mScrollListener != null)
            {
                if (flag)
                {
                    mScrollListener.onScrollStart();
                } else
                {
                    mScrollListener.onScrollEnd();
                }
            }
        }
        if (flag)
        {
            resetDrag();
        }
    }

    public void setSize(float f, float f1)
    {
        mListWidth = f;
        mListHeight = f1;
        super.setSize(f, f1);
    }

    protected void setVisibleArea()
    {
        mListVisibleWidth = getWidth() - (float)mPaddings.left - (float)mPaddings.right;
        mListVisibleHeight = getHeight() - (float)mPaddings.top - (float)mPaddings.bottom;
        if (mScrollOrientation == 1)
        {
            if (mBounceImageTop != null && mBounceImageBottom != null)
            {
                mBounceImageTop.setSize(getWidth(), 0.0F);
                mBounceImageBottom.setSize(getWidth(), 0.0F);
                mBounceImageBottom.moveLayoutAbsolute(0.0F, mListVisibleHeight);
            }
        } else
        if (mScrollOrientation == 2 && mBounceImageTop != null && mBounceImageBottom != null)
        {
            mBounceImageTop.setSize(0.0F, getHeight());
            mBounceImageBottom.setSize(0.0F, getHeight());
            mBounceImageBottom.moveLayoutAbsolute(mListVisibleWidth, 0.0F);
            return;
        }
    }

    public void setWidth(float f)
    {
        mListWidth = f;
        super.setWidth(f);
    }

    public void showScrollBar()
    {
        if (mScrollBar == null || !isScrollable())
        {
            return;
        } else
        {
            mScrollBar.setAnimation(null);
            mScrollBar.setAlpha(mScrollBarAlpha);
            mScrollBarVisible = true;
            mScrollBar.setVisibility(0);
            restartScrollBarTimer();
            return;
        }
    }


/*
    static boolean access$002(GLAbsList glabslist, boolean flag)
    {
        glabslist.mScrollBarVisible = flag;
        return flag;
    }

*/



/*
    static boolean access$202(GLAbsList glabslist, boolean flag)
    {
        glabslist.mIsDecelerationHandlerMessageExecuted = flag;
        return flag;
    }

*/
}
