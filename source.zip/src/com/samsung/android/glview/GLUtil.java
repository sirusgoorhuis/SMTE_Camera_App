// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.UserHandle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import com.samsung.android.knox.SemPersonaManager;
import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Locale;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

public class GLUtil
{

    private static final int ANIMATION_DURATION = 300;
    private static final double EPSILON = 9.9999997473787516E-06D;

    private GLUtil()
    {
    }

    public static Object checkNotNull(Object obj)
    {
        if (obj == null)
        {
            throw new NullPointerException();
        } else
        {
            return obj;
        }
    }

    public static int clamp(int i, int j, int k)
    {
        if (i > k)
        {
            return k;
        }
        if (i < j)
        {
            return j;
        } else
        {
            return i;
        }
    }

    public static void closeSilently(Closeable closeable)
    {
        if (closeable == null)
        {
            return;
        }
        try
        {
            closeable.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Closeable closeable)
        {
            return;
        }
    }

    public static String convertTimeInfoForTTS(Context context, String s)
    {
        String s1 = s;
        if (s.contains("("))
        {
            s1 = s;
            if (s.contains(")"))
            {
                s1 = s.substring(2, s.length() - 1);
            }
        }
        if (s1.matches("[0-5][0-9]:[0-5][0-9]:[0-5][0-9]") || s1.matches("[0-5][0-9]:[0-5][0-9]:[0-5][0-9] / [0-5][0-9]:[0-5][0-9]:[0-5][0-9]"))
        {
            s = s1.substring(0, 2);
            String s2 = s1.substring(3, 5);
            String s4 = s1.substring(6, 8);
            int i = Integer.parseInt(s);
            int i1 = Integer.parseInt(s2);
            int i2 = Integer.parseInt(s4);
            if (i > 1)
            {
                s = context.getString(R.string.tts_hours);
            } else
            {
                s = context.getString(R.string.tts_hour);
            }
            if (i1 > 1)
            {
                s2 = context.getString(R.string.tts_minutes);
            } else
            {
                s2 = context.getString(R.string.tts_minute);
            }
            if (i2 > 1)
            {
                s4 = context.getString(R.string.tts_seconds);
            } else
            {
                s4 = context.getString(R.string.tts_second);
            }
            s2 = (new StringBuilder()).append(Integer.toString(i)).append(s).append(Integer.toString(i1)).append(s2).append(Integer.toString(i2)).append(s4).toString();
            s = s2;
            if (s1.contains("/"))
            {
                s = s1.substring(11, 13);
                s4 = s1.substring(14, 16);
                s1 = s1.substring(17, 19);
                int j = Integer.parseInt(s);
                int j1 = Integer.parseInt(s4);
                int j2 = Integer.parseInt(s1);
                if (j1 > 1)
                {
                    s = context.getString(R.string.tts_hours);
                } else
                {
                    s = context.getString(R.string.tts_hour);
                }
                if (j1 > 1)
                {
                    s1 = context.getString(R.string.tts_minutes);
                } else
                {
                    s1 = context.getString(R.string.tts_minute);
                }
                if (j2 > 1)
                {
                    context = context.getString(R.string.tts_seconds);
                } else
                {
                    context = context.getString(R.string.tts_second);
                }
                s = (new StringBuilder()).append(s2).append("/").append(Integer.toString(j)).append(s).append(Integer.toString(j1)).append(s1).append(Integer.toString(j2)).append(context).toString();
            }
        } else
        {
            s = s1.substring(0, 2);
            String s3 = s1.substring(3, 5);
            int k = Integer.parseInt(s);
            int k1 = Integer.parseInt(s3);
            if (k > 1)
            {
                s = context.getString(R.string.tts_minutes);
            } else
            {
                s = context.getString(R.string.tts_minute);
            }
            if (k1 > 1)
            {
                s3 = context.getString(R.string.tts_seconds);
            } else
            {
                s3 = context.getString(R.string.tts_second);
            }
            s3 = (new StringBuilder()).append(Integer.toString(k)).append(s).append(Integer.toString(k1)).append(s3).toString();
            s = s3;
            if (s1.contains("/"))
            {
                s = s1.substring(8, 10);
                s1 = s1.substring(11, 13);
                int l = Integer.parseInt(s);
                int l1 = Integer.parseInt(s1);
                if (l > 1)
                {
                    s = context.getString(R.string.tts_minutes);
                } else
                {
                    s = context.getString(R.string.tts_minute);
                }
                if (l1 > 1)
                {
                    context = context.getString(R.string.tts_seconds);
                } else
                {
                    context = context.getString(R.string.tts_second);
                }
                return (new StringBuilder()).append(s3).append("/").append(Integer.toString(l)).append(s).append(Integer.toString(l1)).append(context).toString();
            }
        }
        return s;
    }

    public static float distance(float f, float f1, float f2, float f3)
    {
        f -= f2;
        f1 -= f3;
        return (float)Math.sqrt(f * f + f1 * f1);
    }

    public static boolean doubleEquals(double d, double d1)
    {
        return Double.compare(d, d1) == 0;
    }

    public static boolean equals(Object obj, Object obj1)
    {
        return obj == obj1 || obj != null && obj.equals(obj1);
    }

    public static boolean floatEquals(double d, double d1)
    {
        return Math.abs(d - d1) < 9.9999997473787516E-06D;
    }

    public static boolean floatEquals(float f, float f1)
    {
        return Float.compare(f, f1) == 0;
    }

    public static Animation getAlphaOffAnimation()
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(1.0F, 0.0F);
        alphaanimation.setDuration(300L);
        return alphaanimation;
    }

    public static Animation getAlphaOffAnimation(float f)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(f, 0.0F);
        alphaanimation.setDuration(300L);
        return alphaanimation;
    }

    public static Animation getAlphaOffAnimation(int i, Interpolator interpolator)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(1.0F, 0.0F);
        alphaanimation.setDuration(i);
        alphaanimation.setInterpolator(interpolator);
        return alphaanimation;
    }

    public static Animation getAlphaOnAnimation()
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(300L);
        return alphaanimation;
    }

    public static Animation getAlphaOnAnimation(float f)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, f);
        alphaanimation.setDuration(300L);
        return alphaanimation;
    }

    public static Animation getAlphaOnAnimation(int i, int j, Interpolator interpolator)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(i);
        alphaanimation.setInterpolator(interpolator);
        alphaanimation.setStartOffset(j);
        return alphaanimation;
    }

    public static Animation getAlphaOnAnimation(int i, Interpolator interpolator)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(i);
        alphaanimation.setInterpolator(interpolator);
        return alphaanimation;
    }

    public static Animation getBlinkAnimation(boolean flag)
    {
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(300L);
        if (flag)
        {
            alphaanimation.setRepeatMode(2);
            alphaanimation.setRepeatCount(-1);
        }
        return alphaanimation;
    }

    public static ByteBuffer getByteBufferFromByteArray(byte abyte0[])
    {
        ByteBuffer bytebuffer = ByteBuffer.allocateDirect(abyte0.length);
        bytebuffer.put(abyte0);
        bytebuffer.position(0);
        return bytebuffer;
    }

    public static FloatBuffer getFloatBufferFromFloatArray(float af[])
    {
        Object obj = ByteBuffer.allocateDirect(af.length * 4);
        ((ByteBuffer) (obj)).order(ByteOrder.nativeOrder());
        obj = ((ByteBuffer) (obj)).asFloatBuffer();
        ((FloatBuffer) (obj)).put(af);
        ((FloatBuffer) (obj)).position(0);
        return ((FloatBuffer) (obj));
    }

    public static void getGLCoordinateFromScreenCoordinate(GLContext glcontext, float af[], float f, float f1)
    {
        af[0] = f;
        af[1] = f1;
    }

    public static float getGLDistanceFromScreenDistanceX(GLContext glcontext, float f)
    {
        return f;
    }

    public static float getGLDistanceFromScreenDistanceY(GLContext glcontext, float f)
    {
        return f;
    }

    public static int getGLOrientationByDisplayOrientation(int i)
    {
        if (GLContext.isScreenOrientationLandscape())
        {
            switch (i)
            {
            case 1: // '\001'
                return 1;

            case 2: // '\002'
                return 2;

            case 3: // '\003'
                return 3;
            }
        } else
        {
            switch (i)
            {
            default:
                return 0;

            case 0: // '\0'
                return 3;

            case 2: // '\002'
                return 1;

            case 3: // '\003'
                return 2;

            case 1: // '\001'
                break;
            }
        }
        while (true) 
        {
            return 0;
        }
    }

    public static int getGLOrientationBySystemOrientation(int i)
    {
        if (i == -1)
        {
            return GLContext.getLastOrientation();
        }
        switch (roundOrientation((GLContext.getOrientationCompensationValue() + i) % 360))
        {
        default:
            return 0;

        case 90: // 'Z'
            return 3;

        case 180: 
            return 2;

        case 270: 
            return 1;
        }
    }

    public static void getScreenCoordinateFromGLCoordinate(GLContext glcontext, float af[], float f, float f1)
    {
        af[0] = f;
        af[1] = f1;
    }

    public static float getScreenDistanceFromGLDistanceX(GLContext glcontext, float f)
    {
        return f;
    }

    public static float getScreenDistanceFromGLDistanceY(GLContext glcontext, float f)
    {
        return f;
    }

    public static int indexOf(Object aobj[], Object obj)
    {
        for (int i = 0; i < aobj.length; i++)
        {
            if (aobj[i].equals(obj))
            {
                return i;
            }
        }

        return -1;
    }

    public static boolean isKNOXMode()
    {
        if (android.os.Build.VERSION.SEM_INT <= 2601)
        {
            return SemPersonaManager.isKnoxId(UserHandle.semGetMyUserId());
        }
        return UserHandle.semGetMyUserId() >= 100;
    }

    public static boolean isLocaleRTL()
    {
        return TextUtils.getLayoutDirectionFromLocale(Locale.getDefault()) == 1;
    }

    public static boolean isPowerOf2(int i)
    {
        return (-i & i) == i;
    }

    public static boolean isReversePortraitOrientation(int i)
    {
        return getGLOrientationBySystemOrientation(i) == 1;
    }

    public static boolean isTimeInfo(String s)
    {
        String s1 = s;
        if (s.contains("("))
        {
            s1 = s;
            if (s.contains(")"))
            {
                s1 = s.substring(2, s.length() - 1);
            }
        }
        return s1.matches("[0-5][0-9]:[0-5][0-9]") || s1.matches("[0-5][0-9]:[0-5][0-9] / [0-5][0-9]:[0-5][0-9]") || s1.matches("[0-5][0-9]:[0-5][0-9]:[0-5][0-9]") || s1.matches("[0-5][0-9]:[0-5][0-9]:[0-5][0-9] / [0-5][0-9]:[0-5][0-9]:[0-5][0-9]");
    }

    public static void multiplyMM(float af[], float af1[], float af2[])
    {
        if (af == null || af1 == null || af2 == null)
        {
            return;
        } else
        {
            af[0] = af1[0] * af2[0] + af1[4] * af2[1] + af1[8] * af2[2] + af1[12] * af2[3];
            af[1] = af1[1] * af2[0] + af1[5] * af2[1] + af1[9] * af2[2] + af1[13] * af2[3];
            af[2] = af1[2] * af2[0] + af1[6] * af2[1] + af1[10] * af2[2] + af1[14] * af2[3];
            af[3] = af1[3] * af2[0] + af1[7] * af2[1] + af1[11] * af2[2] + af1[15] * af2[3];
            af[4] = af1[0] * af2[4] + af1[4] * af2[5] + af1[8] * af2[6] + af1[12] * af2[7];
            af[5] = af1[1] * af2[4] + af1[5] * af2[5] + af1[9] * af2[6] + af1[13] * af2[7];
            af[6] = af1[2] * af2[4] + af1[6] * af2[5] + af1[10] * af2[6] + af1[14] * af2[7];
            af[7] = af1[3] * af2[4] + af1[7] * af2[5] + af1[11] * af2[6] + af1[15] * af2[7];
            af[8] = af1[0] * af2[8] + af1[4] * af2[9] + af1[8] * af2[10] + af1[12] * af2[11];
            af[9] = af1[1] * af2[8] + af1[5] * af2[9] + af1[9] * af2[10] + af1[13] * af2[11];
            af[10] = af1[2] * af2[8] + af1[6] * af2[9] + af1[10] * af2[10] + af1[14] * af2[11];
            af[11] = af1[3] * af2[8] + af1[7] * af2[9] + af1[11] * af2[10] + af1[15] * af2[11];
            af[12] = af1[0] * af2[12] + af1[4] * af2[13] + af1[8] * af2[14] + af1[12] * af2[15];
            af[13] = af1[1] * af2[12] + af1[5] * af2[13] + af1[9] * af2[14] + af1[13] * af2[15];
            af[14] = af1[2] * af2[12] + af1[6] * af2[13] + af1[10] * af2[14] + af1[14] * af2[15];
            af[15] = af1[3] * af2[12] + af1[7] * af2[13] + af1[11] * af2[14] + af1[15] * af2[15];
            return;
        }
    }

    public static int nextPowerOf2(int i)
    {
        i--;
        i |= i >>> 16;
        i |= i >>> 8;
        i |= i >>> 4;
        i |= i >>> 2;
        return (i | i >>> 1) + 1;
    }

    public static Bitmap rotate(Bitmap bitmap, int i)
    {
        Object obj = bitmap;
        if (i != 0)
        {
            obj = bitmap;
            if (bitmap != null)
            {
                obj = new Matrix();
                ((Matrix) (obj)).setRotate(i, (float)bitmap.getWidth() / 2.0F, (float)bitmap.getHeight() / 2.0F);
                Bitmap bitmap1;
                try
                {
                    bitmap1 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), ((Matrix) (obj)), true);
                }
                catch (OutOfMemoryError outofmemoryerror)
                {
                    return bitmap;
                }
                obj = bitmap;
                if (bitmap != bitmap1)
                {
                    obj = bitmap1;
                }
            }
        }
        return ((Bitmap) (obj));
    }

    public static PointF rotatePoint(float f, float f1, int i, float f2, float f3)
    {
        Matrix matrix = new Matrix();
        matrix.setRotate(i, f2, f3);
        float af[] = new float[2];
        af[0] = f;
        af[1] = f1;
        matrix.mapPoints(af);
        return new PointF(af[0], af[1]);
    }

    public static int roundOrientation(int i)
    {
        GLContext.getLastOrientation();
        JVM INSTR tableswitch 0 3: default 32
    //                   0 47
    //                   1 95
    //                   2 78
    //                   3 62;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return (((i + 45) / 90) * 90) % 360;
_L2:
        if (305 <= i || i < 55)
        {
            return 0;
        }
        continue; /* Loop/switch isn't completed */
_L5:
        if (35 <= i && i < 145)
        {
            return 90;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (125 <= i && i < 235)
        {
            return 180;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (215 <= i && i < 325)
        {
            return 270;
        }
        if (true) goto _L1; else goto _L6
_L6:
    }

    public static float[] toGLMatrix(float af[])
    {
        af[15] = af[8];
        af[13] = af[5];
        af[5] = af[4];
        af[4] = af[1];
        af[12] = af[2];
        af[1] = af[3];
        af[3] = af[6];
        af[9] = 0.0F;
        af[8] = 0.0F;
        af[6] = 0.0F;
        af[2] = 0.0F;
        af[10] = 1.0F;
        return af;
    }

    public static void transformEventByGLOrientation(MotionEvent motionevent, int i, int j, int k)
    {
        switch (i)
        {
        default:
            return;

        case 1: // '\001'
            motionevent.setLocation((float)j - motionevent.getY(), motionevent.getX());
            return;

        case 2: // '\002'
            motionevent.setLocation((float)j - motionevent.getX(), (float)k - motionevent.getY());
            return;

        case 3: // '\003'
            motionevent.setLocation(motionevent.getY(), (float)k - motionevent.getX());
            break;
        }
    }

    public static void transformEventByScreenOrientation(MotionEvent motionevent, int i, int j, int k)
    {
        if (GLContext.isScreenOrientationLandscape())
        {
            switch (i)
            {
            default:
                return;

            case 1: // '\001'
                motionevent.setLocation((float)j - motionevent.getY(), motionevent.getX());
                return;

            case 2: // '\002'
                motionevent.setLocation((float)j - motionevent.getX(), (float)k - motionevent.getY());
                return;

            case 3: // '\003'
                motionevent.setLocation(motionevent.getY(), (float)k - motionevent.getX());
                break;
            }
            return;
        }
        switch (i)
        {
        case 1: // '\001'
        default:
            return;

        case 0: // '\0'
            motionevent.setLocation(motionevent.getY(), (float)k - motionevent.getX());
            return;

        case 2: // '\002'
            motionevent.setLocation((float)j - motionevent.getY(), motionevent.getX());
            return;

        case 3: // '\003'
            motionevent.setLocation((float)j - motionevent.getX(), (float)k - motionevent.getY());
            break;
        }
    }
}
