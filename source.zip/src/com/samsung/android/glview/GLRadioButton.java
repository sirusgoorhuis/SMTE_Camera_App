// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.media.AudioManager;
import android.view.MotionEvent;

// Referenced classes of package com.samsung.android.glview:
//            GLSelectButton, GLContext

public class GLRadioButton extends GLSelectButton
{

    private int mRadioButtonId;

    public GLRadioButton(GLContext glcontext, float f, float f1, int i, int j)
    {
        super(glcontext, f, f1, i, j);
        mRadioButtonId = 0;
    }

    public GLRadioButton(GLContext glcontext, float f, float f1, int i, int j, int k)
    {
        super(glcontext, f, f1, i, j, k);
        mRadioButtonId = 0;
    }

    public GLRadioButton(GLContext glcontext, int i, int j)
    {
        super(glcontext, i, j);
        mRadioButtonId = 0;
    }

    public int getRadioButtonId()
    {
        return mRadioButtonId;
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if (motionevent.getAction() != 0)
        {
            if (motionevent.getAction() == 1)
            {
                if (!mSelected)
                {
                    setSelected(true);
                    if (mClickListener != null)
                    {
                        ((AudioManager)GLContext.getApplicationContext().getSystemService("audio")).playSoundEffect(0);
                        mClickListener.onClick(this);
                        return true;
                    }
                }
            } else
            {
                return super.onTouchEvent(motionevent);
            }
        }
        return true;
    }

    public void setRadioButtonId(int i)
    {
        mRadioButtonId = i;
    }
}
