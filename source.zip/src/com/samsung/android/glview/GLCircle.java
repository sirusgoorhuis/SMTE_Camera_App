// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Log;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLUtil, GLContext, GLProgramStorage, 
//            GLProgram, GLView

public class GLCircle extends GLTexture
{

    private static final float DEFAULT_THICKNESS = 1F;
    private static final String TAG = "GLCircle";
    public static final int TYPE_FILL = 1;
    public static final int TYPE_STROKE = 0;
    private int mCircleType;
    private float mColor[];
    private GLProgram.NameIndexerObj mObjSampler;
    private GLProgram.NameIndexerObj mObjThickness;
    private GLProgram.NameIndexerObj mObjType;
    private float mThickness;

    public GLCircle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4)
    {
        super(glcontext, 0.0F, 0.0F);
        mCircleType = 0;
        mThickness = 1.0F;
        mObjSampler = null;
        mObjThickness = null;
        mObjType = null;
        mColor = new float[4];
        mCircleType = 0;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness = 1.0F;
        } else
        {
            mThickness = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    public GLCircle(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4, 
            int j)
    {
        super(glcontext, 0.0F, 0.0F);
        mCircleType = 0;
        mThickness = 1.0F;
        mObjSampler = null;
        mObjThickness = null;
        mObjType = null;
        mColor = new float[4];
        mCircleType = j;
        setColor(i);
        if (f4 < 1.0F)
        {
            mThickness = 1.0F;
        } else
        {
            mThickness = f4;
        }
        translateAbsolute(f, f1);
        setSize(f2, f3);
    }

    public boolean contains(float f, float f1)
    {
        this;
        JVM INSTR monitorenter ;
        return false;
    }

    public GLView findViewByCoordinate(float f, float f1)
    {
        this;
        JVM INSTR monitorenter ;
        return null;
    }

    public int getColor()
    {
        return Color.argb((int)(mColor[0] * 255F), (int)(mColor[1] * 255F), (int)(mColor[2] * 255F), (int)(mColor[3] * 255F));
    }

    public float getThickness()
    {
        return mThickness;
    }

    public void initSize()
    {
        this;
        JVM INSTR monitorenter ;
        setSize(getWidth(), getHeight());
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected Bitmap loadBitmap()
    {
        return null;
    }

    public void onDraw()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mTextureLoaded;
        if (flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (!mLayoutUpdated) goto _L4; else goto _L3
_L3:
        setVertices();
        if (mVertexBuffer != null)
        {
            mVertexBuffer.clear();
        }
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        mLayoutUpdated = false;
_L6:
        GLES20.glUseProgram(mProgramID);
        GLES20.glUniform4fv(mObjSampler.mHandle, 1, mColor, 0);
        Matrix.multiplyMM(mViewMatrix, 0, getContext().getProjMatrix(), 0, getMatrix(), 0);
        GLES20.glUniformMatrix4fv(mObjMVPMatrix.mHandle, 1, false, mViewMatrix, 0);
        GLES20.glUniform1f(mObjAlpha.mHandle, getAlpha());
        GLES20.glUniform1f(mObjType.mHandle, mCircleType);
        GLES20.glUniform1f(mObjThickness.mHandle, (1.0F / getWidth()) * mThickness);
        GLES20.glUniform1f(mObjParam.mHandle, getWidth() / getHeight());
        GLES20.glEnableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glEnableVertexAttribArray(mObjTextureCoord.mHandle);
        GLES20.glDisable(2929);
        GLES20.glVertexAttribPointer(mObjPosition.mHandle, 3, 5126, false, 0, mVertexBuffer);
        if (!mFlip)
        {
            break MISSING_BLOCK_LABEL_368;
        }
        GLES20.glVertexAttribPointer(mObjTextureCoord.mHandle, 2, 5126, false, 0, mTexFlipCoordBuffer);
_L7:
        if (mTextureReloaded)
        {
            mTextureReloaded = false;
        }
        GLES20.glDrawElements(4, mIndices.length, 5121, mIndexBuffer);
        GLES20.glEnable(2929);
        GLES20.glDisableVertexAttribArray(mObjPosition.mHandle);
        GLES20.glDisableVertexAttribArray(mObjTextureCoord.mHandle);
          goto _L1
        Exception exception;
        exception;
        throw exception;
_L4:
        if (mVertexBuffer != null && mTexFlipCoordBuffer != null && mTexCoordBuffer != null && mIndexBuffer != null) goto _L6; else goto _L5
_L5:
        Log.e("GLCircle", "init buffers on onDraw");
        setVertices();
        initBuffers();
          goto _L6
        GLES20.glVertexAttribPointer(mObjTextureCoord.mHandle, 2, 5126, false, 0, mTexCoordBuffer);
          goto _L7
    }

    protected boolean onLoad()
    {
        this;
        JVM INSTR monitorenter ;
        GLProgram glprogram;
        initSize();
        setVertices();
        initBuffers();
        glprogram = getContext().getProgramStorage().getProgram(1004);
        if (glprogram == null)
        {
            break MISSING_BLOCK_LABEL_125;
        }
        mProgramID = glprogram.getProgramID();
        mObjPosition = glprogram.getNameIndexer("a_position");
        mObjTextureCoord = glprogram.getNameIndexer("a_texcoord");
        mObjSampler = glprogram.getNameIndexer("tex_sampler");
        mObjMVPMatrix = glprogram.getNameIndexer("u_MVPMatrix");
        mObjAlpha = glprogram.getNameIndexer("u_alpha");
        mObjParam = glprogram.getNameIndexer("u_param");
        mObjThickness = glprogram.getNameIndexer("u_thickness");
        mObjType = glprogram.getNameIndexer("u_type");
        mTextureLoaded = true;
        this;
        JVM INSTR monitorexit ;
        return true;
        Exception exception;
        exception;
        throw exception;
    }

    public void setCircle(float f, float f1, float f2, float f3)
    {
        translateAbsolute(f, f1);
        setSize(f2, f3);
        setVertices();
        initBuffers();
    }

    public void setColor(int i)
    {
        mColor[0] = (float)Color.red(i) / 255F;
        mColor[1] = (float)Color.green(i) / 255F;
        mColor[2] = (float)Color.blue(i) / 255F;
        mColor[3] = (float)Color.alpha(i) / 255F;
    }

    public void setShaderProgram(int i)
    {
    }

    public void setThickness(float f)
    {
        mThickness = f;
    }

    public void setTint(int i)
    {
    }
}
