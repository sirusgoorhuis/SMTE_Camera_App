// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.NinePatchDrawable;
import android.media.AudioManager;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.animation.Animation;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLResourceTexture, GLRectangle, GLTexture, 
//            GLNinePatch, GLContext, GLBitmapTexture, GLFileTexture, 
//            GLByteArrayTexture, GLCircle, GLUtil, GLText

public class GLButton extends GLView
{
    public static interface ButtonHighlightChangeListener
    {

        public abstract void onButtonHighlightChanged(GLView glview, boolean flag);
    }

    public static interface ButtonPressListener
    {

        public abstract void onButtonPressed(GLView glview, boolean flag);
    }

    public static interface ButtonSelectListener
    {

        public abstract void onButtonSelected(GLView glview, boolean flag);
    }


    private static final int BUTTON_BACKGROUND_COLOR = Color.argb(77, 250, 250, 250);
    private static final int BUTTON_BACKGROUND_FILL_COLOR = Color.argb(38, 37, 37, 37);
    private static final int DRAW_HIGHLIGHT_DELAY = 200;
    private static final int DRAW_HIGHLIGHT_MINIMUM_DURATION = 200;
    private static final int HIGHLIGHTTYPE_COLOR = 2;
    private static final int HIGHLIGHTTYPE_NONE = 0;
    private static final int HIGHLIGHTTYPE_RESOURCE = 1;
    private static final int HIGHLIGHT_FADE_OUT_ANIM_DURATION = 400;
    private static final int STATE_PRESSED_MINIMUM_DURATION = 100;
    private static final String TAG = "GLButton";
    protected float mButtonHeight;
    protected ButtonPressListener mButtonPressListener;
    protected ButtonSelectListener mButtonSelectListener;
    protected float mButtonWidth;
    protected GLTexture mDimBackground;
    protected int mDimId;
    protected boolean mDrawHighlight;
    protected boolean mDrawRipple;
    protected GLTexture mHighlight;
    protected GLView.AnimationEventListener mHighlightAnimationListener = new GLView.AnimationEventListener() {

        final GLButton this$0;

        public void onAnimationEnd(GLView glview, Animation animation)
        {
            setDrawHighlight(false);
            mHighlight.setAnimation(null);
        }

        public void onAnimationStart(GLView glview, Animation animation)
        {
        }

            
            {
                this$0 = GLButton.this;
                super();
            }
    };
    protected ButtonHighlightChangeListener mHighlightChangeListener;
    protected boolean mHighlightFadeOut;
    protected int mHighlightId;
    protected boolean mIsNinePatchButton;
    protected boolean mIsStretchedButton;
    protected boolean mMute;
    protected GLTexture mNormalBackground;
    protected int mNormalId;
    protected int mNormalTextColor;
    protected boolean mPressed;
    protected GLTexture mPressedBackground;
    protected int mPressedId;
    protected int mPressedTextColor;
    private int mPressedTintColor;
    private final Runnable mResetButtonPressed;
    private final Runnable mResetDrawHighlight;
    private final Runnable mResetDrawRippleEffect;
    protected float mResourceOffsetX;
    protected float mResourceOffsetY;
    protected GLCircle mRippleBackground;
    private float mRippleDiameter;
    protected GLCircle mRippleEffect;
    protected int mRippleEffectColor;
    protected boolean mRippleEffectEnabled;
    protected GLView.AnimationEventListener mRippleEffectFadeOutAnimationListener = new GLView.AnimationEventListener() {

        final GLButton this$0;

        public void onAnimationEnd(GLView glview, Animation animation)
        {
            setDrawRippleEffect(false);
            mRippleEffect.setAnimation(null);
            mRippleBackground.setAnimation(null);
        }

        public void onAnimationStart(GLView glview, Animation animation)
        {
        }

            
            {
                this$0 = GLButton.this;
                super();
            }
    };
    private float mRippleRadius;
    private boolean mRippleSizeGiven;
    protected boolean mSelected;
    private final Runnable mSetButtonPressed;
    private final Runnable mSetDrawHighlight;
    private final Runnable mSetDrawRippleEffect;
    protected GLRectangle mShapeBackground;
    private int mShapeBackgroundVisibility;
    protected boolean mShowHighlight;
    protected boolean mShowText;
    protected GLText mText;

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k)
    {
        this(glcontext, f, f1, f2, f3, i, j, k, true);
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, int l)
    {
        this(glcontext, f, f1, f2, f3, i, j, k, l, true);
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, int l, android.graphics.Bitmap.Config config)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setDrawRippleEffect(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        mResetDrawRippleEffect = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setDrawRippleEffect(false);
                getContext().setDirty(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setDrawHighlight(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        mResetDrawHighlight = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setDrawHighlight(false);
                getContext().setDirty(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setButtonPressed(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        mResetButtonPressed = new Runnable() {

            final GLButton this$0;

            public void run()
            {
                setButtonPressed(false);
                getContext().setDirty(true);
            }

            
            {
                this$0 = GLButton.this;
                super();
            }
        };
        if (i != 0)
        {
            mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
        }
        if (j != 0)
        {
            mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
        }
        if (k != 0)
        {
            mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
        }
        if (l != 0)
        {
            mHighlight = new GLRectangle(glcontext, 0.0F, 0.0F, f2, f3, l, 1.0F, 1);
        }
        mButtonWidth = f2;
        mButtonHeight = f3;
        if (mNormalBackground != null && mButtonWidth > mNormalBackground.getWidth())
        {
            mResourceOffsetX = (mButtonWidth - mNormalBackground.getWidth()) / 2.0F;
        }
        if (mNormalBackground != null && mButtonHeight > mNormalBackground.getHeight())
        {
            mResourceOffsetY = (mButtonHeight - mNormalBackground.getHeight()) / 2.0F;
        }
        if (mResourceOffsetX != 0.0F || mResourceOffsetY != 0.0F)
        {
            if (mNormalBackground != null)
            {
                mNormalBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
            if (mDimBackground != null)
            {
                mDimBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, int l, android.graphics.Bitmap.Config config, int i1, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (i != 0)
        {
            if (flag)
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i1, i1, i);
            } else
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            }
        }
        if (j != 0)
        {
            if (flag)
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i1, i1, j);
            } else
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
            }
        }
        if (k != 0)
        {
            if (flag)
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i1, i1, k);
            } else
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
            }
        }
        if (l != 0)
        {
            mHighlight = new GLRectangle(glcontext, 0.0F, 0.0F, f2, f3, l, 1.0F, 1);
        }
        mButtonWidth = f2;
        mButtonHeight = f3;
        mIsStretchedButton = flag;
        if (mNormalBackground != null && mButtonWidth > mNormalBackground.getWidth())
        {
            mResourceOffsetX = (mButtonWidth - mNormalBackground.getWidth()) / 2.0F;
        }
        if (mNormalBackground != null && mButtonHeight > mNormalBackground.getHeight())
        {
            mResourceOffsetY = (mButtonHeight - mNormalBackground.getHeight()) / 2.0F;
        }
        if (mResourceOffsetX != 0.0F || mResourceOffsetY != 0.0F)
        {
            if (mNormalBackground != null)
            {
                mNormalBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
            if (mDimBackground != null)
            {
                mDimBackground.moveLayout(mResourceOffsetX, mResourceOffsetY);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, int l, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (i != 0)
        {
            if (flag)
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, i);
            } else
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            }
        }
        if (j != 0)
        {
            if (flag)
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, j);
            } else
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
            }
        }
        if (k != 0)
        {
            if (flag)
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, k);
            } else
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
            }
        }
        if (l != 0)
        {
            mHighlight = new GLNinePatch(glcontext, 0.0F, 0.0F, f2, f3, l);
        }
        mButtonWidth = f2;
        mButtonHeight = f3;
        mIsStretchedButton = flag;
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        mButtonWidth = f2;
        mButtonHeight = f3;
        mIsStretchedButton = flag;
        if (i != 0)
        {
            if (GLContext.getApplicationContext().getResources().getDrawable(i).getClass().equals(android/graphics/drawable/NinePatchDrawable))
            {
                mNormalBackground = new GLNinePatch(glcontext, 0.0F, 0.0F, mButtonWidth, mButtonHeight, i);
                mIsNinePatchButton = true;
            } else
            if (flag)
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, i);
            } else
            {
                mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            }
        }
        if (j != 0)
        {
            if (GLContext.getApplicationContext().getResources().getDrawable(j).getClass().equals(android/graphics/drawable/NinePatchDrawable))
            {
                mPressedBackground = new GLNinePatch(glcontext, 0.0F, 0.0F, mButtonWidth, mButtonHeight, j);
            } else
            if (flag)
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, j);
            } else
            {
                mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
            }
        }
        if (k != 0)
        {
            if (GLContext.getApplicationContext().getResources().getDrawable(k).getClass().equals(android/graphics/drawable/NinePatchDrawable))
            {
                mDimBackground = new GLNinePatch(glcontext, 0.0F, 0.0F, mButtonWidth, mButtonHeight, k);
            } else
            if (flag)
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, k);
            } else
            {
                mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, Bitmap bitmap, Bitmap bitmap1, 
            Bitmap bitmap2)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        mButtonWidth = f2;
        mButtonHeight = f3;
        if (bitmap != null)
        {
            mNormalBackground = new GLBitmapTexture(glcontext, 0.0F, 0.0F, bitmap);
        }
        if (bitmap1 != null)
        {
            mPressedBackground = new GLBitmapTexture(glcontext, 0.0F, 0.0F, bitmap1);
        }
        if (bitmap2 != null)
        {
            mDimBackground = new GLBitmapTexture(glcontext, 0.0F, 0.0F, bitmap2);
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, String s)
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (s != null)
        {
            mNormalBackground = new GLFileTexture(glcontext, 0.0F, 0.0F, f2, f3, s);
            mButtonWidth = f2;
            mButtonHeight = f3;
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, float f2, float f3, byte abyte0[])
    {
        super(glcontext, f, f1, f2, f3);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (abyte0 != null)
        {
            mNormalBackground = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, f2, f3, abyte0, true);
            mButtonWidth = f2;
            mButtonHeight = f3;
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, int i, int j, int k, int l)
    {
        super(glcontext, f, f1);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (i != 0)
        {
            mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (j != 0)
        {
            mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
        }
        if (k != 0)
        {
            mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
        }
        if (l != 0)
        {
            if (mNormalBackground != null)
            {
                mHighlight = new GLNinePatch(glcontext, 0.0F, 0.0F, mNormalBackground.getWidth(), mNormalBackground.getHeight(), l);
            } else
            {
                mHighlight = new GLNinePatch(glcontext, 0.0F, 0.0F, 0.0F, 0.0F, l);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, int i, int j, int k, int l, 
            android.graphics.Bitmap.Config config)
    {
        super(glcontext, f, f1);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (i != 0)
        {
            mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (j != 0)
        {
            mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
        }
        if (k != 0)
        {
            mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
        }
        if (l != 0)
        {
            if (mNormalBackground != null)
            {
                mHighlight = new GLRectangle(glcontext, 0.0F, 0.0F, mNormalBackground.getWidth(), mNormalBackground.getHeight(), l, 1.0F, 1);
            } else
            {
                mHighlight = new GLRectangle(glcontext, 0.0F, 0.0F, 0.0F, 0.0F, l, 1.0F, 1);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, String s)
    {
        super(glcontext, f, f1);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (s != null)
        {
            mNormalBackground = new GLFileTexture(glcontext, 0.0F, 0.0F, s);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, float f, float f1, byte abyte0[])
    {
        super(glcontext, f, f1);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (abyte0 != null)
        {
            mNormalBackground = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, abyte0);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, int i, int j, int k, int l)
    {
        super(glcontext, 0.0F, 0.0F);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (i != 0)
        {
            mNormalBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (j != 0)
        {
            mPressedBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, j);
        }
        if (k != 0)
        {
            mDimBackground = new GLResourceTexture(glcontext, 0.0F, 0.0F, k);
        }
        if (l != 0)
        {
            if (mNormalBackground != null)
            {
                mHighlight = new GLNinePatch(glcontext, 0.0F, 0.0F, mNormalBackground.getWidth(), mNormalBackground.getHeight(), l);
            } else
            {
                mHighlight = new GLNinePatch(glcontext, 0.0F, 0.0F, 0.0F, 0.0F, l);
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
            mShowHighlight = true;
        }
        mNormalId = i;
        mPressedId = j;
        mDimId = k;
        mHighlightId = l;
        initButton();
    }

    public GLButton(GLContext glcontext, String s)
    {
        super(glcontext, 0.0F, 0.0F);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (s != null)
        {
            mNormalBackground = new GLFileTexture(glcontext, 0.0F, 0.0F, s);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    public GLButton(GLContext glcontext, byte abyte0[])
    {
        super(glcontext, 0.0F, 0.0F);
        mRippleEffectColor = 0;
        mRippleEffectEnabled = true;
        mNormalTextColor = Color.argb(255, 255, 255, 255);
        mPressedTextColor = Color.argb(255, 255, 255, 255);
        mButtonWidth = 0.0F;
        mButtonHeight = 0.0F;
        mPressed = false;
        mSelected = false;
        mMute = false;
        mShowText = false;
        mShowHighlight = false;
        mDrawHighlight = false;
        mDrawRipple = false;
        mSetDrawRippleEffect = new _cls1();
        mResetDrawRippleEffect = new _cls2();
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        mIsNinePatchButton = false;
        mIsStretchedButton = false;
        mHighlightFadeOut = true;
        mHighlightChangeListener = null;
        mSetDrawHighlight = new _cls4();
        mResetDrawHighlight = new _cls5();
        mButtonPressListener = null;
        mButtonSelectListener = null;
        mRippleDiameter = 0.0F;
        mRippleRadius = 0.0F;
        mRippleSizeGiven = false;
        mShapeBackgroundVisibility = 4;
        mPressedTintColor = 0;
        mSetButtonPressed = new _cls7();
        mResetButtonPressed = new _cls8();
        if (abyte0 != null)
        {
            mNormalBackground = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, abyte0);
            mButtonWidth = mNormalBackground.getWidth();
            mButtonHeight = mNormalBackground.getHeight();
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
        }
        initButton();
    }

    private void initButton()
    {
        setFocusable(true);
        setClickable(true);
        if (getContext().isRippleEffectEnabled() && mSizeGiven)
        {
            initRippleEffect();
        }
        if (checkShapeBackgroundDrawingCondition() && mSizeGiven)
        {
            initShapeBackground();
        }
    }

    private void initRippleEffect()
    {
        int i = getContext().getRippleEffectColor();
        if (mRippleEffectColor != 0)
        {
            i = mRippleEffectColor;
        }
        if (!mRippleSizeGiven)
        {
            mRippleDiameter = (float)Math.sqrt(mButtonWidth * mButtonWidth + mButtonHeight * mButtonHeight);
        }
        mRippleRadius = (int)(mRippleDiameter / 2.0F + 0.5F);
        if (mRippleEffect != null)
        {
            mRippleEffect.clear();
        }
        if (mRippleBackground != null)
        {
            mRippleBackground.clear();
        }
        mRippleEffect = new GLCircle(getContext(), mButtonWidth / 2.0F - mRippleRadius, mButtonHeight / 2.0F - mRippleRadius, mRippleRadius * 2.0F, mRippleRadius * 2.0F, i, 1.0F, 1);
        mRippleEffect.mParent = this;
        mRippleBackground = new GLCircle(getContext(), mButtonWidth / 2.0F - mRippleRadius, mButtonHeight / 2.0F - mRippleRadius, mRippleRadius * 2.0F, mRippleRadius * 2.0F, i, 1.0F, 1);
        mRippleBackground.mParent = this;
    }

    private void initShapeBackground()
    {
        if (mShapeBackground == null)
        {
            mShapeBackground = new GLRectangle(getContext(), 0.0F, 0.0F, getWidth(), getHeight(), BUTTON_BACKGROUND_COLOR, 2.0F, 1);
            mShapeBackground.setFillColor(BUTTON_BACKGROUND_FILL_COLOR);
            mShapeBackground.mParent = this;
        }
        mShapeBackground.setSize(getWidth() - (float)mPaddings.left - (float)mPaddings.right, getHeight() - (float)mPaddings.top - (float)mPaddings.bottom);
        mShapeBackground.moveLayoutAbsolute(mPaddings.left, mPaddings.top);
    }

    private boolean isPossibleDrawRippleEffect()
    {
        return getContext().isRippleEffectEnabled() && mRippleEffectEnabled && mRippleBackground != null;
    }

    private void onSetText(String s)
    {
        mTitle = s;
        mShowText = true;
        if (checkShapeBackgroundDrawingCondition() && mShapeBackground == null)
        {
            initShapeBackground();
        }
    }

    private void startHighlightFadeOutAnimation()
    {
        if (mHighlight == null)
        {
            return;
        } else
        {
            setDrawHighlight(true);
            Animation animation = GLUtil.getAlphaOffAnimation();
            animation.setDuration(400L);
            animation.setFillAfter(true);
            mHighlight.setAnimation(animation);
            mHighlight.setAnimationEventListener(mHighlightAnimationListener);
            mHighlight.startAnimation();
            return;
        }
    }

    private void startRippleEffectFadeOutAnimation()
    {
        if (mRippleEffect == null)
        {
            return;
        } else
        {
            setDrawRippleEffect(true);
            Animation animation = GLUtil.getAlphaOffAnimation();
            animation.setDuration(400L);
            animation.setFillAfter(true);
            mRippleEffect.setAnimation(animation);
            mRippleBackground.setAnimation(animation);
            mRippleEffect.startAnimation();
            mRippleBackground.setAnimationEventListener(mRippleEffectFadeOutAnimationListener);
            mRippleBackground.startAnimation();
            return;
        }
    }

    protected boolean checkShapeBackgroundDrawingCondition()
    {
        boolean flag;
        for (flag = true; !getContext().isShowButtonBackgroundEnabled() || mShapeBackgroundVisibility == 32;)
        {
            return false;
        }

        if (mShowText)
        {
            return true;
        }
        if (mShapeBackgroundVisibility != 0)
        {
            flag = false;
        }
        return flag;
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        if (mNormalBackground != null)
        {
            mNormalBackground.clear();
            mNormalBackground = null;
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
            mPressedBackground = null;
        }
        if (mDimBackground != null)
        {
            mDimBackground.clear();
            mDimBackground = null;
        }
        if (mHighlight != null)
        {
            mHighlight.clear();
            mHighlight = null;
        }
        if (mText != null)
        {
            mText.clear();
            mText = null;
        }
        if (mRippleBackground != null)
        {
            mRippleBackground.clear();
            mRippleBackground = null;
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.clear();
            mRippleEffect = null;
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.clear();
            mShapeBackground = null;
        }
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void enableRippleEffect(boolean flag)
    {
        mRippleEffectEnabled = flag;
    }

    public boolean getLoaded()
    {
        boolean flag1 = true;
        boolean flag = flag1;
        if (mNormalBackground != null)
        {
            flag = flag1;
            if (!mNormalBackground.load())
            {
                flag = false;
            }
        }
        flag1 = flag;
        if (mPressedBackground != null)
        {
            flag1 = flag;
            if (!mPressedBackground.load())
            {
                flag1 = false;
            }
        }
        flag = flag1;
        if (mDimBackground != null)
        {
            flag = flag1;
            if (!mDimBackground.load())
            {
                flag = false;
            }
        }
        flag1 = flag;
        if (mHighlight != null)
        {
            flag1 = flag;
            if (!mHighlight.load())
            {
                flag1 = false;
            }
        }
        flag = flag1;
        if (mText != null)
        {
            flag = flag1;
            if (!mText.load())
            {
                flag = false;
            }
        }
        flag1 = flag;
        if (mRippleBackground != null)
        {
            flag1 = flag;
            if (!mRippleBackground.load())
            {
                flag1 = false;
            }
        }
        flag = flag1;
        if (mRippleEffect != null)
        {
            flag = flag1;
            if (!mRippleEffect.load())
            {
                flag = false;
            }
        }
        flag1 = flag;
        if (mShapeBackground != null)
        {
            flag1 = flag;
            if (!mShapeBackground.load())
            {
                flag1 = false;
            }
        }
        return flag1;
    }

    public String getTtsString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (mContentDescription == null) goto _L2; else goto _L1
_L1:
        stringbuilder.append(mContentDescription);
_L4:
        if (GLUtil.isTimeInfo(stringbuilder.toString()))
        {
            stringbuilder.setLength(0);
            stringbuilder.append(GLUtil.convertTimeInfoForTTS(GLContext.getApplicationContext(), stringbuilder.toString()));
        }
        if (mSubTitle != null)
        {
            stringbuilder.append(", ").append(mSubTitle);
        }
        if (isDim())
        {
            stringbuilder.append(", ").append(GLContext.getApplicationContext().getString(R.string.disable));
        }
        return stringbuilder.toString();
_L2:
        if (mTitle != null)
        {
            stringbuilder.append(mTitle).append(" ").append(GLContext.getApplicationContext().getResources().getString(R.string.button));
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void initSize()
    {
        float f = 0.0F;
        float f1 = 0.0F;
        float f4 = 0.0F;
        float f3 = f4;
        if (mNormalBackground != null)
        {
            if (mButtonWidth > 0.0F)
            {
                f1 = mButtonWidth;
            }
            f3 = f4;
            f = f1;
            if (mButtonHeight > 0.0F)
            {
                f3 = mButtonHeight;
                f = f1;
            }
        }
        f4 = f3;
        f1 = f;
        if (mPressedBackground != null)
        {
            float f5 = f;
            if (mButtonWidth > f)
            {
                f5 = mButtonWidth;
            }
            f4 = f3;
            f1 = f5;
            if (mButtonHeight > f3)
            {
                f4 = mButtonHeight;
                f1 = f5;
            }
        }
        f3 = f4;
        f = f1;
        if (mDimBackground != null)
        {
            float f6 = f1;
            if (mButtonWidth > f1)
            {
                f6 = mButtonWidth;
            }
            f3 = f4;
            f = f6;
            if (mButtonHeight > f4)
            {
                f3 = mButtonHeight;
                f = f6;
            }
        }
        float f7 = f3;
        f4 = f;
        if (mText != null)
        {
            float f2 = f;
            if (mText.getWidth() > f)
            {
                f2 = mText.getWidth();
            }
            f7 = f3;
            f4 = f2;
            if (mText.getHeight() > f3)
            {
                f7 = mText.getHeight();
                f4 = f2;
            }
        }
        setSize(f4, f7);
        if (getContext().isRippleEffectEnabled())
        {
            initRippleEffect();
        }
        if (checkShapeBackgroundDrawingCondition())
        {
            initShapeBackground();
        }
    }

    public boolean isPressed()
    {
        return mPressed;
    }

    public boolean isRippleEffectEnabled()
    {
        return mRippleEffectEnabled;
    }

    public boolean isSelected()
    {
        return mSelected;
    }

    public boolean keyDownEvent(int i, KeyEvent keyevent)
    {
        return onKeyDownEvent(i, keyevent);
    }

    public boolean keyUpEvent(int i, KeyEvent keyevent)
    {
        return onKeyUpEvent(i, keyevent);
    }

    public String mText()
    {
        if (mText != null)
        {
            return mText.getText();
        } else
        {
            return null;
        }
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        if (mNormalBackground != null)
        {
            mNormalBackground.onAlphaUpdated();
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.onAlphaUpdated();
        }
        if (mDimBackground != null)
        {
            mDimBackground.onAlphaUpdated();
        }
        if (mHighlight != null)
        {
            mHighlight.onAlphaUpdated();
        }
        if (mText != null)
        {
            mText.onAlphaUpdated();
        }
        if (mRippleBackground != null)
        {
            mRippleBackground.onAlphaUpdated();
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.onAlphaUpdated();
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.onAlphaUpdated();
        }
    }

    protected void onDraw()
    {
        boolean flag;
        if (mShapeBackground != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag & checkShapeBackgroundDrawingCondition())
        {
            mShapeBackground.draw(getMatrix(), getClipRect());
        }
        if (isDim())
        {
            if (mDimBackground != null)
            {
                mDimBackground.draw(getMatrix(), getClipRect());
            } else
            if (mNormalBackground != null)
            {
                mNormalBackground.draw(getMatrix(), getClipRect());
            }
        } else
        if (mPressed || mSelected)
        {
            if (mHighlight != null && mShowHighlight && mDrawHighlight)
            {
                mHighlight.draw(getMatrix(), getClipRect());
            }
            if (mDrawRipple && isPossibleDrawRippleEffect())
            {
                if (!isParentClippingForced() && mParent != null)
                {
                    mParent.clearClip();
                }
                mRippleBackground.draw(getMatrix(), getClipRect());
                if (!isParentClippingForced() && mParent != null)
                {
                    mParent.clip();
                }
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.draw(getMatrix(), getClipRect());
            } else
            if (mNormalBackground != null)
            {
                mNormalBackground.draw(getMatrix(), getClipRect());
            }
        } else
        if (mDrawHighlight || mDrawRipple)
        {
            if (mDrawHighlight && mHighlight != null && mShowHighlight)
            {
                mHighlight.draw(getMatrix(), getClipRect());
            }
            if (mDrawRipple && isPossibleDrawRippleEffect())
            {
                if (!isParentClippingForced() && mParent != null)
                {
                    mParent.clearClip();
                }
                mRippleBackground.draw(getMatrix(), getClipRect());
                if (!isParentClippingForced() && mParent != null)
                {
                    mParent.clip();
                }
            }
            if (mNormalBackground != null)
            {
                mNormalBackground.draw(getMatrix(), getClipRect());
            }
        } else
        if (mNormalBackground != null)
        {
            mNormalBackground.draw(getMatrix(), getClipRect());
        }
        if (mText != null && mShowText)
        {
            if (isSelected())
            {
                mText.setColor(mPressedTextColor);
            } else
            if (!mPressed)
            {
                mText.setColor(mNormalTextColor);
            }
            mText.draw(getMatrix(), getClipRect());
        }
    }

    public boolean onKeyDownEvent(int i, KeyEvent keyevent)
    {
        boolean flag1 = false;
        i;
        JVM INSTR lookupswitch 6: default 64
    //                   19: 92
    //                   20: 92
    //                   21: 92
    //                   22: 92
    //                   23: 113
    //                   66: 113;
           goto _L1 _L2 _L2 _L2 _L2 _L3 _L3
_L1:
        boolean flag = flag1;
_L7:
        if (mKeyListener != null)
        {
            flag = mKeyListener.onKeyDown(this, keyevent);
        }
        if (!flag)
        {
            break; /* Loop/switch isn't completed */
        }
_L5:
        return true;
_L2:
        flag = flag1;
        if (isPressed())
        {
            setPressed(false);
            flag = flag1;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (!isClickable() || isDim()) goto _L5; else goto _L4
_L4:
        setButtonPressed(true);
        setDrawHighlight(true);
        flag = true;
        if (true) goto _L7; else goto _L6
_L6:
        return super.onKeyDownEvent(i, keyevent);
    }

    public boolean onKeyUpEvent(int i, KeyEvent keyevent)
    {
        boolean flag = false;
        i;
        JVM INSTR lookupswitch 2: default 28
    //                   23: 53
    //                   66: 53;
           goto _L1 _L2 _L2
_L1:
        if (mKeyListener != null)
        {
            flag = mKeyListener.onKeyUp(this, keyevent);
        }
        if (flag)
        {
            return true;
        } else
        {
            return super.onKeyUpEvent(i, keyevent);
        }
_L2:
        if (!isClickable())
        {
            return true;
        }
        if (isDim())
        {
            return true;
        }
        setButtonPressed(false);
        if (keyevent.getDownTime() + 200L > keyevent.getEventTime())
        {
            setDrawHighlight(true);
            getContext().getMainHandler().postDelayed(mResetDrawHighlight, 200L - (keyevent.getEventTime() - keyevent.getDownTime()));
        } else
        {
            setDrawHighlight(false);
        }
        if (mClickListener != null)
        {
            if (!mMute)
            {
                ((AudioManager)GLContext.getApplicationContext().getSystemService("audio")).playSoundEffect(0);
            }
            mClickListener.onClick(this);
        }
        flag = true;
          goto _L1
    }

    protected void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        if (mNormalBackground != null)
        {
            mNormalBackground.onLayoutUpdated();
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.onLayoutUpdated();
        }
        if (mDimBackground != null)
        {
            mDimBackground.onLayoutUpdated();
        }
        if (mHighlight != null)
        {
            mHighlight.onLayoutUpdated();
        }
        if (mText != null)
        {
            mText.onLayoutUpdated();
        }
        if (mRippleBackground != null)
        {
            mRippleBackground.onLayoutUpdated();
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.onLayoutUpdated();
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.onLayoutUpdated();
        }
    }

    protected boolean onLoad()
    {
        boolean flag1 = true;
        if (mNormalBackground != null)
        {
            flag1 = true & mNormalBackground.load();
        }
        boolean flag = flag1;
        if (mPressedBackground != null)
        {
            flag = flag1 & mPressedBackground.load();
        }
        flag1 = flag;
        if (mDimBackground != null)
        {
            flag1 = flag & mDimBackground.load();
        }
        flag = flag1;
        if (mHighlight != null)
        {
            flag = flag1 & mHighlight.load();
        }
        flag1 = flag;
        if (mText != null)
        {
            flag1 = flag & mText.load();
        }
        flag = flag1;
        if (mRippleBackground != null)
        {
            flag = flag1 & mRippleBackground.load();
        }
        flag1 = flag;
        if (mRippleEffect != null)
        {
            flag1 = flag & mRippleEffect.load();
        }
        flag = flag1;
        if (mShapeBackground != null)
        {
            flag = flag1 & mShapeBackground.load();
        }
        return flag;
    }

    public void onReset()
    {
        if (mDimBackground != null)
        {
            mDimBackground.reset();
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.reset();
        }
        if (mHighlight != null)
        {
            mHighlight.reset();
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.reset();
        }
        if (mText != null)
        {
            mText.reset();
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.reset();
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.reset();
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if (!isClickable())
        {
            return false;
        }
        if (isDim())
        {
            if (mPressed)
            {
                setButtonPressed(false);
                setDrawHighlight(false);
                setDrawRippleEffect(false);
            }
            if (motionevent.getAction() == 2 && !mDragging && !contains(motionevent.getX(), motionevent.getY()))
            {
                motionevent.setAction(3);
            }
            if (motionevent.getAction() == 3)
            {
                resetDrag();
            }
            return true;
        }
        if (motionevent.getAction() == 0)
        {
            setButtonPressed(true);
            getContext().getMainHandler().removeCallbacks(mResetButtonPressed);
            if (mText != null && mShowText)
            {
                mText.setColor(mPressedTextColor);
            }
            if (mShowHighlight)
            {
                getContext().getMainHandler().postDelayed(mSetDrawHighlight, 200L);
            }
            if (isPossibleDrawRippleEffect())
            {
                getContext().getMainHandler().postDelayed(mSetDrawRippleEffect, 200L);
            }
            return true;
        }
        if (motionevent.getAction() == 2 && mPressed)
        {
            if (!mDragging && !contains(motionevent.getX(), motionevent.getY()))
            {
                motionevent.setAction(3);
                if (mText != null && mShowText)
                {
                    mText.setColor(mNormalTextColor);
                }
            }
        } else
        if (motionevent.getAction() == 1 && mPressed)
        {
            if (motionevent.getDownTime() + 200L > motionevent.getEventTime() && !mHighlightFadeOut)
            {
                setDrawHighlight(true);
                getContext().getMainHandler().postDelayed(mResetDrawHighlight, 200L - (motionevent.getEventTime() - motionevent.getDownTime()));
            }
            if (motionevent.getDownTime() + 100L > motionevent.getEventTime())
            {
                setButtonPressed(true);
                getContext().getMainHandler().postDelayed(mResetButtonPressed, 100L - (motionevent.getEventTime() - motionevent.getDownTime()));
            } else
            {
                setButtonPressed(false);
            }
            if (mText != null && mShowText)
            {
                mText.setColor(mNormalTextColor);
            }
            if (mHighlight != null && mHighlightFadeOut)
            {
                startHighlightFadeOutAnimation();
            }
            if (isPossibleDrawRippleEffect())
            {
                startRippleEffectFadeOutAnimation();
            }
            if (mClickListener != null)
            {
                if (!mMute)
                {
                    ((AudioManager)GLContext.getApplicationContext().getSystemService("audio")).playSoundEffect(0);
                }
                if (mTitle != null && getVisibility() != 4 && GLContext.isTalkBackEnabled())
                {
                    (new Thread() {

                        final GLButton this$0;

                        public void run()
                        {
                            try
                            {
                                Thread.sleep(700L);
                                getContext().getTts().speak(getTtsString(), 0, null, null);
                                return;
                            }
                            catch (InterruptedException interruptedexception)
                            {
                                Log.e("GLButton", (new StringBuilder()).append("onTouchEvent : ").append(interruptedexception.toString()).toString());
                            }
                        }

            
            {
                this$0 = GLButton.this;
                super();
            }
                    }).start();
                }
                mClickListener.onClick(this);
            }
            return true;
        }
        if (motionevent.getAction() == 3)
        {
            if (mPressed)
            {
                if (mText != null && mShowText)
                {
                    mText.setColor(mNormalTextColor);
                }
                if (motionevent.getDownTime() + 200L < motionevent.getEventTime())
                {
                    if (mHighlight != null && mHighlightFadeOut)
                    {
                        startHighlightFadeOutAnimation();
                    } else
                    {
                        setDrawHighlight(false);
                    }
                    if (isPossibleDrawRippleEffect())
                    {
                        startRippleEffectFadeOutAnimation();
                    }
                } else
                {
                    setDrawHighlight(false);
                    setDrawRippleEffect(false);
                }
                setButtonPressed(false);
                resetDrag();
            }
            return true;
        } else
        {
            return super.onTouchEvent(motionevent);
        }
    }

    protected void onVisibilityChanged(int i)
    {
        super.onVisibilityChanged(i);
        if (i != 0)
        {
            setDrawHighlight(false);
            setDrawRippleEffect(false);
            if (mPressed)
            {
                setButtonPressed(false);
                resetDrag();
                if (mText != null && mShowText)
                {
                    mText.setColor(mNormalTextColor);
                }
            }
        }
        if (mNormalBackground != null)
        {
            mNormalBackground.onVisibilityChanged(i);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.onVisibilityChanged(i);
        }
        if (mDimBackground != null)
        {
            mDimBackground.onVisibilityChanged(i);
        }
        if (mHighlight != null)
        {
            mHighlight.onVisibilityChanged(i);
        }
        if (mText != null)
        {
            mText.onVisibilityChanged(i);
        }
        if (mRippleBackground != null)
        {
            mRippleBackground.onVisibilityChanged(i);
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.onVisibilityChanged(i);
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.onVisibilityChanged(i);
        }
    }

    public void resetTint()
    {
        super.setTint(0);
        if (mNormalBackground != null)
        {
            mNormalBackground.resetTint();
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.resetTint();
        }
        if (mDimBackground != null)
        {
            mDimBackground.resetTint();
        }
        if (mHighlight != null)
        {
            mHighlight.resetTint();
        }
    }

    public void setButtonHighlightChangeListener(ButtonHighlightChangeListener buttonhighlightchangelistener)
    {
        mHighlightChangeListener = buttonhighlightchangelistener;
    }

    public void setButtonPressListener(ButtonPressListener buttonpresslistener)
    {
        mButtonPressListener = buttonpresslistener;
    }

    protected void setButtonPressed(boolean flag)
    {
        getContext().getMainHandler().removeCallbacks(mSetButtonPressed);
        mPressed = flag;
        updateTintColor();
        if (mButtonPressListener != null)
        {
            mButtonPressListener.onButtonPressed(this, flag);
        }
    }

    public void setButtonResources(int i, int j, int k, int l)
    {
        this;
        JVM INSTR monitorenter ;
        if (i == 0) goto _L2; else goto _L1
_L1:
        if (mNormalId == i) goto _L2; else goto _L3
_L3:
        mNormalId = i;
        if (mNormalBackground != null)
        {
            mNormalBackground.clear();
        }
        if (!mSizeGiven) goto _L5; else goto _L4
_L4:
        mNormalBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, mButtonWidth - mResourceOffsetX * 2.0F, mButtonHeight - mResourceOffsetY * 2.0F, i);
_L2:
        if (j == 0) goto _L7; else goto _L6
_L6:
        if (mPressedId == j) goto _L7; else goto _L8
_L8:
        mPressedId = j;
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
        }
        if (!mSizeGiven) goto _L10; else goto _L9
_L9:
        mPressedBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, mButtonWidth - mResourceOffsetX * 2.0F, mButtonHeight - mResourceOffsetY * 2.0F, j);
_L19:
        if (k == 0) goto _L12; else goto _L11
_L11:
        if (mDimId == k) goto _L12; else goto _L13
_L13:
        mDimId = k;
        if (mDimBackground != null)
        {
            mDimBackground.clear();
        }
        if (!mSizeGiven) goto _L15; else goto _L14
_L14:
        mDimBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, mButtonWidth - mResourceOffsetX * 2.0F, mButtonHeight - mResourceOffsetY * 2.0F, k);
_L21:
        if (l == 0) goto _L17; else goto _L16
_L16:
        if (mHighlightId == l) goto _L17; else goto _L18
_L18:
        mHighlightId = l;
        if (mHighlight != null)
        {
            mHighlight.clear();
        }
        mHighlight = new GLNinePatch(getContext(), 0.0F, 0.0F, getWidth(), getHeight(), l);
_L24:
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
            mNormalBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
            mPressedBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
            mDimBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
        }
        this;
        JVM INSTR monitorexit ;
        return;
_L5:
        mNormalBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, i);
          goto _L2
        Exception exception;
        exception;
        throw exception;
_L10:
        mPressedBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, j);
          goto _L19
_L7:
        if (j != 0) goto _L19; else goto _L20
_L20:
        mPressedId = 0;
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
            mPressedBackground = null;
        }
          goto _L19
_L15:
        mDimBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, k);
          goto _L21
_L12:
        if (k != 0) goto _L21; else goto _L22
_L22:
        mDimId = 0;
        if (mDimBackground != null)
        {
            mDimBackground.clear();
            mDimBackground = null;
        }
          goto _L21
_L17:
        if (l != 0) goto _L24; else goto _L23
_L23:
        mHighlightId = 0;
        if (mHighlight != null)
        {
            mHighlight.clear();
            mHighlight = null;
        }
          goto _L24
    }

    public void setButtonResources(int i, int j, int k, int l, android.graphics.Bitmap.Config config)
    {
        this;
        JVM INSTR monitorenter ;
        if (i == 0)
        {
            break MISSING_BLOCK_LABEL_51;
        }
        if (mNormalId != i)
        {
            mNormalId = i;
            if (mNormalBackground != null)
            {
                mNormalBackground.clear();
            }
            mNormalBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, i);
        }
        if (j == 0) goto _L2; else goto _L1
_L1:
        if (mPressedId == j) goto _L2; else goto _L3
_L3:
        mPressedId = j;
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
        }
        mPressedBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, j);
_L11:
        if (k == 0) goto _L5; else goto _L4
_L4:
        if (mDimId == k) goto _L5; else goto _L6
_L6:
        mDimId = k;
        if (mDimBackground != null)
        {
            mDimBackground.clear();
        }
        mDimBackground = new GLResourceTexture(getContext(), 0.0F, 0.0F, k);
_L13:
        if (l == 0) goto _L8; else goto _L7
_L7:
        if (mHighlightId == l) goto _L8; else goto _L9
_L9:
        mHighlightId = l;
        if (mHighlight != null)
        {
            mHighlight.clear();
        }
        mHighlight = new GLRectangle(getContext(), 0.0F, 0.0F, getWidth(), getHeight(), l, 1.0F, 1);
_L15:
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
            mNormalBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
            mPressedBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mDimBackground != null)
        {
            mDimBackground.mParent = this;
            mDimBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        if (mHighlight != null)
        {
            mHighlight.mParent = this;
        }
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (j != 0) goto _L11; else goto _L10
_L10:
        mPressedId = 0;
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
            mPressedBackground = null;
        }
          goto _L11
        config;
        throw config;
_L5:
        if (k != 0) goto _L13; else goto _L12
_L12:
        mDimId = 0;
        if (mDimBackground != null)
        {
            mDimBackground.clear();
            mDimBackground = null;
        }
          goto _L13
_L8:
        if (l != 0) goto _L15; else goto _L14
_L14:
        mHighlightId = 0;
        if (mHighlight != null)
        {
            mHighlight.clear();
            mHighlight = null;
        }
          goto _L15
    }

    public void setButtonResources(Bitmap bitmap, Bitmap bitmap1)
    {
        this;
        JVM INSTR monitorenter ;
        if (mNormalBackground != null)
        {
            mNormalBackground.clear();
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.clear();
        }
        if (bitmap == null)
        {
            break MISSING_BLOCK_LABEL_87;
        }
        mNormalBackground = new GLBitmapTexture(getContext(), 0.0F, 0.0F, bitmap);
        if (mNormalBackground != null)
        {
            mNormalBackground.mParent = this;
            mNormalBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
            mNormalId = 0;
        }
        if (bitmap1 == null)
        {
            break MISSING_BLOCK_LABEL_144;
        }
        mPressedBackground = new GLBitmapTexture(getContext(), 0.0F, 0.0F, bitmap1);
        if (mPressedBackground != null)
        {
            mPressedBackground.mParent = this;
            mPressedBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
            mPressedId = 0;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        bitmap;
        throw bitmap;
    }

    public void setButtonSelectListener(ButtonSelectListener buttonselectlistener)
    {
        mButtonSelectListener = buttonselectlistener;
    }

    public void setButtonShapeVisibility(boolean flag)
    {
        if (flag)
        {
            mShapeBackgroundVisibility = 0;
        } else
        {
            mShapeBackgroundVisibility = 32;
        }
        initShapeBackground();
    }

    public void setDim(boolean flag)
    {
        super.setDim(flag);
        setDrawRippleEffect(false);
        setButtonPressed(false);
    }

    protected void setDrawHighlight(boolean flag)
    {
        if (mHighlight != null)
        {
            getContext().getMainHandler().removeCallbacks(mSetDrawHighlight);
            if (mDrawHighlight != flag)
            {
                if (flag && mHighlight != null)
                {
                    mHighlight.cancelAnimation();
                    mHighlight.setAlpha(1.0F);
                }
                mDrawHighlight = flag;
                if (mHighlight != null && mHighlightChangeListener != null)
                {
                    mHighlightChangeListener.onButtonHighlightChanged(this, flag);
                    return;
                }
            }
        }
    }

    protected void setDrawRippleEffect(boolean flag)
    {
        getContext().getMainHandler().removeCallbacks(mSetDrawRippleEffect);
        if (mDrawRipple == flag)
        {
            return;
        }
        if (flag)
        {
            if (mRippleBackground != null)
            {
                mRippleBackground.cancelAnimation();
                mRippleBackground.setAlpha(1.0F);
            }
            if (mRippleEffect != null)
            {
                mRippleEffect.cancelAnimation();
                mRippleEffect.setAlpha(1.0F);
            }
        }
        mDrawRipple = flag;
    }

    public void setHeight(float f)
    {
        super.setHeight(f);
        mButtonHeight = f;
        if (mIsNinePatchButton || mIsStretchedButton)
        {
            if (mNormalBackground != null)
            {
                mNormalBackground.setHeight(mButtonHeight);
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.setHeight(mButtonHeight);
            }
            if (mDimBackground != null)
            {
                mDimBackground.setHeight(mButtonHeight);
            }
            if (mHighlight != null)
            {
                mHighlight.setHeight(mButtonHeight);
            }
            if (mText != null)
            {
                mText.setHeight(mButtonHeight);
            }
            if (mShapeBackground != null)
            {
                mShapeBackground.setHeight(mButtonHeight);
            }
        }
    }

    public void setHighlightVisibility(boolean flag)
    {
        mShowHighlight = flag;
    }

    public void setMute(boolean flag)
    {
        mMute = flag;
    }

    public void setPaddings(Rect rect)
    {
        super.setPaddings(rect);
        if (mHighlight != null)
        {
            mHighlight.setSize(mButtonWidth - (float)mPaddings.left - (float)mPaddings.right, mButtonHeight - (float)mPaddings.top - (float)mPaddings.bottom);
            mHighlight.moveLayoutAbsolute(mPaddings.left, mPaddings.top);
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.setSize(mButtonWidth - (float)mPaddings.left - (float)mPaddings.right, mButtonHeight - (float)mPaddings.top - (float)mPaddings.bottom);
            mShapeBackground.moveLayoutAbsolute(mPaddings.left, mPaddings.top);
        }
    }

    public void setPressed(boolean flag)
    {
        mPressed = flag;
        setDrawHighlight(flag);
        setButtonPressed(flag);
        setDrawRippleEffect(flag);
    }

    public void setPressedTint(int i)
    {
        mPressedTintColor = i;
        updateTintColor();
    }

    public boolean setResourceOffset(float f, float f1)
    {
        mResourceOffsetX = f;
        mResourceOffsetY = f1;
        if (mNormalBackground == null)
        {
            return false;
        }
        f = mNormalBackground.getWidth();
        f1 = mNormalBackground.getHeight();
        if (mButtonWidth >= f && mButtonHeight >= f1 && (!GLUtil.floatEquals(mButtonWidth, f) || !GLUtil.floatEquals(mButtonHeight, f1)))
        {
            mNormalBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
            if (mPressedBackground != null)
            {
                mPressedBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
            }
            if (mDimBackground != null)
            {
                mDimBackground.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
            }
        }
        return true;
    }

    public void setRippleDiameter(float f)
    {
        mRippleSizeGiven = true;
        mRippleDiameter = f;
        initRippleEffect();
    }

    public void setRippleEffectColor(int i)
    {
        mRippleEffectColor = i;
        if (mRippleBackground != null)
        {
            mRippleBackground.setColor(i);
        }
        if (mRippleEffect != null)
        {
            mRippleEffect.setColor(i);
        }
    }

    public void setSelected(boolean flag)
    {
        mSelected = flag;
        setDrawHighlight(flag);
        if (mButtonSelectListener != null)
        {
            mButtonSelectListener.onButtonSelected(this, flag);
        }
    }

    public void setShaderParameter(float f)
    {
        if (mNormalBackground != null)
        {
            mNormalBackground.setShaderParameter(f);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.setShaderParameter(f);
        }
        if (mDimBackground != null)
        {
            mDimBackground.setShaderParameter(f);
        }
        if (mHighlight != null)
        {
            mHighlight.setShaderParameter(f);
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.setShaderParameter(f);
        }
    }

    public void setShaderProgram(int i)
    {
        if (mNormalBackground != null)
        {
            mNormalBackground.setShaderProgram(i);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.setShaderProgram(i);
        }
        if (mDimBackground != null)
        {
            mDimBackground.setShaderProgram(i);
        }
        if (mHighlight != null)
        {
            mHighlight.setShaderProgram(i);
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.setShaderProgram(i);
        }
    }

    public void setShaderStep(float f)
    {
        if (mNormalBackground != null)
        {
            mNormalBackground.setShaderStep(f);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.setShaderStep(f);
        }
        if (mDimBackground != null)
        {
            mDimBackground.setShaderStep(f);
        }
        if (mHighlight != null)
        {
            mHighlight.setShaderStep(f);
        }
        if (mShapeBackground != null)
        {
            mShapeBackground.setShaderStep(f);
        }
    }

    public void setSize(float f, float f1)
    {
        super.setSize(f, f1);
        mButtonWidth = f;
        mButtonHeight = f1;
        if (mIsNinePatchButton || mIsStretchedButton)
        {
            if (mNormalBackground != null)
            {
                mNormalBackground.setSize(mButtonWidth, mButtonHeight);
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.setSize(mButtonWidth, mButtonHeight);
            }
            if (mDimBackground != null)
            {
                mDimBackground.setSize(mButtonWidth, mButtonHeight);
            }
            if (mHighlight != null)
            {
                mHighlight.setSize(mButtonWidth, mButtonHeight);
            }
            if (mText != null)
            {
                mText.setSize(mButtonWidth, mButtonHeight);
            }
            if (mShapeBackground != null)
            {
                mShapeBackground.setSize(mButtonWidth, mButtonHeight);
            }
        }
    }

    public void setStroke(boolean flag, float f, int i)
    {
        mText.setStroke(flag, f, i);
    }

    public void setText(GLText gltext)
    {
        if (gltext == null)
        {
            throw new IllegalArgumentException();
        }
        if (mText != null)
        {
            mText.clear();
        }
        mNormalTextColor = gltext.getTextColor();
        mPressedTextColor = mNormalTextColor;
        mText = gltext;
        mText.mParent = this;
        mText.setFocusable(false);
        onSetText(gltext.getText());
    }

    public void setText(GLText gltext, int i, int j)
    {
        if (gltext == null)
        {
            throw new IllegalArgumentException();
        }
        if (mText != null)
        {
            mText.clear();
        }
        mNormalTextColor = i;
        mPressedTextColor = j;
        mText = gltext;
        mText.mParent = this;
        mText.setFocusable(false);
        onSetText(gltext.getText());
    }

    public void setText(String s)
    {
        if (mText == null)
        {
            mText = new GLText(getContext(), 0.0F, 0.0F, mButtonWidth, mButtonHeight, s);
            mText.setAlign(2, 2);
            mText.mParent = this;
        } else
        {
            mText.setText(s);
        }
        mText.setFocusable(false);
        onSetText(s);
    }

    public void setText(String s, float f, int i, int j)
    {
        if (mText != null)
        {
            mText.clear();
        }
        mText = new GLText(getContext(), 0.0F, 0.0F, mButtonWidth, mButtonHeight, s, f, i);
        mText.setAlign(2, 2);
        mText.mParent = this;
        mText.setFocusable(false);
        mNormalTextColor = i;
        mPressedTextColor = j;
        onSetText(s);
    }

    public void setText(String s, float f, int i, int j, boolean flag, boolean flag1)
    {
        if (mText != null)
        {
            mText.clear();
        }
        mText = new GLText(getContext(), 0.0F, 0.0F, mButtonWidth, mButtonHeight, s, f, i, flag);
        mText.setAlign(2, 2);
        mText.setBold(flag1);
        mText.setFocusable(false);
        mText.mParent = this;
        mNormalTextColor = i;
        mPressedTextColor = j;
        onSetText(s);
    }

    public void setText(String s, float f, int i, boolean flag)
    {
        if (mText != null)
        {
            mText.clear();
        }
        mText = new GLText(getContext(), 0.0F, 0.0F, mButtonWidth, mButtonHeight, s, f, i, flag);
        mText.setAlign(2, 2);
        mText.mParent = this;
        mText.setFocusable(false);
        mNormalTextColor = i;
        mPressedTextColor = i;
        onSetText(s);
    }

    public void setTextAlign(int i, int j)
    {
        if (mText != null)
        {
            mText.setAlign(i, j);
        }
    }

    public void setTextFont(Typeface typeface)
    {
        if (mText != null)
        {
            mText.setTextFont(typeface);
        }
    }

    public void setTextPosition(float f, float f1)
    {
        float f2;
        float f3;
label0:
        {
            if (mText != null)
            {
                f2 = mButtonWidth - f;
                f3 = mButtonHeight - f1;
                if (mText.getWidth() > f2 || mText.getHeight() > f3)
                {
                    break label0;
                }
                mText.moveLayoutAbsolute(f, f1);
            }
            return;
        }
        mText.moveLayoutAbsolute(f, f1, false);
        mText.setSize(f2, f3);
    }

    public void setTextVisibility(boolean flag)
    {
        mShowText = flag;
        if (mShowText)
        {
            if (checkShapeBackgroundDrawingCondition() && mShapeBackground == null)
            {
                initShapeBackground();
            }
        } else
        if (!checkShapeBackgroundDrawingCondition() && mShapeBackground != null)
        {
            mShapeBackground.clear();
            mShapeBackground = null;
            return;
        }
    }

    public void setTint(int i)
    {
        super.setTint(i);
        if (mNormalBackground != null)
        {
            mNormalBackground.setTint(i);
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.setTint(i);
        }
        if (mDimBackground != null)
        {
            mDimBackground.setTint(i);
        }
        if (mHighlight != null)
        {
            mHighlight.setTint(i);
        }
    }

    public void setVisibility(int i)
    {
        getContext().getMainHandler().removeCallbacks(mSetDrawRippleEffect);
        setDrawRippleEffect(false);
        super.setVisibility(i);
    }

    public void setVisibility(int i, boolean flag)
    {
        getContext().getMainHandler().removeCallbacks(mSetDrawRippleEffect);
        setDrawRippleEffect(false);
        super.setVisibility(i, flag);
    }

    public void setWidth(float f)
    {
        super.setWidth(f);
        mButtonWidth = f;
        if (mIsNinePatchButton || mIsStretchedButton)
        {
            if (mNormalBackground != null)
            {
                mNormalBackground.setWidth(mButtonWidth);
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.setWidth(mButtonWidth);
            }
            if (mDimBackground != null)
            {
                mDimBackground.setWidth(mButtonWidth);
            }
            if (mHighlight != null)
            {
                mHighlight.setWidth(mButtonWidth);
            }
            if (mText != null)
            {
                mText.setWidth(mButtonWidth);
            }
            if (mShapeBackground != null)
            {
                mShapeBackground.setWidth(mButtonWidth);
            }
        }
    }

    protected void updateTintColor()
    {
        if (!mPressed && !mSelected || mPressedTintColor == 0) goto _L2; else goto _L1
_L1:
        if (mPressedBackground == null) goto _L4; else goto _L3
_L3:
        mPressedBackground.setTint(mPressedTintColor);
_L6:
        return;
_L4:
        if (mPressedBackground == null && mNormalBackground != null)
        {
            mNormalBackground.setTint(mPressedTintColor);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (getTint() == 0)
        {
            break; /* Loop/switch isn't completed */
        }
        if (mPressedBackground != null)
        {
            mPressedBackground.setTint(getTint());
            return;
        }
        if (mPressedBackground == null && mNormalBackground != null)
        {
            mNormalBackground.setTint(getTint());
            return;
        }
        if (true) goto _L6; else goto _L5
_L5:
        if (mPressedBackground != null)
        {
            mPressedBackground.setShaderProgram(1001);
            return;
        }
        if (mPressedBackground == null && mNormalBackground != null)
        {
            mNormalBackground.setShaderProgram(1001);
            return;
        }
        if (true) goto _L6; else goto _L7
_L7:
    }

}
