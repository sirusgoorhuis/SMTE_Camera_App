// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import com.samsung.android.util.SemLog;

// Referenced classes of package com.samsung.android.glview:
//            GLContext

class  extends ContentObserver
{

    final GLContext this$0;

    public void onChange(boolean flag)
    {
        if (GLContext.access$500(GLContext.this))
        {
            SemLog.secW("GLContext", "GLContext is pausing, not updated");
        } else
        {
            if (android.provider.tem.getInt(GLContext.mApplicationContext.getContentResolver(), "access_control_enabled", 0) == 0)
            {
                enableOrientationListener();
                return;
            }
            if (android.provider.tem.getInt(GLContext.mApplicationContext.getContentResolver(), "access_control_enabled", 0) == 1)
            {
                GLContext.access$600(GLContext.this);
                return;
            }
        }
    }

    (Handler handler)
    {
        this$0 = GLContext.this;
        super(handler);
    }
}
