// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import android.view.MotionEvent;

// Referenced classes of package com.samsung.android.glview:
//            GLButton, GLUtil, GLContext, GLRectangle, 
//            GLTexture, GLText

public class GLSelectButton extends GLButton
{

    public GLSelectButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k)
    {
        this(glcontext, f, f1, f2, f3, i, j, k, true);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, float f2, float f3, int i, int j, 
            int k, boolean flag)
    {
        super(glcontext, f, f1, f2, f3, i, j, k, flag);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, float f2, float f3, Bitmap bitmap, Bitmap bitmap1, 
            Bitmap bitmap2)
    {
        super(glcontext, f, f1, f2, f3, bitmap, bitmap1, bitmap2);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, float f2, float f3, String s)
    {
        super(glcontext, f, f1, f2, f3, s);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, int i, int j)
    {
        super(glcontext, f, f1, i, j, 0, 0);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, int i, int j, int k)
    {
        super(glcontext, f, f1, i, j, 0, k);
    }

    public GLSelectButton(GLContext glcontext, float f, float f1, int i, int j, int k, int l)
    {
        super(glcontext, f, f1, i, j, k, l);
    }

    public GLSelectButton(GLContext glcontext, int i, int j)
    {
        super(glcontext, i, j, 0, 0);
    }

    public boolean getSelected()
    {
        return mSelected;
    }

    public String getTtsString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (mContentDescription != null)
        {
            stringbuilder.append(mContentDescription);
        } else
        if (mTitle != null)
        {
            stringbuilder.append(mTitle).append(" ").append(GLContext.getApplicationContext().getResources().getString(R.string.button));
        }
        if (GLUtil.isTimeInfo(stringbuilder.toString()))
        {
            stringbuilder.setLength(0);
            stringbuilder.append(GLUtil.convertTimeInfoForTTS(GLContext.getApplicationContext(), stringbuilder.toString()));
        }
        if (mSubTitle != null)
        {
            stringbuilder.append(", ").append(mSubTitle);
        }
        if (mSelected)
        {
            stringbuilder.append(", ").append(GLContext.getApplicationContext().getResources().getString(R.string.tts_selected));
        } else
        {
            stringbuilder.append(", ").append(GLContext.getApplicationContext().getResources().getString(R.string.tts_not_selected));
        }
        if (isDim())
        {
            stringbuilder.append(", ").append(GLContext.getApplicationContext().getString(R.string.disable));
        }
        return stringbuilder.toString();
    }

    protected void onDraw()
    {
        boolean flag;
        if (mShapeBackground != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag & checkShapeBackgroundDrawingCondition())
        {
            mShapeBackground.draw(getMatrix(), getClipRect());
        }
        if (!isDim()) goto _L2; else goto _L1
_L1:
        if (mDimBackground == null) goto _L4; else goto _L3
_L3:
        mDimBackground.draw(getMatrix(), getClipRect());
_L6:
        if (mText != null && mShowText)
        {
            mText.draw(getMatrix(), getClipRect());
        }
        return;
_L4:
        if (mSelected)
        {
            if (mPressedBackground != null)
            {
                mPressedBackground.draw(getMatrix(), getClipRect());
            }
        } else
        if (mNormalBackground != null)
        {
            mNormalBackground.draw(getMatrix(), getClipRect());
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (mPressed || mSelected)
        {
            if (mHighlight != null && mShowHighlight && mDrawHighlight)
            {
                mHighlight.draw(getMatrix(), getClipRect());
            }
            if (mPressedBackground != null)
            {
                mPressedBackground.draw(getMatrix(), getClipRect());
            } else
            if (mNormalBackground != null)
            {
                mNormalBackground.draw(getMatrix(), getClipRect());
            }
        } else
        if (mNormalBackground != null)
        {
            mNormalBackground.draw(getMatrix(), getClipRect());
        } else
        if (mHighlight != null && mShowHighlight && mDrawHighlight)
        {
            mHighlight.draw(getMatrix(), getClipRect());
            if (!mHighlightFadeOut)
            {
                mDrawHighlight = false;
            }
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public boolean onKeyUpEvent(int i, KeyEvent keyevent)
    {
        boolean flag1 = true;
        i;
        JVM INSTR lookupswitch 2: default 32
    //                   23: 41
    //                   66: 41;
           goto _L1 _L2 _L2
_L1:
        boolean flag = super.onKeyUpEvent(i, keyevent);
_L4:
        return flag;
_L2:
        flag = flag1;
        if (isClickable())
        {
            flag = flag1;
            if (!isDim())
            {
                if (mSelected)
                {
                    setSelected(false);
                    setPressed(false);
                } else
                {
                    setSelected(true);
                }
                flag = flag1;
                if (mClickListener != null)
                {
                    if (!mMute)
                    {
                        ((AudioManager)GLContext.getApplicationContext().getSystemService("audio")).playSoundEffect(0);
                    }
                    if (mTitle != null && getVisibility() != 4 && GLContext.isTalkBackEnabled())
                    {
                        getContext().getTts().speak(getTtsString(), 0, null);
                    }
                    mClickListener.onClick(this);
                    return true;
                }
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if (isClickable()) goto _L2; else goto _L1
_L1:
        return true;
_L2:
        if (!isDim())
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mPressed)
        {
            setButtonPressed(false);
            setDrawHighlight(false);
            setDrawRippleEffect(false);
        }
        if (motionevent.getAction() == 2 && !contains(motionevent.getX(), motionevent.getY()))
        {
            motionevent.setAction(3);
        }
        if (motionevent.getAction() == 3)
        {
            resetDrag();
            return true;
        }
        continue; /* Loop/switch isn't completed */
        if (motionevent.getAction() == 0) goto _L1; else goto _L3
_L3:
        if (motionevent.getAction() == 1)
        {
            if (mSelected)
            {
                setSelected(false);
            } else
            {
                setSelected(true);
            }
            if (mClickListener != null)
            {
                if (!mMute)
                {
                    ((AudioManager)GLContext.getApplicationContext().getSystemService("audio")).playSoundEffect(0);
                }
                if (mTitle != null && getVisibility() != 4 && GLContext.isTalkBackEnabled())
                {
                    getContext().getTts().speak(getTtsString(), 0, null);
                }
                mClickListener.onClick(this);
                return true;
            }
        } else
        {
            return super.onTouchEvent(motionevent);
        }
        if (true) goto _L1; else goto _L4
_L4:
    }

    public void setSelected(boolean flag)
    {
        if (mSelected != flag)
        {
            mSelected = flag;
            updateTintColor();
        }
    }
}
