// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import com.samsung.android.graphics.spr.SemPathRenderingDrawable;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLContext, GLTextureStorage

public class GLResourceTexture extends GLTexture
{

    private GLTextureStorage mGLTextureStorage;
    private final int mResId;
    private GLTextureStorage.TextureInfo mTextureInfo;

    public GLResourceTexture(GLContext glcontext, float f, float f1, float f2, float f3, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mGLTextureStorage = glcontext.getGLTextureStorage();
        mResId = i;
    }

    public GLResourceTexture(GLContext glcontext, float f, float f1, int i)
    {
        super(glcontext, f, f1);
        mGLTextureStorage = glcontext.getGLTextureStorage();
        mResId = i;
    }

    public void clearTexture()
    {
        if (mGLTextureStorage.removeTexture(mResId) == 0 && mTextures != null)
        {
            GLES20.glDeleteTextures(1, new int[] {
                mTextures[0]
            }, 0);
            mTextures = null;
        }
        mTextureSharing = false;
        mTextureInfo = null;
    }

    protected void generateTexture()
    {
        mTextureInfo = mGLTextureStorage.getTextureInfo(mResId);
        if (mTextureInfo == null)
        {
            super.generateTexture();
            mGLTextureStorage.addTexture(mResId, mTextures[0], mBitmap.getWidth(), mBitmap.getHeight());
            mTextureSharing = false;
            return;
        }
        if (mTextures == null)
        {
            mTextures = new int[1];
        }
        mTextures[0] = mTextureInfo.mTextureID;
        mGLTextureStorage.addTexture(mResId, mTextures[0], mTextureInfo.mWidth, mTextureInfo.mHeight);
        mTextureSharing = true;
    }

    public void initSize()
    {
        this;
        JVM INSTR monitorenter ;
        if (mBitmap == null)
        {
            mBitmap = loadBitmap();
        }
        if (mBitmap == null) goto _L2; else goto _L1
_L1:
        if (getSizeSpecified()) goto _L4; else goto _L3
_L3:
        setSize(mBitmap.getWidth(), mBitmap.getHeight());
_L5:
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        setSize(getWidth(), getHeight());
          goto _L5
        Exception exception;
        exception;
        throw exception;
_L2:
label0:
        {
            if (getSizeSpecified())
            {
                break label0;
            }
            setSize(mTextureInfo.mWidth, mTextureInfo.mHeight);
        }
          goto _L5
        setSize(getWidth(), getHeight());
          goto _L5
    }

    protected Bitmap loadBitmap()
    {
        Object obj = null;
        this;
        JVM INSTR monitorenter ;
        GLTextureStorage.TextureInfo textureinfo;
        mTextureInfo = mGLTextureStorage.getTextureInfo(mResId);
        textureinfo = mTextureInfo;
        if (textureinfo == null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return ((Bitmap) (obj));
_L2:
        obj = GLContext.getApplicationContext().getResources().getDrawable(mResId, null);
        if (obj instanceof SemPathRenderingDrawable)
        {
            obj = Bitmap.createBitmap(((SemPathRenderingDrawable)obj).getBitmap());
            continue; /* Loop/switch isn't completed */
        }
        obj = BitmapFactory.decodeResource(GLContext.getApplicationContext().getResources(), mResId);
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    protected void loadGLTexture()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = mTextureSharing;
        if (!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        super.loadGLTexture();
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }
}
