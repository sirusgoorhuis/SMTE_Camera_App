// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            GLTextureStorage

public static class mHeight
{

    public int mCounter;
    public float mHeight;
    public int mTextureID;
    public float mWidth;

    public (int i, int j, float f, float f1)
    {
        mTextureID = i;
        mCounter = j;
        mWidth = f;
        mHeight = f1;
    }
}
