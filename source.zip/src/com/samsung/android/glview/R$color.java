// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;


// Referenced classes of package com.samsung.android.glview:
//            R

public static final class 
{

    public static final int default_black_color = 0x7f0b000e;
    public static final int default_text_color = 0x7f0b0011;
    public static final int default_white_color = 0x7f0b0013;

    public ()
    {
    }
}
