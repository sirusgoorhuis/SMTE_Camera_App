// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import com.samsung.android.util.SemLog;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLUtil, GLContext

public class GLNinePatch extends GLTexture
{

    private static final int COORDINATE_LENGTH = 2;
    private static final String TAG = "GLNinePatchTexture";
    private static final int TRIANGLE_INDEX_LENGTH = 3;
    private static final int U_INDEX = 0;
    private static final int VERTEX_LENGTH = 3;
    private static final int V_INDEX = 1;
    private static final int X_INDEX = 0;
    private static final int Y_INDEX = 1;
    private static final int Z_INDEX = 2;
    private int mDivX[];
    private int mDivY[];
    private int mNinePatchHeight;
    private int mNinePatchWidth;
    private int mResId;

    public GLNinePatch(GLContext glcontext, float f, float f1, float f2, float f3, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mNinePatchWidth = 0;
        mNinePatchHeight = 0;
        mResId = i;
        loadNinePatchResource();
    }

    public GLNinePatch(GLContext glcontext, float f, float f1, float f2, float f3, int i, float f4)
    {
        super(glcontext, f, f1, f2, f3);
        mNinePatchWidth = 0;
        mNinePatchHeight = 0;
        mResId = i;
        mAlpha = f4;
        loadNinePatchResource();
    }

    public GLNinePatch(GLContext glcontext, float f, float f1, int i)
    {
        super(glcontext, f, f1);
        mNinePatchWidth = 0;
        mNinePatchHeight = 0;
        mResId = i;
        loadNinePatchResource();
    }

    private boolean processNinePatchChunk(byte abyte0[])
    {
        this;
        JVM INSTR monitorenter ;
        int i;
        abyte0 = ByteBuffer.wrap(abyte0).order(ByteOrder.nativeOrder());
        i = abyte0.get();
        if (i != 0) goto _L2; else goto _L1
_L1:
        boolean flag = false;
_L8:
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        i = abyte0.get();
        int j = abyte0.get();
        abyte0.get();
        mDivX = new int[i];
        mDivY = new int[j];
        abyte0.getInt();
        abyte0.getInt();
        i = abyte0.getInt();
        j = abyte0.getInt();
        setPaddings(new Rect(i, abyte0.getInt(), j, abyte0.getInt()));
        abyte0.getInt();
        i = 0;
        int k = mDivX.length;
_L4:
        if (i >= k)
        {
            break; /* Loop/switch isn't completed */
        }
        mDivX[i] = abyte0.getInt();
        i++;
        if (true) goto _L4; else goto _L3
_L3:
        i = 0;
        k = mDivY.length;
_L6:
        if (i >= k)
        {
            break; /* Loop/switch isn't completed */
        }
        mDivY[i] = abyte0.getInt();
        i++;
        if (true) goto _L6; else goto _L5
_L5:
        flag = true;
        if (true) goto _L8; else goto _L7
_L7:
        abyte0;
        throw abyte0;
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        mDivX = null;
        mDivY = null;
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public int getIntrinsicHeight()
    {
        return mNinePatchHeight;
    }

    public int getIntrinsicWidth()
    {
        return mNinePatchWidth;
    }

    protected void initBuffers()
    {
        this;
        JVM INSTR monitorenter ;
        int l;
        int i1;
        int j1;
        int k1;
        clearBuffers();
        mVertexBuffer = GLUtil.getFloatBufferFromFloatArray(mVertices);
        l = mDivX.length + 1;
        i1 = mDivY.length + 1;
        j1 = mDivX.length + 2;
        k1 = mDivY.length + 2;
        int k = -1;
        if (mIndices == null)
        {
            mIndices = new byte[l * i1 * 2 * 3];
        }
          goto _L1
_L2:
        int j;
        if (j >= l)
        {
            break MISSING_BLOCK_LABEL_346;
        }
        byte abyte0[] = mIndices;
        int i;
        k++;
        abyte0[k] = (byte)(i * j1 + j);
        abyte0 = mIndices;
        k++;
        abyte0[k] = (byte)((i + 1) * j1 + j);
        abyte0 = mIndices;
        k++;
        abyte0[k] = (byte)((i + 1) * j1 + (j + 1));
        abyte0 = mIndices;
        k++;
        abyte0[k] = (byte)(i * j1 + j);
        abyte0 = mIndices;
        k++;
        abyte0[k] = (byte)((i + 1) * j1 + (j + 1));
        abyte0 = mIndices;
        k++;
        abyte0[k] = (byte)(i * j1 + (j + 1));
        j++;
          goto _L2
_L4:
        mIndexBuffer = GLUtil.getByteBufferFromByteArray(mIndices);
        mTexCoordBuffer = ByteBuffer.allocateDirect((j1 * k1 * 2 * 32) / 8).order(ByteOrder.nativeOrder());
        mTexFlipCoordBuffer = ByteBuffer.allocateDirect((j1 * k1 * 2 * 32) / 8).order(ByteOrder.nativeOrder());
        if (mCoordBuffer == null)
        {
            mCoordBuffer = new float[j1 * k1 * 2];
        }
        initCoordBuffer();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
_L1:
        i = 0;
_L5:
        if (i >= i1) goto _L4; else goto _L3
_L3:
        j = 0;
          goto _L2
        i++;
          goto _L5
    }

    protected void initCoordBuffer()
    {
        this;
        JVM INSTR monitorenter ;
        int k;
        int l;
        k = mDivX.length + 2;
        l = mDivY.length + 2;
        int i = 0;
          goto _L1
_L15:
        float f;
        int j;
        Object obj = mCoordBuffer;
          goto _L2
_L17:
        obj = mCoordBuffer;
          goto _L3
_L16:
        mCoordBuffer[(i * k + j) * 2 + 0] = (float)mDivX[j - 1] / (float)mNinePatchWidth;
          goto _L4
        obj;
        throw obj;
_L18:
        mCoordBuffer[(i * k + j) * 2 + 1] = (float)mDivY[i - 1] / (float)mNinePatchHeight;
          goto _L5
_L12:
        mTexCoordBuffer.asFloatBuffer().put(mCoordBuffer).position(0);
        i = 0;
          goto _L6
_L22:
        obj = mCoordBuffer;
          goto _L7
_L24:
        obj = mCoordBuffer;
          goto _L8
_L23:
        mCoordBuffer[(i * k + j) * 2 + 0] = 1.0F - (float)mDivX[j - 1] / (float)mNinePatchWidth;
          goto _L9
_L25:
        mCoordBuffer[(i * k + j) * 2 + 1] = (float)mDivY[i - 1] / (float)mNinePatchHeight;
          goto _L10
_L21:
        mTexFlipCoordBuffer.asFloatBuffer().put(mCoordBuffer).position(0);
        this;
        JVM INSTR monitorexit ;
        return;
_L1:
        if (i >= l) goto _L12; else goto _L11
_L11:
        j = 0;
_L19:
        if (j >= k) goto _L14; else goto _L13
_L13:
        if (j != 0 && j != k - 1) goto _L16; else goto _L15
_L2:
        if (j == 0)
        {
            f = 0.0F;
        } else
        {
            f = 1.0F;
        }
        obj[(i * k + j) * 2 + 0] = f;
_L4:
        if (i != 0 && i != l - 1) goto _L18; else goto _L17
_L3:
        if (i == 0)
        {
            f = 0.0F;
        } else
        {
            f = 1.0F;
        }
        obj[(i * k + j) * 2 + 1] = f;
_L5:
        j++;
          goto _L19
_L14:
        i++;
          goto _L1
_L6:
        if (i >= l) goto _L21; else goto _L20
_L20:
        j = 0;
_L26:
        if (j >= k)
        {
            break MISSING_BLOCK_LABEL_471;
        }
        if (j != 0 && j != k - 1) goto _L23; else goto _L22
_L7:
        if (j == 0)
        {
            f = 1.0F;
        } else
        {
            f = 0.0F;
        }
        obj[(i * k + j) * 2 + 0] = f;
_L9:
        if (i != 0 && i != l - 1) goto _L25; else goto _L24
_L8:
        if (i == 0)
        {
            f = 0.0F;
        } else
        {
            f = 1.0F;
        }
        obj[(i * k + j) * 2 + 1] = f;
_L10:
        j++;
          goto _L26
        i++;
          goto _L6
    }

    protected Bitmap loadBitmap()
    {
        this;
        JVM INSTR monitorenter ;
        Bitmap bitmap;
        if (mBitmap == null)
        {
            loadNinePatchResource();
        }
        bitmap = mBitmap;
        this;
        JVM INSTR monitorexit ;
        return bitmap;
        Exception exception;
        exception;
        throw exception;
    }

    protected void loadNinePatchResource()
    {
        try
        {
            mBitmap = BitmapFactory.decodeResource(GLContext.getApplicationContext().getResources(), mResId);
        }
        catch (OutOfMemoryError outofmemoryerror)
        {
            SemLog.secE("GLNinePatchTexture", (new StringBuilder()).append("ResId : ").append(mResId).toString());
            return;
        }
        mNinePatchWidth = mBitmap.getWidth();
        mNinePatchHeight = mBitmap.getHeight();
        processNinePatchChunk(mBitmap.getNinePatchChunk());
    }

    public void setNinePatch(int i)
    {
        mResId = i;
        loadNinePatchResource();
        reLoad();
    }

    public void setSize(float f, float f1)
    {
        super.setSize(f, f1);
        setVertices();
        initBuffers();
    }

    protected void setVertices()
    {
        this;
        JVM INSTR monitorenter ;
        float f1;
        float f2;
        int j1;
        int k1;
        int l1;
        int i2;
        j1 = mDivX.length + 2;
        k1 = mDivY.length + 2;
        f1 = getLeft();
        f2 = getTop();
        l1 = (int)getWidth();
        i2 = (int)getHeight();
        int i;
        int j;
        j = 0;
        i = 0;
        int k = mDivX.length / 2;
_L2:
        if (i >= k)
        {
            break; /* Loop/switch isn't completed */
        }
        j += mDivX[i * 2 + 1] - mDivX[i * 2];
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        if (l1 > mNinePatchWidth) goto _L4; else goto _L3
_L3:
        i = 0;
_L7:
        k = 0;
        j = 0;
        int l = mDivY.length / 2;
_L6:
        if (j >= l)
        {
            break; /* Loop/switch isn't completed */
        }
        k += mDivY[j * 2 + 1] - mDivY[j * 2];
        j++;
        if (true) goto _L6; else goto _L5
_L4:
        i = (l1 - mNinePatchWidth - j) / (mDivX.length / 2) + 1;
          goto _L7
_L5:
        if (i2 > mNinePatchHeight) goto _L9; else goto _L8
_L8:
        j = 0;
_L14:
        if (mVertices == null)
        {
            mVertices = new float[j1 * k1 * 3];
        }
          goto _L10
_L22:
        Object obj = mVertices;
          goto _L11
_L24:
        obj = mVertices;
          goto _L12
_L16:
        mVertices[(k * j1 + i1) * 3 + 2] = 0.0F;
        i1++;
          goto _L13
_L9:
        j = (i2 - mNinePatchHeight - k) / (mDivY.length / 2) + 1;
          goto _L14
_L23:
        mVertices[(k * j1 + i1) * 3 + 0] = (float)((double)mDivX[i1 - 1] + (double)i * Math.ceil((float)(i1 - 1) / 2.0F)) + f1;
          goto _L15
        obj;
        throw obj;
_L25:
        mVertices[(k * j1 + i1) * 3 + 1] = (float)((double)mDivY[k - 1] + (double)j * Math.ceil((float)(k - 1) / 2.0F)) + f2;
          goto _L16
_L21:
        k++;
          goto _L17
_L19:
        return;
_L10:
        k = 0;
_L17:
        if (k >= k1) goto _L19; else goto _L18
_L18:
        i1 = 0;
_L13:
        if (i1 >= j1) goto _L21; else goto _L20
_L20:
        if (i1 != 0 && i1 != j1 - 1) goto _L23; else goto _L22
_L11:
        float f;
        int i1;
        if (i1 == 0)
        {
            f = f1;
        } else
        {
            f = (float)l1 + f1;
        }
        obj[(k * j1 + i1) * 3 + 0] = f;
_L15:
        if (k != 0 && k != k1 - 1) goto _L25; else goto _L24
_L12:
        if (k == 0)
        {
            f = f2;
        } else
        {
            f = (float)i2 + f2;
        }
        obj[(k * j1 + i1) * 3 + 1] = f;
          goto _L16
    }
}
