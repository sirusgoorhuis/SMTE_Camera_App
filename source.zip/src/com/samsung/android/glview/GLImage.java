// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLBitmapTexture, GLTexture, GLFileTexture, 
//            GLResourceTexture, GLByteArrayTexture, GLUtil, GLContext

public class GLImage extends GLView
{

    protected GLTexture mImage;
    protected int mImageId;
    protected float mResourceOffsetX;
    protected float mResourceOffsetY;

    public GLImage(GLContext glcontext, float f, float f1, float f2, float f3, Bitmap bitmap)
    {
        super(glcontext, f, f1, f2, f3);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (bitmap != null)
        {
            mImage = new GLBitmapTexture(glcontext, 0.0F, 0.0F, f2, f3, bitmap);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, float f, float f1, float f2, float f3, String s)
    {
        super(glcontext, f, f1, f2, f3);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (s != null)
        {
            mImage = new GLFileTexture(glcontext, 0.0F, 0.0F, f2, f3, s);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, float f, float f1, float f2, float f3, boolean flag, int i)
    {
        super(glcontext, f, f1, f2, f3);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (i != 0)
        {
            if (flag)
            {
                mImage = new GLResourceTexture(glcontext, 0.0F, 0.0F, f2, f3, i);
            } else
            {
                mImage = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
            }
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
        mImageId = i;
    }

    public GLImage(GLContext glcontext, float f, float f1, float f2, float f3, byte abyte0[])
    {
        super(glcontext, f, f1, f2, f3);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (abyte0 != null)
        {
            mImage = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, f2, f3, abyte0);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, float f, float f1, float f2, int i)
    {
        super(glcontext, f, f1, f2);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (i != 0)
        {
            mImage = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
        mImageId = i;
    }

    public GLImage(GLContext glcontext, float f, float f1, int i)
    {
        super(glcontext, f, f1);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (i != 0)
        {
            mImage = new GLResourceTexture(glcontext, 0.0F, 0.0F, i);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
        mImageId = i;
    }

    public GLImage(GLContext glcontext, float f, float f1, Bitmap bitmap)
    {
        super(glcontext, f, f1);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (bitmap != null)
        {
            mImage = new GLBitmapTexture(glcontext, 0.0F, 0.0F, bitmap);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, float f, float f1, String s)
    {
        super(glcontext, f, f1);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (s != null)
        {
            mImage = new GLFileTexture(glcontext, 0.0F, 0.0F, s);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, float f, float f1, byte abyte0[])
    {
        super(glcontext, f, f1);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (abyte0 != null)
        {
            mImage = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, abyte0);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, Bitmap bitmap)
    {
        super(glcontext, 0.0F, 0.0F);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (bitmap != null)
        {
            mImage = new GLBitmapTexture(glcontext, 0.0F, 0.0F, bitmap);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, String s)
    {
        super(glcontext, 0.0F, 0.0F);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (s != null)
        {
            mImage = new GLFileTexture(glcontext, 0.0F, 0.0F, s);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public GLImage(GLContext glcontext, byte abyte0[])
    {
        super(glcontext, 0.0F, 0.0F);
        mResourceOffsetX = 0.0F;
        mResourceOffsetY = 0.0F;
        if (abyte0 != null)
        {
            mImage = new GLByteArrayTexture(glcontext, 0.0F, 0.0F, abyte0);
        }
        if (mImage != null)
        {
            mImage.mParent = this;
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        if (mImage != null)
        {
            mImage.clear();
            mImage = null;
        }
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getLoaded()
    {
        return mImage.getLoaded();
    }

    public void initSize()
    {
        float f2 = 0.0F;
        float f = 0.0F;
        float f3 = 0.0F;
        float f1 = f3;
        if (mImage != null)
        {
            if (mImage.getWidth() > 0.0F)
            {
                f = mImage.getWidth();
            }
            f1 = f3;
            f2 = f;
            if (mImage.getHeight() > 0.0F)
            {
                f1 = mImage.getHeight();
                f2 = f;
            }
        }
        setSize(f2, f1);
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        if (mImage != null)
        {
            mImage.onAlphaUpdated();
        }
    }

    protected void onDraw()
    {
        if (mImage != null)
        {
            mImage.draw(getMatrix(), getClipRect());
        }
    }

    public void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        if (mImage != null)
        {
            mImage.onLayoutUpdated();
        }
    }

    protected boolean onLoad()
    {
        if (mImage != null)
        {
            return mImage.load();
        } else
        {
            return true;
        }
    }

    public void onOrientationChanged(int i)
    {
        super.onOrientationChanged(i);
    }

    public void onReset()
    {
        if (mImage != null)
        {
            mImage.reset();
        }
    }

    protected void onVisibilityChanged(int i)
    {
        super.onVisibilityChanged(i);
        if (mImage != null)
        {
            mImage.onVisibilityChanged(i);
        }
    }

    public void setFlip(boolean flag)
    {
        if (mImage != null)
        {
            mImage.setFlip(flag);
        }
    }

    public void setHeight(float f)
    {
        super.setHeight(f);
        if (mImage != null)
        {
            mImage.setHeight(f);
        }
    }

    public void setImageBitmap(Bitmap bitmap)
    {
        this;
        JVM INSTR monitorenter ;
        if (mImage != null)
        {
            mImage.clear();
        }
        if (bitmap == null)
        {
            break MISSING_BLOCK_LABEL_53;
        }
        if (!mSizeGiven)
        {
            break MISSING_BLOCK_LABEL_71;
        }
        mImage = new GLBitmapTexture(getContext(), 0.0F, 0.0F, getWidth(), getHeight(), bitmap);
_L1:
        if (mImage != null)
        {
            mImage.mParent = this;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        mImage = new GLBitmapTexture(getContext(), 0.0F, 0.0F, bitmap);
          goto _L1
        bitmap;
        throw bitmap;
    }

    public boolean setImageOffset(float f, float f1)
    {
        float f2 = mImage.getWidth();
        float f3 = mImage.getHeight();
        if (f > getWidth() - f2 || f1 > getHeight() - f3)
        {
            return false;
        }
        mResourceOffsetX = f;
        mResourceOffsetY = f1;
        if (getWidth() >= f2 && getHeight() >= f3 && (!GLUtil.floatEquals(getWidth(), f2) || !GLUtil.floatEquals(getHeight(), f3)))
        {
            mImage.moveLayoutAbsolute(mResourceOffsetX, mResourceOffsetY);
        }
        return true;
    }

    public void setImageResources(int i)
    {
        if (mImage != null)
        {
            mImage.clear();
        }
        if (i != 0)
        {
            mImage = new GLResourceTexture(getContext(), 0.0F, 0.0F, i);
            mImage.mParent = this;
        }
    }

    public void setSampleSize(int i)
    {
        if (mImage != null)
        {
            if (mImage instanceof GLByteArrayTexture)
            {
                ((GLByteArrayTexture)mImage).setSampleSize(i);
            } else
            if (mImage instanceof GLFileTexture)
            {
                ((GLFileTexture)mImage).setSampleSize(i);
                return;
            }
        }
    }

    public void setShaderParameter(float f)
    {
        if (mImage != null)
        {
            mImage.setShaderParameter(f);
        }
    }

    public void setShaderProgram(int i)
    {
        if (mImage != null)
        {
            mImage.setShaderProgram(i);
        }
    }

    public void setShaderStep(float f)
    {
        if (mImage != null)
        {
            mImage.setShaderStep(f);
        }
    }

    public void setSize(float f, float f1)
    {
        super.setSize(f, f1);
        if (mImage != null)
        {
            mImage.setSize(f, f1);
        }
    }

    public void setTint(int i)
    {
        super.setTint(i);
        if (mImage != null)
        {
            mImage.setTint(i);
        }
    }

    public void setWidth(float f)
    {
        super.setWidth(f);
        if (mImage != null)
        {
            mImage.setWidth(f);
        }
    }
}
