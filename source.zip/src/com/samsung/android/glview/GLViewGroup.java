// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.PointF;
import android.graphics.Rect;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package com.samsung.android.glview:
//            GLView, GLContext, GLUtil

public class GLViewGroup extends GLView
{

    private static final int FLAG_MASK_FOCUSABILITY = 0x60000;
    public static final int FOCUS_AFTER_DESCENDANTS = 0x40000;
    public static final int FOCUS_BEFORE_DESCENDANTS = 0x20000;
    public static final int FOCUS_BLOCK_DESCENDANTS = 0x60000;
    private boolean mDepthSortNeeded;
    protected CopyOnWriteArrayList mGLViews;
    private int mViewGroupFlags;

    public GLViewGroup(GLContext glcontext)
    {
        super(glcontext, 0.0F, 0.0F);
        mGLViews = new CopyOnWriteArrayList();
        mDepthSortNeeded = false;
        initViewGroup();
    }

    public GLViewGroup(GLContext glcontext, float f, float f1)
    {
        super(glcontext, f, f1);
        mGLViews = new CopyOnWriteArrayList();
        mDepthSortNeeded = false;
        initViewGroup();
    }

    public GLViewGroup(GLContext glcontext, float f, float f1, float f2, float f3)
    {
        super(glcontext, f, f1, f2, f3);
        mGLViews = new CopyOnWriteArrayList();
        mDepthSortNeeded = false;
        initViewGroup();
    }

    private void initViewGroup()
    {
        setDescendantFocusability(0x20000);
    }

    public void addAccessibilityBaseViewNode(ArrayList arraylist)
    {
        if (!mInScreen || getVisibility() != 0)
        {
            return;
        } else
        {
            arraylist.add(this);
            return;
        }
    }

    public void addAccessibilityChildViewNode(ArrayList arraylist)
    {
        Iterator iterator = mGLViews.iterator();
        if (mInScreen && getVisibility() == 0)
        {
            arraylist.add(this);
            while (iterator.hasNext()) 
            {
                GLView glview = (GLView)iterator.next();
                glview.setParentId(getId());
                glview.addAccessibilityChildViewNode(arraylist);
            }
        }
    }

    public void addView(int i, GLView glview)
    {
        if (glview == null)
        {
            throw new IllegalArgumentException();
        }
        glview.mParent = this;
        try
        {
            mGLViews.add(i, glview);
        }
        catch (IndexOutOfBoundsException indexoutofboundsexception)
        {
            mGLViews.add(glview);
        }
        glview.onLayoutUpdated();
        glview.onAlphaUpdated();
        mDepthSortNeeded = true;
        if (!mSizeGiven)
        {
            updateSize();
        }
    }

    public void addView(GLView glview)
    {
        if (glview == null)
        {
            throw new IllegalArgumentException();
        }
        glview.mParent = this;
        glview.onOrientationChanged(GLContext.getLastOrientation());
        mGLViews.add(glview);
        glview.onLayoutUpdated();
        glview.onAlphaUpdated();
        mDepthSortNeeded = true;
        if (!mSizeGiven)
        {
            updateSize();
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).clear()) { }
        break MISSING_BLOCK_LABEL_39;
        Exception exception;
        exception;
        throw exception;
        mGLViews.clear();
        super.clear();
        this;
        JVM INSTR monitorexit ;
    }

    public boolean contains(float f, float f1)
    {
        float f2;
        float f3;
        f3 = f;
        f2 = f1;
        if (mInScreen) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if (mRotateDegree != 0)
        {
            float af[] = new float[2];
            float af1[] = getLeftTop((getOrientation() + mDefaultOrientation) % 4);
            af1[0] = (getLeft() + getRight()) / 2.0F;
            af1[1] = (getTop() + getBottom()) / 2.0F;
            GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, af1[0], af1[1]);
            PointF pointf = GLUtil.rotatePoint(f, f1, -((getOrientation() + mDefaultOrientation) % 4) * 90 - getRotateDegree(), af1[0], af1[1]);
            f3 = pointf.x;
            f2 = pointf.y;
        }
        Iterator iterator = mGLViews.iterator();
        GLView glview;
        do
        {
            if (!iterator.hasNext())
            {
                continue; /* Loop/switch isn't completed */
            }
            glview = (GLView)iterator.next();
        } while (glview.getVisibility() != 0 || !glview.contains(f3, f2));
        break; /* Loop/switch isn't completed */
        if (true) goto _L1; else goto _L3
_L3:
        return true;
    }

    public boolean contains(GLView glview)
    {
        if (glview != null)
        {
            Iterator iterator = mGLViews.iterator();
            while (iterator.hasNext()) 
            {
                if ((GLView)iterator.next() == glview)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public void dumpViewHierarchy(int i)
    {
        Object obj = new StringBuilder();
        for (int j = 0; j < i; j++)
        {
            ((StringBuilder) (obj)).append("| ");
        }

        if (getClipRect() != null)
        {
            SemLog.secE("DUMP", (new StringBuilder()).append(((StringBuilder) (obj)).toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append(") Focusable=").append(isFocusable()).append(", Visible=").append(isVisible()).append(", Clip(Manual:").append(mManualClip).append(",").append(getClipRect().left).append(",").append(getClipRect().top).append(",").append(getClipRect().width()).append(",").append(getClipRect().height()).append(")").toString());
        } else
        {
            SemLog.secE("DUMP", (new StringBuilder()).append(((StringBuilder) (obj)).toString()).append(getClass().getSimpleName()).append("(").append(getLeft()).append(",").append(getTop()).append(",").append(getWidth()).append(",").append(getHeight()).append(") Focusable=").append(isFocusable()).append(", Visible=").append(isVisible()).toString());
        }
        for (obj = mGLViews.iterator(); ((Iterator) (obj)).hasNext(); ((GLView)((Iterator) (obj)).next()).dumpViewHierarchy(i + 1)) { }
    }

    public GLView findNextFocusFromView(GLView glview, int i)
    {
        if (glview != null) goto _L2; else goto _L1
_L1:
        GLView glview2 = null;
_L6:
        return glview2;
_L2:
        float f;
        float f1;
        GLView glview1;
        Iterator iterator;
        glview1 = null;
        glview2 = super.findNextFocusFromView(glview, i);
        if (glview2 != null)
        {
            glview1 = glview2;
        }
        f = (float)(glview.getOriginalClipRect().left + glview.getOriginalClipRect().right) / 2.0F;
        f1 = (float)(glview.getOriginalClipRect().top + glview.getOriginalClipRect().bottom) / 2.0F;
        iterator = mGLViews.iterator();
_L4:
        do
        {
            glview2 = glview1;
            if (!iterator.hasNext())
            {
                continue; /* Loop/switch isn't completed */
            }
            glview2 = ((GLView)iterator.next()).findNextFocusFromView(glview, i);
            if (glview2 != null)
            {
label0:
                {
                    if (glview1 != null)
                    {
                        break label0;
                    }
                    glview1 = glview2;
                }
            }
        } while (true);
        continue; /* Loop/switch isn't completed */
        float f2 = (float)(glview2.getOriginalClipRect().left + glview2.getOriginalClipRect().right) / 2.0F;
        float f3 = (float)(glview2.getOriginalClipRect().top + glview2.getOriginalClipRect().bottom) / 2.0F;
        float f4 = (float)(glview1.getOriginalClipRect().left + glview1.getOriginalClipRect().right) / 2.0F;
        float f5 = (float)(glview1.getOriginalClipRect().top + glview1.getOriginalClipRect().bottom) / 2.0F;
        float f6 = Math.abs(f - f2);
        float f7 = Math.abs(f1 - f3);
        float f8 = Math.abs(f - f4);
        float f9 = Math.abs(f1 - f5);
        switch (i)
        {
        case 17: // '\021'
        case 49: // '1'
            if (f2 >= f4 && f2 <= f && f6 >= f7)
            {
                if (Math.abs(f7 - f9) <= Math.abs(f6 - f8))
                {
                    glview1 = glview2;
                } else
                if (f7 <= f9)
                {
                    glview1 = glview2;
                }
            }
            break;

        case 66: // 'B'
        case 98: // 'b'
            if (f2 <= f4 && f2 >= f && f6 >= f7)
            {
                if (Math.abs(f7 - f9) <= Math.abs(f6 - f8))
                {
                    glview1 = glview2;
                } else
                if (f7 <= f9)
                {
                    glview1 = glview2;
                }
            }
            break;

        case 33: // '!'
        case 65: // 'A'
            if (f3 >= f5 && f3 <= f1 && f6 <= f7)
            {
                if (Math.abs(f7 - f9) >= Math.abs(f6 - f8))
                {
                    glview1 = glview2;
                } else
                if (f6 <= f8)
                {
                    glview1 = glview2;
                }
            }
            break;

        case 82: // 'R'
        case 130: 
            if (f3 <= f5 && f3 >= f1 && f6 <= f7)
            {
                if (Math.abs(f7 - f9) >= Math.abs(f6 - f8))
                {
                    glview1 = glview2;
                } else
                if (f6 <= f8)
                {
                    glview1 = glview2;
                }
            }
            break;
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (true) goto _L6; else goto _L5
_L5:
    }

    public GLView findViewByCoordinate(float f, float f1)
    {
        Object obj = null;
        float f3 = f;
        float f2 = f1;
        if (!mInScreen)
        {
            obj = null;
        } else
        {
            if (getVisibility() != 0)
            {
                return null;
            }
            if (getBypassTouch())
            {
                return null;
            }
            if (mRotateDegree != 0)
            {
                float af[] = new float[2];
                float af1[] = getLeftTop((getOrientation() + mDefaultOrientation) % 4);
                af1[0] = (getLeft() + getRight()) / 2.0F;
                af1[1] = (getTop() + getBottom()) / 2.0F;
                GLUtil.getGLCoordinateFromScreenCoordinate(mGLContext, af, af1[0], af1[1]);
                PointF pointf = GLUtil.rotatePoint(f, f1, -((getOrientation() + mDefaultOrientation) % 4) * 90 - getRotateDegree(), af1[0], af1[1]);
                f3 = pointf.x;
                f2 = pointf.y;
            }
            Iterator iterator = mGLViews.iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                GLView glview = ((GLView)iterator.next()).findViewByCoordinate(f3, f2);
                if (glview != null)
                {
                    obj = glview;
                }
            } while (true);
            if (obj != null)
            {
                return ((GLView) (obj));
            }
            obj = this;
            if (!contains(f, f1))
            {
                return null;
            }
        }
        return ((GLView) (obj));
    }

    public GLView findViewById(int i)
    {
        if (getId() == i)
        {
            return this;
        }
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext();)
        {
            GLView glview = ((GLView)iterator.next()).findViewById(i);
            if (glview != null)
            {
                return glview;
            }
        }

        return null;
    }

    public GLView findViewByObjectTag(String s)
    {
        if (s.equals(getObjectTag()))
        {
            return this;
        }
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext();)
        {
            GLView glview = ((GLView)iterator.next()).findViewByObjectTag(s);
            if (glview != null && glview.isVisible() == 0 && glview.getClipRect().width() > 0 && glview.getClipRect().height() > 0)
            {
                return glview;
            }
        }

        return null;
    }

    public GLView findViewByTag(int i)
    {
        if (getTag() == i)
        {
            return this;
        }
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext();)
        {
            GLView glview = ((GLView)iterator.next()).findViewByTag(i);
            if (glview != null)
            {
                return glview;
            }
        }

        return null;
    }

    public GLView findViewFromLeftMostTop()
    {
        GLView glview = null;
        if (mInScreen) goto _L2; else goto _L1
_L1:
        GLView glview1 = glview;
_L4:
        return glview1;
_L2:
        glview1 = glview;
        if (getVisibility() != 0)
        {
            continue;
        }
        glview1 = glview;
        if (getBypassTouch())
        {
            continue;
        }
        glview = null;
        Iterator iterator = mGLViews.iterator();
        do
        {
            glview1 = glview;
            if (!iterator.hasNext())
            {
                continue;
            }
            glview1 = ((GLView)iterator.next()).findViewFromLeftMostTop();
            if (glview1 != null && glview1.isFocusable())
            {
                GLView glview2 = glview;
                if (glview == null)
                {
                    glview2 = glview1;
                }
                if (glview1.getCurrentLeft() < glview2.getCurrentLeft())
                {
                    glview = glview1;
                } else
                {
                    glview = glview2;
                    if (glview1.getCurrentLeft() == glview2.getCurrentLeft())
                    {
                        glview = glview2;
                        if (glview1.getCurrentTop() <= glview2.getCurrentTop())
                        {
                            glview = glview1;
                        }
                    }
                }
            }
        } while (true);
        if (true) goto _L4; else goto _L3
_L3:
    }

    public GLView findViewFromLeftMostTop(int i, float f, float f1)
    {
        GLView glview1;
        glview1 = null;
        break MISSING_BLOCK_LABEL_3;
_L4:
        GLView glview;
        Iterator iterator;
        do
        {
            return glview1;
        } while (getVisibility() != 0 || getBypassTouch());
        glview1 = super.findViewFromLeftMostTop(i, f, f1);
        iterator = null;
        glview = iterator;
        if (glview1 != null)
        {
            glview = iterator;
            if (glview1.isFocusable())
            {
                glview = glview1;
            }
        }
        iterator = mGLViews.iterator();
_L2:
        do
        {
            glview1 = glview;
            if (!iterator.hasNext())
            {
                continue; /* Loop/switch isn't completed */
            }
            glview1 = ((GLView)iterator.next()).findViewFromLeftMostTop(i, f, f1);
            if (glview1 != null && glview1.isFocusable())
            {
label0:
                {
                    if (glview != null)
                    {
                        break label0;
                    }
                    glview = glview1;
                }
            }
        } while (true);
        continue; /* Loop/switch isn't completed */
        float f2 = (float)(glview1.getOriginalClipRect().left + glview1.getOriginalClipRect().right) / 2.0F;
        float f3 = (float)(glview1.getOriginalClipRect().top + glview1.getOriginalClipRect().bottom) / 2.0F;
        float f4 = (float)(glview.getOriginalClipRect().left + glview.getOriginalClipRect().right) / 2.0F;
        float f5 = (float)(glview.getOriginalClipRect().top + glview.getOriginalClipRect().bottom) / 2.0F;
        switch (i)
        {
        case 0: // '\0'
            if (f3 < f5)
            {
                glview = glview1;
            } else
            if (GLUtil.floatEquals(f3, f5) && f2 <= f4)
            {
                glview = glview1;
            }
            break;

        case 2: // '\002'
            if (f3 > f5)
            {
                glview = glview1;
            } else
            if (GLUtil.floatEquals(f3, f5) && f2 > f4)
            {
                glview = glview1;
            }
            break;

        case 1: // '\001'
            if (f2 > f4)
            {
                glview = glview1;
            } else
            if (GLUtil.floatEquals(f2, f4) && f2 <= f5)
            {
                glview = glview1;
            }
            break;

        case 3: // '\003'
            if (f2 < f4)
            {
                glview = glview1;
            } else
            if (GLUtil.floatEquals(f2, f4) && f3 >= f5)
            {
                glview = glview1;
            }
            break;
        }
        if (true) goto _L2; else goto _L1
_L1:
        if (true) goto _L4; else goto _L3
_L3:
    }

    public GLView findViewOnSameLine(GLView glview, int i)
    {
        if (glview != null) goto _L2; else goto _L1
_L1:
        GLView glview2 = null;
_L6:
        return glview2;
_L2:
        float f;
        float f1;
        GLView glview1;
        Iterator iterator;
        glview1 = null;
        glview2 = super.findViewOnSameLine(glview, i);
        if (glview2 != null)
        {
            glview1 = glview2;
        }
        f = (float)(glview.getOriginalClipRect().left + glview.getOriginalClipRect().right) / 2.0F;
        f1 = (float)(glview.getOriginalClipRect().top + glview.getOriginalClipRect().bottom) / 2.0F;
        iterator = mGLViews.iterator();
_L4:
        do
        {
            glview2 = glview1;
            if (!iterator.hasNext())
            {
                continue; /* Loop/switch isn't completed */
            }
            glview2 = ((GLView)iterator.next()).findViewOnSameLine(glview, i);
            if (glview2 != null && glview2.isFocusable())
            {
label0:
                {
                    if (glview1 != null)
                    {
                        break label0;
                    }
                    glview1 = glview2;
                }
            }
        } while (true);
        continue; /* Loop/switch isn't completed */
        float f2 = (float)(glview2.getOriginalClipRect().left + glview2.getOriginalClipRect().right) / 2.0F;
        float f3 = (float)(glview2.getOriginalClipRect().top + glview2.getOriginalClipRect().bottom) / 2.0F;
        float f4 = (float)(glview1.getOriginalClipRect().left + glview1.getOriginalClipRect().right) / 2.0F;
        float f5 = (float)(glview1.getOriginalClipRect().top + glview1.getOriginalClipRect().bottom) / 2.0F;
        switch (i)
        {
        case 17: // '\021'
        case 49: // '1'
            if (f2 > f4 && f2 < f)
            {
                glview1 = glview2;
            }
            break;

        case 66: // 'B'
        case 98: // 'b'
            if (f2 < f4 && f2 > f)
            {
                glview1 = glview2;
            }
            break;

        case 33: // '!'
        case 65: // 'A'
            if (f3 > f5 && f3 < f1)
            {
                glview1 = glview2;
            }
            break;

        case 82: // 'R'
        case 130: 
            if (f3 < f5 && f3 > f1)
            {
                glview1 = glview2;
            }
            break;
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (true) goto _L6; else goto _L5
_L5:
    }

    public int getDescendantFocusability()
    {
        return mViewGroupFlags & 0x60000;
    }

    public int getIndex(GLView glview)
    {
        Iterator iterator = mGLViews.iterator();
        for (int i = 0; iterator.hasNext(); i++)
        {
            if (iterator.next() == glview)
            {
                return i;
            }
        }

        return -1;
    }

    public boolean getLoaded()
    {
        return true;
    }

    public int getSize()
    {
        return mGLViews.size();
    }

    public GLView getView(int i)
    {
        return (GLView)mGLViews.get(i);
    }

    public void initSize()
    {
        float f1 = getLeft();
        float f = getTop();
        Iterator iterator = mGLViews.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            GLView glview = (GLView)iterator.next();
            float f2 = f1;
            if (glview.getLeft() + glview.getWidth() > f1)
            {
                f2 = glview.getLeft() + glview.getWidth();
            }
            f1 = f2;
            if (glview.getTop() + glview.getHeight() > f)
            {
                f = glview.getTop() + glview.getHeight();
                f1 = f2;
            }
        } while (true);
        if (!getSizeSpecified())
        {
            updateSize(f1 - getLeft(), f - getTop());
        }
    }

    public boolean isDepthSorted()
    {
        Iterator iterator = mGLViews.iterator();
        GLView glview1;
        for (GLView glview = null; iterator.hasNext(); glview = glview1)
        {
            glview1 = (GLView)iterator.next();
            if (glview != null && glview.getLayoutZ() > glview1.getLayoutZ())
            {
                return false;
            }
        }

        return true;
    }

    public void onAlphaUpdated()
    {
        super.onAlphaUpdated();
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onAlphaUpdated()) { }
    }

    public void onDepthUpdated()
    {
        super.onDepthUpdated();
        mDepthSortNeeded = true;
    }

    protected void onDraw()
    {
        if (mDepthSortNeeded)
        {
            sortViews();
        }
        float af[] = getMatrix();
        Rect rect = getClipRect();
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); clearClip())
        {
            GLView glview = (GLView)iterator.next();
            clip();
            glview.draw(af, rect);
        }

    }

    public void onHoverIndicatorColorChanged()
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onHoverIndicatorColorChanged()) { }
        super.onHoverIndicatorColorChanged();
    }

    public void onLayoutUpdated()
    {
        super.onLayoutUpdated();
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onLayoutUpdated()) { }
    }

    protected boolean onLoad()
    {
        return true;
    }

    protected void onOrientationChanged(int i)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onOrientationChanged(i)) { }
        super.onOrientationChanged(i);
    }

    protected void onOutOfScreen()
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onOutOfScreen()) { }
        super.onOutOfScreen();
    }

    public boolean onRequestFocusInDescendants(int i, GLView glview)
    {
        int k = getSize();
        CopyOnWriteArrayList copyonwritearraylist;
        int j;
        byte byte0;
        if ((i & 2) != 0)
        {
            j = 0;
            byte0 = 1;
        } else
        {
            j = k - 1;
            byte0 = -1;
            k = -1;
        }
        copyonwritearraylist = (CopyOnWriteArrayList)mGLViews.clone();
        do
        {
            if (j == k || j >= copyonwritearraylist.size())
            {
                return false;
            }
            GLView glview1 = (GLView)copyonwritearraylist.get(j);
            if (glview1.isVisible() == 0 && (glview1.isFocusable() || (glview1 instanceof GLViewGroup)) && glview1.requestFocus(i, glview))
            {
                return true;
            }
            j += byte0;
        } while (true);
    }

    public void onReset()
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).reset()) { }
    }

    protected void onVisibilityChanged(int i)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).onVisibilityChanged(i)) { }
        super.onVisibilityChanged(i);
    }

    public void removeView(GLView glview)
    {
        if (glview == null)
        {
            return;
        }
        if (!mGLViews.remove(glview))
        {
            for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).removeView(glview)) { }
        }
        glview.onLayoutUpdated();
        glview.onAlphaUpdated();
        glview.onVisibilityChanged(8);
    }

    public boolean requestFocus(int i, GLView glview)
    {
        int j = getDescendantFocusability();
        j;
        JVM INSTR lookupswitch 3: default 40
    //                   131072: 79
    //                   262144: 103
    //                   393216: 68;
           goto _L1 _L2 _L3 _L4
_L1:
        throw new IllegalStateException((new StringBuilder()).append("descendant focusability must be one of FOCUS_BEFORE_DESCENDANTS, FOCUS_AFTER_DESCENDANTS, FOCUS_BLOCK_DESCENDANTS but is ").append(j).toString());
_L4:
        boolean flag = super.requestFocus(i, glview);
_L6:
        return flag;
_L2:
        boolean flag1 = super.requestFocus(i, glview);
        flag = flag1;
        if (!flag1)
        {
            return onRequestFocusInDescendants(i, glview);
        }
        continue; /* Loop/switch isn't completed */
_L3:
        boolean flag2 = onRequestFocusInDescendants(i, glview);
        flag = flag2;
        if (!flag2)
        {
            return super.requestFocus(i, glview);
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public void setDescendantFocusability(int i)
    {
        switch (i)
        {
        default:
            throw new IllegalArgumentException("must be one of FOCUS_BEFORE_DESCENDANTS, FOCUS_AFTER_DESCENDANTS, FOCUS_BLOCK_DESCENDANTS");

        case 131072: 
        case 262144: 
        case 393216: 
            mViewGroupFlags = mViewGroupFlags & 0xfff9ffff;
            break;
        }
        mViewGroupFlags = mViewGroupFlags | 0x60000 & i;
    }

    public void setDragListener(GLView.DragListener draglistener)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setDragListener(draglistener)) { }
        super.setDragListener(draglistener);
    }

    public void setPaddings(Rect rect)
    {
        super.setPaddings(rect);
        Iterator iterator = mGLViews.iterator();
        while (iterator.hasNext()) 
        {
            GLView glview = (GLView)iterator.next();
            Rect rect1 = new Rect(0, 0, 0, 0);
            if (glview.getLeft() - getLeft() < (float)rect.left && glview.getLeft() >= getLeft())
            {
                rect1.left = (int)((float)rect.left - (glview.getLeft() - getLeft()));
            } else
            {
                rect1.left = glview.getPaddings().left;
            }
            if (getRight() - glview.getRight() < (float)rect.right && getRight() >= glview.getRight())
            {
                rect1.right = (int)((float)rect.right - (getRight() - glview.getRight()));
            } else
            {
                rect1.right = glview.getPaddings().right;
            }
            if (glview.getTop() - getTop() < (float)rect.top && glview.getTop() >= getTop())
            {
                rect1.top = (int)((float)rect.top - (glview.getTop() - getTop()));
            } else
            {
                rect1.top = glview.getPaddings().top;
            }
            if (getBottom() - glview.getBottom() < (float)rect.bottom && getBottom() >= glview.getBottom())
            {
                rect1.bottom = (int)((float)rect.bottom - (getBottom() - glview.getBottom()));
            } else
            {
                rect1.bottom = glview.getPaddings().bottom;
            }
            glview.setPaddings(rect1);
        }
    }

    public void setShaderParameter(float f)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setShaderParameter(f)) { }
        super.setShaderParameter(f);
    }

    public void setShaderProgram(int i)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setShaderProgram(i)) { }
        super.setShaderProgram(i);
    }

    public void setShaderStep(float f)
    {
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).setShaderStep(f)) { }
        super.setShaderStep(f);
    }

    protected void sortViews()
    {
        Iterator iterator = mGLViews.iterator();
        if (isDepthSorted())
        {
            return;
        }
        ArrayList arraylist = new ArrayList();
        for (; iterator.hasNext(); arraylist.add(iterator.next())) { }
        Collections.sort(arraylist, new Comparator() {

            final GLViewGroup this$0;

            public int compare(GLView glview, GLView glview1)
            {
                return Float.compare(glview.getLayoutZ(), glview1.getLayoutZ());
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((GLView)obj, (GLView)obj1);
            }

            
            {
                this$0 = GLViewGroup.this;
                super();
            }
        });
        mGLViews.clear();
        mGLViews.addAll(arraylist);
        mDepthSortNeeded = false;
    }

    public void updateLayout(boolean flag)
    {
        super.updateLayout(flag);
        for (Iterator iterator = mGLViews.iterator(); iterator.hasNext(); ((GLView)iterator.next()).updateLayout(flag)) { }
    }

    public void updateSize()
    {
        float f1 = getLeft();
        float f = getTop();
        Iterator iterator = mGLViews.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            GLView glview = (GLView)iterator.next();
            float f2 = f1;
            if (glview.getLeft() + glview.getWidth() > f1)
            {
                f2 = glview.getLeft() + glview.getWidth();
            }
            f1 = f2;
            if (glview.getTop() + glview.getHeight() > f)
            {
                f = glview.getTop() + glview.getHeight();
                f1 = f2;
            }
        } while (true);
        updateSize(f1 - getLeft(), f - getTop());
        refreshClipRect();
    }
}
