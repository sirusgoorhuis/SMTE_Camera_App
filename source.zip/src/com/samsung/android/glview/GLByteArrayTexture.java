// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

// Referenced classes of package com.samsung.android.glview:
//            GLTexture, GLContext

public class GLByteArrayTexture extends GLTexture
{

    private byte mBitmapData[];
    private int mSampleSize;

    public GLByteArrayTexture(GLContext glcontext, float f, float f1, float f2, float f3, byte abyte0[])
    {
        super(glcontext, f, f1, f2, f3);
        mSampleSize = 2;
        mBitmapData = abyte0;
        if (mBitmapData == null)
        {
            throw new IllegalArgumentException();
        } else
        {
            return;
        }
    }

    public GLByteArrayTexture(GLContext glcontext, float f, float f1, float f2, float f3, byte abyte0[], boolean flag)
    {
        super(glcontext, f, f1, f2, f3);
        mSampleSize = 2;
        mBitmapData = abyte0;
        if (mBitmapData == null)
        {
            throw new IllegalArgumentException();
        } else
        {
            return;
        }
    }

    public GLByteArrayTexture(GLContext glcontext, float f, float f1, byte abyte0[])
    {
        super(glcontext, f, f1);
        mSampleSize = 2;
        mBitmapData = abyte0;
        if (mBitmapData == null)
        {
            throw new IllegalArgumentException();
        } else
        {
            return;
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        super.clear();
        mBitmapData = null;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected Bitmap loadBitmap()
    {
        this;
        JVM INSTR monitorenter ;
        android.graphics.BitmapFactory.Options options;
        options = new android.graphics.BitmapFactory.Options();
        options.inSampleSize = mSampleSize;
        options.inDither = false;
        options.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
        Bitmap bitmap = null;
        if (mBitmapData != null)
        {
            bitmap = BitmapFactory.decodeByteArray(mBitmapData, 0, mBitmapData.length, options);
        }
        mBitmapData = null;
        this;
        JVM INSTR monitorexit ;
        return bitmap;
        Exception exception;
        exception;
        throw exception;
    }

    public void setSampleSize(int i)
    {
        mSampleSize = i;
    }
}
