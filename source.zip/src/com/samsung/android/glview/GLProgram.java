// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.glview;

import android.opengl.GLES20;
import java.util.Hashtable;

public class GLProgram
{
    public static class NameIndexerObj
    {

        public int mHandle;

        public NameIndexerObj()
        {
            mHandle = 0;
        }
    }


    public static final String INDEXER_ALPHA = "u_alpha";
    public static final String INDEXER_FILL_COLOR = "fill_color";
    public static final String INDEXER_MVPMATRIX = "u_MVPMatrix";
    public static final String INDEXER_PARAMETER = "u_param";
    public static final String INDEXER_POINTSIZE = "a_pointsize";
    public static final String INDEXER_SAMPLER = "tex_sampler";
    public static final String INDEXER_STEP = "u_step";
    public static final String INDEXER_TEXCOORD = "a_texcoord";
    public static final String INDEXER_THICKNESS = "u_thickness";
    public static final String INDEXER_TINT_COLOR = "u_tint_color";
    public static final String INDEXER_TYPE = "u_type";
    public static final String INDEXER_VERTEX = "a_position";
    public static final int QUALIFIER_ATTRIBUTE = 102;
    public static final int QUALIFIER_CONST = 101;
    public static final int QUALIFIER_UNIFORM = 103;
    public static final int QUALIFIER_VARYING = 104;
    public static final int TYPE_BOOL = 202;
    public static final int TYPE_BVEC2 = 208;
    public static final int TYPE_BVEC3 = 209;
    public static final int TYPE_BVEC4 = 210;
    public static final int TYPE_FLOAT = 204;
    public static final int TYPE_INT = 203;
    public static final int TYPE_IVEC2 = 211;
    public static final int TYPE_IVEC3 = 212;
    public static final int TYPE_IVEC4 = 213;
    public static final int TYPE_MAT2 = 214;
    public static final int TYPE_MAT3 = 215;
    public static final int TYPE_MAT4 = 216;
    public static final int TYPE_SAMPLER2D = 217;
    public static final int TYPE_SAMPLERCUBE = 219;
    public static final int TYPE_SAMPLER_EXTERNAL = 218;
    public static final int TYPE_VEC2 = 205;
    public static final int TYPE_VEC3 = 206;
    public static final int TYPE_VEC4 = 207;
    public static final int TYPE_VOID = 201;
    private final Hashtable mNameIndexerObjMap = new Hashtable();
    private int mProgram;

    public GLProgram(String s, String s1)
    {
        mProgram = 0;
        mProgram = loadProgram(s, s1);
    }

    private void checkGlError(String s)
    {
    }

    private int loadProgram(String s, String s1)
    {
        int i = loadShader(35633, s);
        if (i == 0)
        {
            return 0;
        }
        int j = loadShader(35632, s1);
        if (j == 0)
        {
            return 0;
        }
        int k = GLES20.glCreateProgram();
        if (k != 0)
        {
            GLES20.glAttachShader(k, i);
            checkGlError("glAttachShader");
            GLES20.glAttachShader(k, j);
            checkGlError("glAttachShader");
            GLES20.glLinkProgram(k);
            s = new int[1];
            GLES20.glGetProgramiv(k, 35714, s, 0);
            if (s[0] != 1)
            {
                s = GLES20.glGetProgramInfoLog(k);
                GLES20.glDeleteProgram(k);
                throw new RuntimeException((new StringBuilder()).append("Could not link program: ").append(s).toString());
            }
        }
        GLES20.glDeleteShader(i);
        GLES20.glDeleteShader(j);
        return k;
    }

    private int loadShader(int i, String s)
    {
        int j = GLES20.glCreateShader(i);
        if (j != 0)
        {
            GLES20.glShaderSource(j, s);
            GLES20.glCompileShader(j);
            s = new int[1];
            GLES20.glGetShaderiv(j, 35713, s, 0);
            if (s[0] == 0)
            {
                s = GLES20.glGetShaderInfoLog(j);
                GLES20.glDeleteShader(j);
                throw new RuntimeException((new StringBuilder()).append("Could not compile shader ").append(i).append(":").append(s).toString());
            }
        }
        return j;
    }

    public boolean addNameIndexer(String s, int i, int j)
    {
        if (mProgram == 0) goto _L2; else goto _L1
_L1:
        NameIndexerObj nameindexerobj = new NameIndexerObj();
        i;
        JVM INSTR tableswitch 102 103: default 40
    //                   102 53
    //                   103 69;
           goto _L3 _L4 _L5
_L3:
        mNameIndexerObjMap.put(s, nameindexerobj);
        return true;
_L4:
        nameindexerobj.mHandle = GLES20.glGetAttribLocation(mProgram, s);
        continue; /* Loop/switch isn't completed */
_L5:
        nameindexerobj.mHandle = GLES20.glGetUniformLocation(mProgram, s);
        if (true) goto _L3; else goto _L2
_L2:
        return false;
    }

    public NameIndexerObj getNameIndexer(String s)
    {
        return (NameIndexerObj)mNameIndexerObjMap.get(s);
    }

    public int getProgramID()
    {
        return mProgram;
    }

    public void release()
    {
        if (mProgram != 0)
        {
            GLES20.glDeleteProgram(mProgram);
        }
        mNameIndexerObjMap.clear();
    }
}
