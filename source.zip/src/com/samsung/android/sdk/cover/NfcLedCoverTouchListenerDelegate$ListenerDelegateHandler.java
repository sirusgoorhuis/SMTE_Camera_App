// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.cover;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

// Referenced classes of package com.samsung.android.sdk.cover:
//            NfcLedCoverTouchListenerDelegate

private static class mListenerRef extends Handler
{

    private final WeakReference mListenerRef;

    public void handleMessage(Message message)
    {
        mListenerRef mlistenerref = (mListenerRef)mListenerRef.get();
        if (mlistenerref == null) goto _L2; else goto _L1
_L1:
        message.what;
        JVM INSTR tableswitch 0 4: default 52
    //                   0 53
    //                   1 58
    //                   2 63
    //                   3 68
    //                   4 73;
           goto _L2 _L3 _L4 _L5 _L6 _L7
_L2:
        return;
_L3:
        mlistenerref.();
        return;
_L4:
        mlistenerref.();
        return;
_L5:
        mlistenerref.();
        return;
_L6:
        mlistenerref.();
        return;
_L7:
        mlistenerref.();
        return;
    }

    public (Looper looper,  )
    {
        super(looper);
        mListenerRef = new WeakReference();
    }
}
