// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.cover;


// Referenced classes of package com.samsung.android.sdk.cover:
//            ScoverManager

public static class 
{

    public void onCoverAttachStateChanged(boolean flag)
    {
    }

    public void onCoverSwitchStateChanged(boolean flag)
    {
    }

    public ()
    {
    }
}
