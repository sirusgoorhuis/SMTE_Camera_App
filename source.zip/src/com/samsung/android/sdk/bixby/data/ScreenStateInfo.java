// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class ScreenStateInfo
{

    public static final ScreenStateInfo STATE_NOT_APPLICABLE = null;
    String mCallerAppName;
    LinkedHashSet mStateList;

    public ScreenStateInfo(String s)
        throws IllegalArgumentException
    {
        mCallerAppName = "";
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        } else
        {
            mStateList = new LinkedHashSet();
            mStateList.add(s);
            return;
        }
    }

    public ScreenStateInfo(LinkedHashSet linkedhashset)
        throws IllegalArgumentException
    {
        mCallerAppName = "";
        if (linkedhashset == null || linkedhashset.isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        } else
        {
            mStateList = linkedhashset;
            return;
        }
    }

    public ScreenStateInfo addState(String s)
        throws IllegalArgumentException
    {
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        }
        if (mStateList.contains(s))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("The screen parameter name is duplicated. ").append(s).toString());
        } else
        {
            mStateList.add(s);
            return this;
        }
    }

    public String getCallerAppName()
    {
        return mCallerAppName;
    }

    public LinkedHashSet getStates()
    {
        return mStateList;
    }

    public ScreenStateInfo setCallerAppName(String s)
        throws IllegalArgumentException
    {
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        } else
        {
            mCallerAppName = s;
            return this;
        }
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (!mCallerAppName.isEmpty())
        {
            stringbuilder.append("\"callerAppName\":");
            stringbuilder.append("\"").append(mCallerAppName).append("\",");
        }
        stringbuilder.append("\"stateIds\":[");
        if (mStateList != null && mStateList.size() > 0)
        {
            String s;
            for (Iterator iterator = mStateList.iterator(); iterator.hasNext(); stringbuilder.append("\"").append(s).append("\","))
            {
                s = (String)iterator.next();
            }

            stringbuilder.deleteCharAt(stringbuilder.length() - 1);
            stringbuilder.append("]");
            return stringbuilder.toString();
        } else
        {
            return null;
        }
    }

}
