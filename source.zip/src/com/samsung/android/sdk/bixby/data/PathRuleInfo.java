// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import java.util.List;

public final class PathRuleInfo
{

    private String apps[];
    private String executionType;
    private String intent;
    private boolean isCalleePathRule;
    private boolean isFromSimulator;
    private boolean isRoot;
    private String pathRuleId;
    private String pathRuleName;
    private String sampleUtterance;
    private List states;
    private String utterance;

    public PathRuleInfo(String s, String s1, String s2, String s3, String s4, String as[], String s5, 
            boolean flag, boolean flag1, boolean flag2, List list)
    {
        pathRuleId = null;
        pathRuleName = null;
        intent = null;
        utterance = null;
        sampleUtterance = null;
        apps = null;
        executionType = null;
        pathRuleId = s;
        pathRuleName = s1;
        intent = s2;
        utterance = s3;
        sampleUtterance = s4;
        apps = as;
        executionType = s5;
        isRoot = flag;
        isCalleePathRule = flag1;
        isFromSimulator = flag2;
        states = list;
    }

    public String[] getApps()
    {
        return apps;
    }

    public String getExecutionType()
    {
        return executionType;
    }

    public String getIntent()
    {
        return intent;
    }

    public String getPathRuleId()
    {
        return pathRuleId;
    }

    public String getPathRuleName()
    {
        return pathRuleName;
    }

    public String getSampleUtterance()
    {
        return sampleUtterance;
    }

    public List getStates()
    {
        return states;
    }

    public String getUtterance()
    {
        return utterance;
    }

    public boolean isCalleePathRule()
    {
        return isCalleePathRule;
    }

    public boolean isFromSimulator()
    {
        return isFromSimulator;
    }

    public boolean isRoot()
    {
        return isRoot;
    }
}
