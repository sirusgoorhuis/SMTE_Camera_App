// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.samsung.android.sdk.bixby.data:
//            Parameter

public class State
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public State createFromParcel(Parcel parcel)
        {
            return new State(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public State[] newArray(int i)
        {
            return new State[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    private String appName;
    private Boolean isExecuted;
    private Boolean isLandingState;
    private Boolean isLastState;
    private Boolean isResent;
    private List parameters;
    private String ruleId;
    private Integer seqNum;
    private String specVer;
    private String stateId;
    private String subIntent;

    public State()
    {
        specVer = "1.0";
        parameters = new ArrayList();
    }

    public State(Parcel parcel)
    {
        boolean flag1 = true;
        super();
        specVer = "1.0";
        parameters = new ArrayList();
        specVer = parcel.readString();
        seqNum = Integer.valueOf(parcel.readInt());
        boolean flag;
        if (parcel.readByte() != 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        isExecuted = Boolean.valueOf(flag);
        appName = parcel.readString();
        ruleId = parcel.readString();
        stateId = parcel.readString();
        if (parcel.readByte() != 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        isResent = Boolean.valueOf(flag);
        if (parcel.readByte() != 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        isLandingState = Boolean.valueOf(flag);
        if (parcel.readByte() != 0)
        {
            flag = flag1;
        } else
        {
            flag = false;
        }
        isLastState = Boolean.valueOf(flag);
        subIntent = parcel.readString();
        parameters = parcel.createTypedArrayList(Parameter.CREATOR);
    }

    public State(String s, Integer integer, Boolean boolean1, String s1, String s2, String s3, Boolean boolean2, 
            Boolean boolean3, Boolean boolean4, String s4, List list)
    {
        specVer = "1.0";
        parameters = new ArrayList();
        specVer = s;
        seqNum = integer;
        isExecuted = boolean1;
        appName = s1;
        ruleId = s2;
        stateId = s3;
        isResent = boolean2;
        isLandingState = boolean3;
        isLastState = boolean4;
        subIntent = s4;
        parameters = list;
    }

    public int describeContents()
    {
        return 0;
    }

    public String getAppName()
    {
        return appName;
    }

    public Map getParamMap()
    {
        HashMap hashmap = new HashMap();
        Parameter parameter;
        for (Iterator iterator = parameters.iterator(); iterator.hasNext(); hashmap.put(parameter.getParameterName(), parameter))
        {
            parameter = (Parameter)iterator.next();
        }

        return hashmap;
    }

    public List getParameters()
    {
        return parameters;
    }

    public String getRuleId()
    {
        return ruleId;
    }

    public Integer getSeqNum()
    {
        return seqNum;
    }

    public String getStateId()
    {
        return stateId;
    }

    public String getSubIntent()
    {
        return subIntent;
    }

    public Boolean isExecuted()
    {
        return isExecuted;
    }

    public Boolean isLandingState()
    {
        return isLandingState;
    }

    public Boolean isLastState()
    {
        return isLastState;
    }

    public Boolean isResent()
    {
        return isResent;
    }

    public void setAppName(String s)
    {
        appName = s;
    }

    public void setExecuted(Boolean boolean1)
    {
        isExecuted = boolean1;
    }

    public void setLandingState(Boolean boolean1)
    {
        isLandingState = boolean1;
    }

    public void setLastState(Boolean boolean1)
    {
        isLastState = boolean1;
    }

    public void setParameters(List list)
    {
        parameters = list;
    }

    public void setResent(Boolean boolean1)
    {
        isResent = boolean1;
    }

    public void setRuleId(String s)
    {
        ruleId = s;
    }

    public void setSeqNum(Integer integer)
    {
        seqNum = integer;
    }

    public void setStateId(String s)
    {
        stateId = s;
    }

    public void setSubIntent(String s)
    {
        subIntent = s;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        boolean flag = true;
        parcel.writeString(specVer);
        parcel.writeInt(seqNum.intValue());
        if (isExecuted.booleanValue())
        {
            i = 1;
        } else
        {
            i = 0;
        }
        parcel.writeByte((byte)i);
        parcel.writeString(appName);
        parcel.writeString(ruleId);
        parcel.writeString(stateId);
        if (isResent.booleanValue())
        {
            i = 1;
        } else
        {
            i = 0;
        }
        parcel.writeByte((byte)i);
        if (isLandingState.booleanValue())
        {
            i = 1;
        } else
        {
            i = 0;
        }
        parcel.writeByte((byte)i);
        if (isLastState.booleanValue())
        {
            i = ((flag) ? 1 : 0);
        } else
        {
            i = 0;
        }
        parcel.writeByte((byte)i);
        parcel.writeString(subIntent);
        parcel.writeTypedList(parameters);
    }

}
