// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;


// Referenced classes of package com.samsung.android.sdk.bixby.data:
//            NlgRequestInfo

public static class <init>
{

    public String name;
    public String value;

    private A(String s, String s1)
    {
        name = s;
        value = s1;
    }

    value(String s, String s1, value value1)
    {
        this(s, s1);
    }
}
