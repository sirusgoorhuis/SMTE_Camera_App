// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.samsung.android.sdk.bixby.data:
//            ScreenParameter

public class ParamFilling
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public ParamFilling createFromParcel(Parcel parcel)
        {
            return new ParamFilling(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public ParamFilling[] newArray(int i)
        {
            return new ParamFilling[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    String appName;
    String intent;
    List mScreenParameters;
    List screenStates;
    String utterance;

    protected ParamFilling(Parcel parcel)
    {
        screenStates = new ArrayList();
        mScreenParameters = new ArrayList();
        utterance = parcel.readString();
        intent = parcel.readString();
        appName = parcel.readString();
        screenStates = parcel.createStringArrayList();
        mScreenParameters = parcel.createTypedArrayList(ScreenParameter.CREATOR);
    }

    public ParamFilling(String s, String s1, String s2, List list, List list1)
    {
        screenStates = new ArrayList();
        mScreenParameters = new ArrayList();
        utterance = s;
        intent = s1;
        appName = s2;
        screenStates = list;
        mScreenParameters = list1;
    }

    public static android.os.Parcelable.Creator getCREATOR()
    {
        return CREATOR;
    }

    public int describeContents()
    {
        return 0;
    }

    public String getAppName()
    {
        return appName;
    }

    public String getIntent()
    {
        return intent;
    }

    public Map getScreenParamMap()
    {
        HashMap hashmap = new HashMap();
        ScreenParameter screenparameter;
        for (Iterator iterator = mScreenParameters.iterator(); iterator.hasNext(); hashmap.put(screenparameter.getParameterName(), screenparameter))
        {
            screenparameter = (ScreenParameter)iterator.next();
        }

        return hashmap;
    }

    public List getScreenParameters()
    {
        return mScreenParameters;
    }

    public List getScreenStates()
    {
        return screenStates;
    }

    public String getUtterance()
    {
        return utterance;
    }

    public void setAppName(String s)
    {
        appName = s;
    }

    public void setIntent(String s)
    {
        intent = s;
    }

    public void setScreenParameters(List list)
    {
        mScreenParameters = list;
    }

    public void setScreenStates(List list)
    {
        screenStates = list;
    }

    public void setUtterance(String s)
    {
        utterance = s;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeString(utterance);
        parcel.writeString(intent);
        parcel.writeString(appName);
        parcel.writeStringList(screenStates);
        parcel.writeTypedList(mScreenParameters);
    }

}
