// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.samsung.android.sdk.bixby.data:
//            CHObject

public class Parameter
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public Parameter createFromParcel(Parcel parcel)
        {
            return new Parameter(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public Parameter[] newArray(int i)
        {
            return new Parameter[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    private String CHObjectType;
    private List CHObjects;
    private Boolean isMandatory;
    private String parameterName;
    private String parameterType;
    private String slotName;
    private String slotType;
    private String slotValue;
    private String slotValueType;

    public Parameter()
    {
        CHObjects = new ArrayList();
    }

    public Parameter(Parcel parcel)
    {
        boolean flag = true;
        super();
        CHObjects = new ArrayList();
        slotType = parcel.readString();
        slotName = parcel.readString();
        slotValue = parcel.readString();
        slotValueType = parcel.readString();
        CHObjectType = parcel.readString();
        byte byte0;
        if (parcel.readByte() == 1)
        {
            CHObjects = new ArrayList();
            parcel.readList(CHObjects, com/samsung/android/sdk/bixby/data/CHObject.getClassLoader());
        } else
        {
            CHObjects = null;
        }
        parameterName = parcel.readString();
        parameterType = parcel.readString();
        byte0 = parcel.readByte();
        if (byte0 == 2)
        {
            parcel = null;
        } else
        {
            if (byte0 == 0)
            {
                flag = false;
            }
            parcel = Boolean.valueOf(flag);
        }
        isMandatory = parcel;
    }

    public Parameter(String s, String s1, String s2, String s3, String s4, List list, String s5, 
            String s6, Boolean boolean1)
    {
        CHObjects = new ArrayList();
        slotType = s;
        slotName = s1;
        slotValue = s2;
        slotValueType = s3;
        CHObjectType = s4;
        CHObjects = list;
        parameterName = s5;
        parameterType = s6;
        isMandatory = boolean1;
    }

    public int describeContents()
    {
        return 0;
    }

    public String getCHObjectType()
    {
        return CHObjectType;
    }

    public List getCHObjects()
    {
        return CHObjects;
    }

    public Boolean getIsMandatory()
    {
        return isMandatory;
    }

    public String getParameterName()
    {
        return parameterName;
    }

    public String getParameterType()
    {
        return parameterType;
    }

    public String getSlotName()
    {
        return slotName;
    }

    public String getSlotType()
    {
        return slotType;
    }

    public String getSlotValue()
    {
        return slotValue;
    }

    public String getSlotValueType()
    {
        return slotValueType;
    }

    public void setCHObjectType(String s)
    {
        CHObjectType = s;
    }

    public void setCHObjects(List list)
    {
        CHObjects = list;
    }

    public void setIsMandatory(Boolean boolean1)
    {
        isMandatory = boolean1;
    }

    public void setParameterName(String s)
    {
        parameterName = s;
    }

    public void setParameterType(String s)
    {
        parameterType = s;
    }

    public void setSlotName(String s)
    {
        slotName = s;
    }

    public void setSlotType(String s)
    {
        slotType = s;
    }

    public void setSlotValue(String s)
    {
        slotValue = s;
    }

    public void setSlotValueType(String s)
    {
        slotValueType = s;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        i = 1;
        parcel.writeString(slotType);
        parcel.writeString(slotName);
        parcel.writeString(slotValue);
        parcel.writeString(slotValueType);
        parcel.writeString(CHObjectType);
        if (CHObjects == null)
        {
            parcel.writeByte((byte)0);
        } else
        {
            parcel.writeByte((byte)1);
            parcel.writeList(CHObjects);
        }
        parcel.writeString(parameterName);
        parcel.writeString(parameterType);
        if (isMandatory == null)
        {
            parcel.writeByte((byte)2);
            return;
        }
        if (!isMandatory.booleanValue())
        {
            i = 0;
        }
        parcel.writeByte((byte)i);
    }

}
