// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.samsung.android.sdk.bixby.data:
//            CHObject

public class ScreenParameter
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public ScreenParameter createFromParcel(Parcel parcel)
        {
            return new ScreenParameter(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public ScreenParameter[] newArray(int i)
        {
            return new ScreenParameter[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    private String CHObjectType;
    private List CHObjects;
    private String parameterName;
    private String parameterType;
    private String slotName;
    private String slotType;
    private String slotValue;

    public ScreenParameter()
    {
        CHObjects = new ArrayList();
    }

    protected ScreenParameter(Parcel parcel)
    {
        CHObjects = new ArrayList();
        slotType = parcel.readString();
        slotName = parcel.readString();
        slotValue = parcel.readString();
        CHObjectType = parcel.readString();
        CHObjects = parcel.createTypedArrayList(CHObject.CREATOR);
        parameterName = parcel.readString();
        parameterType = parcel.readString();
    }

    public ScreenParameter(String s, String s1, String s2, String s3, List list, String s4, String s5)
    {
        CHObjects = new ArrayList();
        slotType = s;
        slotName = s1;
        slotValue = s2;
        CHObjectType = s3;
        CHObjects = list;
        parameterName = s4;
        parameterType = s5;
    }

    public static android.os.Parcelable.Creator getCREATOR()
    {
        return CREATOR;
    }

    public int describeContents()
    {
        return 0;
    }

    public String getCHObjectType()
    {
        return CHObjectType;
    }

    public List getCHObjects()
    {
        return CHObjects;
    }

    public String getParameterName()
    {
        return parameterName;
    }

    public String getParameterType()
    {
        return parameterType;
    }

    public String getSlotName()
    {
        return slotName;
    }

    public String getSlotType()
    {
        return slotType;
    }

    public String getSlotValue()
    {
        return slotValue;
    }

    public void setCHObjectType(String s)
    {
        CHObjectType = s;
    }

    public void setCHObjects(List list)
    {
        CHObjects = list;
    }

    public void setParameterName(String s)
    {
        parameterName = s;
    }

    public void setParameterType(String s)
    {
        parameterType = s;
    }

    public void setSlotName(String s)
    {
        slotName = s;
    }

    public void setSlotType(String s)
    {
        slotType = s;
    }

    public void setSlotValue(String s)
    {
        slotValue = s;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeString(slotType);
        parcel.writeString(slotName);
        parcel.writeString(slotValue);
        parcel.writeString(CHObjectType);
        parcel.writeTypedList(CHObjects);
        parcel.writeString(parameterName);
        parcel.writeString(parameterType);
    }

}
