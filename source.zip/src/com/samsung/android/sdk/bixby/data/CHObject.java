// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import android.os.Parcel;
import android.os.Parcelable;

public class CHObject
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public CHObject createFromParcel(Parcel parcel)
        {
            return new CHObject(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public CHObject[] newArray(int i)
        {
            return new CHObject[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    private String CH_Type;
    private String CH_Value;
    private String CH_ValueType;

    public CHObject()
    {
    }

    public CHObject(Parcel parcel)
    {
        CH_Type = parcel.readString();
        CH_Value = parcel.readString();
        CH_ValueType = parcel.readString();
    }

    public CHObject(String s, String s1, String s2)
    {
        CH_Type = s;
        CH_Value = s1;
        CH_ValueType = s2;
    }

    public int describeContents()
    {
        return 0;
    }

    public String getCHType()
    {
        return CH_Type;
    }

    public String getCHValue()
    {
        return CH_Value;
    }

    public String getCHValueType()
    {
        return CH_ValueType;
    }

    public void setCHType(String s)
    {
        CH_Type = s;
    }

    public void setCHValue(String s)
    {
        CH_Value = s;
    }

    public void setCHValueType(String s)
    {
        CH_ValueType = s;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeString(CH_Type);
        parcel.writeString(CH_Value);
        parcel.writeString(CH_ValueType);
    }

}
