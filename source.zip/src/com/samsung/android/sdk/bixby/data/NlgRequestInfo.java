// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby.data;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class NlgRequestInfo
{
    public static class Attribute
    {

        public String name;
        public String value;

        private Attribute(String s, String s1)
        {
            name = s;
            value = s1;
        }

    }


    private String mRequestStateId;
    private HashMap mResultParams;
    private String mRuleId;
    private HashMap mScreenParams;

    public NlgRequestInfo(String s)
        throws IllegalArgumentException
    {
        mScreenParams = new HashMap();
        mResultParams = new HashMap();
        mRuleId = null;
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        } else
        {
            mRequestStateId = s;
            return;
        }
    }

    public NlgRequestInfo(String s, String s1)
        throws IllegalArgumentException
    {
        mScreenParams = new HashMap();
        mResultParams = new HashMap();
        mRuleId = null;
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        }
        if (s1 == null || s1.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        } else
        {
            mRequestStateId = s;
            mRuleId = s1;
            return;
        }
    }

    public NlgRequestInfo addResultParam(String s, String s1)
    {
        if (s == null || s.trim().isEmpty() || s1 == null || s1.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty");
        }
        if (mResultParams.containsKey(s))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("The result parameter name is duplicated.").append(s).toString());
        } else
        {
            mResultParams.put(s, s1);
            return this;
        }
    }

    public NlgRequestInfo addScreenParam(String s, String s1, String s2)
        throws IllegalArgumentException
    {
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalArgumentException("The input parameter is null or empty.");
        }
        if (mScreenParams.containsKey(s))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("The screen parameter name is duplicated. ").append(s).toString());
        } else
        {
            mScreenParams.put(s, new Attribute(s1, s2));
            return this;
        }
    }

    public String getRequestStateId()
    {
        return mRequestStateId;
    }

    public HashMap getResultParams()
    {
        return mResultParams;
    }

    public String getRuleId()
    {
        return mRuleId;
    }

    public HashMap getScreenParams()
    {
        return mScreenParams;
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("\"requestedStateId\":\"").append(mRequestStateId).append("\"");
        if (mRuleId != null)
        {
            stringbuilder.append(",\"ruleId\":\"").append(mRuleId).append("\"");
        }
        if (mScreenParams.size() > 0)
        {
            stringbuilder.append(",\"screenParameters\":[");
            java.util.Map.Entry entry;
            for (Iterator iterator = mScreenParams.entrySet().iterator(); iterator.hasNext(); stringbuilder.append("{\"parameterName\":\"").append((String)entry.getKey()).append("\",").append("\"attributeName\":\"").append(((Attribute)entry.getValue()).name).append("\",\"attributeValue\":\"").append(((Attribute)entry.getValue()).value).append("\"},"))
            {
                entry = (java.util.Map.Entry)iterator.next();
            }

            stringbuilder.deleteCharAt(stringbuilder.length() - 1);
            stringbuilder.append("]");
        }
        if (mResultParams.size() > 0)
        {
            stringbuilder.append(",\"resultParameters\":[");
            java.util.Map.Entry entry1;
            for (Iterator iterator1 = mResultParams.entrySet().iterator(); iterator1.hasNext(); stringbuilder.append("{\"name\":\"").append((String)entry1.getKey()).append("\",\"value\":\"").append((String)entry1.getValue()).append("\"},"))
            {
                entry1 = (java.util.Map.Entry)iterator1.next();
            }

            stringbuilder.deleteCharAt(stringbuilder.length() - 1);
            stringbuilder.append("]");
        }
        return stringbuilder.toString();
    }
}
