// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class  extends Enum
{

    private static final WAIT $VALUES[];
    public static final WAIT CUT;
    public static final WAIT WAIT;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$TtsMode, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    public String toString()
    {
        switch (hMap.com.samsung.android.sdk.bixby.BixbyApi.TtsMode[ordinal()])
        {
        default:
            return super.toString();

        case 1: // '\001'
            return "\"ttsMode\":\"cut\"";

        case 2: // '\002'
            return "\"ttsMode\":\"wait\"";
        }
    }

    static 
    {
        CUT = new <init>("CUT", 0);
        WAIT = new <init>("WAIT", 1);
        $VALUES = (new .VALUES[] {
            CUT, WAIT
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
