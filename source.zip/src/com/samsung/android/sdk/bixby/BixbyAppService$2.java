// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.os.Handler;
import android.os.RemoteException;
import android.util.Log;
import com.samsung.android.bixby.agent.IBixbyAgentAppServiceCallback;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyAppService, CommandHandlerRunnable

class rvice.Stub extends com.samsung.android.bixby.agent.ice.Stub
{

    final BixbyAppService this$0;

    public void sendCommand(String s)
        throws RemoteException
    {
        if (BixbyAppService.access$000())
        {
            Log.d(BixbyAppService.access$100(), (new StringBuilder()).append("BixbyAppService Command From EM: ").append(s).toString());
        } else
        {
            Log.d(BixbyAppService.access$100(), "BixbyAppService Command From EM");
        }
        if (!BixbyAppService.access$400(BixbyAppService.this))
        {
            Log.e(BixbyAppService.access$100(), "sendCommand: Unauthorized access detected!");
            return;
        } else
        {
            BixbyAppService.access$500(BixbyAppService.this).post(new CommandHandlerRunnable(s));
            return;
        }
    }

    public void setCallback(IBixbyAgentAppServiceCallback ibixbyagentappservicecallback)
        throws RemoteException
    {
        Log.d(BixbyAppService.access$100(), "BixbyAppService setCallback");
        if (!BixbyAppService.access$400(BixbyAppService.this))
        {
            Log.e(BixbyAppService.access$100(), "setCallback: Unauthorized access detected!");
            return;
        } else
        {
            BixbyAppService.access$202(BixbyAppService.this, ibixbyagentappservicecallback);
            return;
        }
    }

    rviceCallback()
    {
        this$0 = BixbyAppService.this;
        super();
    }
}
