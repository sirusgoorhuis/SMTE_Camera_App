// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class value extends Enum
{

    private static final RULE_COMPLETE $VALUES[];
    public static final RULE_COMPLETE FAILURE;
    public static final RULE_COMPLETE RULE_COMPLETE;
    public static final RULE_COMPLETE STATE_FAILURE;
    public static final RULE_COMPLETE STATE_SUCCESS;
    public static final RULE_COMPLETE SUCCESS;
    public static final RULE_COMPLETE TEST_ALL_STATES_FAILURE;
    public static final RULE_COMPLETE TEST_ALL_STATES_SUCCESS;
    public static final RULE_COMPLETE TEST_SETUP_FAILURE;
    public static final RULE_COMPLETE TEST_SETUP_SUCCESS;
    public static final RULE_COMPLETE TEST_TEARDOWN_FAILURE;
    public static final RULE_COMPLETE TEST_TEARDOWN_SUCCESS;
    private int value;

    public static value valueOf(String s)
    {
        return (value)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ResponseResults, s);
    }

    public static value[] values()
    {
        return (value[])$VALUES.clone();
    }

    public int getValue()
    {
        return value;
    }

    public String toString()
    {
        switch (.samsung.android.sdk.bixby.BixbyApi.ResponseResults[ordinal()])
        {
        default:
            return super.toString();

        case 1: // '\001'
        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
            return "success";

        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
        case 9: // '\t'
        case 10: // '\n'
            return "failure";

        case 11: // '\013'
            return "rule_complete";
        }
    }

    static 
    {
        SUCCESS = new <init>("SUCCESS", 0, 0);
        FAILURE = new <init>("FAILURE", 1, 1);
        STATE_SUCCESS = new <init>("STATE_SUCCESS", 2, 0);
        STATE_FAILURE = new <init>("STATE_FAILURE", 3, 1);
        TEST_SETUP_SUCCESS = new <init>("TEST_SETUP_SUCCESS", 4, 2);
        TEST_SETUP_FAILURE = new <init>("TEST_SETUP_FAILURE", 5, 3);
        TEST_TEARDOWN_SUCCESS = new <init>("TEST_TEARDOWN_SUCCESS", 6, 4);
        TEST_TEARDOWN_FAILURE = new <init>("TEST_TEARDOWN_FAILURE", 7, 5);
        TEST_ALL_STATES_SUCCESS = new <init>("TEST_ALL_STATES_SUCCESS", 8, 6);
        TEST_ALL_STATES_FAILURE = new <init>("TEST_ALL_STATES_FAILURE", 9, 7);
        RULE_COMPLETE = new <init>("RULE_COMPLETE", 10, 8);
        $VALUES = (new .VALUES[] {
            SUCCESS, FAILURE, STATE_SUCCESS, STATE_FAILURE, TEST_SETUP_SUCCESS, TEST_SETUP_FAILURE, TEST_TEARDOWN_SUCCESS, TEST_TEARDOWN_FAILURE, TEST_ALL_STATES_SUCCESS, TEST_ALL_STATES_FAILURE, 
            RULE_COMPLETE
        });
    }

    private (String s, int i, int j)
    {
        super(s, i);
        value = j;
    }
}
