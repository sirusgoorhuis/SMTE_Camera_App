// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.app.Application;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Base64;
import android.util.Log;
import com.samsung.android.bixby.agent.IBixbyAgentAppServiceCallback;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi, CommandHandlerRunnable

public class BixbyAppService extends Service
{
    private static class CommandHandler extends Handler
    {

        public void dispatchMessage(Message message)
        {
            try
            {
                super.dispatchMessage(message);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Message message)
            {
                message.printStackTrace();
            }
        }

        CommandHandler(Looper looper)
        {
            super(looper);
        }
    }


    private static final String BIXBY_AGENT_PACKAGE_NAME = "com.samsung.android.bixby.agent";
    private static final String BIXBY_COMMAND_VERSION = "1.0";
    private static final boolean DEBUG;
    private static final String TAG = (new StringBuilder()).append(com/samsung/android/sdk/bixby/BixbyAppService.getSimpleName()).append("_0.2.7").toString();
    private static HandlerThread mActorThreadHandler;
    private static Signature mBixbAgentSignature = new Signature(Base64.decode("MIIE1DCCA7ygAwIBAgIJANIJlaecDarWMA0GCSqGSIb3DQEBBQUAMIGiMQswCQYDVQQGEwJLUjEUMBIGA1UECBMLU291dGggS29yZWExEzARBgNVBAcTClN1d29uIENpdHkxHDAaBgNVBAoTE1NhbXN1bmcgQ29ycG9yYXRpb24xDDAKBgNVBAsTA0RNQzEVMBMGA1UEAxMMU2Ftc3VuZyBDZXJ0MSUwIwYJKoZIhvcNAQkBFhZhbmRyb2lkLm9zQHNhbXN1bmcuY29tMB4XDTExMDYyMjEyMjUxMloXDTM4MTEwNzEyMjUxMlowgaIxCzAJBgNVBAYTAktSMRQwEgYDVQQIEwtTb3V0aCBLb3JlYTETMBEGA1UEBxMKU3V3b24gQ2l0eTEcMBoGA1UEChMTU2Ftc3VuZyBDb3Jwb3JhdGlvbjEMMAoGA1UECxMDRE1DMRUwEwYDVQQDEwxTYW1zdW5nIENlcnQxJTAjBgkqhkiG9w0BCQEWFmFuZHJvaWQub3NAc2Ftc3VuZy5jb20wggEgMA0GCSqGSIb3DQEBAQUAA4IBDQAwggEIAoIBAQDJhjhKPh8vsgZnDnjvIyIVwNJvRaInKNuZpE2hHDWsM6cf4HHEotaCWptMiLMz7ZbzxebGZtYPPulMSQiFq8+NxmD3B6q8d+rT4tDYrugQjBXNJg8uhQQsKNLyktqjxtoMe/I5HbeEGq3o/fDJ0N7893Ek5tLeCp4NLadGw2cOT/zchbcBu0dEhhuW/3MR2jYDxaEDNuVf+jS0NT7tyF9RAV4VGMZ+MJ45+HY5/xeBB/EJzRhBGmB38mlktuY/inC5YZ2wQwajI8Gh0jr4Z+GfFPVw/+Vz0OOgwrMGMqrsMXM4CZS+HjQeOpC9LkthVIH0bbOeqDgWRI7DX+sXNcHzAgEDo4IBCzCCAQcwHQYDVR0OBBYEFJMsOvcLYnoMdhC1oOdCfWz66j8eMIHXBgNVHSMEgc8wgcyAFJMsOvcLYnoMdhC1oOdCfWz66j8eoYGopIGlMIGiMQswCQYDVQQGEwJLUjEUMBIGA1UECBMLU291dGggS29yZWExEzARBgNVBAcTClN1d29uIENpdHkxHDAaBgNVBAoTE1NhbXN1bmcgQ29ycG9yYXRpb24xDDAKBgNVBAsTA0RNQzEVMBMGA1UEAxMMU2Ftc3VuZyBDZXJ0MSUwIwYJKoZIhvcNAQkBFhZhbmRyb2lkLm9zQHNhbXN1bmcuY29tggkA0gmVp5wNqtYwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOCAQEAMpYB/kDgNqSobMXUndjBtUFZmOcmN1OLDUMDaaxRUw9jqs6MAZoaZmFqLxuyxfq9bzEyYfOA40cWI/BT2ePFP1/W0ZZdewAOTcJEwbJ+L+mjI/8Hf1LEZ16GJHqoARhxN+MMm78BxWekKZ20vwslt9cQenuB7hAvcv9HlQFk4mdS4RTEL4udKkLnMIiX7GQOoZJO0Tq76dEgkSti9JJkk6htuUwLRvRMYWHVjC9kgWSJDFEt+yjULIVb9HDb7i2raWDK0E6B9xUl3tRs3Q81n5nEYNufAH2WzoO0shisLYLEjxJgjUaXM/BaM3VZRmnMv4pJVUTWxXAek2nAjIEBWA==", 0));
    private static final boolean mIsUserBuild;
    com.samsung.android.bixby.agent.IBixbyAgentAppService.Stub mBinder;
    private BixbyApi mBixbyApi;
    private IBixbyAgentAppServiceCallback mCallbackToBa;
    private Handler mHandler;
    private boolean mIsKnoxId;
    BixbyApi.OnResponseCallback mResponseFromMediator;

    public BixbyAppService()
    {
        mIsKnoxId = false;
        mHandler = new Handler();
        mResponseFromMediator = new BixbyApi.OnResponseCallback() {

            final BixbyAppService this$0;

            public void onResponse(String s, String s1)
                throws IllegalStateException
            {
                if (BixbyAppService.DEBUG)
                {
                    Log.d(BixbyAppService.TAG, (new StringBuilder()).append("Send command to EM ").append(s).append(" ").append(s1).toString());
                } else
                {
                    Log.d(BixbyAppService.TAG, (new StringBuilder()).append("Send command to EM ").append(s).toString());
                }
                if (mCallbackToBa == null)
                {
                    Log.e(BixbyAppService.TAG, "No Bixby Agent response callback method registered.");
                    return;
                }
                s = handleResponseCommand(s, s1);
                if (s == null)
                {
                    try
                    {
                        Log.e(BixbyAppService.TAG, "Failed to handle response command to Bixby Agent.");
                        return;
                    }
                    // Misplaced declaration of an exception variable
                    catch (String s)
                    {
                        Log.e(BixbyAppService.TAG, "Failed to send command to Bixby Agent.");
                    }
                    return;
                }
                if (BixbyAppService.DEBUG)
                {
                    Log.d(BixbyAppService.TAG, (new StringBuilder()).append("jsonResponse: ").append(s).toString());
                }
                mCallbackToBa.onResponse(s);
                return;
            }

            
            {
                this$0 = BixbyAppService.this;
                super();
            }
        };
        mBinder = new com.samsung.android.bixby.agent.IBixbyAgentAppService.Stub() {

            final BixbyAppService this$0;

            public void sendCommand(String s)
                throws RemoteException
            {
                if (BixbyAppService.DEBUG)
                {
                    Log.d(BixbyAppService.TAG, (new StringBuilder()).append("BixbyAppService Command From EM: ").append(s).toString());
                } else
                {
                    Log.d(BixbyAppService.TAG, "BixbyAppService Command From EM");
                }
                if (!checkSenderIdentity())
                {
                    Log.e(BixbyAppService.TAG, "sendCommand: Unauthorized access detected!");
                    return;
                } else
                {
                    mHandler.post(new CommandHandlerRunnable(s));
                    return;
                }
            }

            public void setCallback(IBixbyAgentAppServiceCallback ibixbyagentappservicecallback)
                throws RemoteException
            {
                Log.d(BixbyAppService.TAG, "BixbyAppService setCallback");
                if (!checkSenderIdentity())
                {
                    Log.e(BixbyAppService.TAG, "setCallback: Unauthorized access detected!");
                    return;
                } else
                {
                    mCallbackToBa = ibixbyagentappservicecallback;
                    return;
                }
            }

            
            {
                this$0 = BixbyAppService.this;
                super();
            }
        };
    }

    private boolean checkSenderIdentity()
        throws RemoteException
    {
        boolean flag1 = false;
        if (mIsUserBuild && !mIsKnoxId) goto _L2; else goto _L1
_L1:
        boolean flag = true;
_L4:
        return flag;
_L2:
        PackageManager packagemanager;
        String as[];
        int i = Binder.getCallingUid();
        packagemanager = getPackageManager();
        as = packagemanager.getPackagesForUid(i);
        flag = flag1;
        if (as == null) goto _L4; else goto _L3
_L3:
        int j;
        int k;
        k = as.length;
        j = 0;
_L6:
        flag = flag1;
        if (j >= k) goto _L4; else goto _L5
_L5:
        String s;
        s = as[j];
        if (!"com.samsung.android.bixby.agent".equals(s))
        {
            break MISSING_BLOCK_LABEL_122;
        }
        Signature asignature[] = packagemanager.getPackageInfo(s, 64).signatures;
        if (asignature == null)
        {
            break MISSING_BLOCK_LABEL_122;
        }
        if (asignature.length <= 0)
        {
            break MISSING_BLOCK_LABEL_122;
        }
        flag = mBixbAgentSignature.equals(asignature[0]);
        if (flag)
        {
            return true;
        }
        break MISSING_BLOCK_LABEL_122;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        namenotfoundexception.printStackTrace();
        j++;
          goto _L6
    }

    private String handleResponseCommand(String s, String s1)
    {
        if ("esem_request_nlg".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("esem_request_tts".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("esem_context_result".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("esem_param_filling_result".equals(s))
        {
            return wrapCommand(s, (new StringBuilder()).append("\"result\":\"").append(s1).append("\"").toString());
        }
        if ("esem_state_log".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("esem_client_control".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("state_command_result".equals(s))
        {
            return makeStateResultCommand(s1);
        }
        if ("esem_chatty_mode_result".equals(s))
        {
            return wrapCommand(s, (new StringBuilder()).append("\"result\":\"").append(s1).append("\"").toString());
        }
        if ("esem_cancel_chatty_mode".equals(s))
        {
            return wrapCommand(s, s1);
        }
        if ("esem_split_state_result".equals(s))
        {
            return wrapCommand(s, (new StringBuilder()).append("\"selectedStateId\":\"").append(s1).append("\"").toString());
        }
        if ("esem_all_states_result".equals(s))
        {
            return wrapCommand(s, (new StringBuilder()).append("\"result\":\"").append(s1).append("\"").toString());
        }
        if ("esem_user_confirm_result".equals(s))
        {
            return wrapCommand(s, s1);
        } else
        {
            Log.e(TAG, (new StringBuilder()).append("handleResponseCommand: Unsupported Command:").append(s).toString());
            return null;
        }
    }

    private boolean isKnoxId()
    {
        boolean flag;
        int i = ((Integer)Class.forName("android.os.UserHandle").getMethod("semGetMyUserId", new Class[0]).invoke(null, new Object[0])).intValue();
        if (DEBUG)
        {
            Log.d(TAG, (new StringBuilder()).append("userId = ").append(i).toString());
        }
        flag = ((Boolean)Class.forName("com.samsung.android.knox.SemPersonaManager").getMethod("isKnoxId", new Class[] {
            Integer.TYPE
        }).invoke(null, new Object[] {
            Integer.valueOf(i)
        })).booleanValue();
        if (DEBUG)
        {
            Log.d(TAG, (new StringBuilder()).append("bRet = ").append(flag).toString());
        }
        return flag;
        Object obj;
        obj;
_L2:
        Log.e(TAG, "isKnoxId: Can't read information on KNOX.");
        Log.d(TAG, ((Exception) (obj)).toString());
        return false;
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        if (true) goto _L2; else goto _L1
_L1:
    }

    private String makeStateResultCommand(String s)
    {
        if (mBixbyApi.mStateCommandJsonFromBa == null)
        {
            Log.e(TAG, "makeStateResultCommand: Can't make a state result command. Ignored.");
            return null;
        }
        try
        {
            JSONObject jsonobject = new JSONObject(mBixbyApi.mStateCommandJsonFromBa);
            JSONObject jsonobject1 = new JSONObject();
            JSONObject jsonobject2 = new JSONObject();
            jsonobject1.put("version", "1.0");
            jsonobject1.put("command", "esem_state_result");
            jsonobject1.put("requestId", jsonobject.getString("requestId"));
            jsonobject2.put("result", s);
            jsonobject2.put("state", jsonobject.getJSONObject("content").getJSONObject("state"));
            jsonobject1.put("content", jsonobject2);
            s = jsonobject1.toString();
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            s.printStackTrace();
            return null;
        }
        return s;
    }

    private String wrapCommand(String s, String s1)
    {
        return (new StringBuilder()).append("{").append("\"version\":\"").append("1.0").append("\",").append("\"command\":\"").append(s).append("\",").append("\"content\":{").append(s1).append("}}").toString();
    }

    public IBinder onBind(Intent intent)
    {
        mBixbyApi.onServiceBound(intent);
        return mBinder;
    }

    public void onCreate()
    {
        Log.d(TAG, (new StringBuilder()).append("BixbyAppService onCreate package:").append(getApplication().getPackageName()).toString());
        super.onCreate();
        mIsKnoxId = isKnoxId();
        mBixbyApi = BixbyApi.getInstance();
        mBixbyApi.setResponseCallback(mResponseFromMediator);
        if ("com.samsung.android.bixby.agent".equals(getApplication().getPackageName()))
        {
            if (mActorThreadHandler == null)
            {
                mActorThreadHandler = new HandlerThread("ExtCmdHandler");
                mActorThreadHandler.start();
            }
            mHandler = new CommandHandler(mActorThreadHandler.getLooper());
            mBixbyApi.mHandler = mHandler;
        }
        mBixbyApi.onServiceCreated();
    }

    public void onDestroy()
    {
        Log.d(TAG, (new StringBuilder()).append("BixbyAppService onDestroy package:").append(getApplication().getPackageName()).toString());
        mBixbyApi.clearData();
        mBixbyApi.onServiceDestroyed();
        super.onDestroy();
    }

    public boolean onUnbind(Intent intent)
    {
        mBixbyApi.onServiceUnbound(intent);
        return super.onUnbind(intent);
    }

    static 
    {
        mIsUserBuild = "user".equals(Build.TYPE);
        boolean flag;
        if (!mIsUserBuild)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        DEBUG = flag;
    }





/*
    static IBixbyAgentAppServiceCallback access$202(BixbyAppService bixbyappservice, IBixbyAgentAppServiceCallback ibixbyagentappservicecallback)
    {
        bixbyappservice.mCallbackToBa = ibixbyagentappservicecallback;
        return ibixbyagentappservicecallback;
    }

*/



}
