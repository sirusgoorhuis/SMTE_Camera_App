// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class TestInformationReader
{
    public static class TestInformation
    {

        public static final String TYPE_SETUP = "setup";
        public static final String TYPE_TEARDOWN = "teardown";
        private Map content;
        private String type;

        public Map getContent()
        {
            return content;
        }

        public String getType()
        {
            return type;
        }

        public void setContent(Map map)
        {
            content = map;
        }

        public void setType(String s)
        {
            type = s;
        }

        public TestInformation(String s, Map map)
        {
            type = null;
            content = null;
            type = s;
            content = map;
        }
    }


    TestInformationReader()
    {
    }

    private static Map getTestParams(JSONObject jsonobject)
    {
        HashMap hashmap = new HashMap();
        String s;
        for (Iterator iterator = jsonobject.keys(); iterator.hasNext(); hashmap.put(s, jsonobject.getString(s)))
        {
            s = (String)iterator.next();
        }

        boolean flag = hashmap.isEmpty();
        jsonobject = hashmap;
        if (flag)
        {
            return null;
        }
        break MISSING_BLOCK_LABEL_64;
        jsonobject;
        jsonobject = null;
        return jsonobject;
    }

    public static List read(String s)
    {
        JSONArray jsonarray;
        int j;
        jsonarray = new JSONArray(s);
        j = jsonarray.length();
        if (j == 0)
        {
            return null;
        }
        ArrayList arraylist = new ArrayList();
        int i = 0;
_L2:
        s = arraylist;
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        s = jsonarray.getJSONObject(i);
        if (s.has("type"))
        {
            String s1 = s.get("type").toString();
            if (s.has("content"))
            {
                arraylist.add(new TestInformation(s1, getTestParams(s.getJSONObject("content"))));
            }
        }
        i++;
        if (true) goto _L2; else goto _L1
        s;
        s = null;
_L1:
        return s;
    }
}
