// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class _cls9 extends Enum
{

    private static final CONFIRM $VALUES[];
    public static final CONFIRM CONFIRM;
    public static final CONFIRM MULTIPLE;
    public static final CONFIRM NONE;
    public static final CONFIRM TARGETED;

    public static _cls9 valueOf(String s)
    {
        return (_cls9)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$NlgParamMode, s);
    }

    public static _cls9[] values()
    {
        return (_cls9[])$VALUES.clone();
    }

    public String toString()
    {
        switch (com.samsung.android.sdk.bixby.BixbyApi.NlgParamMode[ordinal()])
        {
        default:
            return super.toString();

        case 1: // '\001'
            return "\"nlgParamMode\":\"none\"";

        case 2: // '\002'
            return "\"nlgParamMode\":\"targeted\"";

        case 3: // '\003'
            return "\"nlgParamMode\":\"multiple\"";

        case 4: // '\004'
            return "\"nlgParamMode\":\"confirm\"";
        }
    }

    static 
    {
        NONE = new <init>("NONE", 0);
        TARGETED = new <init>("TARGETED", 1);
        MULTIPLE = new <init>("MULTIPLE", 2);
        CONFIRM = new <init>("CONFIRM", 3);
        $VALUES = (new .VALUES[] {
            NONE, TARGETED, MULTIPLE, CONFIRM
        });
    }

    private _cls9(String s, int i)
    {
        super(s, i);
    }
}
