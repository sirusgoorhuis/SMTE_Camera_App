// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class  extends Enum
{

    private static final COMMON $VALUES[];
    public static final COMMON APPLY;
    public static final COMMON COMMON;
    public static final COMMON DELETE;
    public static final COMMON DISCARD;
    public static final COMMON EXECUTE;
    public static final COMMON FORWARD;
    public static final COMMON INQUIRE;
    public static final COMMON MERGE;
    public static final COMMON REPLY;
    public static final COMMON RESET;
    public static final COMMON SAVE;
    public static final COMMON SEND;
    public static final COMMON TURN_ON;
    public static final COMMON UPDATE;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ConfirmMode, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    public String toString()
    {
        switch (.com.samsung.android.sdk.bixby.BixbyApi.ConfirmMode[ordinal()])
        {
        default:
            return super.toString();

        case 1: // '\001'
            return "\"confirmMode\":\"send\"";

        case 2: // '\002'
            return "\"confirmMode\":\"delete\"";

        case 3: // '\003'
            return "\"confirmMode\":\"turnOn\"";

        case 4: // '\004'
            return "\"confirmMode\":\"apply\"";

        case 5: // '\005'
            return "\"confirmMode\":\"forward\"";

        case 6: // '\006'
            return "\"confirmMode\":\"merge\"";

        case 7: // '\007'
            return "\"confirmMode\":\"discard\"";

        case 8: // '\b'
            return "\"confirmMode\":\"reset\"";

        case 9: // '\t'
            return "\"confirmMode\":\"update\"";

        case 10: // '\n'
            return "\"confirmMode\":\"execute\"";

        case 11: // '\013'
            return "\"confirmMode\":\"inquire\"";

        case 12: // '\f'
            return "\"confirmMode\":\"save\"";

        case 13: // '\r'
            return "\"confirmMode\":\"reply\"";

        case 14: // '\016'
            return "\"confirmMode\":\"common\"";
        }
    }

    static 
    {
        SEND = new <init>("SEND", 0);
        DELETE = new <init>("DELETE", 1);
        TURN_ON = new <init>("TURN_ON", 2);
        APPLY = new <init>("APPLY", 3);
        FORWARD = new <init>("FORWARD", 4);
        MERGE = new <init>("MERGE", 5);
        DISCARD = new <init>("DISCARD", 6);
        RESET = new <init>("RESET", 7);
        UPDATE = new <init>("UPDATE", 8);
        EXECUTE = new <init>("EXECUTE", 9);
        INQUIRE = new <init>("INQUIRE", 10);
        SAVE = new <init>("SAVE", 11);
        REPLY = new <init>("REPLY", 12);
        COMMON = new <init>("COMMON", 13);
        $VALUES = (new .VALUES[] {
            SEND, DELETE, TURN_ON, APPLY, FORWARD, MERGE, DISCARD, RESET, UPDATE, EXECUTE, 
            INQUIRE, SAVE, REPLY, COMMON
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
