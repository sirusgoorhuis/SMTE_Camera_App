// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import com.samsung.android.sdk.bixby.data.PathRuleInfo;
import com.samsung.android.sdk.bixby.data.State;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            StateReader

class PathRuleInfoReader
{

    private static final String APPS = "apps";
    private static final String EXECUTION_TYPE = "executionType";
    private static final String INTENT = "intent";
    private static final String IS_CALLEE_PATH_RULE = "isCalleePathRule";
    private static final String IS_FROM_SIMULATOR = "isFromSimulator";
    private static final String IS_ROOT = "isRoot";
    private static final String PATH_RULE_ID = "pathRuleId";
    private static final String PATH_RULE_NAME = "pathRuleName";
    private static final String PATH_RULE_STATES = "states";
    private static final String SAMPLE_UTTERANCE = "sampleUtterance";
    private static final String UTTERANCE = "utterance";

    PathRuleInfoReader()
    {
    }

    public static PathRuleInfo read(String s)
        throws IllegalArgumentException
    {
        ArrayList arraylist;
        JSONArray jsonarray;
        boolean flag;
        boolean flag1;
        jsonarray = null;
        flag = false;
        flag1 = false;
        arraylist = null;
        String s1;
        String s2;
        String s3;
        String s4;
        String s5;
        String as[];
        JSONObject jsonobject;
        jsonobject = new JSONObject(s);
        s1 = jsonobject.getString("pathRuleId");
        s2 = jsonobject.getString("pathRuleName");
        s3 = jsonobject.getString("intent");
        s4 = jsonobject.getString("utterance");
        s5 = jsonobject.getString("sampleUtterance");
        s = jsonobject.getJSONArray("apps");
        as = new String[s.length()];
        int i = 0;
_L2:
        if (i >= s.length())
        {
            break; /* Loop/switch isn't completed */
        }
        as[i] = s.optString(i);
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        s = jsonarray;
        boolean flag2;
        if (jsonobject.has("executionType"))
        {
            s = jsonobject.getString("executionType");
        }
        flag2 = jsonobject.getBoolean("isRoot");
        if (jsonobject.has("isCalleePathRule"))
        {
            flag = jsonobject.getBoolean("isCalleePathRule");
        }
        if (jsonobject.has("isFromSimulator"))
        {
            flag1 = jsonobject.getBoolean("isFromSimulator");
        }
        if (!jsonobject.has("states"))
        {
            break MISSING_BLOCK_LABEL_254;
        }
        jsonarray = jsonobject.getJSONArray("states");
        arraylist = new ArrayList();
        i = 0;
_L4:
        if (i >= jsonarray.length())
        {
            break; /* Loop/switch isn't completed */
        }
        arraylist.add(StateReader.read(jsonarray.optString(i)));
        i++;
        if (true) goto _L4; else goto _L3
_L3:
        Collections.sort(arraylist, new Comparator() {

            public int compare(State state, State state1)
            {
                return state.getSeqNum().compareTo(state1.getSeqNum());
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((State)obj, (State)obj1);
            }

        });
        s = new PathRuleInfo(s1, s2, s3, s4, s5, as, s, flag2, flag, flag1, arraylist);
        return s;
        s;
_L6:
        throw new IllegalArgumentException(s.toString());
        s;
        if (true) goto _L6; else goto _L5
_L5:
    }
}
