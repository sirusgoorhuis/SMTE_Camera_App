// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import com.samsung.android.sdk.bixby.data.State;
import java.util.Comparator;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            PathRuleInfoReader

static final class 
    implements Comparator
{

    public int compare(State state, State state1)
    {
        return state.getSeqNum().compareTo(state1.getSeqNum());
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((State)obj, (State)obj1);
    }

    ()
    {
    }
}
