// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class  extends Enum
{

    private static final UNKNOWN $VALUES[];
    public static final UNKNOWN CANCEL;
    public static final UNKNOWN NO;
    public static final UNKNOWN OTHER;
    public static final UNKNOWN UNKNOWN;
    public static final UNKNOWN YES;

    public static  toEnum(String s)
    {
        byte byte0 = -1;
        s.hashCode();
        JVM INSTR lookupswitch 4: default 48
    //                   -1367724422: 112
    //                   3521: 98
    //                   119527: 84
    //                   106069776: 126;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        break; /* Loop/switch isn't completed */
_L5:
        break MISSING_BLOCK_LABEL_126;
_L6:
        switch (byte0)
        {
        default:
            return UNKNOWN;

        case 0: // '\0'
            return YES;

        case 1: // '\001'
            return NO;

        case 2: // '\002'
            return CANCEL;

        case 3: // '\003'
            return OTHER;
        }
_L4:
        if (s.equals("yes"))
        {
            byte0 = 0;
        }
          goto _L6
_L3:
        if (s.equals("no"))
        {
            byte0 = 1;
        }
          goto _L6
_L2:
        if (s.equals("cancel"))
        {
            byte0 = 2;
        }
          goto _L6
        if (s.equals("other"))
        {
            byte0 = 3;
        }
          goto _L6
    }

    public static OTHER valueOf(String s)
    {
        return (OTHER)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ConfirmResult, s);
    }

    public static OTHER[] values()
    {
        return (OTHER[])$VALUES.clone();
    }

    static 
    {
        YES = new <init>("YES", 0);
        NO = new <init>("NO", 1);
        CANCEL = new <init>("CANCEL", 2);
        OTHER = new <init>("OTHER", 3);
        UNKNOWN = new <init>("UNKNOWN", 4);
        $VALUES = (new .VALUES[] {
            YES, NO, CANCEL, OTHER, UNKNOWN
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
