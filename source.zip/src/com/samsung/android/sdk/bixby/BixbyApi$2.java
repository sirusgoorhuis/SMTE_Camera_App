// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

static class gParamMode
{

    static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[];
    static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[];
    static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[];
    static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[];

    static 
    {
        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults = new int[sponseResults.values().length];
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.SUCCESS.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror30) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.STATE_SUCCESS.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror29) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_SETUP_SUCCESS.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror28) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_TEARDOWN_SUCCESS.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror27) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_ALL_STATES_SUCCESS.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror26) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.FAILURE.ordinal()] = 6;
        }
        catch (NoSuchFieldError nosuchfielderror25) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.STATE_FAILURE.ordinal()] = 7;
        }
        catch (NoSuchFieldError nosuchfielderror24) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_SETUP_FAILURE.ordinal()] = 8;
        }
        catch (NoSuchFieldError nosuchfielderror23) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_TEARDOWN_FAILURE.ordinal()] = 9;
        }
        catch (NoSuchFieldError nosuchfielderror22) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.TEST_ALL_STATES_FAILURE.ordinal()] = 10;
        }
        catch (NoSuchFieldError nosuchfielderror21) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[sponseResults.RULE_COMPLETE.ordinal()] = 11;
        }
        catch (NoSuchFieldError nosuchfielderror20) { }
        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode = new int[sMode.values().length];
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[sMode.CUT.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror19) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[sMode.WAIT.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror18) { }
        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode = new int[nfirmMode.values().length];
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.SEND.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror17) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.DELETE.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror16) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.TURN_ON.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror15) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.APPLY.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror14) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.FORWARD.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror13) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.MERGE.ordinal()] = 6;
        }
        catch (NoSuchFieldError nosuchfielderror12) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.DISCARD.ordinal()] = 7;
        }
        catch (NoSuchFieldError nosuchfielderror11) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.RESET.ordinal()] = 8;
        }
        catch (NoSuchFieldError nosuchfielderror10) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.UPDATE.ordinal()] = 9;
        }
        catch (NoSuchFieldError nosuchfielderror9) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.EXECUTE.ordinal()] = 10;
        }
        catch (NoSuchFieldError nosuchfielderror8) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.INQUIRE.ordinal()] = 11;
        }
        catch (NoSuchFieldError nosuchfielderror7) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.SAVE.ordinal()] = 12;
        }
        catch (NoSuchFieldError nosuchfielderror6) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.REPLY.ordinal()] = 13;
        }
        catch (NoSuchFieldError nosuchfielderror5) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[nfirmMode.COMMON.ordinal()] = 14;
        }
        catch (NoSuchFieldError nosuchfielderror4) { }
        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode = new int[gParamMode.values().length];
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[gParamMode.NONE.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[gParamMode.TARGETED.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[gParamMode.MULTIPLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[gParamMode.CONFIRM.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
