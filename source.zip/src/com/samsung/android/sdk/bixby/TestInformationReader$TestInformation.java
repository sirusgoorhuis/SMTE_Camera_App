// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import java.util.Map;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            TestInformationReader

public static class content
{

    public static final String TYPE_SETUP = "setup";
    public static final String TYPE_TEARDOWN = "teardown";
    private Map content;
    private String type;

    public Map getContent()
    {
        return content;
    }

    public String getType()
    {
        return type;
    }

    public void setContent(Map map)
    {
        content = map;
    }

    public void setType(String s)
    {
        type = s;
    }

    public I(String s, Map map)
    {
        type = null;
        content = null;
        type = s;
        content = map;
    }
}
