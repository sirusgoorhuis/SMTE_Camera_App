// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import com.samsung.android.sdk.bixby.data.ParamFilling;
import com.samsung.android.sdk.bixby.data.ScreenStateInfo;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static interface A
    extends A
{

    public abstract boolean onParamFillingReceived(ParamFilling paramfilling);

    public abstract ScreenStateInfo onScreenStatesRequested();
}
