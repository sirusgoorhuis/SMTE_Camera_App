// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


public final class R
{
    public static final class string
    {

        public static final int app_name = 0x7f090128;

        public string()
        {
        }
    }


    public R()
    {
    }
}
