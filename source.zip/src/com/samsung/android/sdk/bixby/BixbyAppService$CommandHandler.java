// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyAppService

private static class  extends Handler
{

    public void dispatchMessage(Message message)
    {
        try
        {
            super.dispatchMessage(message);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Message message)
        {
            message.printStackTrace();
        }
    }

    (Looper looper)
    {
        super(looper);
    }
}
