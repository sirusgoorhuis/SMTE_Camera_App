// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.util.Log;
import com.samsung.android.bixby.agent.IBixbyAgentAppServiceCallback;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyAppService

class this._cls0
    implements eCallback
{

    final BixbyAppService this$0;

    public void onResponse(String s, String s1)
        throws IllegalStateException
    {
        if (BixbyAppService.access$000())
        {
            Log.d(BixbyAppService.access$100(), (new StringBuilder()).append("Send command to EM ").append(s).append(" ").append(s1).toString());
        } else
        {
            Log.d(BixbyAppService.access$100(), (new StringBuilder()).append("Send command to EM ").append(s).toString());
        }
        if (BixbyAppService.access$200(BixbyAppService.this) == null)
        {
            Log.e(BixbyAppService.access$100(), "No Bixby Agent response callback method registered.");
            return;
        }
        s = BixbyAppService.access$300(BixbyAppService.this, s, s1);
        if (s == null)
        {
            try
            {
                Log.e(BixbyAppService.access$100(), "Failed to handle response command to Bixby Agent.");
                return;
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                Log.e(BixbyAppService.access$100(), "Failed to send command to Bixby Agent.");
            }
            return;
        }
        if (BixbyAppService.access$000())
        {
            Log.d(BixbyAppService.access$100(), (new StringBuilder()).append("jsonResponse: ").append(s).toString());
        }
        BixbyAppService.access$200(BixbyAppService.this).onResponse(s);
        return;
    }

    rviceCallback()
    {
        this$0 = BixbyAppService.this;
        super();
    }
}
