// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi, ParamFillingReader, PathRuleInfoReader

class CommandHandlerRunnable
    implements Runnable
{

    static final String CMD_ALL_STATES = "emes_all_states";
    static final String CMD_CHATTY_MODE = "emes_chatty_mode";
    static final String CMD_CONTEXT = "emes_request_context";
    static final String CMD_FILLING = "emes_request_param_filling";
    static final String CMD_NLG_RESULT = "emes_nlg_end_result";
    static final String CMD_PARTIAL_LANDING_STATE = "emes_partial_landing_state";
    static final String CMD_PATH_RULE_INFO = "emes_pathrule_info";
    static final String CMD_SPLIT_STATE = "emes_split_state";
    static final String CMD_STATE = "emes_state";
    static final String CMD_TTS_RESULT = "emes_tts_result";
    static final String CMD_USER_CONFIRM = "emes_user_confirm";
    private static final String TAG = (new StringBuilder()).append(com/samsung/android/sdk/bixby/CommandHandlerRunnable.getSimpleName()).append("_0.2.7").toString();
    private BixbyApi mBixbyApi;
    private final String mJsonCommand;

    CommandHandlerRunnable(String s)
    {
        mJsonCommand = s;
        mBixbyApi = BixbyApi.getInstance();
    }

    private JSONObject getContent(JSONObject jsonobject)
        throws JSONException
    {
        return jsonobject.getJSONObject("content");
    }

    public void run()
    {
        Object obj;
        JSONObject jsonobject;
        try
        {
            jsonobject = new JSONObject(mJsonCommand);
            obj = jsonobject.getString("command");
            Log.d(TAG, (new StringBuilder()).append("Command from EM: ").append(((String) (obj))).toString());
            if (((String) (obj)).equals("emes_request_context"))
            {
                mBixbyApi.requestContext();
                return;
            }
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            ((JSONException) (obj)).printStackTrace();
            return;
        }
        jsonobject = getContent(jsonobject);
        if (((String) (obj)).equals("emes_state"))
        {
            mBixbyApi.mStateCommandJsonFromBa = mJsonCommand;
            obj = jsonobject.get("state").toString();
            mBixbyApi.sendState(((String) (obj)));
            return;
        }
        if (((String) (obj)).equals("emes_request_param_filling"))
        {
            obj = ParamFillingReader.read(jsonobject.get("slotFillingResult").toString());
            mBixbyApi.sendParamFilling(((com.samsung.android.sdk.bixby.data.ParamFilling) (obj)));
            return;
        }
        if (((String) (obj)).equals("emes_pathrule_info"))
        {
            obj = PathRuleInfoReader.read(jsonobject.get("pathRuleInfo").toString());
            mBixbyApi.handlePathRuleInfo(((com.samsung.android.sdk.bixby.data.PathRuleInfo) (obj)));
            return;
        }
        if (((String) (obj)).equals("emes_chatty_mode"))
        {
            obj = jsonobject.get("utterance").toString();
            boolean flag = jsonobject.getBoolean("directSend");
            mBixbyApi.sendChatText(((String) (obj)), flag);
            return;
        }
        if (((String) (obj)).equals("emes_split_state"))
        {
            mBixbyApi.sendMultiStates(jsonobject.getJSONArray("stateIds"));
            return;
        }
        if (((String) (obj)).equals("emes_all_states"))
        {
            mBixbyApi.sendAllStates(jsonobject.getJSONArray("states"));
            return;
        }
        if (((String) (obj)).equals("emes_partial_landing_state"))
        {
            boolean flag1 = jsonobject.getBoolean("isLanded");
            mBixbyApi.setPartiallyLanded(flag1);
            return;
        }
        if (((String) (obj)).equals("emes_user_confirm"))
        {
            mBixbyApi.sendUserConfirm(jsonobject.get("appName").toString(), jsonobject.get("result").toString());
            return;
        }
        if (((String) (obj)).equals("emes_tts_result"))
        {
            mBixbyApi.sendTtsResult(jsonobject.get("result").toString());
            return;
        }
        if (((String) (obj)).equals("emes_nlg_end_result"))
        {
            mBixbyApi.sendNlgEnd();
            return;
        }
        Log.e(TAG, (new StringBuilder()).append("Unknown command arrived : ").append(((String) (obj))).toString());
        return;
    }

}
