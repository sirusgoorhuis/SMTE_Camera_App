// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import com.samsung.android.sdk.bixby.data.NlgRequestInfo;
import com.samsung.android.sdk.bixby.data.ParamFilling;
import com.samsung.android.sdk.bixby.data.PathRuleInfo;
import com.samsung.android.sdk.bixby.data.ScreenStateInfo;
import com.samsung.android.sdk.bixby.data.State;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            TestInformationReader, StateReader

public class BixbyApi
{
    public static abstract class AbstractEventMonitor
    {

        public void onPathRuleStarted(PathRuleInfo pathruleinfo)
        {
            Log.d(BixbyApi.TAG, "AbstractEventMonitor onPathRuleStarted()");
        }

        public void onServiceBound(Intent intent)
        {
            Log.d(BixbyApi.TAG, "AbstractEventMonitor onServiceBound()");
        }

        public void onServiceCreated()
        {
            Log.d(BixbyApi.TAG, "AbstractEventMonitor onServiceCreated()");
        }

        public void onServiceDestroyed()
        {
            Log.d(BixbyApi.TAG, "AbstractEventMonitor onServiceDestroyed()");
        }

        public void onServiceUnbound(Intent intent)
        {
            Log.d(BixbyApi.TAG, "AbstractEventMonitor onServiceUnbound()");
        }

        public AbstractEventMonitor()
        {
        }
    }

    public static interface ChattyModeListener
    {

        public abstract boolean onChatTextReceived(String s, boolean flag);
    }

    public static interface CommonStateListener
    {

        public abstract void onRuleCanceled(String s);

        public abstract void onStateReceived(State state);
    }

    public static final class ConfirmMode extends Enum
    {

        private static final ConfirmMode $VALUES[];
        public static final ConfirmMode APPLY;
        public static final ConfirmMode COMMON;
        public static final ConfirmMode DELETE;
        public static final ConfirmMode DISCARD;
        public static final ConfirmMode EXECUTE;
        public static final ConfirmMode FORWARD;
        public static final ConfirmMode INQUIRE;
        public static final ConfirmMode MERGE;
        public static final ConfirmMode REPLY;
        public static final ConfirmMode RESET;
        public static final ConfirmMode SAVE;
        public static final ConfirmMode SEND;
        public static final ConfirmMode TURN_ON;
        public static final ConfirmMode UPDATE;

        public static ConfirmMode valueOf(String s)
        {
            return (ConfirmMode)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ConfirmMode, s);
        }

        public static ConfirmMode[] values()
        {
            return (ConfirmMode[])$VALUES.clone();
        }

        public String toString()
        {
            static class _cls2
            {

                static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[];
                static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[];
                static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[];
                static final int $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[];

                static 
                {
                    $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults = new int[ResponseResults.values().length];
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.SUCCESS.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror30) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.STATE_SUCCESS.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror29) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_SETUP_SUCCESS.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror28) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_TEARDOWN_SUCCESS.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror27) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_ALL_STATES_SUCCESS.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror26) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.FAILURE.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror25) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.STATE_FAILURE.ordinal()] = 7;
                    }
                    catch (NoSuchFieldError nosuchfielderror24) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_SETUP_FAILURE.ordinal()] = 8;
                    }
                    catch (NoSuchFieldError nosuchfielderror23) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_TEARDOWN_FAILURE.ordinal()] = 9;
                    }
                    catch (NoSuchFieldError nosuchfielderror22) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.TEST_ALL_STATES_FAILURE.ordinal()] = 10;
                    }
                    catch (NoSuchFieldError nosuchfielderror21) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ResponseResults[ResponseResults.RULE_COMPLETE.ordinal()] = 11;
                    }
                    catch (NoSuchFieldError nosuchfielderror20) { }
                    $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode = new int[TtsMode.values().length];
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[TtsMode.CUT.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror19) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$TtsMode[TtsMode.WAIT.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror18) { }
                    $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode = new int[ConfirmMode.values().length];
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.SEND.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror17) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.DELETE.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror16) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.TURN_ON.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror15) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.APPLY.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror14) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.FORWARD.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror13) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.MERGE.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror12) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.DISCARD.ordinal()] = 7;
                    }
                    catch (NoSuchFieldError nosuchfielderror11) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.RESET.ordinal()] = 8;
                    }
                    catch (NoSuchFieldError nosuchfielderror10) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.UPDATE.ordinal()] = 9;
                    }
                    catch (NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.EXECUTE.ordinal()] = 10;
                    }
                    catch (NoSuchFieldError nosuchfielderror8) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.INQUIRE.ordinal()] = 11;
                    }
                    catch (NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.SAVE.ordinal()] = 12;
                    }
                    catch (NoSuchFieldError nosuchfielderror6) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.REPLY.ordinal()] = 13;
                    }
                    catch (NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$ConfirmMode[ConfirmMode.COMMON.ordinal()] = 14;
                    }
                    catch (NoSuchFieldError nosuchfielderror4) { }
                    $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode = new int[NlgParamMode.values().length];
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[NlgParamMode.NONE.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[NlgParamMode.TARGETED.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[NlgParamMode.MULTIPLE.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$samsung$android$sdk$bixby$BixbyApi$NlgParamMode[NlgParamMode.CONFIRM.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror)
                    {
                        return;
                    }
                }
            }

            switch (_cls2..SwitchMap.com.samsung.android.sdk.bixby.BixbyApi.ConfirmMode[ordinal()])
            {
            default:
                return super.toString();

            case 1: // '\001'
                return "\"confirmMode\":\"send\"";

            case 2: // '\002'
                return "\"confirmMode\":\"delete\"";

            case 3: // '\003'
                return "\"confirmMode\":\"turnOn\"";

            case 4: // '\004'
                return "\"confirmMode\":\"apply\"";

            case 5: // '\005'
                return "\"confirmMode\":\"forward\"";

            case 6: // '\006'
                return "\"confirmMode\":\"merge\"";

            case 7: // '\007'
                return "\"confirmMode\":\"discard\"";

            case 8: // '\b'
                return "\"confirmMode\":\"reset\"";

            case 9: // '\t'
                return "\"confirmMode\":\"update\"";

            case 10: // '\n'
                return "\"confirmMode\":\"execute\"";

            case 11: // '\013'
                return "\"confirmMode\":\"inquire\"";

            case 12: // '\f'
                return "\"confirmMode\":\"save\"";

            case 13: // '\r'
                return "\"confirmMode\":\"reply\"";

            case 14: // '\016'
                return "\"confirmMode\":\"common\"";
            }
        }

        static 
        {
            SEND = new ConfirmMode("SEND", 0);
            DELETE = new ConfirmMode("DELETE", 1);
            TURN_ON = new ConfirmMode("TURN_ON", 2);
            APPLY = new ConfirmMode("APPLY", 3);
            FORWARD = new ConfirmMode("FORWARD", 4);
            MERGE = new ConfirmMode("MERGE", 5);
            DISCARD = new ConfirmMode("DISCARD", 6);
            RESET = new ConfirmMode("RESET", 7);
            UPDATE = new ConfirmMode("UPDATE", 8);
            EXECUTE = new ConfirmMode("EXECUTE", 9);
            INQUIRE = new ConfirmMode("INQUIRE", 10);
            SAVE = new ConfirmMode("SAVE", 11);
            REPLY = new ConfirmMode("REPLY", 12);
            COMMON = new ConfirmMode("COMMON", 13);
            $VALUES = (new ConfirmMode[] {
                SEND, DELETE, TURN_ON, APPLY, FORWARD, MERGE, DISCARD, RESET, UPDATE, EXECUTE, 
                INQUIRE, SAVE, REPLY, COMMON
            });
        }

        private ConfirmMode(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class ConfirmResult extends Enum
    {

        private static final ConfirmResult $VALUES[];
        public static final ConfirmResult CANCEL;
        public static final ConfirmResult NO;
        public static final ConfirmResult OTHER;
        public static final ConfirmResult UNKNOWN;
        public static final ConfirmResult YES;

        public static ConfirmResult toEnum(String s)
        {
            byte byte0 = -1;
            s.hashCode();
            JVM INSTR lookupswitch 4: default 48
        //                       -1367724422: 112
        //                       3521: 98
        //                       119527: 84
        //                       106069776: 126;
               goto _L1 _L2 _L3 _L4 _L5
_L1:
            break; /* Loop/switch isn't completed */
_L5:
            break MISSING_BLOCK_LABEL_126;
_L6:
            switch (byte0)
            {
            default:
                return UNKNOWN;

            case 0: // '\0'
                return YES;

            case 1: // '\001'
                return NO;

            case 2: // '\002'
                return CANCEL;

            case 3: // '\003'
                return OTHER;
            }
_L4:
            if (s.equals("yes"))
            {
                byte0 = 0;
            }
              goto _L6
_L3:
            if (s.equals("no"))
            {
                byte0 = 1;
            }
              goto _L6
_L2:
            if (s.equals("cancel"))
            {
                byte0 = 2;
            }
              goto _L6
            if (s.equals("other"))
            {
                byte0 = 3;
            }
              goto _L6
        }

        public static ConfirmResult valueOf(String s)
        {
            return (ConfirmResult)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ConfirmResult, s);
        }

        public static ConfirmResult[] values()
        {
            return (ConfirmResult[])$VALUES.clone();
        }

        static 
        {
            YES = new ConfirmResult("YES", 0);
            NO = new ConfirmResult("NO", 1);
            CANCEL = new ConfirmResult("CANCEL", 2);
            OTHER = new ConfirmResult("OTHER", 3);
            UNKNOWN = new ConfirmResult("UNKNOWN", 4);
            $VALUES = (new ConfirmResult[] {
                YES, NO, CANCEL, OTHER, UNKNOWN
            });
        }

        private ConfirmResult(String s, int i)
        {
            super(s, i);
        }
    }

    public static interface ConfirmResultListener
    {

        public abstract void onResult(ConfirmResult confirmresult);
    }

    public static interface InterimStateListener
        extends CommonStateListener
    {

        public abstract boolean onParamFillingReceived(ParamFilling paramfilling);

        public abstract ScreenStateInfo onScreenStatesRequested();
    }

    public static interface MultiPathRuleListener
    {

        public abstract String onPathRuleSplit(List list);
    }

    public static final class NlgParamMode extends Enum
    {

        private static final NlgParamMode $VALUES[];
        public static final NlgParamMode CONFIRM;
        public static final NlgParamMode MULTIPLE;
        public static final NlgParamMode NONE;
        public static final NlgParamMode TARGETED;

        public static NlgParamMode valueOf(String s)
        {
            return (NlgParamMode)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$NlgParamMode, s);
        }

        public static NlgParamMode[] values()
        {
            return (NlgParamMode[])$VALUES.clone();
        }

        public String toString()
        {
            switch (_cls2..SwitchMap.com.samsung.android.sdk.bixby.BixbyApi.NlgParamMode[ordinal()])
            {
            default:
                return super.toString();

            case 1: // '\001'
                return "\"nlgParamMode\":\"none\"";

            case 2: // '\002'
                return "\"nlgParamMode\":\"targeted\"";

            case 3: // '\003'
                return "\"nlgParamMode\":\"multiple\"";

            case 4: // '\004'
                return "\"nlgParamMode\":\"confirm\"";
            }
        }

        static 
        {
            NONE = new NlgParamMode("NONE", 0);
            TARGETED = new NlgParamMode("TARGETED", 1);
            MULTIPLE = new NlgParamMode("MULTIPLE", 2);
            CONFIRM = new NlgParamMode("CONFIRM", 3);
            $VALUES = (new NlgParamMode[] {
                NONE, TARGETED, MULTIPLE, CONFIRM
            });
        }

        private NlgParamMode(String s, int i)
        {
            super(s, i);
        }
    }

    public static interface OnConfirmResultListener
    {

        public abstract void onConfirmResult(ConfirmResult confirmresult);
    }

    public static interface OnNlgEndListener
    {

        public abstract void onNlgEnd();
    }

    static interface OnResponseCallback
    {

        public abstract void onResponse(String s, String s1);
    }

    public static interface OnTtsResultListener
    {

        public abstract void onTtsResult(TtsResult ttsresult);
    }

    public static final class ResponseResults extends Enum
    {

        private static final ResponseResults $VALUES[];
        public static final ResponseResults FAILURE;
        public static final ResponseResults RULE_COMPLETE;
        public static final ResponseResults STATE_FAILURE;
        public static final ResponseResults STATE_SUCCESS;
        public static final ResponseResults SUCCESS;
        public static final ResponseResults TEST_ALL_STATES_FAILURE;
        public static final ResponseResults TEST_ALL_STATES_SUCCESS;
        public static final ResponseResults TEST_SETUP_FAILURE;
        public static final ResponseResults TEST_SETUP_SUCCESS;
        public static final ResponseResults TEST_TEARDOWN_FAILURE;
        public static final ResponseResults TEST_TEARDOWN_SUCCESS;
        private int value;

        public static ResponseResults valueOf(String s)
        {
            return (ResponseResults)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$ResponseResults, s);
        }

        public static ResponseResults[] values()
        {
            return (ResponseResults[])$VALUES.clone();
        }

        public int getValue()
        {
            return value;
        }

        public String toString()
        {
            switch (_cls2..SwitchMap.com.samsung.android.sdk.bixby.BixbyApi.ResponseResults[ordinal()])
            {
            default:
                return super.toString();

            case 1: // '\001'
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
                return "success";

            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
            case 9: // '\t'
            case 10: // '\n'
                return "failure";

            case 11: // '\013'
                return "rule_complete";
            }
        }

        static 
        {
            SUCCESS = new ResponseResults("SUCCESS", 0, 0);
            FAILURE = new ResponseResults("FAILURE", 1, 1);
            STATE_SUCCESS = new ResponseResults("STATE_SUCCESS", 2, 0);
            STATE_FAILURE = new ResponseResults("STATE_FAILURE", 3, 1);
            TEST_SETUP_SUCCESS = new ResponseResults("TEST_SETUP_SUCCESS", 4, 2);
            TEST_SETUP_FAILURE = new ResponseResults("TEST_SETUP_FAILURE", 5, 3);
            TEST_TEARDOWN_SUCCESS = new ResponseResults("TEST_TEARDOWN_SUCCESS", 6, 4);
            TEST_TEARDOWN_FAILURE = new ResponseResults("TEST_TEARDOWN_FAILURE", 7, 5);
            TEST_ALL_STATES_SUCCESS = new ResponseResults("TEST_ALL_STATES_SUCCESS", 8, 6);
            TEST_ALL_STATES_FAILURE = new ResponseResults("TEST_ALL_STATES_FAILURE", 9, 7);
            RULE_COMPLETE = new ResponseResults("RULE_COMPLETE", 10, 8);
            $VALUES = (new ResponseResults[] {
                SUCCESS, FAILURE, STATE_SUCCESS, STATE_FAILURE, TEST_SETUP_SUCCESS, TEST_SETUP_FAILURE, TEST_TEARDOWN_SUCCESS, TEST_TEARDOWN_FAILURE, TEST_ALL_STATES_SUCCESS, TEST_ALL_STATES_FAILURE, 
                RULE_COMPLETE
            });
        }

        private ResponseResults(String s, int i, int j)
        {
            super(s, i);
            value = j;
        }
    }

    public static interface StartStateListener
        extends CommonStateListener
    {
    }

    public static interface TestListener
    {

        public abstract void onAllStates(ArrayList arraylist);

        public abstract void onSetup(Map map);

        public abstract void onTearDown(Map map);
    }

    public static final class TtsMode extends Enum
    {

        private static final TtsMode $VALUES[];
        public static final TtsMode CUT;
        public static final TtsMode WAIT;

        public static TtsMode valueOf(String s)
        {
            return (TtsMode)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$TtsMode, s);
        }

        public static TtsMode[] values()
        {
            return (TtsMode[])$VALUES.clone();
        }

        public String toString()
        {
            switch (_cls2..SwitchMap.com.samsung.android.sdk.bixby.BixbyApi.TtsMode[ordinal()])
            {
            default:
                return super.toString();

            case 1: // '\001'
                return "\"ttsMode\":\"cut\"";

            case 2: // '\002'
                return "\"ttsMode\":\"wait\"";
            }
        }

        static 
        {
            CUT = new TtsMode("CUT", 0);
            WAIT = new TtsMode("WAIT", 1);
            $VALUES = (new TtsMode[] {
                CUT, WAIT
            });
        }

        private TtsMode(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class TtsResult extends Enum
    {

        private static final TtsResult $VALUES[];
        public static final TtsResult COMPLETE;
        public static final TtsResult STOP_ON_CANCEL;
        public static final TtsResult STOP_ON_ERROR;
        public static final TtsResult UNKNOWN;

        public static TtsResult toEnum(String s)
        {
            byte byte0 = -1;
            s.hashCode();
            JVM INSTR lookupswitch 3: default 40
        //                       -2089014459: 86
        //                       -599445191: 72
        //                       -408027939: 100;
               goto _L1 _L2 _L3 _L4
_L1:
            break; /* Loop/switch isn't completed */
_L4:
            break MISSING_BLOCK_LABEL_100;
_L5:
            switch (byte0)
            {
            default:
                return UNKNOWN;

            case 0: // '\0'
                return COMPLETE;

            case 1: // '\001'
                return STOP_ON_ERROR;

            case 2: // '\002'
                return STOP_ON_CANCEL;
            }
_L3:
            if (s.equals("complete"))
            {
                byte0 = 0;
            }
              goto _L5
_L2:
            if (s.equals("stop_on_error"))
            {
                byte0 = 1;
            }
              goto _L5
            if (s.equals("stop_on_cancel"))
            {
                byte0 = 2;
            }
              goto _L5
        }

        public static TtsResult valueOf(String s)
        {
            return (TtsResult)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$TtsResult, s);
        }

        public static TtsResult[] values()
        {
            return (TtsResult[])$VALUES.clone();
        }

        static 
        {
            COMPLETE = new TtsResult("COMPLETE", 0);
            STOP_ON_ERROR = new TtsResult("STOP_ON_ERROR", 1);
            STOP_ON_CANCEL = new TtsResult("STOP_ON_CANCEL", 2);
            UNKNOWN = new TtsResult("UNKNOWN", 3);
            $VALUES = (new TtsResult[] {
                COMPLETE, STOP_ON_ERROR, STOP_ON_CANCEL, UNKNOWN
            });
        }

        private TtsResult(String s, int i)
        {
            super(s, i);
        }
    }


    static final String CM_ACTION = "com.samsung.android.rubin.app.intent.action.CM_LOGGING";
    private static final String CM_PACKAGE = "com.samsung.android.rubin.app";
    private static final boolean DEBUG;
    static final String RESULT_CODE_ALL_STATES = "esem_all_states_result";
    static final String RESULT_CODE_APP_CONTEXT = "esem_context_result";
    static final String RESULT_CODE_CHATTY_MODE = "esem_chatty_mode_result";
    static final String RESULT_CODE_CHATTY_MODE_CANCEL = "esem_cancel_chatty_mode";
    static final String RESULT_CODE_CLIENT_CONTROL = "esem_client_control";
    static final String RESULT_CODE_LOG_STATE = "esem_state_log";
    static final String RESULT_CODE_NLG = "esem_request_nlg";
    static final String RESULT_CODE_PARAM_FILLING = "esem_param_filling_result";
    static final String RESULT_CODE_SPLIT_STATE = "esem_split_state_result";
    static final String RESULT_CODE_STATE_COMMAND = "state_command_result";
    static final String RESULT_CODE_TTS = "esem_request_tts";
    static final String RESULT_CODE_USER_CONFIRM = "esem_user_confirm_result";
    private static final int SEQ_NUM_FIRST = 1;
    private static final int SEQ_NUM_RULE_CANCEL = -1;
    private static final int SEQ_NUM_TEST = 0;
    private static final String STR_FAILURE = "failure";
    private static final String STR_RULE_COMPLETE = "rule_complete";
    private static final String STR_SUCCESS = "success";
    private static final String TAG = (new StringBuilder()).append(com/samsung/android/sdk/bixby/BixbyApi.getSimpleName()).append("_0.2.7").toString();
    static final String VER = "_0.2.7";
    private static BixbyApi mInstance;
    private static final Object syncObj = new Object();
    final String TEST_INFORMATIONS = "testInformations";
    private AbstractEventMonitor mAbstractEventMonitor;
    private String mActiveAppName;
    private ChattyModeListener mChattyModeListener;
    private ConfirmResultListener mConfirmResultListener;
    private Context mContext;
    Handler mHandler;
    private InterimStateListener mInterimListener;
    private boolean mIsPartiallyLanded;
    private boolean mIsRuleRunning;
    private boolean mIsTestMode;
    private boolean mIsTestRunning;
    private State mLastReceivedStateCmd;
    private ScreenStateInfo mLastScreenStateInfo;
    private MultiPathRuleListener mMultiPathRuleListener;
    private OnConfirmResultListener mOnConfirmResultListener;
    private OnNlgEndListener mOnNlgEndListener;
    private OnTtsResultListener mOnTtsResultListener;
    private String mPackageVersionName;
    private PathRuleInfo mPathRuleInfo;
    private OnResponseCallback mResponseCallback;
    private int mSendStateRetryCount;
    private Runnable mSendStateRunnable;
    private StartStateListener mStartListener;
    String mStateCommandJsonFromBa;
    private TestListener mTestListener;

    protected BixbyApi()
    {
        mLastScreenStateInfo = ScreenStateInfo.STATE_NOT_APPLICABLE;
        mHandler = new Handler();
        mIsTestMode = false;
        mIsTestRunning = false;
        mIsRuleRunning = false;
        mLastReceivedStateCmd = null;
        mPathRuleInfo = null;
        mIsPartiallyLanded = false;
    }

    private void clearListeners()
    {
        setConfirmResultListener(null);
        setOnConfirmResultListener(null);
        setOnTtsResultListener(null);
        setOnNlgEndListener(null);
    }

    public static BixbyApi createInstance(Context context, String s)
    {
        if (context == null)
        {
            throw new IllegalArgumentException("Context cannot be null.");
        }
        Object obj = syncObj;
        obj;
        JVM INSTR monitorenter ;
        Object obj1;
        if (mInstance == null)
        {
            mInstance = new BixbyApi();
        }
        mInstance.setContext(context);
        mInstance.setActiveApp(s);
        obj1 = context.getPackageManager();
        obj1 = ((PackageManager) (obj1)).getPackageInfo(context.getPackageName(), 0);
        mInstance.setVersionName(((PackageInfo) (obj1)).versionName);
        if (DEBUG)
        {
            Log.d(TAG, (new StringBuilder()).append("createInstance: Version Name:").append(((PackageInfo) (obj1)).versionName).append(", ").append(s).toString());
        }
_L1:
        context = mInstance;
        return context;
        s;
        Log.e(TAG, (new StringBuilder()).append("createInstance: cannot get versionName from package = ").append(context.getPackageName()).toString());
        mInstance.setVersionName("");
          goto _L1
        context;
        obj;
        JVM INSTR monitorexit ;
        throw context;
    }

    private Intent createIntent(String s)
        throws IllegalStateException
    {
        Intent intent = new Intent();
        intent.setAction("com.samsung.android.rubin.app.intent.action.CM_LOGGING");
        intent.setPackage("com.samsung.android.rubin.app");
        intent.putExtra("command", s);
        intent.putExtra("appName", mActiveAppName);
        intent.putExtra("appVersion", mPackageVersionName);
        intent.putExtra("timestamp", getTimestamp());
        return intent;
    }

    private String createLogStateData(String s, String s1)
    {
        return "\"appName\":\"" + mActiveAppName + "\"," + "\"logType\":\"" + s + "\"," + "\"stateIds\":\"" + s1 + "\"";
    }

    public static BixbyApi getInstance()
        throws IllegalStateException
    {
        Object obj = syncObj;
        obj;
        JVM INSTR monitorenter ;
        if (mInstance == null)
        {
            throw new IllegalStateException("Instance is null. please call createInstance() for the first time.");
        }
        break MISSING_BLOCK_LABEL_28;
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
        BixbyApi bixbyapi = mInstance;
        obj;
        JVM INSTR monitorexit ;
        return bixbyapi;
    }

    private String getNlgStateInfo()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (mInterimListener != null)
        {
            Object obj = mInterimListener.onScreenStatesRequested();
            if (obj == ScreenStateInfo.STATE_NOT_APPLICABLE)
            {
                throw new IllegalArgumentException("Partial Landing handler requires the current state ID. onScreenStatesRequested() is not allowed to return null.");
            }
            obj = ((ScreenStateInfo) (obj)).getStates();
            if (obj != null && !((LinkedHashSet) (obj)).isEmpty())
            {
                for (obj = ((LinkedHashSet) (obj)).iterator(); ((Iterator) (obj)).hasNext(); stringbuilder.append((String)((Iterator) (obj)).next()).append(",")) { }
                stringbuilder.deleteCharAt(stringbuilder.length() - 1);
            }
        } else
        {
            stringbuilder.append("");
        }
        return stringbuilder.toString();
    }

    private Long getTimestamp()
    {
        return Long.valueOf(System.currentTimeMillis());
    }

    private void handleFirstState(State state)
    {
        if (mStartListener != null)
        {
            mStartListener.onStateReceived(state);
            return;
        } else
        {
            Log.v(TAG, "sendState: The first state arrived but StartListener has not been set.");
            sendCommandToBa("state_command_result", ResponseResults.STATE_FAILURE.toString());
            return;
        }
    }

    private void handleRuleCancel(State state)
    {
        setRuleRunning(false);
        if (mOnConfirmResultListener == null) goto _L2; else goto _L1
_L1:
        mOnConfirmResultListener.onConfirmResult(ConfirmResult.CANCEL);
_L4:
        if (mInterimListener == null && mStartListener == null)
        {
            Log.e(TAG, "sendState: No listener is set.");
            return;
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (mConfirmResultListener != null)
        {
            mConfirmResultListener.onResult(ConfirmResult.CANCEL);
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (mInterimListener != null)
        {
            mInterimListener.onRuleCanceled(state.getRuleId());
        }
        if (mStartListener != null)
        {
            mStartListener.onRuleCanceled(state.getRuleId());
        }
        clearListeners();
        return;
    }

    private void handleStates(final State state)
    {
        if (mSendStateRunnable != null)
        {
            Log.e(TAG, "sendState: Remove pending state.");
            mHandler.removeCallbacks(mSendStateRunnable);
        }
        mSendStateRetryCount = 0;
        mSendStateRunnable = new Runnable() ;
        mHandler.post(mSendStateRunnable);
        if (state.isLastState().booleanValue())
        {
            mIsTestMode = false;
        }
    }

    private void handleTestResponse(ResponseResults responseresults, State state)
    {
        if (state.isLastState().booleanValue())
        {
            setRuleRunning(false);
            if (isTestRunning())
            {
                setTestRunning(false);
            }
        } else
        if (state.getSeqNum().intValue() == 0 && responseresults == ResponseResults.TEST_SETUP_SUCCESS)
        {
            setTestRunning(true);
            return;
        }
    }

    private void handleTestState(String s)
    {
        mIsTestMode = true;
        Log.d(TAG, "handleTestState: SeqNo 0 found. isTestMode true");
        Object obj;
        obj = new JSONObject(s);
        if (!((JSONObject) (obj)).has("testInformations"))
        {
            break MISSING_BLOCK_LABEL_269;
        }
        if (mTestListener == null)
        {
            sendResponse(ResponseResults.TEST_SETUP_FAILURE);
            return;
        }
        try
        {
            obj = TestInformationReader.read(((JSONObject) (obj)).get("testInformations").toString());
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            Log.e(TAG, (new StringBuilder()).append("handleTestState: Invalid JSON:").append(s).toString());
            sendResponse(ResponseResults.TEST_SETUP_FAILURE);
            return;
        }
        if (obj == null)
        {
            break MISSING_BLOCK_LABEL_74;
        }
        if (!((List) (obj)).isEmpty())
        {
            break MISSING_BLOCK_LABEL_118;
        }
        sendResponse(ResponseResults.TEST_SETUP_FAILURE);
        return;
        obj = ((List) (obj)).iterator();
_L4:
        TestInformationReader.TestInformation testinformation;
        if (!((Iterator) (obj)).hasNext())
        {
            break MISSING_BLOCK_LABEL_261;
        }
        testinformation = (TestInformationReader.TestInformation)((Iterator) (obj)).next();
        if (!"setup".equals(testinformation.getType())) goto _L2; else goto _L1
_L1:
        if (testinformation.getContent() == null)
        {
            sendResponse(ResponseResults.TEST_SETUP_FAILURE);
            return;
        }
        mTestListener.onSetup(testinformation.getContent());
        return;
_L2:
        if (!"teardown".equals(testinformation.getType()))
        {
            break MISSING_BLOCK_LABEL_228;
        }
        if (testinformation.getContent() == null)
        {
            sendResponse(ResponseResults.TEST_SETUP_FAILURE);
            return;
        }
        mTestListener.onTearDown(testinformation.getContent());
        return;
        Log.d(TAG, (new StringBuilder()).append("Unsupported Item:").append(testinformation.getType()).toString());
        if (true) goto _L4; else goto _L3
_L3:
        sendResponse(ResponseResults.TEST_SETUP_SUCCESS);
        return;
        sendResponse(ResponseResults.TEST_SETUP_SUCCESS);
        return;
    }

    public static boolean isBixbySupported()
    {
        boolean flag;
        Class class1 = Class.forName("com.samsung.android.feature.SemFloatingFeature");
        Object obj1 = class1.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
        flag = ((Boolean)class1.getMethod("getBoolean", new Class[] {
            java/lang/String, Boolean.TYPE
        }).invoke(obj1, new Object[] {
            "SEC_FLOATING_FEATURE_COMMON_SUPPORT_BIXBY", Boolean.valueOf(false)
        })).booleanValue();
        Log.d(TAG, (new StringBuilder()).append("isBixbySupported:").append(flag).toString());
        return flag;
        Object obj;
        obj;
_L2:
        Log.d(TAG, "isBixbySupported: Can't read information on Bixby support.");
        Log.d(TAG, ((Exception) (obj)).toString());
        return false;
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        continue; /* Loop/switch isn't completed */
        obj;
        if (true) goto _L2; else goto _L1
_L1:
    }

    private void logState(String s, String s1)
        throws IllegalStateException
    {
        if (s1 == null)
        {
            throw new IllegalArgumentException("Log value cannot be null.");
        }
        try
        {
            sendCommandToBa("esem_state_log", createLogStateData(s, s1));
        }
        catch (Exception exception)
        {
            Log.e(TAG, "logState: Can't send log to BixbyAgent.");
        }
        s = createIntent(s);
        s.putExtra("stateIds", s1);
        mContext.sendBroadcast(s);
    }

    private void notifyActivityLaunchState(boolean flag)
    {
        if (!isRuleRunning())
        {
            Log.e(TAG, "activityLaunched: Path Rule is not running.");
            return;
        } else
        {
            sendCommandToBa("esem_client_control", (new StringBuilder()).append("\"activityLaunched\":").append(flag).toString());
            return;
        }
    }

    private void requestTtsInternal(String s, TtsMode ttsmode)
    {
        s = JSONObject.quote(s);
        sendCommandToBa("esem_request_tts", String.format("\"appName\":\"%s\",\"text\":%s,%s", new Object[] {
            getActiveApp(), s, ttsmode.toString()
        }));
    }

    private void sendCommandToBa(String s, String s1)
    {
        if (mResponseCallback != null)
        {
            mResponseCallback.onResponse(s, s1);
        } else
        if (!s.equals("esem_state_log") && !s.equals("esem_cancel_chatty_mode"))
        {
            Log.e(TAG, "sendCommandToBa: Bixby Agent is not connected.");
            return;
        }
    }

    private void setConfirmResultListener(ConfirmResultListener confirmresultlistener)
    {
        mConfirmResultListener = confirmresultlistener;
    }

    private void setContext(Context context)
    {
        mContext = context;
    }

    private String setNlgData(NlgRequestInfo nlgrequestinfo, NlgParamMode nlgparammode, OnNlgEndListener onnlgendlistener)
    {
        String s = "NONE";
        if (nlgparammode == NlgParamMode.MULTIPLE)
        {
            s = getNlgStateInfo();
        }
        s = (new StringBuilder()).append("\"currentStateIds\":\"").append(s).append("\"").toString();
        if (onnlgendlistener != null)
        {
            onnlgendlistener = "\"needResultCallback\":true";
        } else
        {
            onnlgendlistener = "\"needResultCallback\":false";
        }
        return String.format("\"requestedAppName\":\"%s\",%s,%s,%s,%s", new Object[] {
            mActiveAppName, nlgrequestinfo.toString(), s, nlgparammode.toString(), onnlgendlistener
        });
    }

    private void setOnConfirmResultListener(OnConfirmResultListener onconfirmresultlistener)
    {
        Log.e(TAG, (new StringBuilder()).append("setOnConfirmResultListener:").append(onconfirmresultlistener).toString());
        mOnConfirmResultListener = onconfirmresultlistener;
    }

    private void setOnNlgEndListener(OnNlgEndListener onnlgendlistener)
    {
        mOnNlgEndListener = onnlgendlistener;
    }

    private void setOnTtsResultListener(OnTtsResultListener onttsresultlistener)
    {
        mOnTtsResultListener = onttsresultlistener;
    }

    private void setRuleRunning(boolean flag)
    {
        mIsRuleRunning = flag;
    }

    private void setTestRunning(boolean flag)
    {
        mIsTestRunning = flag;
    }

    private void setVersionName(String s)
    {
        mPackageVersionName = s;
    }

    void clearData()
    {
        setRuleRunning(false);
        setTestRunning(false);
        setResponseCallback(null);
        setPartiallyLanded(false);
        clearListeners();
    }

    public void clearInterimStateListener()
    {
        if (mInterimListener == null)
        {
            return;
        } else
        {
            mLastScreenStateInfo = mInterimListener.onScreenStatesRequested();
            mInterimListener = null;
            return;
        }
    }

    public void extendTimeout(int i)
    {
        if (!isRuleRunning())
        {
            Log.e(TAG, "extendTimeout: Path Rule is not running.");
            return;
        }
        if (i < 1)
        {
            Log.e(TAG, "extendTimeout: Timeout value is not in the valid range. ");
            return;
        } else
        {
            sendCommandToBa("esem_client_control", (new StringBuilder()).append("\"pathRuleTimeout\":").append(i).toString());
            return;
        }
    }

    public String getActiveApp()
    {
        return mActiveAppName;
    }

    public PathRuleInfo getPathRuleInfo()
    {
        if (mIsRuleRunning)
        {
            return mPathRuleInfo;
        } else
        {
            return null;
        }
    }

    void handlePathRuleInfo(PathRuleInfo pathruleinfo)
    {
        mPathRuleInfo = pathruleinfo;
        if (mAbstractEventMonitor != null)
        {
            mAbstractEventMonitor.onPathRuleStarted(pathruleinfo);
        }
    }

    public boolean isPartiallyLanded()
    {
        return mIsPartiallyLanded;
    }

    public boolean isRuleRunning()
    {
        return mIsRuleRunning;
    }

    public boolean isTestMode()
    {
        return mIsTestMode;
    }

    public boolean isTestRunning()
    {
        return mIsTestRunning;
    }

    public void logEnterState(String s)
        throws IllegalStateException
    {
        logState("state_enter", s);
    }

    public void logEnterStates(Set set)
        throws IllegalStateException
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (set != null && !set.isEmpty())
        {
            for (set = set.iterator(); set.hasNext(); stringbuilder.append((String)set.next()).append(",")) { }
            stringbuilder.deleteCharAt(stringbuilder.length() - 1);
        }
        logState("state_enter", stringbuilder.toString());
    }

    public void logExitState(String s)
        throws IllegalStateException
    {
        logState("state_exit", s);
    }

    public void logExitStates(Set set)
        throws IllegalStateException
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (set != null && !set.isEmpty())
        {
            for (set = set.iterator(); set.hasNext(); stringbuilder.append((String)set.next()).append(",")) { }
            stringbuilder.deleteCharAt(stringbuilder.length() - 1);
        }
        logState("state_exit", stringbuilder.toString());
    }

    public void logOutputParam(String s, String s1)
        throws IllegalStateException
    {
        Intent intent = createIntent("output_param");
        intent.putExtra("paramName", s);
        intent.putExtra("paramValue", s1);
        mContext.sendBroadcast(intent);
    }

    void onServiceBound(Intent intent)
    {
        if (mAbstractEventMonitor == null)
        {
            return;
        } else
        {
            mAbstractEventMonitor.onServiceBound(intent);
            return;
        }
    }

    void onServiceCreated()
    {
        if (mAbstractEventMonitor == null)
        {
            return;
        } else
        {
            mAbstractEventMonitor.onServiceCreated();
            return;
        }
    }

    void onServiceDestroyed()
    {
        if (mAbstractEventMonitor == null)
        {
            return;
        } else
        {
            mAbstractEventMonitor.onServiceDestroyed();
            return;
        }
    }

    void onServiceUnbound(Intent intent)
    {
        if (mAbstractEventMonitor == null)
        {
            return;
        } else
        {
            mAbstractEventMonitor.onServiceUnbound(intent);
            return;
        }
    }

    public void requestConfirm(NlgRequestInfo nlgrequestinfo, ConfirmMode confirmmode, ConfirmResultListener confirmresultlistener)
        throws IllegalArgumentException
    {
        requestConfirm(nlgrequestinfo, confirmmode, null, confirmresultlistener);
    }

    public void requestConfirm(NlgRequestInfo nlgrequestinfo, ConfirmMode confirmmode, OnConfirmResultListener onconfirmresultlistener)
        throws IllegalArgumentException
    {
        requestConfirm(nlgrequestinfo, confirmmode, null, onconfirmresultlistener);
    }

    public void requestConfirm(NlgRequestInfo nlgrequestinfo, ConfirmMode confirmmode, String s, ConfirmResultListener confirmresultlistener)
        throws IllegalArgumentException
    {
        if (nlgrequestinfo == null)
        {
            throw new IllegalArgumentException("NlgRequestInfo cannot be null.");
        }
        if (confirmresultlistener == null)
        {
            throw new IllegalArgumentException("ConfirmResultListener cannot be null.");
        }
        String s1;
        if (s == null)
        {
            s = "";
        } else
        {
            s = (new StringBuilder()).append(",\"nextRuleId\":\"").append(s).append("\"").toString();
        }
        s1 = (new StringBuilder()).append("\"currentStateIds\":\"").append(getNlgStateInfo()).append("\"").toString();
        nlgrequestinfo = String.format("\"requestedAppName\":\"%s\",%s,%s,%s,%s%s", new Object[] {
            mActiveAppName, nlgrequestinfo.toString(), s1, NlgParamMode.CONFIRM.toString(), confirmmode.toString(), s
        });
        setConfirmResultListener(confirmresultlistener);
        sendCommandToBa("esem_request_nlg", nlgrequestinfo);
    }

    public void requestConfirm(NlgRequestInfo nlgrequestinfo, ConfirmMode confirmmode, String s, OnConfirmResultListener onconfirmresultlistener)
        throws IllegalArgumentException
    {
        if (nlgrequestinfo == null)
        {
            throw new IllegalArgumentException("NlgRequestInfo cannot be null.");
        }
        if (onconfirmresultlistener == null)
        {
            throw new IllegalArgumentException("ConfirmResultListener cannot be null.");
        }
        String s1;
        if (s == null)
        {
            s = "";
        } else
        {
            s = (new StringBuilder()).append(",\"nextRuleId\":\"").append(s).append("\"").toString();
        }
        s1 = (new StringBuilder()).append("\"currentStateIds\":\"").append(getNlgStateInfo()).append("\"").toString();
        nlgrequestinfo = String.format("\"requestedAppName\":\"%s\",%s,%s,%s,%s%s", new Object[] {
            mActiveAppName, nlgrequestinfo.toString(), s1, NlgParamMode.CONFIRM.toString(), confirmmode.toString(), s
        });
        setOnConfirmResultListener(onconfirmresultlistener);
        sendCommandToBa("esem_request_nlg", nlgrequestinfo);
    }

    void requestContext()
    {
        boolean flag1 = false;
        StringBuilder stringbuilder = new StringBuilder();
        Object obj;
        boolean flag;
        if (mInterimListener != null)
        {
            obj = mInterimListener.onScreenStatesRequested();
            stringbuilder.append("{").append("\"appName\":\"").append(mActiveAppName).append("\"");
            if (obj != ScreenStateInfo.STATE_NOT_APPLICABLE)
            {
                obj = ((ScreenStateInfo) (obj)).toString();
                if (obj != null)
                {
                    stringbuilder.append(",").append(((String) (obj)));
                    flag = true;
                } else
                {
                    Log.e(TAG, "requestContext: No state ids.");
                    flag = flag1;
                }
            } else
            {
                Log.e(TAG, "requestContext: STATE_NOT_APPLICABLE");
                flag = flag1;
            }
        } else
        {
            stringbuilder.append("{").append("\"appName\":\"").append(mActiveAppName).append("\"");
            Log.e(TAG, "requestContext: InterimListener is not set. ");
            flag = flag1;
            if (mLastScreenStateInfo != ScreenStateInfo.STATE_NOT_APPLICABLE)
            {
                Log.e(TAG, "requestContext: Lastly backed up Screen State info used.");
                obj = mLastScreenStateInfo.toString();
                if (obj != null)
                {
                    stringbuilder.append(",").append(((String) (obj)));
                    stringbuilder.append(",\"isBackedUpState\":true");
                    flag = true;
                } else
                {
                    Log.e(TAG, "requestContext: No state ids.");
                    flag = flag1;
                }
            }
        }
        if (mChattyModeListener != null)
        {
            stringbuilder.append(",\"isChattyModeSupported\":true");
        }
        stringbuilder.append("}");
        if (flag)
        {
            obj = (new StringBuilder()).append("\"result\": \"").append(ResponseResults.SUCCESS.toString()).append("\"").toString();
        } else
        {
            obj = (new StringBuilder()).append("\"result\": \"").append(ResponseResults.FAILURE.toString()).append("\"").toString();
        }
        sendCommandToBa("esem_context_result", (new StringBuilder()).append(((String) (obj))).append(",\"appContext\":").append(stringbuilder.toString()).toString());
    }

    public void requestNlg(NlgRequestInfo nlgrequestinfo, NlgParamMode nlgparammode)
        throws IllegalArgumentException
    {
        if (nlgrequestinfo == null)
        {
            throw new IllegalArgumentException("NlgRequestInfo cannot be null.");
        } else
        {
            setOnNlgEndListener(null);
            setConfirmResultListener(null);
            setOnConfirmResultListener(null);
            sendCommandToBa("esem_request_nlg", setNlgData(nlgrequestinfo, nlgparammode, null));
            return;
        }
    }

    public void requestNlg(NlgRequestInfo nlgrequestinfo, NlgParamMode nlgparammode, OnNlgEndListener onnlgendlistener)
        throws IllegalArgumentException
    {
        if (nlgrequestinfo == null)
        {
            throw new IllegalArgumentException("NlgRequestInfo cannot be null.");
        }
        if (onnlgendlistener == null)
        {
            throw new IllegalArgumentException("Listener cannot be null.");
        } else
        {
            setOnNlgEndListener(onnlgendlistener);
            setConfirmResultListener(null);
            setOnConfirmResultListener(null);
            sendCommandToBa("esem_request_nlg", setNlgData(nlgrequestinfo, nlgparammode, onnlgendlistener));
            return;
        }
    }

    public void requestTts(String s, TtsMode ttsmode)
        throws IllegalArgumentException
    {
        if (TextUtils.isEmpty(s))
        {
            throw new IllegalArgumentException("text cannot be null or empty.");
        } else
        {
            setOnTtsResultListener(null);
            requestTtsInternal(s, ttsmode);
            return;
        }
    }

    public void requestTts(String s, TtsMode ttsmode, OnTtsResultListener onttsresultlistener)
        throws IllegalArgumentException
    {
        if (TextUtils.isEmpty(s))
        {
            throw new IllegalArgumentException("text cannot be null or empty.");
        }
        if (onttsresultlistener == null)
        {
            throw new IllegalArgumentException("listener cannot be null.");
        } else
        {
            setOnTtsResultListener(onttsresultlistener);
            requestTtsInternal(s, ttsmode);
            return;
        }
    }

    void sendAllStates(JSONArray jsonarray)
        throws JSONException
    {
        ArrayList arraylist = new ArrayList();
        if (jsonarray != null)
        {
            int j = jsonarray.length();
            for (int i = 0; i < j; i++)
            {
                arraylist.add(StateReader.read(jsonarray.get(i).toString()));
            }

        }
        if (mTestListener == null || arraylist.isEmpty())
        {
            Log.d(TAG, "sendAllStates: mTestListener is null.");
            sendCommandToBa("esem_all_states_result", ResponseResults.TEST_ALL_STATES_FAILURE.toString());
            return;
        } else
        {
            mTestListener.onAllStates(arraylist);
            return;
        }
    }

    void sendChatText(String s, boolean flag)
    {
        String s1 = ResponseResults.FAILURE.toString();
        if (mChattyModeListener != null) goto _L2; else goto _L1
_L1:
        Log.d(TAG, "sendChatText: ChattyModeListener is null.");
_L4:
        sendCommandToBa("esem_chatty_mode_result", s1);
        return;
_L2:
        if (mChattyModeListener.onChatTextReceived(s, flag))
        {
            s1 = ResponseResults.SUCCESS.toString();
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    void sendMultiStates(JSONArray jsonarray)
        throws JSONException
    {
        Object obj;
        obj = new ArrayList();
        if (jsonarray != null)
        {
            int j = jsonarray.length();
            for (int i = 0; i < j; i++)
            {
                ((ArrayList) (obj)).add(jsonarray.get(i).toString());
            }

        }
        jsonarray = "";
        if (mMultiPathRuleListener != null) goto _L2; else goto _L1
_L1:
        Log.d(TAG, "sendMultiStates: MultiPathRuleListener is null.");
_L4:
        sendCommandToBa("esem_split_state_result", jsonarray);
        return;
_L2:
        obj = mMultiPathRuleListener.onPathRuleSplit(((List) (obj)));
        jsonarray = ((JSONArray) (obj));
        if (obj == null)
        {
            jsonarray = "";
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    void sendNlgEnd()
    {
        Log.d(TAG, "sendNlgEnd");
        if (mOnNlgEndListener == null)
        {
            Log.e(TAG, "unexpected NLG End result. Ignored.");
            return;
        } else
        {
            mOnNlgEndListener.onNlgEnd();
            setOnNlgEndListener(null);
            return;
        }
    }

    void sendParamFilling(ParamFilling paramfilling)
    {
        String s = ResponseResults.FAILURE.toString();
        if (mInterimListener != null)
        {
            if (mInterimListener.onParamFillingReceived(paramfilling))
            {
                s = ResponseResults.SUCCESS.toString();
            }
        } else
        {
            Log.d(TAG, "ParamFilling: InterimListener is null.");
        }
        sendCommandToBa("esem_param_filling_result", s);
    }

    public void sendResponse(ResponseResults responseresults)
    {
        if (responseresults == ResponseResults.TEST_ALL_STATES_FAILURE || responseresults == ResponseResults.TEST_ALL_STATES_SUCCESS)
        {
            sendCommandToBa("esem_all_states_result", responseresults.toString());
            return;
        }
        if (mLastReceivedStateCmd == null)
        {
            Log.e(TAG, "Invalid sendResponse call.");
            return;
        }
        if (responseresults != ResponseResults.FAILURE) goto _L2; else goto _L1
_L1:
        ResponseResults responseresults1 = ResponseResults.STATE_FAILURE;
_L4:
        sendCommandToBa("state_command_result", responseresults1.toString());
        handleTestResponse(responseresults1, mLastReceivedStateCmd);
        if (mLastReceivedStateCmd.isLastState().booleanValue() || responseresults1 == ResponseResults.STATE_FAILURE || responseresults1 == ResponseResults.TEST_SETUP_FAILURE)
        {
            setRuleRunning(false);
            setTestRunning(false);
        }
        setPartiallyLanded(false);
        mLastReceivedStateCmd = null;
        return;
_L2:
        responseresults1 = responseresults;
        if (responseresults == ResponseResults.SUCCESS)
        {
            responseresults1 = ResponseResults.STATE_SUCCESS;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    void sendState(String s)
    {
        setRuleRunning(true);
        State state = StateReader.read(s);
        mLastReceivedStateCmd = state;
        if (state.getSeqNum().intValue() == -1)
        {
            handleRuleCancel(state);
            return;
        }
        clearListeners();
        if (state.getSeqNum().intValue() == 0)
        {
            handleTestState(s);
            return;
        }
        if (state.getSeqNum().intValue() == 1)
        {
            handleFirstState(state);
            return;
        } else
        {
            handleStates(state);
            return;
        }
    }

    void sendTtsResult(String s)
    {
        if (mOnTtsResultListener == null)
        {
            Log.e(TAG, "unexpected TTS result. Ignored.");
            return;
        } else
        {
            mOnTtsResultListener.onTtsResult(TtsResult.toEnum(s));
            setOnTtsResultListener(null);
            return;
        }
    }

    void sendUserConfirm(String s, String s1)
    {
        ConfirmResult confirmresult;
        boolean flag = false;
        confirmresult = ConfirmResult.toEnum(s1);
        Log.e(TAG, (new StringBuilder()).append("mOnConfirmResultListener:").append(mOnConfirmResultListener).toString());
        Log.e(TAG, (new StringBuilder()).append("mConfirmResultListener:").append(mConfirmResultListener).toString());
        String s2;
        if (mOnConfirmResultListener != null || mConfirmResultListener != null)
        {
            if (confirmresult != ConfirmResult.UNKNOWN)
            {
                flag = true;
            } else
            {
                Log.e(TAG, (new StringBuilder()).append("Invalid Confirmation Result: ").append(s1).append(". Ignored").toString());
            }
        } else
        {
            Log.e(TAG, "Confirm Result Listener null. Ignored.");
        }
        if (flag)
        {
            s2 = "success";
        } else
        {
            s2 = "failure";
        }
        sendCommandToBa("esem_user_confirm_result", String.format("\"appName\":\"%s\",\"result\":\"%s\"", new Object[] {
            s, s2
        }));
        if (!flag) goto _L2; else goto _L1
_L1:
        if (mOnConfirmResultListener == null) goto _L4; else goto _L3
_L3:
        mOnConfirmResultListener.onConfirmResult(confirmresult);
_L6:
        Log.d(TAG, (new StringBuilder()).append("Confirmation Result called: ").append(s1).toString());
        setConfirmResultListener(null);
        setOnConfirmResultListener(null);
_L2:
        return;
_L4:
        if (mConfirmResultListener != null)
        {
            mConfirmResultListener.onResult(confirmresult);
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public void setAbstractEventMonitor(AbstractEventMonitor abstracteventmonitor)
    {
        mAbstractEventMonitor = abstracteventmonitor;
    }

    public void setActiveApp(String s)
    {
        if (s == null || s.trim().isEmpty())
        {
            throw new IllegalStateException("appName should not be null or empty");
        } else
        {
            mActiveAppName = s;
            return;
        }
    }

    public void setAppTouchable(boolean flag)
    {
        if (!isRuleRunning())
        {
            Log.d(TAG, "setAppTouchable: Path Rule is not running.");
            return;
        } else
        {
            sendCommandToBa("esem_client_control", (new StringBuilder()).append("\"appTouchable\":").append(flag).toString());
            return;
        }
    }

    public void setAppVisible(boolean flag)
    {
        if (!isRuleRunning())
        {
            Log.d(TAG, "setAppVisible: Path Rule is not running.");
            return;
        } else
        {
            sendCommandToBa("esem_client_control", (new StringBuilder()).append("\"appVisible\":").append(flag).toString());
            return;
        }
    }

    public void setChattyModeListener(ChattyModeListener chattymodelistener)
    {
        if (mChattyModeListener != null && chattymodelistener == null)
        {
            sendCommandToBa("esem_cancel_chatty_mode", "");
        }
        mChattyModeListener = chattymodelistener;
    }

    public void setInterimStateListener(InterimStateListener interimstatelistener)
    {
        mInterimListener = interimstatelistener;
    }

    public void setMultiPathRuleListener(MultiPathRuleListener multipathrulelistener)
    {
        mMultiPathRuleListener = multipathrulelistener;
    }

    void setPartiallyLanded(boolean flag)
    {
        mIsPartiallyLanded = flag;
    }

    void setResponseCallback(OnResponseCallback onresponsecallback)
    {
        mResponseCallback = onresponsecallback;
    }

    public void setStartStateListener(StartStateListener startstatelistener)
    {
        mStartListener = startstatelistener;
    }

    public void setTestListener(TestListener testlistener)
    {
        mTestListener = testlistener;
    }

    static 
    {
        boolean flag;
        if (!"user".equals(Build.TYPE))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        DEBUG = flag;
    }





/*
    static int access$208(BixbyApi bixbyapi)
    {
        int i = bixbyapi.mSendStateRetryCount;
        bixbyapi.mSendStateRetryCount = i + 1;
        return i;
    }

*/


/*
    static Runnable access$302(BixbyApi bixbyapi, Runnable runnable)
    {
        bixbyapi.mSendStateRunnable = runnable;
        return runnable;
    }

*/
}
