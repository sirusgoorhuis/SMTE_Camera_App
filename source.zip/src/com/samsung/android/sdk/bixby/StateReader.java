// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import com.samsung.android.sdk.bixby.data.CHObject;
import com.samsung.android.sdk.bixby.data.Parameter;
import com.samsung.android.sdk.bixby.data.State;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class StateReader
{

    StateReader()
    {
    }

    public static State read(String s)
        throws IllegalArgumentException
    {
        ArrayList arraylist = new ArrayList();
        Object obj = new JSONObject(s);
        if (!((JSONObject) (obj)).has("specVer")) goto _L2; else goto _L1
_L1:
        s = ((JSONObject) (obj)).getString("specVer");
_L50:
        String s2;
        String s3;
        String s4;
        int k;
        boolean flag1;
        k = ((JSONObject) (obj)).getInt("seqNum");
        flag1 = ((JSONObject) (obj)).getBoolean("isExecuted");
        s2 = ((JSONObject) (obj)).getString("appName");
        s3 = ((JSONObject) (obj)).getString("stateId");
        s4 = ((JSONObject) (obj)).getString("ruleId");
        if (!((JSONObject) (obj)).has("isResent")) goto _L4; else goto _L3
_L3:
        boolean flag = ((JSONObject) (obj)).getBoolean("isResent");
_L51:
        boolean flag2 = ((JSONObject) (obj)).getBoolean("isLandingState");
        if (!((JSONObject) (obj)).has("isLastState")) goto _L6; else goto _L5
_L5:
        Boolean boolean1 = Boolean.valueOf(((JSONObject) (obj)).getBoolean("isLastState"));
_L30:
        String s1;
        if (!((JSONObject) (obj)).has("subIntent"))
        {
            break MISSING_BLOCK_LABEL_730;
        }
        s1 = ((JSONObject) (obj)).getString("subIntent");
_L52:
        obj = ((JSONObject) (obj)).getJSONArray("parameters");
        int i = 0;
_L45:
        if (i >= ((JSONArray) (obj)).length()) goto _L8; else goto _L7
_L7:
        JSONObject jsonobject;
        Parameter parameter;
        jsonobject = ((JSONArray) (obj)).getJSONObject(i);
        parameter = new Parameter();
        if (!jsonobject.has("slotType")) goto _L10; else goto _L9
_L9:
        parameter.setSlotType(jsonobject.getString("slotType"));
_L31:
        if (!jsonobject.has("slotName")) goto _L12; else goto _L11
_L11:
        parameter.setSlotName(jsonobject.getString("slotName"));
_L32:
        if (!jsonobject.has("slotValue")) goto _L14; else goto _L13
_L13:
        parameter.setSlotValue(jsonobject.getString("slotValue"));
_L33:
        if (!jsonobject.has("slotValueType")) goto _L16; else goto _L15
_L15:
        parameter.setSlotValueType(jsonobject.getString("slotValueType"));
_L34:
        if (!jsonobject.has("CH_ObjectType")) goto _L18; else goto _L17
_L17:
        parameter.setCHObjectType(jsonobject.getString("CH_ObjectType"));
_L35:
        if (!jsonobject.has("CH_Objects")) goto _L20; else goto _L19
_L19:
        ArrayList arraylist1;
        JSONArray jsonarray;
        arraylist1 = new ArrayList();
        jsonarray = jsonobject.getJSONArray("CH_Objects");
        int j = 0;
_L29:
        if (j >= jsonarray.length()) goto _L22; else goto _L21
_L21:
        JSONObject jsonobject1;
        CHObject chobject;
        jsonobject1 = jsonarray.getJSONObject(j);
        chobject = new CHObject();
        if (!jsonobject1.has("CH_Type")) goto _L24; else goto _L23
_L23:
        chobject.setCHType(jsonobject1.getString("CH_Type"));
_L36:
        if (!jsonobject1.has("CH_Value")) goto _L26; else goto _L25
_L25:
        chobject.setCHValue(jsonobject1.getString("CH_Value"));
_L37:
        if (!jsonobject1.has("CH_ValueType")) goto _L28; else goto _L27
_L27:
        chobject.setCHValueType(jsonobject1.getString("CH_ValueType"));
_L38:
        arraylist1.add(chobject);
        j++;
          goto _L29
_L6:
        try
        {
            boolean1 = Boolean.valueOf(false);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new IllegalArgumentException(s.toString());
        }
          goto _L30
_L10:
        parameter.setSlotType("");
          goto _L31
_L12:
        parameter.setSlotName("");
          goto _L32
_L14:
        parameter.setSlotValue("");
          goto _L33
_L16:
        parameter.setSlotValueType("");
          goto _L34
_L18:
        parameter.setCHObjectType("");
          goto _L35
_L24:
        chobject.setCHType("");
          goto _L36
_L26:
        chobject.setCHValue("");
          goto _L37
_L28:
        chobject.setCHValueType("");
          goto _L38
_L22:
        parameter.setCHObjects(arraylist1);
_L46:
        if (!jsonobject.has("parameterName")) goto _L40; else goto _L39
_L39:
        parameter.setParameterName(jsonobject.getString("parameterName"));
_L47:
        if (!jsonobject.has("parameterType")) goto _L42; else goto _L41
_L41:
        parameter.setParameterType(jsonobject.getString("parameterType"));
_L48:
        if (!jsonobject.has("isMandatory")) goto _L44; else goto _L43
_L43:
        parameter.setIsMandatory(Boolean.valueOf(jsonobject.getBoolean("isMandatory")));
_L49:
        arraylist.add(parameter);
        i++;
          goto _L45
_L20:
        parameter.setCHObjects(null);
          goto _L46
_L40:
        parameter.setParameterName("");
          goto _L47
_L42:
        parameter.setParameterType("");
          goto _L48
_L44:
        parameter.setIsMandatory(Boolean.valueOf(false));
          goto _L49
_L8:
        s = new State(s, Integer.valueOf(k), Boolean.valueOf(flag1), s2, s4, s3, Boolean.valueOf(flag), Boolean.valueOf(flag2), boolean1, s1, arraylist);
        return s;
_L2:
        s = "1.0";
          goto _L50
_L4:
        flag = false;
          goto _L51
        s1 = "";
          goto _L52
    }
}
