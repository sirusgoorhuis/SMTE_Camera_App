// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import com.samsung.android.sdk.bixby.data.CHObject;
import com.samsung.android.sdk.bixby.data.ParamFilling;
import com.samsung.android.sdk.bixby.data.ScreenParameter;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class ParamFillingReader
{

    ParamFillingReader()
    {
    }

    public static ParamFilling read(String s)
        throws IllegalArgumentException
    {
        ArrayList arraylist;
        ArrayList arraylist1;
        String s1;
        String s2;
        Object obj1;
        ScreenParameter screenparameter;
        ArrayList arraylist2;
        CHObject chobject;
        int i;
        arraylist = new ArrayList();
        arraylist1 = new ArrayList();
        Object obj;
        JSONArray jsonarray;
        JSONObject jsonobject;
        int j;
        try
        {
            obj = new JSONObject(s);
            s = ((JSONObject) (obj)).getString("utterance");
            s1 = ((JSONObject) (obj)).getString("intent");
            s2 = ((JSONObject) (obj)).getString("appName");
            obj1 = ((JSONObject) (obj)).getJSONArray("screenStates");
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new IllegalArgumentException(s.toString());
        }
        i = 0;
        if (i >= ((JSONArray) (obj1)).length())
        {
            break; /* Loop/switch isn't completed */
        }
        arraylist.add(((JSONArray) (obj1)).optString(i));
        i++;
        if (true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_63;
_L1:
        obj = ((JSONObject) (obj)).getJSONArray("screenParameters");
        i = 0;
_L35:
        if (i >= ((JSONArray) (obj)).length())
        {
            break MISSING_BLOCK_LABEL_549;
        }
        obj1 = ((JSONArray) (obj)).getJSONObject(i);
        screenparameter = new ScreenParameter();
        if (!((JSONObject) (obj1)).has("slotType")) goto _L4; else goto _L3
_L3:
        screenparameter.setSlotType(((JSONObject) (obj1)).getString("slotType"));
_L22:
        if (!((JSONObject) (obj1)).has("slotName")) goto _L6; else goto _L5
_L5:
        screenparameter.setSlotName(((JSONObject) (obj1)).getString("slotName"));
_L23:
        if (!((JSONObject) (obj1)).has("slotValue")) goto _L8; else goto _L7
_L7:
        screenparameter.setSlotValue(((JSONObject) (obj1)).getString("slotValue"));
_L24:
        if (!((JSONObject) (obj1)).has("CH_ObjectType")) goto _L10; else goto _L9
_L9:
        screenparameter.setCHObjectType(((JSONObject) (obj1)).getString("CH_ObjectType"));
_L25:
        if (!((JSONObject) (obj1)).has("CH_Objects")) goto _L12; else goto _L11
_L11:
        arraylist2 = new ArrayList();
        jsonarray = ((JSONObject) (obj1)).getJSONArray("CH_Objects");
        j = 0;
_L21:
        if (j >= jsonarray.length()) goto _L14; else goto _L13
_L13:
        jsonobject = jsonarray.getJSONObject(j);
        chobject = new CHObject();
        if (!jsonobject.has("CH_Type")) goto _L16; else goto _L15
_L15:
        chobject.setCHType(jsonobject.getString("CH_Type"));
_L26:
        if (!jsonobject.has("CH_Value")) goto _L18; else goto _L17
_L17:
        chobject.setCHValue(jsonobject.getString("CH_Value"));
_L27:
        if (!jsonobject.has("CH_ValueType")) goto _L20; else goto _L19
_L19:
        chobject.setCHValueType(jsonobject.getString("CH_ValueType"));
_L28:
        arraylist2.add(chobject);
        j++;
          goto _L21
_L4:
        screenparameter.setSlotType("");
          goto _L22
_L6:
        screenparameter.setSlotName("");
          goto _L23
_L8:
        screenparameter.setSlotValue("");
          goto _L24
_L10:
        screenparameter.setCHObjectType("");
          goto _L25
_L16:
        chobject.setCHType("");
          goto _L26
_L18:
        chobject.setCHValue("");
          goto _L27
_L20:
        chobject.setCHValueType("");
          goto _L28
_L14:
        screenparameter.setCHObjects(arraylist2);
_L31:
        if (!((JSONObject) (obj1)).has("parameterName")) goto _L30; else goto _L29
_L29:
        screenparameter.setParameterName(((JSONObject) (obj1)).getString("parameterName"));
_L32:
        if (!((JSONObject) (obj1)).has("parameterType"))
        {
            break MISSING_BLOCK_LABEL_539;
        }
        screenparameter.setParameterType(((JSONObject) (obj1)).getString("parameterType"));
_L33:
        arraylist1.add(screenparameter);
        i++;
        continue; /* Loop/switch isn't completed */
_L12:
        screenparameter.setCHObjects(null);
          goto _L31
_L30:
        screenparameter.setParameterName("");
          goto _L32
        screenparameter.setParameterType("");
          goto _L33
        s = new ParamFilling(s, s1, s2, arraylist, arraylist1);
        return s;
        if (true) goto _L35; else goto _L34
_L34:
    }
}
