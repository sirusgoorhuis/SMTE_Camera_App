// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;

import java.util.List;

// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static interface 
{

    public abstract String onPathRuleSplit(List list);
}
