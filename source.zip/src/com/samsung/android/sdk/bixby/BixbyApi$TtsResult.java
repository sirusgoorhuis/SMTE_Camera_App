// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.sdk.bixby;


// Referenced classes of package com.samsung.android.sdk.bixby:
//            BixbyApi

public static final class  extends Enum
{

    private static final UNKNOWN $VALUES[];
    public static final UNKNOWN COMPLETE;
    public static final UNKNOWN STOP_ON_CANCEL;
    public static final UNKNOWN STOP_ON_ERROR;
    public static final UNKNOWN UNKNOWN;

    public static  toEnum(String s)
    {
        byte byte0 = -1;
        s.hashCode();
        JVM INSTR lookupswitch 3: default 40
    //                   -2089014459: 86
    //                   -599445191: 72
    //                   -408027939: 100;
           goto _L1 _L2 _L3 _L4
_L1:
        break; /* Loop/switch isn't completed */
_L4:
        break MISSING_BLOCK_LABEL_100;
_L5:
        switch (byte0)
        {
        default:
            return UNKNOWN;

        case 0: // '\0'
            return COMPLETE;

        case 1: // '\001'
            return STOP_ON_ERROR;

        case 2: // '\002'
            return STOP_ON_CANCEL;
        }
_L3:
        if (s.equals("complete"))
        {
            byte0 = 0;
        }
          goto _L5
_L2:
        if (s.equals("stop_on_error"))
        {
            byte0 = 1;
        }
          goto _L5
        if (s.equals("stop_on_cancel"))
        {
            byte0 = 2;
        }
          goto _L5
    }

    public static STOP_ON_CANCEL valueOf(String s)
    {
        return (STOP_ON_CANCEL)Enum.valueOf(com/samsung/android/sdk/bixby/BixbyApi$TtsResult, s);
    }

    public static STOP_ON_CANCEL[] values()
    {
        return (STOP_ON_CANCEL[])$VALUES.clone();
    }

    static 
    {
        COMPLETE = new <init>("COMPLETE", 0);
        STOP_ON_ERROR = new <init>("STOP_ON_ERROR", 1);
        STOP_ON_CANCEL = new <init>("STOP_ON_CANCEL", 2);
        UNKNOWN = new <init>("UNKNOWN", 3);
        $VALUES = (new .VALUES[] {
            COMPLETE, STOP_ON_ERROR, STOP_ON_CANCEL, UNKNOWN
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
