// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.service;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.view.Surface;

public interface IMotionPhotoComposer
    extends IInterface
{
    public static abstract class Stub extends Binder
        implements IMotionPhotoComposer
    {

        private static final String DESCRIPTOR = "com.samsung.android.apex.service.IMotionPhotoComposer";
        static final int TRANSACTION_connect = 1;
        static final int TRANSACTION_disconnect = 8;
        static final int TRANSACTION_getSurface = 9;
        static final int TRANSACTION_setParameters = 10;
        static final int TRANSACTION_setStoreData = 7;
        static final int TRANSACTION_setStorePath = 6;
        static final int TRANSACTION_start = 2;
        static final int TRANSACTION_stop = 3;
        static final int TRANSACTION_store = 4;
        static final int TRANSACTION_storeWithId = 5;

        public static IMotionPhotoComposer asInterface(IBinder ibinder)
        {
            if (ibinder == null)
            {
                return null;
            }
            IInterface iinterface = ibinder.queryLocalInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
            if (iinterface != null && (iinterface instanceof IMotionPhotoComposer))
            {
                return (IMotionPhotoComposer)iinterface;
            } else
            {
                return new Proxy(ibinder);
            }
        }

        public IBinder asBinder()
        {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
            throws RemoteException
        {
            switch (i)
            {
            default:
                return super.onTransact(i, parcel, parcel1, j);

            case 1598968902: 
                parcel1.writeString("com.samsung.android.apex.service.IMotionPhotoComposer");
                return true;

            case 1: // '\001'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                i = connect();
                parcel1.writeNoException();
                parcel1.writeInt(i);
                return true;

            case 2: // '\002'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                start(parcel.readString());
                parcel1.writeNoException();
                return true;

            case 3: // '\003'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                stop();
                parcel1.writeNoException();
                return true;

            case 4: // '\004'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                long l;
                if (parcel.readInt() != 0)
                {
                    parcel = (Bundle)Bundle.CREATOR.createFromParcel(parcel);
                } else
                {
                    parcel = null;
                }
                l = store(parcel);
                parcel1.writeNoException();
                parcel1.writeLong(l);
                return true;

            case 5: // '\005'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                long l1 = storeWithId();
                parcel1.writeNoException();
                parcel1.writeLong(l1);
                return true;

            case 6: // '\006'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                setStorePath(parcel.readLong(), parcel.readString());
                parcel1.writeNoException();
                return true;

            case 7: // '\007'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                if (parcel.readInt() != 0)
                {
                    parcel = (Bundle)Bundle.CREATOR.createFromParcel(parcel);
                } else
                {
                    parcel = null;
                }
                setStoreData(parcel);
                parcel1.writeNoException();
                return true;

            case 8: // '\b'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                disconnect();
                parcel1.writeNoException();
                return true;

            case 9: // '\t'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                parcel = getSurface();
                parcel1.writeNoException();
                if (parcel != null)
                {
                    parcel1.writeInt(1);
                    parcel.writeToParcel(parcel1, 1);
                    return true;
                } else
                {
                    parcel1.writeInt(0);
                    return true;
                }

            case 10: // '\n'
                parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposer");
                setParameters(parcel.readString());
                parcel1.writeNoException();
                return true;
            }
        }

        public Stub()
        {
            attachInterface(this, "com.samsung.android.apex.service.IMotionPhotoComposer");
        }
    }

    private static class Stub.Proxy
        implements IMotionPhotoComposer
    {

        private IBinder mRemote;

        public IBinder asBinder()
        {
            return mRemote;
        }

        public int connect()
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            int i;
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            mRemote.transact(1, parcel, parcel1, 0);
            parcel1.readException();
            i = parcel1.readInt();
            parcel1.recycle();
            parcel.recycle();
            return i;
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
        }

        public void disconnect()
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            mRemote.transact(8, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
        }

        public String getInterfaceDescriptor()
        {
            return "com.samsung.android.apex.service.IMotionPhotoComposer";
        }

        public Surface getSurface()
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            mRemote.transact(9, parcel, parcel1, 0);
            parcel1.readException();
            if (parcel1.readInt() == 0) goto _L2; else goto _L1
_L1:
            Surface surface = (Surface)Surface.CREATOR.createFromParcel(parcel1);
_L4:
            parcel1.recycle();
            parcel.recycle();
            return surface;
_L2:
            surface = null;
            if (true) goto _L4; else goto _L3
_L3:
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
        }

        public void setParameters(String s)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            parcel.writeString(s);
            mRemote.transact(10, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            s;
            parcel1.recycle();
            parcel.recycle();
            throw s;
        }

        public void setStoreData(Bundle bundle)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            if (bundle == null)
            {
                break MISSING_BLOCK_LABEL_57;
            }
            parcel.writeInt(1);
            bundle.writeToParcel(parcel, 0);
_L1:
            mRemote.transact(7, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            parcel.writeInt(0);
              goto _L1
            bundle;
            parcel1.recycle();
            parcel.recycle();
            throw bundle;
        }

        public void setStorePath(long l, String s)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            parcel.writeLong(l);
            parcel.writeString(s);
            mRemote.transact(6, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            s;
            parcel1.recycle();
            parcel.recycle();
            throw s;
        }

        public void start(String s)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            parcel.writeString(s);
            mRemote.transact(2, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            s;
            parcel1.recycle();
            parcel.recycle();
            throw s;
        }

        public void stop()
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            mRemote.transact(3, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
        }

        public long store(Bundle bundle)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            if (bundle == null)
            {
                break MISSING_BLOCK_LABEL_64;
            }
            parcel.writeInt(1);
            bundle.writeToParcel(parcel, 0);
_L1:
            long l;
            mRemote.transact(4, parcel, parcel1, 0);
            parcel1.readException();
            l = parcel1.readLong();
            parcel1.recycle();
            parcel.recycle();
            return l;
            parcel.writeInt(0);
              goto _L1
            bundle;
            parcel1.recycle();
            parcel.recycle();
            throw bundle;
        }

        public long storeWithId()
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            long l;
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposer");
            mRemote.transact(5, parcel, parcel1, 0);
            parcel1.readException();
            l = parcel1.readLong();
            parcel1.recycle();
            parcel.recycle();
            return l;
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
        }

        Stub.Proxy(IBinder ibinder)
        {
            mRemote = ibinder;
        }
    }


    public abstract int connect()
        throws RemoteException;

    public abstract void disconnect()
        throws RemoteException;

    public abstract Surface getSurface()
        throws RemoteException;

    public abstract void setParameters(String s)
        throws RemoteException;

    public abstract void setStoreData(Bundle bundle)
        throws RemoteException;

    public abstract void setStorePath(long l, String s)
        throws RemoteException;

    public abstract void start(String s)
        throws RemoteException;

    public abstract void stop()
        throws RemoteException;

    public abstract long store(Bundle bundle)
        throws RemoteException;

    public abstract long storeWithId()
        throws RemoteException;
}
