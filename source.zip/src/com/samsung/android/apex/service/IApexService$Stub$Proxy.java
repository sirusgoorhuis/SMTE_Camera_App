// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.service;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

// Referenced classes of package com.samsung.android.apex.service:
//            IApexService, IMotionPhotoComposerListener, IMotionPhotoComposer

private static class mRemote
    implements IApexService
{

    private IBinder mRemote;

    public IBinder asBinder()
    {
        return mRemote;
    }

    public String getInterfaceDescriptor()
    {
        return "com.samsung.android.apex.service.IApexService";
    }

    public IMotionPhotoComposer getMotionPhotoComposer(IMotionPhotoComposerListener imotionphotocomposerlistener)
        throws RemoteException
    {
        Parcel parcel;
        Parcel parcel1;
        parcel = Parcel.obtain();
        parcel1 = Parcel.obtain();
        parcel.writeInterfaceToken("com.samsung.android.apex.service.IApexService");
        if (imotionphotocomposerlistener == null)
        {
            break MISSING_BLOCK_LABEL_66;
        }
        imotionphotocomposerlistener = imotionphotocomposerlistener.asBinder();
_L1:
        parcel.writeStrongBinder(imotionphotocomposerlistener);
        mRemote.transact(1, parcel, parcel1, 0);
        parcel1.readException();
        imotionphotocomposerlistener = b.asInterface(parcel1.readStrongBinder());
        parcel1.recycle();
        parcel.recycle();
        return imotionphotocomposerlistener;
        imotionphotocomposerlistener = null;
          goto _L1
        imotionphotocomposerlistener;
        parcel1.recycle();
        parcel.recycle();
        throw imotionphotocomposerlistener;
    }

    ener(IBinder ibinder)
    {
        mRemote = ibinder;
    }
}
