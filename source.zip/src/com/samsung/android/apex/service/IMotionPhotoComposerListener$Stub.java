// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.service;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

// Referenced classes of package com.samsung.android.apex.service:
//            IMotionPhotoComposerListener

public static abstract class attachInterface extends Binder
    implements IMotionPhotoComposerListener
{
    private static class Proxy
        implements IMotionPhotoComposerListener
    {

        private IBinder mRemote;

        public IBinder asBinder()
        {
            return mRemote;
        }

        public String getInterfaceDescriptor()
        {
            return "com.samsung.android.apex.service.IMotionPhotoComposerListener";
        }

        public void notify(int i, int j, int k, Bundle bundle)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IMotionPhotoComposerListener");
            parcel.writeInt(i);
            parcel.writeInt(j);
            parcel.writeInt(k);
            if (bundle == null)
            {
                break MISSING_BLOCK_LABEL_86;
            }
            parcel.writeInt(1);
            bundle.writeToParcel(parcel, 0);
_L1:
            mRemote.transact(1, parcel, parcel1, 0);
            parcel1.readException();
            parcel1.recycle();
            parcel.recycle();
            return;
            parcel.writeInt(0);
              goto _L1
            bundle;
            parcel1.recycle();
            parcel.recycle();
            throw bundle;
        }

        Proxy(IBinder ibinder)
        {
            mRemote = ibinder;
        }
    }


    private static final String DESCRIPTOR = "com.samsung.android.apex.service.IMotionPhotoComposerListener";
    static final int TRANSACTION_notify = 1;

    public static IMotionPhotoComposerListener asInterface(IBinder ibinder)
    {
        if (ibinder == null)
        {
            return null;
        }
        android.os.IInterface iinterface = ibinder.queryLocalInterface("com.samsung.android.apex.service.IMotionPhotoComposerListener");
        if (iinterface != null && (iinterface instanceof IMotionPhotoComposerListener))
        {
            return (IMotionPhotoComposerListener)iinterface;
        } else
        {
            return new Proxy(ibinder);
        }
    }

    public IBinder asBinder()
    {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
        throws RemoteException
    {
        int k;
        switch (i)
        {
        default:
            return super.onTransact(i, parcel, parcel1, j);

        case 1598968902: 
            parcel1.writeString("com.samsung.android.apex.service.IMotionPhotoComposerListener");
            return true;

        case 1: // '\001'
            parcel.enforceInterface("com.samsung.android.apex.service.IMotionPhotoComposerListener");
            i = parcel.readInt();
            j = parcel.readInt();
            k = parcel.readInt();
            break;
        }
        if (parcel.readInt() != 0)
        {
            parcel = (Bundle)Bundle.CREATOR.l(parcel);
        } else
        {
            parcel = null;
        }
        notify(i, j, k, parcel);
        parcel1.writeNoException();
        return true;
    }

    public Proxy.mRemote()
    {
        attachInterface(this, "com.samsung.android.apex.service.IMotionPhotoComposerListener");
    }
}
