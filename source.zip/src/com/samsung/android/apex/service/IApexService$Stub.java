// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.service;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

// Referenced classes of package com.samsung.android.apex.service:
//            IApexService, IMotionPhotoComposer, IMotionPhotoComposerListener

public static abstract class attachInterface extends Binder
    implements IApexService
{
    private static class Proxy
        implements IApexService
    {

        private IBinder mRemote;

        public IBinder asBinder()
        {
            return mRemote;
        }

        public String getInterfaceDescriptor()
        {
            return "com.samsung.android.apex.service.IApexService";
        }

        public IMotionPhotoComposer getMotionPhotoComposer(IMotionPhotoComposerListener imotionphotocomposerlistener)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.samsung.android.apex.service.IApexService");
            if (imotionphotocomposerlistener == null)
            {
                break MISSING_BLOCK_LABEL_66;
            }
            imotionphotocomposerlistener = imotionphotocomposerlistener.asBinder();
_L1:
            parcel.writeStrongBinder(imotionphotocomposerlistener);
            mRemote.transact(1, parcel, parcel1, 0);
            parcel1.readException();
            imotionphotocomposerlistener = IMotionPhotoComposer.Stub.asInterface(parcel1.readStrongBinder());
            parcel1.recycle();
            parcel.recycle();
            return imotionphotocomposerlistener;
            imotionphotocomposerlistener = null;
              goto _L1
            imotionphotocomposerlistener;
            parcel1.recycle();
            parcel.recycle();
            throw imotionphotocomposerlistener;
        }

        Proxy(IBinder ibinder)
        {
            mRemote = ibinder;
        }
    }


    private static final String DESCRIPTOR = "com.samsung.android.apex.service.IApexService";
    static final int TRANSACTION_getMotionPhotoComposer = 1;

    public static IApexService asInterface(IBinder ibinder)
    {
        if (ibinder == null)
        {
            return null;
        }
        android.os.IInterface iinterface = ibinder.queryLocalInterface("com.samsung.android.apex.service.IApexService");
        if (iinterface != null && (iinterface instanceof IApexService))
        {
            return (IApexService)iinterface;
        } else
        {
            return new Proxy(ibinder);
        }
    }

    public IBinder asBinder()
    {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
        throws RemoteException
    {
        switch (i)
        {
        default:
            return super.onTransact(i, parcel, parcel1, j);

        case 1598968902: 
            parcel1.writeString("com.samsung.android.apex.service.IApexService");
            return true;

        case 1: // '\001'
            parcel.enforceInterface("com.samsung.android.apex.service.IApexService");
            parcel = getMotionPhotoComposer(erListener.Stub.asInterface(parcel.readStrongBinder()));
            parcel1.writeNoException();
            break;
        }
        if (parcel != null)
        {
            parcel = parcel.asBinder();
        } else
        {
            parcel = null;
        }
        parcel1.writeStrongBinder(parcel);
        return true;
    }

    public Proxy.mRemote()
    {
        attachInterface(this, "com.samsung.android.apex.service.IApexService");
    }
}
