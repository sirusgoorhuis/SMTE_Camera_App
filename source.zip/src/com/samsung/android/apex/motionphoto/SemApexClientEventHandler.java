// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

public class SemApexClientEventHandler extends Handler
{
    public static interface OnErrorListener
    {

        public abstract void onError(int i, int j, int k, Object obj);
    }

    public static interface OnInfoListener
    {

        public abstract void onInfo(int i, int j, int k, Object obj);
    }


    private static final String TAG = com/samsung/android/apex/motionphoto/SemApexClientEventHandler.getSimpleName();
    private OnErrorListener mOnErrorListener;
    private OnInfoListener mOnInfoListener;
    private int mToken;

    public SemApexClientEventHandler(Looper looper)
    {
        super(looper);
    }

    public void handleMessage(Message message)
    {
        Log.d(TAG, String.format("handleMessage: what=%d, arg1=%d, arg2=%d", new Object[] {
            Integer.valueOf(message.what), Integer.valueOf(message.arg1), Integer.valueOf(message.arg2)
        }));
        Log.d(TAG, (new StringBuilder()).append("infolistener: ").append(mOnInfoListener).toString());
        Log.d(TAG, (new StringBuilder()).append("errorlistener: ").append(mOnErrorListener).toString());
        message.what;
        JVM INSTR tableswitch 3001 3002: default 132
    //                   3001 162
    //                   3002 195;
           goto _L1 _L2 _L3
_L1:
        Log.e(TAG, (new StringBuilder()).append("Unknown message type").append(message.what).toString());
_L5:
        return;
_L2:
        if (mOnInfoListener != null)
        {
            mOnInfoListener.onInfo(message.arg1, message.arg2, mToken, message.obj);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (mOnErrorListener != null)
        {
            mOnErrorListener.onError(message.arg1, message.arg2, mToken, message.obj);
            return;
        }
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void setOnErrorListener(OnErrorListener onerrorlistener)
    {
        mOnErrorListener = onerrorlistener;
    }

    public void setOnInfoListener(OnInfoListener oninfolistener)
    {
        mOnInfoListener = oninfolistener;
    }

    public void setToken(int i)
    {
        mToken = i;
    }

}
