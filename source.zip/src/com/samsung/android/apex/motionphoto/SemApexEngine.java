// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;

import android.os.Message;
import java.io.FileDescriptor;
import java.lang.ref.WeakReference;
import java.util.List;

public final class SemApexEngine
{
    public static final class BestPhotoScore
    {

        private long mScore;
        private long mTimeUs;
        private long mVideoId;

        public long getScore()
        {
            return mScore;
        }

        public long getTimeUs()
        {
            return mTimeUs;
        }

        public long getVideoId()
        {
            return mVideoId;
        }

        public void setScore(long l)
        {
            mScore = l;
        }

        public void setTimeUs(long l)
        {
            mTimeUs = l;
        }

        public void setVideoId(long l)
        {
            mVideoId = l;
        }

        BestPhotoScore()
        {
        }
    }

    public static interface OnErrorListener
    {

        public abstract void onError(SemApexEngine semapexengine, int i, int j);
    }

    public static interface OnInfoListener
    {

        public abstract void onInfo(SemApexEngine semapexengine, int i, int j, Object obj);
    }


    public static final int APEX_EVENT_ERROR = 1;
    public static final int APEX_EVENT_INFO = 2;
    public static final int APEX_EVENT_LIST_END = 99;
    public static final int APEX_EVENT_LIST_START = 1;
    public static final int APEX_INFO_COMPLETE_UPDATE_SCORE = 101;
    public static final int APEX_INFO_LIST_END = 200;
    public static final int APEX_INFO_LIST_START = 100;
    public static final int APEX_INFO_UPDATE_SCORE = 100;
    private static final String TAG = "ApexEngine";
    private long mNativeContext;
    private OnErrorListener mOnErrorListener;
    private OnInfoListener mOnInfoListener;
    private String mSrcFilePath;

    public SemApexEngine()
    {
    }

    public SemApexEngine(long l, String s)
    {
        setupBestPhoto(l, s);
    }

    private final native void native_createBestPhoto(long l);

    private final native List native_createBestPhotos();

    private final native void native_finalize();

    private static final native void native_init();

    private final native void native_mergeClips(String as[], String s);

    private final native void native_releaseBestPhoto();

    private final native void native_releaseSplitClip();

    private final native void native_setupBestPhoto(long l, String s);

    private final native void native_setupSplitClip(FileDescriptor filedescriptor, long l, long l1);

    private final native boolean native_splitClipWithOffset(FileDescriptor filedescriptor, long l, long l1, long l2, 
            boolean flag, boolean flag1, boolean flag2);

    private static void postEventFromNative(Object obj, int i, int j, int k, Object obj1)
    {
        if ((SemApexEngine)((WeakReference)obj).get() != null);
    }

    private void processCbMessage(Message message)
        throws InterruptedException
    {
        message.what;
        JVM INSTR tableswitch 1 2: default 28
    //                   1 59
    //                   2 29;
           goto _L1 _L2 _L3
_L1:
        return;
_L3:
        if (mOnInfoListener != null)
        {
            mOnInfoListener.onInfo(this, message.arg1, message.arg2, message.obj);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (mOnErrorListener != null)
        {
            mOnErrorListener.onError(this, message.arg1, message.arg2);
            return;
        }
        if (true) goto _L1; else goto _L4
_L4:
    }

    public final void createBestPhoto(long l)
    {
        native_createBestPhoto(l);
    }

    public final List createBestPhotos()
    {
        return native_createBestPhotos();
    }

    public final void mergeClips(String as[], String s)
    {
        native_mergeClips(as, s);
    }

    public final void releaseBestPhoto()
    {
        native_releaseBestPhoto();
    }

    public final void releaseSplitClip()
    {
        native_releaseSplitClip();
    }

    public void setOnErrorListener(OnErrorListener onerrorlistener)
    {
        mOnErrorListener = onerrorlistener;
    }

    public void setOnInfoListener(OnInfoListener oninfolistener)
    {
        mOnInfoListener = oninfolistener;
    }

    public final void setupBestPhoto(long l, String s)
    {
        native_setupBestPhoto(l, s);
        mSrcFilePath = s;
    }

    public final void setupSplitClip(FileDescriptor filedescriptor, long l, long l1)
    {
        native_setupSplitClip(filedescriptor, l, l1);
    }

    public final boolean splitClip(FileDescriptor filedescriptor, long l, long l1, boolean flag, boolean flag1, 
            boolean flag2)
    {
        return native_splitClipWithOffset(filedescriptor, 0L, l, l1, flag, flag1, flag2);
    }

    public final boolean splitClipWithOffset(FileDescriptor filedescriptor, long l, long l1, long l2, 
            boolean flag, boolean flag1, boolean flag2)
    {
        return native_splitClipWithOffset(filedescriptor, l, l1, l2, flag, flag1, flag2);
    }

    static 
    {
        System.loadLibrary("apex_jni");
        native_init();
    }
}
