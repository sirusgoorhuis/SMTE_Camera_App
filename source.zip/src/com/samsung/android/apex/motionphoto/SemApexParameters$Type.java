// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;


// Referenced classes of package com.samsung.android.apex.motionphoto:
//            SemApexParameters

static final class val extends Enum
{

    private static final STRINGARRAY $VALUES[];
    public static final STRINGARRAY BOOLEAN;
    public static final STRINGARRAY FLOAT;
    public static final STRINGARRAY INT;
    public static final STRINGARRAY INTARRAY;
    public static final STRINGARRAY LONG;
    public static final STRINGARRAY LONGARRAY;
    public static final STRINGARRAY NONE;
    public static final STRINGARRAY STRING;
    public static final STRINGARRAY STRINGARRAY;
    public static final STRINGARRAY ULONGARRAY;
    private int val;

    static val valueOf(int i)
    {
        val aval[] = values();
        int k = aval.length;
        for (int j = 0; j < k; j++)
        {
            val val1 = aval[j];
            if (i == val1.val)
            {
                return val1;
            }
        }

        return NONE;
    }

    public static NONE valueOf(String s)
    {
        return (NONE)Enum.valueOf(com/samsung/android/apex/motionphoto/SemApexParameters$Type, s);
    }

    public static NONE[] values()
    {
        return (NONE[])$VALUES.clone();
    }

    public String toString()
    {
        return Integer.toString(val);
    }

    static 
    {
        NONE = new <init>("NONE", 0, "none");
        BOOLEAN = new <init>("BOOLEAN", 1, "vbln");
        INT = new <init>("INT", 2, "vint");
        LONG = new <init>("LONG", 3, "vlng");
        FLOAT = new <init>("FLOAT", 4, "vflt");
        STRING = new <init>("STRING", 5, "vstr");
        INTARRAY = new <init>("INTARRAY", 6, "aint");
        LONGARRAY = new <init>("LONGARRAY", 7, "alng");
        ULONGARRAY = new <init>("ULONGARRAY", 8, "auln");
        STRINGARRAY = new <init>("STRINGARRAY", 9, "astr");
        $VALUES = (new .VALUES[] {
            NONE, BOOLEAN, INT, LONG, FLOAT, STRING, INTARRAY, LONGARRAY, ULONGARRAY, STRINGARRAY
        });
    }

    private A(String s, int i, String s1)
    {
        super(s, i);
        for (i = 0; i < 4; i++)
        {
            val = val << 8;
            val = val | s1.charAt(i);
        }

    }
}
