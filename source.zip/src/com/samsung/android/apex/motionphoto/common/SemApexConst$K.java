// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.common;


// Referenced classes of package com.samsung.android.apex.motionphoto.common:
//            SemApexConst

public static final class 
{

    public static final int SEF_DATA_MOTION_PHOTO = 2608;
    public static final String SEF_TAG_MOTION_PHOTO = "MotionPhoto_Data";

    public ()
    {
    }
}
