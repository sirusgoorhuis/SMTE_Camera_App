// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.common;

import android.os.Environment;
import java.io.File;

// Referenced classes of package com.samsung.android.apex.motionphoto.common:
//            SemApexConst

public static final class 
{

    public static final String APEXSERVICE_UID = "android.uid.system";
    public static final String APEX_APP_PACKAGE = "com.sec.android.app.apex";
    public static final String APEX_MOTIONPHOTO_VIEWER_NAME = "com.sec.android.app.apex.player.PlayerActivity";
    public static final String APEX_SERVICE_NAME = "com.sec.android.app.apex.service.ApexService";
    public static final String CAMERA_OUTPUT_DIR = (new StringBuilder()).append(Environment.getExternalStorageDirectory().getAbsolutePath()).append("/DCIM/Camera/").toString();


    public ()
    {
    }
}
