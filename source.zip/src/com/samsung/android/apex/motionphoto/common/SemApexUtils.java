// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.common;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

public class SemApexUtils
{

    public static final String ALLOW_FILE_DIR = "/data/media/";
    public static final String ALLOW_FILE_EXT = "mp4";
    public static final String BLACKLIST_FILEPATH[] = {
        "..", "../", "..\\"
    };
    private static final String TAG = com/samsung/android/apex/motionphoto/common/SemApexUtils.getSimpleName();
    public static final String WHITELIST_LOCAL_CLIENT[] = {
        "com.sec.android.app.apex", "com.samsung.android.apex"
    };
    public static final String WHITELIST_REMOTE_CLIENT[] = {
        "com.sec.android.app.camera", "com.samsung.android.apex"
    };

    private SemApexUtils()
    {
    }

    public static void copyFile(InputStream inputstream, OutputStream outputstream)
        throws IOException
    {
        byte abyte0[] = new byte[1024];
        do
        {
            int i = inputstream.read(abyte0);
            if (i != -1)
            {
                outputstream.write(abyte0, 0, i);
            } else
            {
                return;
            }
        } while (true);
    }

    public static int getPid(Context context, String s)
    {
label0:
        {
            Log.d(TAG, (new StringBuilder()).append("pkg: ").append(s).toString());
            context = ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses();
            if (context == null)
            {
                break label0;
            }
            context = context.iterator();
            android.app.ActivityManager.RunningAppProcessInfo runningappprocessinfo;
            do
            {
                if (!context.hasNext())
                {
                    break label0;
                }
                runningappprocessinfo = (android.app.ActivityManager.RunningAppProcessInfo)context.next();
                Log.d(TAG, (new StringBuilder()).append("pkg: ").append(runningappprocessinfo.processName).append(", pid: ").append(runningappprocessinfo.pid).toString());
            } while (!s.equals(runningappprocessinfo.processName));
            return runningappprocessinfo.pid;
        }
        return -1;
    }

    public static String getPkgName(Context context, int i)
    {
label0:
        {
            Object obj = null;
            Object obj1 = ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses();
            context = obj;
            if (obj1 == null)
            {
                break label0;
            }
            Log.d(TAG, (new StringBuilder()).append("size: ").append(((List) (obj1)).size()).toString());
            obj1 = ((List) (obj1)).iterator();
            do
            {
                context = obj;
                if (!((Iterator) (obj1)).hasNext())
                {
                    break label0;
                }
                context = (android.app.ActivityManager.RunningAppProcessInfo)((Iterator) (obj1)).next();
                Log.d(TAG, (new StringBuilder()).append("pkg info: name-").append(((android.app.ActivityManager.RunningAppProcessInfo) (context)).processName).append(", pid-").append(((android.app.ActivityManager.RunningAppProcessInfo) (context)).pid).toString());
            } while (((android.app.ActivityManager.RunningAppProcessInfo) (context)).pid != i);
            context = ((android.app.ActivityManager.RunningAppProcessInfo) (context)).processName;
        }
        return context;
    }

    public static boolean isValidFilePath(String s)
    {
label0:
        {
            Log.d(TAG, (new StringBuilder()).append("isValidFilePath: ").append(s).toString());
            if (s == null || s.length() == 0)
            {
                Log.e(TAG, "path is wrong");
                return false;
            }
            Object obj = new File(s);
            if (!((File) (obj)).exists())
            {
                Log.e(TAG, "file not exist");
                return false;
            }
            try
            {
                obj = ((File) (obj)).getCanonicalPath();
                if (((String) (obj)).substring(0, ((String) (obj)).lastIndexOf("/") + 1).toLowerCase().equals("/data/media/"))
                {
                    break label0;
                }
                Log.e(TAG, (new StringBuilder()).append("not allowed path: ").append(((String) (obj))).toString());
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                s.printStackTrace();
                return false;
            }
            return false;
        }
        s = s.substring(s.lastIndexOf('.') + 1).toLowerCase();
        if (!s.equals("mp4"))
        {
            Log.e(TAG, (new StringBuilder()).append("not allowed format: ").append(s).toString());
            return false;
        } else
        {
            return true;
        }
    }

    public static boolean isValidLocalClient(String s)
    {
        boolean flag1 = false;
        String as[] = WHITELIST_LOCAL_CLIENT;
        int j = as.length;
        int i = 0;
        do
        {
label0:
            {
                boolean flag = flag1;
                if (i < j)
                {
                    if (!s.equals(as[i]))
                    {
                        break label0;
                    }
                    flag = true;
                }
                return flag;
            }
            i++;
        } while (true);
    }

    public static boolean isValidRemoteClient(String s)
    {
        boolean flag1 = false;
        String as[] = WHITELIST_REMOTE_CLIENT;
        int j = as.length;
        int i = 0;
        do
        {
label0:
            {
                boolean flag = flag1;
                if (i < j)
                {
                    if (!s.equals(as[i]))
                    {
                        break label0;
                    }
                    flag = true;
                }
                return flag;
            }
            i++;
        } while (true);
    }

    public static String removeExtension(String s)
    {
        String s1;
        if (s == null)
        {
            s1 = null;
        } else
        {
            int i = s.lastIndexOf(".");
            s1 = s;
            if (Math.max(s.lastIndexOf("/"), s.lastIndexOf("\\")) <= i)
            {
                return s.substring(0, i);
            }
        }
        return s1;
    }

    public static String[] renameExtension(String as[], String s)
    {
        String as1[];
        if (as.length > 0)
        {
            String as2[] = new String[as.length];
            int i = 0;
            do
            {
                as1 = as2;
                if (i >= as.length)
                {
                    break;
                }
                as2[i] = (new StringBuilder()).append(removeExtension(as[i])).append(s).toString();
                i++;
            } while (true);
        } else
        {
            as1 = null;
        }
        return as1;
    }

}
