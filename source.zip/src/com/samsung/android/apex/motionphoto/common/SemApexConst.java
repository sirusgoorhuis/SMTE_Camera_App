// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.common;

import android.os.Environment;
import java.io.File;

public class SemApexConst
{
    public static final class E
    {

        public static final int APEX_ERROR_APEXSERVER_DEAD = -9984;
        public static final int APEX_ERROR_INIT_FAIL = -9995;
        public static final int APEX_ERROR_INSUFFICIENT_MEMORY = -9993;
        public static final int APEX_ERROR_INVALID = -9997;
        public static final int APEX_ERROR_INVALID_OPERATION = -9990;
        public static final int APEX_ERROR_MALFORMED = -9992;
        public static final int APEX_ERROR_NOT_EXIST = -9996;
        public static final int APEX_ERROR_NO_DATA = -9986;
        public static final int APEX_ERROR_NO_INIT = -9994;
        public static final int APEX_ERROR_PREPARE_FAIL = -9989;
        public static final int APEX_ERROR_RECORDER_DEAD = -9985;
        public static final int APEX_ERROR_RECORDING_PROXY_DEAD = -9998;
        public static final int APEX_ERROR_START = -10000;
        public static final int APEX_ERROR_START_FAIL = -9988;
        public static final int APEX_ERROR_STOP_FAIL = -9987;
        public static final int APEX_ERROR_WRITE_FAIL = -9991;
        public static final int APEX_ERROR_WRONG_FORMAT = -9999;
        public static final int APEX_EVENT_ERROR = 3002;
        public static final int APEX_EVENT_INFO = 3001;
        public static final int APEX_EVENT_START = 3000;
        public static final int APEX_INFO_COMPLETION_STATUS = 10002;
        public static final int APEX_INFO_FORMAT_CHANGED = 10005;
        public static final int APEX_INFO_REACHED_EOS = 10001;
        public static final int APEX_INFO_RECORDER_CONFIGURED = 10004;
        public static final int APEX_INFO_RECORDER_CONNECTED = 10006;
        public static final int APEX_INFO_RECORDER_DISCONNECTED = 10007;
        public static final int APEX_INFO_RECORDER_STARTED = 10008;
        public static final int APEX_INFO_RECORDER_STOPPED = 10009;
        public static final int APEX_INFO_RECORDER_UNINITIALIZED = 10003;
        public static final int APEX_INFO_START = 10000;
        public static final int APEX_INFO_STORE_CANCELED = 10011;
        public static final int APEX_INFO_STORE_COMPLETED = 10010;
        public static final int APEX_INFO_SURFACE_CONNECTED = 10015;

        public E()
        {
        }
    }

    public static final class K
    {

        public static final int SEF_DATA_MOTION_PHOTO = 2608;
        public static final String SEF_TAG_MOTION_PHOTO = "MotionPhoto_Data";

        public K()
        {
        }
    }

    public static final class V
    {

        public static final String APEXSERVICE_UID = "android.uid.system";
        public static final String APEX_APP_PACKAGE = "com.sec.android.app.apex";
        public static final String APEX_MOTIONPHOTO_VIEWER_NAME = "com.sec.android.app.apex.player.PlayerActivity";
        public static final String APEX_SERVICE_NAME = "com.sec.android.app.apex.service.ApexService";
        public static final String CAMERA_OUTPUT_DIR = (new StringBuilder()).append(Environment.getExternalStorageDirectory().getAbsolutePath()).append("/DCIM/Camera/").toString();


        public V()
        {
        }
    }


    public SemApexConst()
    {
    }
}
