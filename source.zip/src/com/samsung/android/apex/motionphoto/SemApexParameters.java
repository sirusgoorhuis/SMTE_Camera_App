// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SemApexParameters
{
    static final class Type extends Enum
    {

        private static final Type $VALUES[];
        public static final Type BOOLEAN;
        public static final Type FLOAT;
        public static final Type INT;
        public static final Type INTARRAY;
        public static final Type LONG;
        public static final Type LONGARRAY;
        public static final Type NONE;
        public static final Type STRING;
        public static final Type STRINGARRAY;
        public static final Type ULONGARRAY;
        private int val;

        static Type valueOf(int i)
        {
            Type atype[] = values();
            int k = atype.length;
            for (int j = 0; j < k; j++)
            {
                Type type = atype[j];
                if (i == type.val)
                {
                    return type;
                }
            }

            return NONE;
        }

        public static Type valueOf(String s)
        {
            return (Type)Enum.valueOf(com/samsung/android/apex/motionphoto/SemApexParameters$Type, s);
        }

        public static Type[] values()
        {
            return (Type[])$VALUES.clone();
        }

        public String toString()
        {
            return Integer.toString(val);
        }

        static 
        {
            NONE = new Type("NONE", 0, "none");
            BOOLEAN = new Type("BOOLEAN", 1, "vbln");
            INT = new Type("INT", 2, "vint");
            LONG = new Type("LONG", 3, "vlng");
            FLOAT = new Type("FLOAT", 4, "vflt");
            STRING = new Type("STRING", 5, "vstr");
            INTARRAY = new Type("INTARRAY", 6, "aint");
            LONGARRAY = new Type("LONGARRAY", 7, "alng");
            ULONGARRAY = new Type("ULONGARRAY", 8, "auln");
            STRINGARRAY = new Type("STRINGARRAY", 9, "astr");
            $VALUES = (new Type[] {
                NONE, BOOLEAN, INT, LONG, FLOAT, STRING, INTARRAY, LONGARRAY, ULONGARRAY, STRINGARRAY
            });
        }

        private Type(String s, int i, String s1)
        {
            super(s, i);
            for (i = 0; i < 4; i++)
            {
                val = val << 8;
                val = val | s1.charAt(i);
            }

        }
    }


    public static final String KEY_ALLOC_PREVIEW_BUFFER = "alloc-preview-buffer";
    public static final String KEY_BUFFERING_MODE = "buffering-mode";
    public static final String KEY_CAPTURE_INTERVAL = "capture-interval";
    public static final String KEY_DITHER_STRENGTH = "dither-strength";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_EFFECT_MODE = "effect-mode";
    public static final String KEY_FPS_FACTOR = "fps-factor";
    public static final String KEY_FPS_RANGE = "fps-range";
    public static final String KEY_FRAME_RATE = "frame-rate";
    public static final String KEY_HEIGHT = "height";
    public static final String KEY_INPUT_FILE = "input-file";
    public static final String KEY_METADATA_STORED = "metadatastored";
    public static final String KEY_OUTPUT_FILE = "output-file";
    public static final String KEY_PREVIEW_FORMAT = "preview-format";
    public static final String KEY_PREVIEW_SIZE = "preview-size";
    public static final String KEY_QUALITY_FACTOR = "quality-factor";
    public static final String KEY_REPEAT = "repeat";
    public static final String KEY_SAVE_AS_FLIPPED = "save-as-flipped";
    public static final String KEY_TOKEN = "token";
    public static final String KEY_TRANSPARENT = "transparent";
    public static final String KEY_USE_INTRINSIC_TIMESTAMP = "use-intrinsic-timestamp";
    public static final String KEY_USE_PROXY_STORETIME = "use-proxy-storetime";
    public static final String KEY_VIDEO_FORMAT = "video-format";
    public static final String KEY_VIDEO_SIZE = "video-size";
    public static final String KEY_WIDTH = "width";
    private static final String TAG = com/samsung/android/apex/motionphoto/SemApexParameters.getSimpleName();
    private HashMap mMap;

    public SemApexParameters()
    {
        mMap = new HashMap();
    }

    public SemApexParameters(String s)
    {
        mMap = new HashMap();
        unflatten(s);
    }

    public void clear()
    {
        mMap.clear();
    }

    public boolean contains(String s)
    {
        return mMap.containsKey(s);
    }

    public String flatten()
    {
        StringBuilder stringbuilder = new StringBuilder();
        Iterator iterator = mMap.keySet().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            Object obj = (String)iterator.next();
            Object obj1 = mMap.get(obj);
            if (obj1 != null)
            {
                stringbuilder.append(((String) (obj)));
                stringbuilder.append("=");
                if (obj1 instanceof Boolean)
                {
                    stringbuilder.append(((Boolean)obj1).toString());
                    stringbuilder.append((new StringBuilder()).append("@").append(Type.BOOLEAN).toString());
                } else
                if (obj1 instanceof Integer)
                {
                    stringbuilder.append(((Integer)obj1).toString());
                    stringbuilder.append((new StringBuilder()).append("@").append(Type.INT).toString());
                } else
                if (obj1 instanceof Long)
                {
                    stringbuilder.append(((Long)obj1).toString());
                    stringbuilder.append((new StringBuilder()).append("@").append(Type.LONG).toString());
                } else
                if (obj1 instanceof Float)
                {
                    stringbuilder.append(((Float)obj1).toString());
                    stringbuilder.append((new StringBuilder()).append("@").append(Type.FLOAT).toString());
                } else
                if (obj1 instanceof String)
                {
                    stringbuilder.append((String)obj1);
                    stringbuilder.append((new StringBuilder()).append("@").append(Type.STRING).toString());
                } else
                if (obj1 instanceof int[])
                {
                    stringbuilder.append("[");
                    obj = (int[])(int[])obj1;
                    int l = obj.length;
                    for (int i = 0; i < l; i++)
                    {
                        int k1 = obj[i];
                        stringbuilder.append((new StringBuilder()).append(k1).append(",").toString());
                    }

                    stringbuilder.deleteCharAt(stringbuilder.length() - 1);
                    stringbuilder.append((new StringBuilder()).append("]@").append(Type.INTARRAY).toString());
                } else
                if (obj1 instanceof long[])
                {
                    stringbuilder.append("[");
                    obj = (long[])(long[])obj1;
                    int i1 = obj.length;
                    for (int j = 0; j < i1; j++)
                    {
                        long l1 = obj[j];
                        stringbuilder.append((new StringBuilder()).append(l1).append(",").toString());
                    }

                    stringbuilder.insert(stringbuilder.length() - 1, (new StringBuilder()).append("]@").append(Type.LONGARRAY).toString());
                } else
                if (obj1 instanceof String[])
                {
                    stringbuilder.append("[");
                    obj = (String[])(String[])obj1;
                    int j1 = obj.length;
                    for (int k = 0; k < j1; k++)
                    {
                        obj1 = obj[k];
                        stringbuilder.append((new StringBuilder()).append(((String) (obj1))).append(",").toString());
                    }

                    stringbuilder.insert(stringbuilder.length() - 1, (new StringBuilder()).append("]@").append(Type.STRINGARRAY).toString());
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("Unknown type[key=").append(((String) (obj))).append("]: ").append(obj1).toString());
                }
                stringbuilder.append(";");
            }
        } while (true);
        stringbuilder.deleteCharAt(stringbuilder.length() - 1);
        return stringbuilder.toString();
    }

    public Object get(String s)
    {
        return mMap.get(s);
    }

    public Boolean getBoolean(String s)
    {
        return (Boolean)mMap.get(s);
    }

    public float getFloat(String s)
    {
        return ((Float)mMap.get(s)).floatValue();
    }

    public int getInt(String s)
    {
        return ((Integer)mMap.get(s)).intValue();
    }

    public List getList(String s)
    {
        return (List)mMap.get(s);
    }

    public long getLong(String s)
    {
        return ((Long)mMap.get(s)).longValue();
    }

    public String getString(String s)
    {
        return (String)mMap.get(s);
    }

    public void put(Map map)
    {
        mMap.putAll(map);
    }

    public void remove(String s)
    {
        mMap.remove(s);
    }

    public void set(String s, Object obj)
    {
        mMap.put(s, obj);
    }

    public void unflatten(String s)
    {
        mMap.clear();
        Object obj = new android.text.TextUtils.SimpleStringSplitter(';');
        ((android.text.TextUtils.StringSplitter) (obj)).setString(s);
        obj = ((android.text.TextUtils.StringSplitter) (obj)).iterator();
        do
        {
            if (!((Iterator) (obj)).hasNext())
            {
                break;
            }
            s = (String)((Iterator) (obj)).next();
            int i = s.indexOf("=");
            if (i != -1)
            {
                String s1 = s.substring(0, i);
                int j = s.indexOf("@");
                Object obj1 = Type.valueOf(Integer.parseInt(s.substring(j + 1)));
                if (obj1 == Type.BOOLEAN)
                {
                    s = Boolean.valueOf(Boolean.parseBoolean(s.substring(i + 1, j)));
                } else
                if (obj1 == Type.INT)
                {
                    s = Integer.valueOf(Integer.parseInt(s.substring(i + 1, j)));
                } else
                if (obj1 == Type.LONG)
                {
                    s = Long.valueOf(Long.parseLong(s.substring(i + 1, j)));
                } else
                if (obj1 == Type.FLOAT)
                {
                    s = Float.valueOf(Float.parseFloat(s.substring(i + 1, j)));
                } else
                if (obj1 == Type.STRING)
                {
                    s = s.substring(i + 1, j);
                } else
                if (obj1 == Type.INTARRAY)
                {
                    obj1 = s.substring(i + 2, j - 1).split(",");
                    s = new int[obj1.length];
                    i = 0;
                    while (i < obj1.length) 
                    {
                        s[i] = Integer.parseInt(obj1[i]);
                        i++;
                    }
                } else
                if (obj1 == Type.LONGARRAY)
                {
                    obj1 = s.substring(i + 2, j - 1).split(",");
                    s = new long[obj1.length];
                    i = 0;
                    while (i < obj1.length) 
                    {
                        s[i] = Long.parseLong(obj1[i]);
                        i++;
                    }
                } else
                if (obj1 == Type.STRINGARRAY)
                {
                    s = s.substring(i + 2, j - 1).split(",");
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("Unknown type: ").append(obj1).toString());
                }
                mMap.put(s1, s);
            }
        } while (true);
    }

}
