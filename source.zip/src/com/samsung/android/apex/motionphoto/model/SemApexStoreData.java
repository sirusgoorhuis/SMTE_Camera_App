// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.model;

import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import com.samsung.android.apex.motionphoto.SemApexParameters;
import java.util.HashMap;

public class SemApexStoreData
{

    private static final String TAG = com/samsung/android/apex/motionphoto/model/SemApexStoreData.getSimpleName();
    long id;
    private String path;
    private Rect rect;
    private int rotation;
    private long timestamp;
    private int token;

    public SemApexStoreData()
    {
    }

    public SemApexStoreData(long l, int i, String s)
    {
        id = l;
        token = i;
        path = s;
        timestamp = -1L;
        rotation = 0;
        rect = null;
    }

    public SemApexStoreData(long l, int i, String s, long l1)
    {
        id = l;
        token = i;
        path = s;
        timestamp = l1;
        rotation = 0;
        rect = null;
    }

    public SemApexStoreData(long l, int i, String s, long l1, int j)
    {
        id = l;
        token = i;
        path = s;
        timestamp = l1;
        rotation = j;
        rect = null;
    }

    public SemApexStoreData(long l, int i, String s, long l1, int j, 
            Rect rect1)
    {
        id = l;
        token = i;
        path = s;
        timestamp = l1;
        rotation = j;
        rect = rect1;
    }

    public SemApexStoreData(String s)
    {
        unflatten(s);
    }

    public static SemApexStoreData createFrom(Bundle bundle)
    {
        return new SemApexStoreData(bundle.getLong("id", -1L), bundle.getInt("token", -1), bundle.getString("path", null), bundle.getLong("timestamp"), bundle.getInt("rotation"), (Rect)bundle.getParcelable("rect"));
    }

    public static SemApexStoreData createFrom(HashMap hashmap)
    {
        Log.d(TAG, (new StringBuilder()).append("m : ").append(hashmap).toString());
        long l = ((Long)hashmap.get("id")).longValue();
        int i = ((Integer)hashmap.get("token")).intValue();
        String s = (String)hashmap.get("path");
        long l1 = ((Long)hashmap.get("timestamp")).longValue();
        int j = ((Integer)hashmap.get("rotation")).intValue();
        hashmap = (int[])(int[])hashmap.get("rect");
        return new SemApexStoreData(l, i, s, l1, j, new Rect(hashmap[0], hashmap[1], hashmap[2], hashmap[3]));
    }

    public String flatten()
    {
        SemApexParameters semapexparameters = new SemApexParameters();
        semapexparameters.set("id", Long.valueOf(id));
        semapexparameters.set("token", Integer.valueOf(token));
        semapexparameters.set("path", path);
        semapexparameters.set("timestamp", Long.valueOf(timestamp));
        semapexparameters.set("rotation", Integer.valueOf(rotation));
        semapexparameters.set("rect", rect);
        return semapexparameters.flatten();
    }

    public long getId()
    {
        return id;
    }

    public String getPath()
    {
        return path;
    }

    public int getRotation()
    {
        return rotation;
    }

    public long getTimestamp()
    {
        return timestamp;
    }

    public int getToken()
    {
        return token;
    }

    public void setId(long l)
    {
        id = l;
    }

    public void setPath(String s)
    {
        path = s;
    }

    public void setRotation(int i)
    {
        rotation = i;
    }

    public void setTimestamp(long l)
    {
        timestamp = l;
    }

    public void setToken(int i)
    {
        token = i;
    }

    public Bundle toBundle()
    {
        Bundle bundle = new Bundle();
        bundle.putLong("id", id);
        bundle.putInt("token", token);
        bundle.putString("path", path);
        bundle.putLong("timestamp", timestamp);
        bundle.putInt("rotation", rotation);
        bundle.putParcelable("rect", rect);
        return bundle;
    }

    public String toString()
    {
        long l = id;
        int i = token;
        long l1 = timestamp;
        String s1 = path;
        int j = rotation;
        String s;
        if (rect != null)
        {
            s = rect.toString();
        } else
        {
            s = "";
        }
        return String.format("id=%d, token=%d, timestamp=%d, path=%s, rotation=%d, rect=%s", new Object[] {
            Long.valueOf(l), Integer.valueOf(i), Long.valueOf(l1), s1, Integer.valueOf(j), s
        });
    }

    public void unflatten(String s)
    {
        s = new SemApexParameters(s);
        id = s.getLong("id");
        token = s.getInt("token");
        path = s.getString("path");
        timestamp = s.getLong("timestamp");
        rotation = s.getInt("rotation");
        rect = (Rect)s.get("rect");
    }

}
