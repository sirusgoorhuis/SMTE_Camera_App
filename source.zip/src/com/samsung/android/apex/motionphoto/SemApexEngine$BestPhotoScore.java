// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;


// Referenced classes of package com.samsung.android.apex.motionphoto:
//            SemApexEngine

public static final class 
{

    private long mScore;
    private long mTimeUs;
    private long mVideoId;

    public long getScore()
    {
        return mScore;
    }

    public long getTimeUs()
    {
        return mTimeUs;
    }

    public long getVideoId()
    {
        return mVideoId;
    }

    public void setScore(long l)
    {
        mScore = l;
    }

    public void setTimeUs(long l)
    {
        mTimeUs = l;
    }

    public void setVideoId(long l)
    {
        mVideoId = l;
    }

    ()
    {
    }
}
