// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.command;

import android.util.Log;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

// Referenced classes of package com.samsung.android.apex.motionphoto.command:
//            Reply

public static class mData extends LinkedBlockingQueue
{

    private Object mData;

    public Reply awaitResponse()
    {
        Log.e(Reply.access$000(), "awaitResponse");
        Reply reply;
        try
        {
            reply = (Reply)super.take();
        }
        catch (InterruptedException interruptedexception)
        {
            interruptedexception.printStackTrace();
            return new Reply(interruptedexception);
        }
        return reply;
    }

    public Reply awaitResponse(int i)
    {
        Log.e(Reply.access$000(), (new StringBuilder()).append("awaitResponse: ").append(i).toString());
        long l = i;
        Reply reply;
        try
        {
            reply = (Reply)super.poll(l, TimeUnit.SECONDS);
        }
        catch (InterruptedException interruptedexception)
        {
            interruptedexception.printStackTrace();
            return new Reply(interruptedexception);
        }
        return reply;
    }

    public Reply awaitResponse(int i, TimeUnit timeunit)
    {
        Log.d(Reply.access$000(), (new StringBuilder()).append("awaitResponse: ").append(i).toString());
        long l = i;
        try
        {
            timeunit = (Reply)super.poll(l, timeunit);
        }
        // Misplaced declaration of an exception variable
        catch (TimeUnit timeunit)
        {
            timeunit.printStackTrace();
            return new Reply(timeunit);
        }
        return timeunit;
    }

    public Object getData()
    {
        return mData;
    }

    public void respond(Reply reply)
    {
        Log.e(Reply.access$000(), (new StringBuilder()).append("respond: ").append(reply).toString());
        try
        {
            super.put(reply);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Reply reply)
        {
            Log.e(Reply.access$000(), "can't respond");
        }
        reply.printStackTrace();
    }

    public ()
    {
        super(1);
    }

    public (Object obj)
    {
        super(1);
        mData = obj;
    }
}
