// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.command;

import android.util.Log;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class Reply
{
    public static class Token extends LinkedBlockingQueue
    {

        private Object mData;

        public Reply awaitResponse()
        {
            Log.e(Reply.TAG, "awaitResponse");
            Reply reply;
            try
            {
                reply = (Reply)super.take();
            }
            catch (InterruptedException interruptedexception)
            {
                interruptedexception.printStackTrace();
                return new Reply(interruptedexception);
            }
            return reply;
        }

        public Reply awaitResponse(int i)
        {
            Log.e(Reply.TAG, (new StringBuilder()).append("awaitResponse: ").append(i).toString());
            long l = i;
            Reply reply;
            try
            {
                reply = (Reply)super.poll(l, TimeUnit.SECONDS);
            }
            catch (InterruptedException interruptedexception)
            {
                interruptedexception.printStackTrace();
                return new Reply(interruptedexception);
            }
            return reply;
        }

        public Reply awaitResponse(int i, TimeUnit timeunit)
        {
            Log.d(Reply.TAG, (new StringBuilder()).append("awaitResponse: ").append(i).toString());
            long l = i;
            try
            {
                timeunit = (Reply)super.poll(l, timeunit);
            }
            // Misplaced declaration of an exception variable
            catch (TimeUnit timeunit)
            {
                timeunit.printStackTrace();
                return new Reply(timeunit);
            }
            return timeunit;
        }

        public Object getData()
        {
            return mData;
        }

        public void respond(Reply reply)
        {
            Log.e(Reply.TAG, (new StringBuilder()).append("respond: ").append(reply).toString());
            try
            {
                super.put(reply);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Reply reply)
            {
                Log.e(Reply.TAG, "can't respond");
            }
            reply.printStackTrace();
        }

        public Token()
        {
            super(1);
        }

        public Token(Object obj)
        {
            super(1);
            mData = obj;
        }
    }


    private static final String TAG = com/samsung/android/apex/motionphoto/command/Reply.getSimpleName();
    private HashMap data;
    private Exception error;
    private String message;
    private boolean success;

    public Reply(Exception exception)
    {
        success = false;
        data = new HashMap();
        success = false;
        error = exception;
    }

    public Reply(String s)
    {
        success = false;
        data = new HashMap();
        success = false;
        message = s;
    }

    public Reply(String s, Object obj)
    {
        success = false;
        data = new HashMap();
        success = true;
        setData(s, obj);
    }

    public Reply(boolean flag)
    {
        success = false;
        data = new HashMap();
        success = flag;
    }

    protected void finalize()
        throws Throwable
    {
        data.clear();
        super.finalize();
    }

    public Object getData(String s)
    {
        return data.get(s);
    }

    public Exception getError()
    {
        return error;
    }

    public String getMessage()
    {
        if (error == null)
        {
            return message;
        } else
        {
            return error.getMessage();
        }
    }

    public boolean isSuccess()
    {
        return success;
    }

    public void printMessage(String s)
    {
        if (error == null)
        {
            Log.d(s, (new StringBuilder()).append("").append(message).toString());
            return;
        } else
        {
            Log.e(s, (new StringBuilder()).append("").append(error.getMessage()).toString());
            return;
        }
    }

    public void setData(String s, Object obj)
    {
        data.put(s, obj);
    }

    public void setError(Exception exception)
    {
        success = false;
        error = exception;
    }

    public void setSuccess(boolean flag)
    {
        success = flag;
    }


}
