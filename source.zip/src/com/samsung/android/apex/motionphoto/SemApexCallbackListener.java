// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto;

import android.os.Bundle;
import java.util.HashMap;

public abstract class SemApexCallbackListener
{

    public static final int CMD_CANCLE_SPLIT = 3;
    public static final int CMD_DO_SPLIT = 2;
    public static final int CMD_HANDLE_APEXSERVER_DEAD = 6;
    public static final int CMD_HANDLE_PROXY_DEAD = 5;
    public static final int CMD_HANDLE_RECORDER_CONNECTED = 8;
    public static final int CMD_HANDLE_RECORDER_DISCONNECTED = 9;
    public static final int CMD_HANDLE_RECORDER_RELEASED = 7;
    public static final int CMD_HANDLE_RECORDER_STARTED = 10;
    public static final int CMD_HANDLE_RECORDER_STOPPED = 11;
    public static final int CMD_QUEUE_ID = 1;
    public static final int CMD_REQUEST_ID = 4;

    public SemApexCallbackListener()
    {
    }

    public abstract void onApexServerDead(String s, int i);

    public abstract void onRecoderStopped(String s);

    public abstract void onRecorderConnected(String s, int i, Object obj);

    public abstract void onRecorderDisconnected(String s);

    public abstract void onRecorderReleased(String s, int i);

    public abstract void onRecorderStrated(String s);

    public abstract void onRecordingCancel(HashMap hashmap);

    public abstract void onRecordingComplete(HashMap hashmap);

    public abstract void onRecordingProxyDead(String s, int i);

    public abstract long onRequestId();

    public abstract void onStoreData(Bundle bundle);
}
