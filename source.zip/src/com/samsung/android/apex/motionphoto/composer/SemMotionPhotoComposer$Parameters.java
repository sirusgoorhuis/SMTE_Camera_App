// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import com.samsung.android.apex.motionphoto.SemApexParameters;
import java.util.HashMap;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

public static final class unflatten extends SemApexParameters
{
    public static final class Builder
    {

        private String mFlattenParam;
        private HashMap mMap;

        public SemMotionPhotoComposer.Parameters build()
        {
            SemMotionPhotoComposer.Parameters parameters = new SemMotionPhotoComposer.Parameters(null);
            if (mFlattenParam != null)
            {
                parameters.unflatten(mFlattenParam);
            }
            parameters.put(mMap);
            if (parameters.get("buffering-mode") == null)
            {
                parameters.set("buffering-mode", "front");
            }
            if ("on".equals(parameters.get("effect-mode")))
            {
                parameters.set("preview-format", "android-opaque");
            }
            return parameters;
        }

        public Builder set(String s, Object obj)
        {
            mMap.put(s, obj);
            return this;
        }

        public Builder setAllocPreviewBuffer(boolean flag)
        {
            mMap.put("alloc-preview-buffer", Boolean.valueOf(flag));
            return this;
        }

        public Builder setBufferingMode(boolean flag)
        {
            HashMap hashmap = mMap;
            String s;
            if (flag)
            {
                s = "front";
            } else
            {
                s = "back";
            }
            hashmap.put("buffering-mode", s);
            return this;
        }

        public Builder setDuration(int i)
        {
            mMap.put("duration", Integer.valueOf(i));
            return this;
        }

        public Builder setEffectRecording(boolean flag)
        {
            HashMap hashmap = mMap;
            String s;
            if (flag)
            {
                s = "on";
            } else
            {
                s = "off";
            }
            hashmap.put("effect-mode", s);
            return this;
        }

        public Builder setFlattenParameter(String s)
        {
            mFlattenParam = s;
            return this;
        }

        public Builder setFpsFactor(int i)
        {
            mMap.put("fps-factor", Integer.valueOf(i));
            return this;
        }

        public Builder setPreviewFpsRange(int ai[])
        {
            mMap.put("fps-range", ai);
            return this;
        }

        public Builder setPreviewSize(int i, int j)
        {
            mMap.put("preview-size", (new StringBuilder()).append(i).append("x").append(j).toString());
            return this;
        }

        public Builder setPreviewSize(String s)
        {
            mMap.put("preview-size", s);
            return this;
        }

        public Builder setRecordDuration(int i)
        {
            mMap.put("duration", Integer.valueOf(i));
            return this;
        }

        public Builder setSaveAsFlipped(boolean flag)
        {
            mMap.put("save-as-flipped", Boolean.valueOf(flag));
            return this;
        }

        public Builder setToken(int i)
        {
            mMap.put("token", Integer.valueOf(i));
            return this;
        }

        public Builder setUseIntrinsicTimestamp(boolean flag)
        {
            mMap.put("use-intrinsic-timestamp", Boolean.valueOf(flag));
            return this;
        }

        public Builder setUseProxyStoretime(boolean flag)
        {
            mMap.put("use-proxy-storetime", Boolean.valueOf(flag));
            return this;
        }

        public Builder setVideoFrameRate(int i)
        {
            mMap.put("frame-rate", Integer.valueOf(i));
            return this;
        }

        public Builder()
        {
            mMap = new HashMap();
        }
    }


    private static final String BUFFERING_BACK = "back";
    private static final String BUFFERING_FRONT = "front";
    private static final String EFFECT_OFF = "off";
    private static final String EFFECT_ON = "on";

    private Builder.mMap()
    {
    }

    Builder.mMap(Builder.mMap mmap)
    {
        this();
    }

    private <init>(String s)
    {
        unflatten(s);
    }
}
