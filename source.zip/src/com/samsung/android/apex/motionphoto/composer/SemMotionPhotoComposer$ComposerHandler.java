// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

protected static class mComposer extends Handler
{

    private SemMotionPhotoComposer mComposer;

    public void handleMessage(Message message)
    {
        try
        {
            mComposer.handleMessage(message);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Message message)
        {
            message.printStackTrace();
        }
    }

    public (SemMotionPhotoComposer semmotionphotocomposer, Looper looper)
    {
        super(looper);
        mComposer = semmotionphotocomposer;
    }
}
