// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;


// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

private static final class  extends Enum
{

    private static final Remote $VALUES[];
    public static final Remote Local;
    public static final Remote None;
    public static final Remote Remote;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/samsung/android/apex/motionphoto/composer/SemMotionPhotoComposer$Environment, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        None = new <init>("None", 0);
        Local = new <init>("Local", 1);
        Remote = new <init>("Remote", 2);
        $VALUES = (new .VALUES[] {
            None, Local, Remote
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
