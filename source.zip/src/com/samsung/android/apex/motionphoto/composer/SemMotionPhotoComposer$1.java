// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Handler;
import android.os.HandlerThread;
import com.samsung.android.apex.motionphoto.command.Reply;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

class ateHandler extends ateHandler
{

    final SemMotionPhotoComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        SemMotionPhotoComposer.access$000(SemMotionPhotoComposer.this);
        if (mContext != null)
        {
            mContext = null;
        }
        if (mComposerHandler != null)
        {
            mComposerHandler.removeCallbacksAndMessages(null);
        }
        if (mHandlerThread != null)
        {
            mHandlerThread.quit();
        }
        mComposerHandler = null;
        mHandlerThread = null;
    }

    transient ateHandler(Object aobj[])
    {
        this$0 = SemMotionPhotoComposer.this;
        super(aobj);
    }
}
