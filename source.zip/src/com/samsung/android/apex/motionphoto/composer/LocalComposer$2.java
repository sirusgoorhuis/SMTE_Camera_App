// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import com.samsung.android.apex.motionphoto.command.Reply;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            LocalComposer, SemApexRecorder

class mposer.StateHandler extends mposer.StateHandler
{

    final LocalComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        list = (mposer.Parameters)list.get(0);
        LocalComposer.access$000(LocalComposer.this).start(list.flatten());
    }

    transient mposer.Parameters(Object aobj[])
    {
        this$0 = LocalComposer.this;
        super(aobj);
    }
}
