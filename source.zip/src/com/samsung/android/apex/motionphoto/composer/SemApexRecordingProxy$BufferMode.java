// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;


// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemApexRecordingProxy

public static final class  extends Enum
{

    private static final VIDEOOUT $VALUES[];
    public static final VIDEOOUT PREVIEW;
    public static final VIDEOOUT SURFACE;
    public static final VIDEOOUT VIDEOOUT;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/samsung/android/apex/motionphoto/composer/SemApexRecordingProxy$BufferMode, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        PREVIEW = new <init>("PREVIEW", 0);
        SURFACE = new <init>("SURFACE", 1);
        VIDEOOUT = new <init>("VIDEOOUT", 2);
        $VALUES = (new .VALUES[] {
            PREVIEW, SURFACE, VIDEOOUT
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
