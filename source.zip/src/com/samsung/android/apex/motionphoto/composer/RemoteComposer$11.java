// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;


// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            RemoteComposer, State

static class 
{

    static final int $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[];

    static 
    {
        $SwitchMap$com$samsung$android$apex$motionphoto$composer$State = new int[State.values().length];
        try
        {
            $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.UNINITIALIZED.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.LOADED.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.IDLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.EXECUTING.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
