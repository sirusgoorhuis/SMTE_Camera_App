// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.content.Context;
import android.util.Log;
import com.samsung.android.apex.motionphoto.common.SemApexUtils;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer, LocalComposer, RemoteComposer

public static class 
{

    public static SemMotionPhotoComposer create(Context context)
    {
        String s = context.getPackageName();
        if (SemApexUtils.isValidLocalClient(s))
        {
            return new LocalComposer(context);
        }
        if (SemApexUtils.isValidRemoteClient(s))
        {
            return new RemoteComposer(context);
        } else
        {
            Log.w(SemMotionPhotoComposer.TAG, (new StringBuilder()).append("no suitable composer for : ").append(s).toString());
            return null;
        }
    }

    public ()
    {
    }
}
