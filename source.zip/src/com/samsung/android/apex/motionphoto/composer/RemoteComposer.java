// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.Surface;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.motionphoto.composer.utils.ConnectionManager;
import com.samsung.android.apex.motionphoto.model.SemApexStoreData;
import com.samsung.android.apex.service.IApexService;
import com.samsung.android.apex.service.IMotionPhotoComposer;
import java.lang.ref.WeakReference;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer, State

class RemoteComposer extends SemMotionPhotoComposer
    implements com.samsung.android.apex.motionphoto.composer.utils.ConnectionManager.OnConnectionListener
{
    static class ComposerListener extends com.samsung.android.apex.service.IMotionPhotoComposerListener.Stub
        implements Runnable
    {

        private static final String TAG;
        private Object mData;
        private WeakReference mOwner;

        public void notify(int i, int j, int k, Bundle bundle)
            throws RemoteException
        {
            Log.d(TAG, String.format("notify: what=%d, arg1=%d, arg2=%d", new Object[] {
                Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
            }));
            if (mOwner.get() == null)
            {
                Log.w(TAG, "composer is already released!!!");
                return;
            }
            SemMotionPhotoComposer semmotionphotocomposer = (SemMotionPhotoComposer)mOwner.get();
            switch (i)
            {
            default:
                return;

            case 3001: 
                if (semmotionphotocomposer.mOnInfoListener == null)
                {
                    Log.v(TAG, "onInfo listener is not set");
                    return;
                } else
                {
                    semmotionphotocomposer.mOnInfoListener.onInfo(j, k, 0, bundle);
                    return;
                }

            case 3002: 
                break;
            }
            if (semmotionphotocomposer.mOnErrorListener == null)
            {
                Log.v(TAG, "onError listener is not set");
                return;
            } else
            {
                semmotionphotocomposer.mOnErrorListener.onError(j, k, 0, null);
                semmotionphotocomposer.release();
                return;
            }
        }

        public void notifyAsync(int i, int j, int k, Bundle bundle)
        {
            HashMap hashmap = new HashMap();
            hashmap.put("what", Integer.valueOf(i));
            hashmap.put("arg1", Integer.valueOf(j));
            hashmap.put("arg2", Integer.valueOf(j));
            hashmap.put("data", bundle);
            mData = hashmap;
            (new Thread(this)).start();
        }

        public void run()
        {
            try
            {
                HashMap hashmap = (HashMap)mData;
                notify(((Integer)hashmap.get("what")).intValue(), ((Integer)hashmap.get("arg1")).intValue(), ((Integer)hashmap.get("arg2")).intValue(), (Bundle)hashmap.get("data"));
                return;
            }
            catch (RemoteException remoteexception)
            {
                remoteexception.printStackTrace();
            }
        }

        static 
        {
            TAG = (new StringBuilder()).append(SemMotionPhotoComposer.TAG).append("-listener").toString();
        }

        public ComposerListener(SemMotionPhotoComposer semmotionphotocomposer)
        {
            mOwner = new WeakReference(semmotionphotocomposer);
        }
    }

    private static class DeathNotifier
        implements android.os.IBinder.DeathRecipient
    {

        private static final String TAG = com/samsung/android/apex/motionphoto/composer/RemoteComposer$DeathNotifier.getSimpleName();
        private WeakReference mOwner;

        public void binderDied()
        {
            SemMotionPhotoComposer semmotionphotocomposer = (SemMotionPhotoComposer)mOwner.get();
            if (semmotionphotocomposer == null)
            {
                Log.w(TAG, "composer is null");
                return;
            } else
            {
                Log.d(semmotionphotocomposer.getTag(), "binder died");
                semmotionphotocomposer.onEvent(3002, -9985, 0, null);
                return;
            }
        }


        public DeathNotifier(SemMotionPhotoComposer semmotionphotocomposer)
        {
            mOwner = new WeakReference(semmotionphotocomposer);
        }
    }


    private static final int CMD_CONNECT = 2;
    private static final int CMD_GET_SURFACE = 8;
    private static final int CMD_SET_PARAMETERS = 6;
    private static final int CMD_START = 3;
    private static final int CMD_STOP = 5;
    private static final int CMD_STORE = 4;
    private static final String TAG;
    private ComposerListener mComposerListener;
    private android.os.IBinder.DeathRecipient mDeathNotifier;
    private IMotionPhotoComposer mRecorder;

    RemoteComposer(Context context)
    {
        super(context);
        mComposerListener = new ComposerListener(this);
        mDeathNotifier = new DeathNotifier(this);
        Log.d(getTag(), "remote-composer");
        if (ConnectionManager.getInstance().isBound())
        {
            Log.d(TAG, "Since ApexService is bound, use service");
            ConnectionManager.getInstance().setContext(context);
            ConnectionManager.getInstance().setConnectionListener(this);
            onServiceConnected(ConnectionManager.getInstance().getApex());
            return;
        } else
        {
            ConnectionManager.getInstance().init(context, this);
            return;
        }
    }

    public void connect()
        throws RemoteException
    {
        Log.d(TAG, getStateLog("connect"));
        mComposerHandler.sendEmptyMessage(2);
    }

    public void disconnect()
    {
        Log.d(TAG, getStateLog("disconnect"));
        changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.EXECUTING
        }) {

            final RemoteComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                mRecorder.stop();
            }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
        }, State.IDLE);
        changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.IDLE
        }) {

            final RemoteComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                if (mRecorder != null)
                {
                    mRecorder.disconnect();
                    mRecorder.asBinder().unlinkToDeath(mDeathNotifier, 0);
                    mRecorder = null;
                    mDeathNotifier = null;
                    mToken = -1;
                    ConnectionManager.getInstance().unbind();
                }
            }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
        }, State.LOADED);
    }

    public Surface getSurface()
        throws RemoteException
    {
        Log.d(getTag(), String.format("getSurface[%s]", new Object[] {
            mState.name()
        }));
        if (!isStateAt(State.unloaded())) goto _L2; else goto _L1
_L1:
        Log.w(getTag(), (new StringBuilder()).append("not proper state: ").append(mState.name()).toString());
_L4:
        return null;
_L2:
        Object obj;
        obj = new com.samsung.android.apex.motionphoto.command.Reply.Token();
        static class _cls11
        {

            static final int $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[];

            static 
            {
                $SwitchMap$com$samsung$android$apex$motionphoto$composer$State = new int[State.values().length];
                try
                {
                    $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.UNINITIALIZED.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.LOADED.ordinal()] = 2;
                }
                catch (NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.IDLE.ordinal()] = 3;
                }
                catch (NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$samsung$android$apex$motionphoto$composer$State[State.EXECUTING.ordinal()] = 4;
                }
                catch (NoSuchFieldError nosuchfielderror)
                {
                    return;
                }
            }
        }

        switch (_cls11..SwitchMap.com.samsung.android.apex.motionphoto.composer.State[mState.ordinal()])
        {
        default:
            mComposerHandler.sendMessage(mComposerHandler.obtainMessage(8, obj));
            break;

        case 2: // '\002'
            break; /* Loop/switch isn't completed */
        }
_L5:
        obj = ((com.samsung.android.apex.motionphoto.command.Reply.Token) (obj)).awaitResponse(2);
        if (obj != null && ((Reply) (obj)).isSuccess())
        {
            return (Surface)((Reply) (obj)).getData("surface");
        }
        if (true) goto _L4; else goto _L3
_L3:
        queueCommand(State.IDLE, mComposerHandler.obtainMessage(8, obj));
          goto _L5
        if (true) goto _L4; else goto _L6
_L6:
    }

    protected String getTag()
    {
        return TAG;
    }

    void handleMessage(Message message)
        throws RemoteException
    {
        super.handleMessage(message);
        if (!isStateAt(new State[] {
            State.UNINITIALIZED
        })) goto _L2; else goto _L1
_L1:
        Log.d(getTag(), "already released");
_L4:
        return;
_L2:
        switch (message.what)
        {
        case 7: // '\007'
        default:
            return;

        case 6: // '\006'
            continue; /* Loop/switch isn't completed */

        case 2: // '\002'
            if (changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.LOADED
}) {

        final RemoteComposer this$0;

        void onState(List list, Reply reply1)
        {
            try
            {
                mToken = mRecorder.connect();
                if (mToken < 0)
                {
                    reply1.setError(new InvalidKeyException("invalid token"));
                }
                return;
            }
            // Misplaced declaration of an exception variable
            catch (List list)
            {
                list.printStackTrace();
            }
        }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
    }, State.IDLE).isSuccess() && mComposerListener != null)
            {
                mComposerListener.notifyAsync(10006, mToken, 0, null);
                return;
            }
            break;

        case 3: // '\003'
            changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
                State.IDLE, message.obj
            }) {

                final RemoteComposer this$0;

                void onState(List list, Reply reply1)
                    throws RemoteException
                {
                    mRecorder.start((String)list.get(0));
                }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
            }, State.EXECUTING);
            return;

        case 4: // '\004'
            message = (com.samsung.android.apex.motionphoto.command.Reply.Token)message.obj;
            if (!doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.EXECUTING, message
}) {

        final RemoteComposer this$0;

        void onState(List list, Reply reply1)
            throws Exception
        {
            com.samsung.android.apex.motionphoto.command.Reply.Token token = (com.samsung.android.apex.motionphoto.command.Reply.Token)list.get(0);
            reply1 = (SemApexStoreData)token.getData();
            list = reply1;
            if (reply1 == null)
            {
                list = new SemApexStoreData();
            }
            token.respond(new Reply("id", Long.valueOf(mRecorder.store(list.toBundle()))));
        }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
    }).isSuccess())
            {
                message.respond(new Reply("id", Long.valueOf(-1L)));
                return;
            }
            break;

        case 8: // '\b'
            Reply reply = doStateIf(new SemMotionPhotoComposer.StateHandler(State.connected()) {

                final RemoteComposer this$0;

                void onState(List list, Reply reply1)
                    throws Exception
                {
                    reply1.setData("surface", mRecorder.getSurface());
                }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
            });
            ((com.samsung.android.apex.motionphoto.command.Reply.Token)message.obj).respond(reply);
            return;

        case 5: // '\005'
            changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
                State.EXECUTING
            }) {

                final RemoteComposer this$0;

                public void onState(List list, Reply reply1)
                {
                    try
                    {
                        mRecorder.stop();
                        return;
                    }
                    // Misplaced declaration of an exception variable
                    catch (List list)
                    {
                        list.printStackTrace();
                    }
                }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
            }, State.IDLE);
            return;
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (!isConnected()) goto _L4; else goto _L5
_L5:
        mRecorder.setParameters((String)message.obj);
        return;
    }

    public boolean isConnected()
    {
        return isStateAt(State.connected());
    }

    public void onEvent(int i, int j, int k, Object obj)
    {
        if (j == -9984)
        {
            changeState(State.ERROR);
        }
        super.onEvent(i, j, k, obj);
    }

    public void onServiceConnected(IApexService iapexservice)
    {
        Log.d(TAG, getStateLog("service is connected successfully"));
        if (!doStateIfNot(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.UNINITIALIZED, iapexservice
}) {

        final RemoteComposer this$0;

        void onState(List list, Reply reply)
            throws Exception
        {
            list = (IApexService)list.get(0);
            mRecorder = list.getMotionPhotoComposer(mComposerListener);
            if (mRecorder != null)
            {
                mRecorder.asBinder().linkToDeath(mDeathNotifier, 0);
                connect();
                return;
            } else
            {
                Log.e(getTag(), "recorder is null, try release");
                release();
                return;
            }
        }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
    }).isSuccess() && isStateAt(new State[] {
    State.UNINITIALIZED
}))
        {
            Log.d(getTag(), "but composer is released, try unbind");
            ConnectionManager.getInstance().unbind();
        }
    }

    public void onServiceDisconnected()
    {
        Log.d(TAG, getStateLog("unwanted disconnection with ApexService"));
        release();
    }

    public void release()
    {
        Log.d(TAG, getStateLog("release"));
        super.release();
        mComposerListener = null;
    }

    public void setParameters(SemMotionPhotoComposer.Parameters parameters)
        throws RemoteException, IllegalStateException
    {
        Log.d(getTag(), String.format("setParameters[%s]", new Object[] {
            mState.name()
        }));
        if (isStateAt(State.unloaded()))
        {
            Log.w(getTag(), (new StringBuilder()).append("not proper state: ").append(mState.name()).toString());
            return;
        }
        switch (_cls11..SwitchMap.com.samsung.android.apex.motionphoto.composer.State[mState.ordinal()])
        {
        default:
            mComposerHandler.sendMessage(mComposerHandler.obtainMessage(6, parameters.flatten()));
            return;

        case 2: // '\002'
            queueCommand(State.IDLE, mComposerHandler.obtainMessage(6, parameters.flatten()));
            break;
        }
    }

    public void setStoreData(Bundle bundle)
        throws RemoteException, IllegalStateException
    {
        if (!doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.connected(), bundle
}) {

        final RemoteComposer this$0;

        void onState(List list, Reply reply)
            throws Exception
        {
            list = (Bundle)list.get(0);
            Log.d(getTag(), getStateLog((new StringBuilder()).append("SemApexStoreData: data=%s").append(list.toString()).toString()));
            mRecorder.setStoreData(list);
        }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
    }).isSuccess() && isStateAt(State.disconnected()))
        {
            Log.d(getTag(), "ignore after release or in error state");
            if (mComposerListener != null)
            {
                bundle.putLong("id", -1L);
                mComposerListener.notifyAsync(3001, 10011, 0, bundle);
            }
        }
    }

    public void setStorePath(long l, String s)
        throws RemoteException
    {
        Log.d(getTag(), String.format("setStorePath[%s]: id=%d, path=%s", new Object[] {
            mState.name(), Long.valueOf(l), s
        }));
        if (l >= 0L)
        {
            doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
                State.EXECUTING, Long.valueOf(l), s
            }) {

                final RemoteComposer this$0;

                void onState(List list, Reply reply)
                    throws Exception
                {
                    long l1 = ((Long)list.get(0)).longValue();
                    list = (String)list.get(1);
                    list = new SemApexStoreData(l1, mToken, list);
                    mRecorder.setStoreData(list.toBundle());
                }

            transient 
            {
                this$0 = RemoteComposer.this;
                super(aobj);
            }
            });
            return;
        } else
        {
            Log.d(getTag(), (new StringBuilder()).append("invalid id: ").append(l).toString());
            return;
        }
    }

    public void start(SemMotionPhotoComposer.Parameters parameters)
        throws RemoteException
    {
        Log.d(getTag(), getStateLog((new StringBuilder()).append("start, ").append(parameters.flatten()).toString()));
        removeCommand(State.EXECUTING, 5);
        switch (_cls11..SwitchMap.com.samsung.android.apex.motionphoto.composer.State[mState.ordinal()])
        {
        default:
            Log.e(getTag(), getStateLog("can not handle"));
            return;

        case 1: // '\001'
            Log.d(getTag(), "ignore after release");
            return;

        case 2: // '\002'
            queueCommand(State.IDLE, mComposerHandler.obtainMessage(3, parameters.flatten()));
            return;

        case 3: // '\003'
            mComposerHandler.sendMessage(mComposerHandler.obtainMessage(3, parameters.flatten()));
            return;

        case 4: // '\004'
            Log.v(getTag(), "already started");
            break;
        }
    }

    public void stop()
        throws RemoteException
    {
        Log.d(getTag(), String.format("stop[%s]", new Object[] {
            mState.name()
        }));
        removeCommand(State.IDLE, 3);
        _cls11..SwitchMap.com.samsung.android.apex.motionphoto.composer.State[mState.ordinal()];
        JVM INSTR tableswitch 1 4: default 80
    //                   1 96
    //                   2 108
    //                   3 108
    //                   4 135;
           goto _L1 _L2 _L3 _L3 _L4
_L1:
        Log.e(getTag(), getStateLog("can not handle"));
_L6:
        return;
_L2:
        Log.d(getTag(), "ignore after release");
        return;
_L3:
        if (removeCommand(State.IDLE, 3)) goto _L6; else goto _L5
_L5:
        queueCommand(State.EXECUTING, mComposerHandler.obtainMessage(5));
        return;
_L4:
        mComposerHandler.sendEmptyMessage(5);
        return;
    }

    public long store()
        throws RemoteException
    {
        Log.d(getTag(), String.format("store[%s]", new Object[] {
            mState.name()
        }));
        return store(((SemApexStoreData) (null)));
    }

    public long store(int i)
        throws RemoteException
    {
        SemApexStoreData semapexstoredata = new SemApexStoreData();
        semapexstoredata.setRotation(i);
        return store(semapexstoredata);
    }

    public long store(int i, long l)
        throws RemoteException, IllegalStateException
    {
        SemApexStoreData semapexstoredata = new SemApexStoreData();
        semapexstoredata.setRotation(i);
        semapexstoredata.setTimestamp(l);
        return store(semapexstoredata);
    }

    public long store(SemApexStoreData semapexstoredata)
        throws RemoteException
    {
        String s = getTag();
        String s1 = mState.name();
        Object obj;
        if (semapexstoredata != null)
        {
            obj = semapexstoredata;
        } else
        {
            obj = "null";
        }
        Log.d(s, String.format("store[%s]: %s", new Object[] {
            s1, obj
        }));
        if (semapexstoredata == null)
        {
            semapexstoredata = new com.samsung.android.apex.motionphoto.command.Reply.Token();
        } else
        {
            semapexstoredata = new com.samsung.android.apex.motionphoto.command.Reply.Token(semapexstoredata);
        }
        switch (_cls11..SwitchMap.com.samsung.android.apex.motionphoto.composer.State[mState.ordinal()])
        {
        default:
            Log.e(getTag(), getStateLog("can not handle"));
            return -1L;

        case 4: // '\004'
            break MISSING_BLOCK_LABEL_207;

        case 2: // '\002'
        case 3: // '\003'
            if (!mComposerHandler.hasMessages(3))
            {
                Log.e(getTag(), getStateLog("invalid store call, already stopped"));
                return -1L;
            }
            queueCommand(State.EXECUTING, mComposerHandler.obtainMessage(4, semapexstoredata));
            break;
        }
_L1:
        semapexstoredata = semapexstoredata.awaitResponse(3);
        if (semapexstoredata != null && semapexstoredata.isSuccess())
        {
            return ((Long)semapexstoredata.getData("id")).longValue();
        } else
        {
            Log.e(getTag(), "for 3s, store is not finished");
            return -1L;
        }
        mComposerHandler.sendMessage(mComposerHandler.obtainMessage(4, semapexstoredata));
          goto _L1
    }

    static 
    {
        TAG = (new StringBuilder()).append(SemMotionPhotoComposer.TAG).append("-remote").toString();
    }



/*
    static IMotionPhotoComposer access$002(RemoteComposer remotecomposer, IMotionPhotoComposer imotionphotocomposer)
    {
        remotecomposer.mRecorder = imotionphotocomposer;
        return imotionphotocomposer;
    }

*/




/*
    static android.os.IBinder.DeathRecipient access$202(RemoteComposer remotecomposer, android.os.IBinder.DeathRecipient deathrecipient)
    {
        remotecomposer.mDeathNotifier = deathrecipient;
        return deathrecipient;
    }

*/
}
