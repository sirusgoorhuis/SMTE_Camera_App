// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import com.samsung.android.apex.motionphoto.command.Reply;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer, State

protected static abstract class mDatas
{

    private ArrayList mDatas;
    private ArrayList mStates;

    boolean contains(State state)
    {
        return mStates.contains(state);
    }

    ArrayList getStates()
    {
        return mStates;
    }

    abstract void onState(List list, Reply reply)
        throws Exception;


    transient (Object aobj[])
    {
        mStates = new ArrayList();
        int j = 0;
        int i = 0;
        do
        {
            if (i >= aobj.length)
            {
                break;
            }
            if (aobj[i] instanceof State)
            {
                i++;
                continue;
            }
            if (!(aobj[i] instanceof State[]))
            {
                break;
            }
            mStates.addAll(Arrays.asList(Arrays.copyOfRange(aobj, j, i)));
            mStates.addAll(Arrays.asList((State[])(State[])aobj[i]));
            i++;
            j = i;
        } while (true);
        mStates.addAll(Arrays.asList(Arrays.copyOfRange(aobj, j, i)));
        mDatas = new ArrayList(Arrays.asList(Arrays.copyOfRange(aobj, i, aobj.length)));
    }
}
