// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.IBinder;
import android.util.Log;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.service.IApexService;
import com.samsung.android.apex.service.IMotionPhotoComposer;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            RemoteComposer

class poser.StateHandler extends poser.StateHandler
{

    final RemoteComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        list = (IApexService)list.get(0);
        RemoteComposer.access$002(RemoteComposer.this, list.getMotionPhotoComposer(RemoteComposer.access$100(RemoteComposer.this)));
        if (RemoteComposer.access$000(RemoteComposer.this) != null)
        {
            RemoteComposer.access$000(RemoteComposer.this).asBinder().linkToDeath(RemoteComposer.access$200(RemoteComposer.this), 0);
            connect();
            return;
        } else
        {
            Log.e(getTag(), "recorder is null, try release");
            release();
            return;
        }
    }

    transient poser.StateHandler(Object aobj[])
    {
        this$0 = RemoteComposer.this;
        super(aobj);
    }
}
