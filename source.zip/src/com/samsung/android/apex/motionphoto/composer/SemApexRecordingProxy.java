// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.util.Log;
import java.nio.ByteBuffer;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemApexRecorderListener

public class SemApexRecordingProxy
{
    public static final class BufferMode extends Enum
    {

        private static final BufferMode $VALUES[];
        public static final BufferMode PREVIEW;
        public static final BufferMode SURFACE;
        public static final BufferMode VIDEOOUT;

        public static BufferMode valueOf(String s)
        {
            return (BufferMode)Enum.valueOf(com/samsung/android/apex/motionphoto/composer/SemApexRecordingProxy$BufferMode, s);
        }

        public static BufferMode[] values()
        {
            return (BufferMode[])$VALUES.clone();
        }

        static 
        {
            PREVIEW = new BufferMode("PREVIEW", 0);
            SURFACE = new BufferMode("SURFACE", 1);
            VIDEOOUT = new BufferMode("VIDEOOUT", 2);
            $VALUES = (new BufferMode[] {
                PREVIEW, SURFACE, VIDEOOUT
            });
        }

        private BufferMode(String s, int i)
        {
            super(s, i);
        }
    }


    private static final String TAG = com/samsung/android/apex/motionphoto/composer/SemApexRecordingProxy.getSimpleName();
    private SemApexRecorderListener mListener;
    private long mNativeContext;
    private int mToken;

    public SemApexRecordingProxy(int i)
    {
        Log.d(TAG, (new StringBuilder()).append("token: ").append(i).toString());
        native_setup(null, i, "preview");
        mToken = i;
    }

    public SemApexRecordingProxy(int i, BufferMode buffermode)
    {
        Log.d(TAG, (new StringBuilder()).append("token: ").append(i).toString());
        if (buffermode == BufferMode.PREVIEW)
        {
            buffermode = "preview";
        } else
        if (buffermode == BufferMode.VIDEOOUT)
        {
            buffermode = "video-out";
        } else
        {
            buffermode = "surface";
        }
        native_setup(null, i, buffermode);
        mToken = i;
    }

    public SemApexRecordingProxy(SemApexRecorderListener semapexrecorderlistener, int i)
    {
        Log.d(TAG, (new StringBuilder()).append("token: ").append(i).toString());
        native_setup(semapexrecorderlistener, i, "preview");
        mToken = i;
    }

    public SemApexRecordingProxy(SemApexRecorderListener semapexrecorderlistener, int i, BufferMode buffermode)
    {
        Log.d(TAG, (new StringBuilder()).append("token: ").append(i).toString());
        if (buffermode == BufferMode.PREVIEW)
        {
            buffermode = "preview";
        } else
        if (buffermode == BufferMode.VIDEOOUT)
        {
            buffermode = "video-out";
        } else
        {
            buffermode = "surface";
        }
        native_setup(semapexrecorderlistener, i, buffermode);
        mToken = i;
    }

    private final native int native_connect();

    private final native int native_dequeBuffer();

    private final native void native_finalize();

    private final native ByteBuffer native_getBuffer(int i);

    private static final native void native_init();

    private final native void native_queueBuffer(int i, long l, int j);

    private final native int native_queueBuffer2(ByteBuffer bytebuffer, int i, int j, long l);

    private final native int native_setup(Object obj, int i, String s);

    public int connect()
    {
        return native_connect();
    }

    public int dequeuBuffer()
    {
        return native_dequeBuffer();
    }

    public ByteBuffer getBuffer(int i)
    {
        return native_getBuffer(i);
    }

    public void queueBuffer(int i, int j, long l)
    {
        native_queueBuffer(i, l, j);
    }

    public boolean queueBuffer(ByteBuffer bytebuffer, int i, long l)
    {
        bytebuffer.rewind();
        return native_queueBuffer2(bytebuffer, bytebuffer.remaining(), i, l) == 0;
    }

    public void release()
    {
        native_finalize();
    }

    static 
    {
        System.loadLibrary("apex_jni");
        native_init();
    }
}
