// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Looper;
import android.util.Log;
import com.samsung.android.apex.motionphoto.SemApexClientEventHandler;
import java.lang.ref.WeakReference;

public class SemApexRecorderListener
{

    private static final String TAG = com/samsung/android/apex/motionphoto/composer/SemApexRecorderListener.getSimpleName();
    private SemApexClientEventHandler mEventHandler;
    private long mNativeContext;

    public SemApexRecorderListener()
    {
        Log.d(TAG, "SemApexRecorderListener");
        Looper looper = Looper.myLooper();
        if (looper != null)
        {
            mEventHandler = new SemApexClientEventHandler(looper);
        } else
        {
            Looper looper1 = Looper.getMainLooper();
            if (looper1 != null)
            {
                mEventHandler = new SemApexClientEventHandler(looper1);
            } else
            {
                mEventHandler = null;
            }
        }
        native_setup(new WeakReference(this));
    }

    private final native void native_finalize();

    private static final native void native_init();

    private final native void native_setup(Object obj);

    private static void postEventFromNative(Object obj, int i, int j, int k, Object obj1)
    {
        Log.d(TAG, String.format("postEventFromNative: %d, %d, %d", new Object[] {
            Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
        }));
        for (obj = (SemApexRecorderListener)((WeakReference)obj).get(); obj == null || ((SemApexRecorderListener) (obj)).mEventHandler == null;)
        {
            return;
        }

        obj1 = ((SemApexRecorderListener) (obj)).mEventHandler.obtainMessage(i, j, k, obj1);
        ((SemApexRecorderListener) (obj)).mEventHandler.sendMessage(((android.os.Message) (obj1)));
    }

    public void release()
    {
        Log.d(TAG, "release");
        mEventHandler.removeCallbacksAndMessages(null);
        mEventHandler = null;
        setOnInfoListener(null);
        setOnErrorListener(null);
        native_finalize();
    }

    public void setOnErrorListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener onerrorlistener)
    {
        Log.d(TAG, "setOnErrorListener");
        if (mEventHandler != null)
        {
            mEventHandler.setOnErrorListener(onerrorlistener);
        }
    }

    public void setOnInfoListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener oninfolistener)
    {
        Log.d(TAG, "setOnErrorListener");
        if (mEventHandler != null)
        {
            mEventHandler.setOnInfoListener(oninfolistener);
        }
    }

    public void setToken(int i)
    {
        Log.d(TAG, "setToken");
        if (mEventHandler != null)
        {
            mEventHandler.setToken(i);
        }
    }

    static 
    {
        System.loadLibrary("apex_jni");
        native_init();
    }
}
