// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.RemoteException;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.service.IMotionPhotoComposer;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            RemoteComposer

class oser.StateHandler extends oser.StateHandler
{

    final RemoteComposer this$0;

    public void onState(List list, Reply reply)
    {
        try
        {
            RemoteComposer.access$000(RemoteComposer.this).stop();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (List list)
        {
            list.printStackTrace();
        }
    }

    transient oser.StateHandler(Object aobj[])
    {
        this$0 = RemoteComposer.this;
        super(aobj);
    }
}
