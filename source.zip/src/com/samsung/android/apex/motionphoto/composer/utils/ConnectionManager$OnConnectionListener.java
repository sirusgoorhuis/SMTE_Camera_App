// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer.utils;

import com.samsung.android.apex.service.IApexService;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer.utils:
//            ConnectionManager

public static interface 
{

    public abstract void onServiceConnected(IApexService iapexservice);

    public abstract void onServiceDisconnected();
}
