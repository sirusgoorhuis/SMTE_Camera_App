// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import com.samsung.android.apex.motionphoto.command.Reply;
import java.security.InvalidKeyException;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            LocalComposer, SemApexRecorderListener, SemApexRecorder

class mposer.StateHandler extends mposer.StateHandler
{

    final LocalComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        SemApexRecorderListener semapexrecorderlistener = new SemApexRecorderListener();
        LocalComposer.access$002(LocalComposer.this, new SemApexRecorder(semapexrecorderlistener));
        mToken = LocalComposer.access$000(LocalComposer.this).getToken();
        if (mToken < 0)
        {
            throw new InvalidKeyException((new StringBuilder()).append("invalid token: ").append(mToken).toString());
        }
        LocalComposer.access$000(LocalComposer.this).setInfoListener((com.samsung.android.apex.motionphoto.ntHandler.OnInfoListener)list.get(0));
        LocalComposer.access$000(LocalComposer.this).setErrorListener((com.samsung.android.apex.motionphoto.ntHandler.OnErrorListener)list.get(0));
        if (mEventCbListener == null)
        {
            throw new IllegalStateException("request eventHandler should be set(ex: SimplRequestHandler)");
        } else
        {
            LocalComposer.access$102(LocalComposer.this, true);
            reply.setData("listener", semapexrecorderlistener);
            return;
        }
    }

    transient .OnErrorListener(Object aobj[])
    {
        this$0 = LocalComposer.this;
        super(aobj);
    }
}
