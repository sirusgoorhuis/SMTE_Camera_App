// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;
import android.view.Surface;
import com.samsung.android.apex.motionphoto.SemApexCallbackListener;
import com.samsung.android.apex.motionphoto.SemApexParameters;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.motionphoto.common.SemApexUtils;
import com.samsung.android.apex.motionphoto.model.SemApexStoreData;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.ReentrantReadWriteLock;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemApexDummyCallbackListener, State, LocalComposer, RemoteComposer

public abstract class SemMotionPhotoComposer
{
    protected static class ComposerHandler extends Handler
    {

        private SemMotionPhotoComposer mComposer;

        public void handleMessage(Message message)
        {
            try
            {
                mComposer.handleMessage(message);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Message message)
            {
                message.printStackTrace();
            }
        }

        public ComposerHandler(SemMotionPhotoComposer semmotionphotocomposer, Looper looper)
        {
            super(looper);
            mComposer = semmotionphotocomposer;
        }
    }

    private static final class Environment extends Enum
    {

        private static final Environment $VALUES[];
        public static final Environment Local;
        public static final Environment None;
        public static final Environment Remote;

        public static Environment valueOf(String s)
        {
            return (Environment)Enum.valueOf(com/samsung/android/apex/motionphoto/composer/SemMotionPhotoComposer$Environment, s);
        }

        public static Environment[] values()
        {
            return (Environment[])$VALUES.clone();
        }

        static 
        {
            None = new Environment("None", 0);
            Local = new Environment("Local", 1);
            Remote = new Environment("Remote", 2);
            $VALUES = (new Environment[] {
                None, Local, Remote
            });
        }

        private Environment(String s, int i)
        {
            super(s, i);
        }
    }

    public static class Factory
    {

        public static SemMotionPhotoComposer create(Context context)
        {
            String s = context.getPackageName();
            if (SemApexUtils.isValidLocalClient(s))
            {
                return new LocalComposer(context);
            }
            if (SemApexUtils.isValidRemoteClient(s))
            {
                return new RemoteComposer(context);
            } else
            {
                Log.w(SemMotionPhotoComposer.TAG, (new StringBuilder()).append("no suitable composer for : ").append(s).toString());
                return null;
            }
        }

        public Factory()
        {
        }
    }

    public static interface OnErrorListener
        extends com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener
    {
    }

    public static interface OnInfoListener
        extends com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener
    {
    }

    public static final class Parameters extends SemApexParameters
    {

        private static final String BUFFERING_BACK = "back";
        private static final String BUFFERING_FRONT = "front";
        private static final String EFFECT_OFF = "off";
        private static final String EFFECT_ON = "on";

        private Parameters()
        {
        }


        private Parameters(String s)
        {
            unflatten(s);
        }
    }

    public static final class Parameters.Builder
    {

        private String mFlattenParam;
        private HashMap mMap;

        public Parameters build()
        {
            Parameters parameters = new Parameters();
            if (mFlattenParam != null)
            {
                parameters.unflatten(mFlattenParam);
            }
            parameters.put(mMap);
            if (parameters.get("buffering-mode") == null)
            {
                parameters.set("buffering-mode", "front");
            }
            if ("on".equals(parameters.get("effect-mode")))
            {
                parameters.set("preview-format", "android-opaque");
            }
            return parameters;
        }

        public Parameters.Builder set(String s, Object obj)
        {
            mMap.put(s, obj);
            return this;
        }

        public Parameters.Builder setAllocPreviewBuffer(boolean flag)
        {
            mMap.put("alloc-preview-buffer", Boolean.valueOf(flag));
            return this;
        }

        public Parameters.Builder setBufferingMode(boolean flag)
        {
            HashMap hashmap = mMap;
            String s;
            if (flag)
            {
                s = "front";
            } else
            {
                s = "back";
            }
            hashmap.put("buffering-mode", s);
            return this;
        }

        public Parameters.Builder setDuration(int i)
        {
            mMap.put("duration", Integer.valueOf(i));
            return this;
        }

        public Parameters.Builder setEffectRecording(boolean flag)
        {
            HashMap hashmap = mMap;
            String s;
            if (flag)
            {
                s = "on";
            } else
            {
                s = "off";
            }
            hashmap.put("effect-mode", s);
            return this;
        }

        public Parameters.Builder setFlattenParameter(String s)
        {
            mFlattenParam = s;
            return this;
        }

        public Parameters.Builder setFpsFactor(int i)
        {
            mMap.put("fps-factor", Integer.valueOf(i));
            return this;
        }

        public Parameters.Builder setPreviewFpsRange(int ai[])
        {
            mMap.put("fps-range", ai);
            return this;
        }

        public Parameters.Builder setPreviewSize(int i, int j)
        {
            mMap.put("preview-size", (new StringBuilder()).append(i).append("x").append(j).toString());
            return this;
        }

        public Parameters.Builder setPreviewSize(String s)
        {
            mMap.put("preview-size", s);
            return this;
        }

        public Parameters.Builder setRecordDuration(int i)
        {
            mMap.put("duration", Integer.valueOf(i));
            return this;
        }

        public Parameters.Builder setSaveAsFlipped(boolean flag)
        {
            mMap.put("save-as-flipped", Boolean.valueOf(flag));
            return this;
        }

        public Parameters.Builder setToken(int i)
        {
            mMap.put("token", Integer.valueOf(i));
            return this;
        }

        public Parameters.Builder setUseIntrinsicTimestamp(boolean flag)
        {
            mMap.put("use-intrinsic-timestamp", Boolean.valueOf(flag));
            return this;
        }

        public Parameters.Builder setUseProxyStoretime(boolean flag)
        {
            mMap.put("use-proxy-storetime", Boolean.valueOf(flag));
            return this;
        }

        public Parameters.Builder setVideoFrameRate(int i)
        {
            mMap.put("frame-rate", Integer.valueOf(i));
            return this;
        }

        public Parameters.Builder()
        {
            mMap = new HashMap();
        }
    }

    protected static abstract class StateHandler
    {

        private ArrayList mDatas;
        private ArrayList mStates;

        boolean contains(State state)
        {
            return mStates.contains(state);
        }

        ArrayList getStates()
        {
            return mStates;
        }

        abstract void onState(List list, Reply reply)
            throws Exception;


        transient StateHandler(Object aobj[])
        {
            mStates = new ArrayList();
            int j = 0;
            int i = 0;
            do
            {
                if (i >= aobj.length)
                {
                    break;
                }
                if (aobj[i] instanceof State)
                {
                    i++;
                    continue;
                }
                if (!(aobj[i] instanceof State[]))
                {
                    break;
                }
                mStates.addAll(Arrays.asList(Arrays.copyOfRange(aobj, j, i)));
                mStates.addAll(Arrays.asList((State[])(State[])aobj[i]));
                i++;
                j = i;
            } while (true);
            mStates.addAll(Arrays.asList(Arrays.copyOfRange(aobj, j, i)));
            mDatas = new ArrayList(Arrays.asList(Arrays.copyOfRange(aobj, i, aobj.length)));
        }
    }


    static final boolean $assertionsDisabled;
    public static final String TAG = com/samsung/android/apex/motionphoto/composer/SemMotionPhotoComposer.getSimpleName();
    protected int mApiLevel;
    protected String mClientId;
    protected SparseArray mCommandQueue;
    protected Handler mComposerHandler;
    protected WeakReference mContext;
    private Environment mEnvironment;
    protected SemApexCallbackListener mEventCbListener;
    protected HandlerThread mHandlerThread;
    protected ReentrantReadWriteLock mLock;
    protected OnErrorListener mOnErrorListener;
    protected OnInfoListener mOnInfoListener;
    protected State mState;
    protected int mToken;

    SemMotionPhotoComposer(Context context)
    {
        mEnvironment = Environment.None;
        mLock = new ReentrantReadWriteLock();
        Log.d(getTag(), (new StringBuilder()).append("SemMotionPhotoComposer: ").append(context).toString());
        mContext = new WeakReference(context);
        mHandlerThread = new HandlerThread(getTag());
        mHandlerThread.start();
        mComposerHandler = new ComposerHandler(this, mHandlerThread.getLooper());
        mCommandQueue = new SparseArray();
        mEventCbListener = new SemApexDummyCallbackListener(this);
        mState = State.LOADED;
    }

    private void removeAllCommands()
    {
        if (mCommandQueue == null)
        {
            return;
        }
        for (int i = 0; i < mCommandQueue.size(); i++)
        {
            ((ConcurrentLinkedQueue)mCommandQueue.valueAt(i)).clear();
        }

        mCommandQueue.clear();
    }

    public void changeState(State state)
    {
        mLock.writeLock().lock();
        if (mState != State.UNINITIALIZED)
        {
            break MISSING_BLOCK_LABEL_41;
        }
        Log.d(getTag(), "changeState: ignore already released");
        mLock.writeLock().unlock();
        return;
        Log.d(getTag(), (new StringBuilder()).append("changeState: ").append(mState.name()).append(" -> ").append(state.name()).toString());
        mState = state;
        handleCommand(state);
        mLock.writeLock().unlock();
        return;
        state;
        mLock.writeLock().unlock();
        throw state;
    }

    public Reply changeStateIf(StateHandler statehandler, State state)
    {
        Reply reply;
        mLock.writeLock().lock();
        reply = null;
        if (mState != State.UNINITIALIZED) goto _L2; else goto _L1
_L1:
        statehandler = new Reply("already released, ignore this");
_L4:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (!statehandler.contains(mState))
        {
            statehandler = new Reply((new StringBuilder()).append("state is at ").append(mState).append(", not at ").append(statehandler.getStates()).append(", ignore this").toString());
            continue; /* Loop/switch isn't completed */
        }
        Reply reply1 = new Reply(true);
        reply = reply1;
        statehandler.onState(statehandler.mDatas, reply1);
        reply = reply1;
        Log.d(getTag(), (new StringBuilder()).append("changeState: ").append(mState.name()).append(" -> ").append(state.name()).toString());
        reply = reply1;
        mState = state;
        reply = reply1;
        handleCommand(mState);
        statehandler = reply1;
        if (true) goto _L4; else goto _L3
_L3:
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        return statehandler;
        statehandler;
        reply1 = null;
_L8:
        reply = reply1;
        statehandler.printStackTrace();
        reply = reply1;
        statehandler = new Reply(statehandler);
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        return statehandler;
        state;
        statehandler = reply;
_L6:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        throw state;
        state;
        statehandler = reply;
        if (true) goto _L6; else goto _L5
_L5:
        statehandler;
        if (true) goto _L8; else goto _L7
_L7:
    }

    public Reply changeStateIfNot(StateHandler statehandler, State state)
    {
        Reply reply;
        mLock.writeLock().lock();
        reply = null;
        if (mState != State.UNINITIALIZED) goto _L2; else goto _L1
_L1:
        statehandler = new Reply("ignore already released");
_L4:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (statehandler.contains(mState))
        {
            statehandler = new Reply((new StringBuilder()).append("state is in ").append(statehandler.getStates()).append(", do nothing").toString());
            continue; /* Loop/switch isn't completed */
        }
        Reply reply1 = new Reply(true);
        reply = reply1;
        statehandler.onState(statehandler.mDatas, reply1);
        reply = reply1;
        Log.d(getTag(), (new StringBuilder()).append("changeState: ").append(mState.name()).append(" -> ").append(state.name()).toString());
        reply = reply1;
        mState = state;
        reply = reply1;
        handleCommand(mState);
        statehandler = reply1;
        if (true) goto _L4; else goto _L3
_L3:
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        return statehandler;
        statehandler;
        reply1 = null;
_L8:
        reply = reply1;
        statehandler.printStackTrace();
        reply = reply1;
        statehandler = new Reply(statehandler);
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        return statehandler;
        state;
        statehandler = reply;
_L6:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.writeLock().unlock();
        throw state;
        state;
        statehandler = reply;
        if (true) goto _L6; else goto _L5
_L5:
        statehandler;
        if (true) goto _L8; else goto _L7
_L7:
    }

    protected transient void checkState(State astate[])
        throws IllegalStateException
    {
        boolean flag;
        flag = false;
        mLock.readLock().lock();
        int j = astate.length;
        int i = 0;
_L2:
        Object obj;
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        obj = astate[i];
        State state = mState;
        if (state == obj)
        {
            mLock.readLock().unlock();
            return;
        }
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        obj = new StringBuffer();
        j = astate.length;
        i = ((flag) ? 1 : 0);
_L4:
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        ((StringBuffer) (obj)).append(astate[i]);
        ((StringBuffer) (obj)).append(", ");
        i++;
        if (true) goto _L4; else goto _L3
_L3:
        ((StringBuffer) (obj)).deleteCharAt(((StringBuffer) (obj)).length() - 1);
        throw new IllegalStateException(String.format("should be in %s state, but current is %s", new Object[] {
            ((StringBuffer) (obj)).toString(), mState
        }));
        astate;
        mLock.readLock().unlock();
        throw astate;
    }

    public abstract void connect()
        throws RemoteException, IllegalStateException;

    public abstract void disconnect()
        throws RemoteException, IllegalStateException;

    public Reply doStateIf(StateHandler statehandler)
    {
        Object obj1;
        mLock.readLock().lock();
        obj1 = null;
        if (!statehandler.contains(mState)) goto _L2; else goto _L1
_L1:
        Reply reply = new Reply(true);
        Object obj = reply;
        statehandler.onState(statehandler.mDatas, reply);
_L4:
        if (!$assertionsDisabled && reply == null)
        {
            throw new AssertionError();
        }
        break; /* Loop/switch isn't completed */
_L2:
        reply = new Reply(getStateLog((new StringBuilder()).append("state is not ").append(statehandler.getStates()).toString()));
        if (true) goto _L4; else goto _L3
_L3:
        if (!reply.isSuccess())
        {
            reply.printMessage(getTag());
        }
        mLock.readLock().unlock();
        return reply;
        statehandler;
        reply = null;
_L8:
        obj = reply;
        statehandler.printStackTrace();
        obj = reply;
        statehandler = new Reply(statehandler);
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.readLock().unlock();
        return statehandler;
        obj;
        statehandler = obj1;
_L6:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.readLock().unlock();
        throw obj;
        Exception exception;
        exception;
        statehandler = ((StateHandler) (obj));
        obj = exception;
        if (true) goto _L6; else goto _L5
_L5:
        statehandler;
        if (true) goto _L8; else goto _L7
_L7:
    }

    public Reply doStateIfNot(StateHandler statehandler)
    {
        Object obj1;
        mLock.readLock().lock();
        obj1 = null;
        if (statehandler.contains(mState)) goto _L2; else goto _L1
_L1:
        Reply reply = new Reply(true);
        Object obj = reply;
        statehandler.onState(statehandler.mDatas, reply);
_L4:
        if (!$assertionsDisabled && reply == null)
        {
            throw new AssertionError();
        }
        break; /* Loop/switch isn't completed */
_L2:
        reply = new Reply((new StringBuilder()).append("state is in ").append(statehandler.getStates()).append(", do nothing ").toString());
        if (true) goto _L4; else goto _L3
_L3:
        if (!reply.isSuccess())
        {
            reply.printMessage(getTag());
        }
        mLock.readLock().unlock();
        return reply;
        statehandler;
        reply = null;
_L8:
        obj = reply;
        statehandler.printStackTrace();
        obj = reply;
        statehandler = new Reply(statehandler);
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.readLock().unlock();
        return statehandler;
        obj;
        statehandler = obj1;
_L6:
        if (!$assertionsDisabled && statehandler == null)
        {
            throw new AssertionError();
        }
        if (!statehandler.isSuccess())
        {
            statehandler.printMessage(getTag());
        }
        mLock.readLock().unlock();
        throw obj;
        Exception exception;
        exception;
        statehandler = ((StateHandler) (obj));
        obj = exception;
        if (true) goto _L6; else goto _L5
_L5:
        statehandler;
        if (true) goto _L8; else goto _L7
_L7:
    }

    public int getApiLevel()
    {
        return mApiLevel;
    }

    public String getClientId()
    {
        return mClientId;
    }

    protected String getStateLog(String s)
    {
        return String.format("[%s]%s", new Object[] {
            mState.name(), s
        });
    }

    public abstract Surface getSurface()
        throws RemoteException, IllegalStateException;

    protected abstract String getTag();

    public int getToken()
    {
        return mToken;
    }

    protected void handleCommand(State state)
    {
        if (mState == State.UNINITIALIZED)
        {
            Log.d(getTag(), "handleCommand : ignore already released");
        }
        if (mCommandQueue != null) goto _L2; else goto _L1
_L1:
        Log.d(getTag(), "can not handle command");
_L4:
        return;
_L2:
        state = (ConcurrentLinkedQueue)mCommandQueue.get(state.ordinal());
        if (state != null)
        {
            state = state.iterator();
            while (state.hasNext()) 
            {
                Message message = (Message)state.next();
                mComposerHandler.sendMessage(message);
                state.remove();
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    void handleMessage(Message message)
        throws RemoteException, IllegalStateException
    {
        Log.d(getTag(), getStateLog((new StringBuilder()).append("handleMessage : ").append(message.what).toString()));
    }

    public abstract boolean isConnected();

    public boolean isLocal()
    {
        return mEnvironment == Environment.Local;
    }

    public boolean isStarted()
    {
        State state;
        State state1;
        mLock.readLock().lock();
        state = mState;
        state1 = State.EXECUTING;
        boolean flag;
        if (state == state1)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        mLock.readLock().unlock();
        return flag;
        Exception exception;
        exception;
        mLock.readLock().unlock();
        throw exception;
    }

    public transient boolean isStateAt(State astate[])
    {
        mLock.readLock().lock();
        int j = astate.length;
        int i = 0;
_L2:
        State state;
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        state = astate[i];
        State state1 = mState;
        if (state1 == state)
        {
            mLock.readLock().unlock();
            return true;
        }
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        mLock.readLock().unlock();
        return false;
        astate;
        mLock.readLock().unlock();
        throw astate;
    }

    public boolean isStopped()
    {
        State state;
        State state1;
        mLock.readLock().lock();
        state = mState;
        state1 = State.IDLE;
        boolean flag;
        if (state == state1)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        mLock.readLock().unlock();
        return flag;
        Exception exception;
        exception;
        mLock.readLock().unlock();
        throw exception;
    }

    public void onEvent(int i, int j, int k, Object obj)
    {
        Log.d(getTag(), (new StringBuilder()).append(String.format("event[%d]: %d, %d, ", new Object[0])).append(obj).toString());
        if (i == 3001 && mOnInfoListener != null)
        {
            mOnInfoListener.onInfo(j, k, 0, obj);
        } else
        if (i == 3002 && mOnErrorListener != null)
        {
            mOnErrorListener.onError(j, k, 0, obj);
            return;
        }
    }

    protected void queueCommand(State state, Message message)
    {
        if (mCommandQueue.get(state.ordinal()) == null)
        {
            mCommandQueue.append(state.ordinal(), new ConcurrentLinkedQueue());
        }
        ((ConcurrentLinkedQueue)mCommandQueue.get(state.ordinal())).add(message);
    }

    public void release()
    {
        this;
        JVM INSTR monitorenter ;
        Log.d(getTag(), "release");
        disconnect();
        changeStateIfNot(new StateHandler(new Object[] {
            State.UNINITIALIZED
        }) {

            final SemMotionPhotoComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                removeAllCommands();
                if (mContext != null)
                {
                    mContext = null;
                }
                if (mComposerHandler != null)
                {
                    mComposerHandler.removeCallbacksAndMessages(null);
                }
                if (mHandlerThread != null)
                {
                    mHandlerThread.quit();
                }
                mComposerHandler = null;
                mHandlerThread = null;
            }

            transient 
            {
                this$0 = SemMotionPhotoComposer.this;
                super(aobj);
            }
        }, State.UNINITIALIZED);
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
        Object obj;
        obj;
        ((RemoteException) (obj)).printStackTrace();
        changeStateIfNot(new _cls1(new Object[] {
            State.UNINITIALIZED
        }), State.UNINITIALIZED);
        if (true) goto _L2; else goto _L1
_L1:
        obj;
        throw obj;
        obj;
        changeStateIfNot(new _cls1(new Object[] {
            State.UNINITIALIZED
        }), State.UNINITIALIZED);
        throw obj;
    }

    protected boolean removeCommand(State state, int i)
    {
        boolean flag1 = false;
        boolean flag = false;
        if (mCommandQueue.get(state.ordinal()) != null)
        {
            state = ((ConcurrentLinkedQueue)mCommandQueue.get(state.ordinal())).iterator();
            do
            {
                flag1 = flag;
                if (!state.hasNext())
                {
                    break;
                }
                if (((Message)state.next()).what == i)
                {
                    state.remove();
                    flag = true;
                }
            } while (true);
        }
        return flag1;
    }

    public long requestId()
        throws RemoteException, IllegalStateException
    {
        return -1L;
    }

    public void setCallbackListener(SemApexCallbackListener semapexcallbacklistener)
    {
        Log.d(getTag(), String.format("setCallbackListener[%s]: listener=", new Object[] {
            mState.name(), semapexcallbacklistener
        }));
        mEventCbListener = semapexcallbacklistener;
    }

    public void setClientId(String s)
    {
        mClientId = s;
    }

    public void setOnErrorListener(OnErrorListener onerrorlistener)
    {
        mOnErrorListener = onerrorlistener;
    }

    public void setOnInfoListener(OnInfoListener oninfolistener)
    {
        mOnInfoListener = oninfolistener;
    }

    public abstract void setParameters(Parameters parameters)
        throws RemoteException, IllegalStateException;

    public abstract void setStoreData(Bundle bundle)
        throws RemoteException, IllegalStateException;

    public abstract void setStorePath(long l, String s)
        throws RemoteException, IllegalStateException;

    public abstract void start(Parameters parameters)
        throws RemoteException, IllegalStateException;

    public abstract void stop()
        throws RemoteException, IllegalStateException;

    public abstract long store()
        throws RemoteException, IllegalStateException;

    public long store(int i)
        throws RemoteException, IllegalStateException
    {
        return 0L;
    }

    public long store(int i, long l)
        throws RemoteException, IllegalStateException
    {
        return 0L;
    }

    public abstract long store(SemApexStoreData semapexstoredata)
        throws RemoteException, IllegalStateException;

    static 
    {
        boolean flag;
        if (!com/samsung/android/apex/motionphoto/composer/SemMotionPhotoComposer.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        $assertionsDisabled = flag;
    }

}
