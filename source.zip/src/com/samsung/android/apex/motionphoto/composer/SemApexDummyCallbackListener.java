// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Bundle;
import android.util.Log;
import com.samsung.android.apex.motionphoto.SemApexCallbackListener;
import java.lang.ref.WeakReference;
import java.util.HashMap;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

public class SemApexDummyCallbackListener extends SemApexCallbackListener
{

    private static final String TAG = com/samsung/android/apex/motionphoto/composer/SemApexDummyCallbackListener.getSimpleName();
    private WeakReference mOwner;

    public SemApexDummyCallbackListener(SemMotionPhotoComposer semmotionphotocomposer)
    {
        mOwner = new WeakReference(semmotionphotocomposer);
    }

    private void handleError(int i, int j, int k, Object obj)
    {
        if (mOwner.get() == null)
        {
            Log.w(TAG, "composer is null");
        } else
        {
            SemMotionPhotoComposer semmotionphotocomposer = (SemMotionPhotoComposer)mOwner.get();
            if (semmotionphotocomposer.mOnErrorListener != null)
            {
                semmotionphotocomposer.mOnErrorListener.onError(i, j, k, obj);
                return;
            }
        }
    }

    private void handleInfo(int i, int j, int k, Object obj)
    {
        if (mOwner.get() == null)
        {
            Log.w(TAG, "composer is null");
        } else
        {
            SemMotionPhotoComposer semmotionphotocomposer = (SemMotionPhotoComposer)mOwner.get();
            if (semmotionphotocomposer.mOnInfoListener != null)
            {
                semmotionphotocomposer.mOnInfoListener.onInfo(i, j, k, obj);
                return;
            }
        }
    }

    public void onApexServerDead(String s, int i)
    {
        handleError(-9984, 0, i, null);
    }

    public void onRecoderStopped(String s)
    {
        handleInfo(10009, 0, 0, null);
    }

    public void onRecorderConnected(String s, int i, Object obj)
    {
        handleInfo(10006, 0, i, obj);
    }

    public void onRecorderDisconnected(String s)
    {
        handleInfo(10007, 0, 0, null);
    }

    public void onRecorderReleased(String s, int i)
    {
        handleInfo(10003, 0, i, null);
    }

    public void onRecorderStrated(String s)
    {
        handleInfo(10008, 0, 0, null);
    }

    public void onRecordingCancel(HashMap hashmap)
    {
    }

    public void onRecordingComplete(HashMap hashmap)
    {
    }

    public void onRecordingProxyDead(String s, int i)
    {
        handleError(-9998, 0, i, null);
    }

    public long onRequestId()
    {
        return 0L;
    }

    public void onStoreData(Bundle bundle)
    {
    }

}
