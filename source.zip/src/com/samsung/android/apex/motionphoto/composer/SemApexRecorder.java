// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.util.Log;
import android.view.Surface;
import com.samsung.android.apex.motionphoto.model.SemApexStoreData;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemApexRecorderListener

public class SemApexRecorder
{

    private static final String TAG = com/samsung/android/apex/motionphoto/composer/SemApexRecorder.getSimpleName();
    private SemApexRecorderListener mListener;
    private long mNativeContext;
    private int mToken;

    public SemApexRecorder(SemApexRecorderListener semapexrecorderlistener)
    {
        if (semapexrecorderlistener == null)
        {
            throw new NullPointerException("listener should not null");
        } else
        {
            mListener = semapexrecorderlistener;
            mToken = native_setup(semapexrecorderlistener, getClass().getName());
            semapexrecorderlistener.setToken(mToken);
            return;
        }
    }

    public static void deinit()
    {
    }

    public static void init()
    {
    }

    private static final native void native_deinit();

    private final native void native_finalize();

    private final native Surface native_getSurface();

    private static final native void native_init();

    private final native void native_setParameters(String s);

    private final native int native_setup(Object obj, String s);

    private final native void native_start(String s);

    private final native void native_stop();

    private final native int native_store(long l);

    private final native int native_store(String s);

    public Surface getSurface()
    {
        return native_getSurface();
    }

    public int getToken()
    {
        return mToken;
    }

    public void release()
    {
        Log.d(TAG, "release");
        mListener = null;
        native_finalize();
    }

    public void setErrorListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener onerrorlistener)
    {
        if (mListener != null)
        {
            mListener.setOnErrorListener(onerrorlistener);
        }
    }

    public void setInfoListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener oninfolistener)
    {
        if (mListener != null)
        {
            mListener.setOnInfoListener(oninfolistener);
        }
    }

    public void setParameters(String s)
    {
        native_setParameters(s);
    }

    public void start(String s)
    {
        Log.d(TAG, (new StringBuilder()).append("start: ").append(s).toString());
        native_start(s);
    }

    public void stop()
    {
        Log.d(TAG, "stop");
        native_stop();
    }

    public int store(SemApexStoreData semapexstoredata)
    {
        return native_store(semapexstoredata.flatten());
    }

    public void store(long l)
    {
        native_store(l);
    }

    public void store(String s)
    {
        native_store(s);
    }

    static 
    {
        System.loadLibrary("apex_jni");
        native_init();
    }
}
