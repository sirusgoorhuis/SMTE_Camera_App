// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.HashMap;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            RemoteComposer, SemMotionPhotoComposer

static class mOwner extends com.samsung.android.apex.service.b
    implements Runnable
{

    private static final String TAG;
    private Object mData;
    private WeakReference mOwner;

    public void notify(int i, int j, int k, Bundle bundle)
        throws RemoteException
    {
        Log.d(TAG, String.format("notify: what=%d, arg1=%d, arg2=%d", new Object[] {
            Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
        }));
        if (mOwner.get() == null)
        {
            Log.w(TAG, "composer is already released!!!");
            return;
        }
        SemMotionPhotoComposer semmotionphotocomposer = (SemMotionPhotoComposer)mOwner.get();
        switch (i)
        {
        default:
            return;

        case 3001: 
            if (semmotionphotocomposer.mOnInfoListener == null)
            {
                Log.v(TAG, "onInfo listener is not set");
                return;
            } else
            {
                semmotionphotocomposer.mOnInfoListener.onInfo(j, k, 0, bundle);
                return;
            }

        case 3002: 
            break;
        }
        if (semmotionphotocomposer.mOnErrorListener == null)
        {
            Log.v(TAG, "onError listener is not set");
            return;
        } else
        {
            semmotionphotocomposer.mOnErrorListener.onError(j, k, 0, null);
            semmotionphotocomposer.release();
            return;
        }
    }

    public void notifyAsync(int i, int j, int k, Bundle bundle)
    {
        HashMap hashmap = new HashMap();
        hashmap.put("what", Integer.valueOf(i));
        hashmap.put("arg1", Integer.valueOf(j));
        hashmap.put("arg2", Integer.valueOf(j));
        hashmap.put("data", bundle);
        mData = hashmap;
        (new Thread(this)).start();
    }

    public void run()
    {
        try
        {
            HashMap hashmap = (HashMap)mData;
            notify(((Integer)hashmap.get("what")).intValue(), ((Integer)hashmap.get("arg1")).intValue(), ((Integer)hashmap.get("arg2")).intValue(), (Bundle)hashmap.get("data"));
            return;
        }
        catch (RemoteException remoteexception)
        {
            remoteexception.printStackTrace();
        }
    }

    static 
    {
        TAG = (new StringBuilder()).append(SemMotionPhotoComposer.TAG).append("-listener").toString();
    }

    public stener(SemMotionPhotoComposer semmotionphotocomposer)
    {
        mOwner = new WeakReference(semmotionphotocomposer);
    }
}
