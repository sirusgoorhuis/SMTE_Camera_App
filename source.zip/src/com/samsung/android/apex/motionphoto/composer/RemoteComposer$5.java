// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Bundle;
import android.util.Log;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.service.IMotionPhotoComposer;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            RemoteComposer

class poser.StateHandler extends poser.StateHandler
{

    final RemoteComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        list = (Bundle)list.get(0);
        Log.d(getTag(), getStateLog((new StringBuilder()).append("SemApexStoreData: data=%s").append(list.toString()).toString()));
        RemoteComposer.access$000(RemoteComposer.this).setStoreData(list);
    }

    transient poser.StateHandler(Object aobj[])
    {
        this$0 = RemoteComposer.this;
        super(aobj);
    }
}
