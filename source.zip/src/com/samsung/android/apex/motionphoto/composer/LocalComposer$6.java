// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import com.samsung.android.apex.motionphoto.SemApexCallbackListener;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.motionphoto.model.SemApexStoreData;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            LocalComposer

class mposer.StateHandler extends mposer.StateHandler
{

    final LocalComposer this$0;

    void onState(List list, Reply reply)
        throws Exception
    {
        long l = ((Long)list.get(0)).longValue();
        list = (String)list.get(1);
        mEventCbListener.onStoreData((new SemApexStoreData(l, mToken, list)).toBundle());
    }

    transient mposer.StateHandler(Object aobj[])
    {
        this$0 = LocalComposer.this;
        super(aobj);
    }
}
