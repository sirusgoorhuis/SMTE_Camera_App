// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.Surface;
import com.samsung.android.apex.motionphoto.SemApexCallbackListener;
import com.samsung.android.apex.motionphoto.command.Reply;
import com.samsung.android.apex.motionphoto.model.SemApexStoreData;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.List;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer, State, SemApexRecorder, SemApexRecorderListener

class LocalComposer extends SemMotionPhotoComposer
    implements com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener, com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener
{

    private static final String TAG;
    private boolean isRecorderConnect;
    private SemApexRecorder mRecorder;

    LocalComposer(Context context)
    {
        super(context);
        isRecorderConnect = false;
        Log.d(getTag(), "composer created");
    }

    public void connect()
        throws RemoteException
    {
        Log.d(getTag(), String.format("connect[%s]", new Object[] {
            mState.name()
        }));
        Reply reply = changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.LOADED, this
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply1)
                throws Exception
            {
                SemApexRecorderListener semapexrecorderlistener = new SemApexRecorderListener();
                mRecorder = new SemApexRecorder(semapexrecorderlistener);
                mToken = mRecorder.getToken();
                if (mToken < 0)
                {
                    throw new InvalidKeyException((new StringBuilder()).append("invalid token: ").append(mToken).toString());
                }
                mRecorder.setInfoListener((com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener)list.get(0));
                mRecorder.setErrorListener((com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener)list.get(0));
                if (mEventCbListener == null)
                {
                    throw new IllegalStateException("request eventHandler should be set(ex: SimplRequestHandler)");
                } else
                {
                    isRecorderConnect = true;
                    reply1.setData("listener", semapexrecorderlistener);
                    return;
                }
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        }, State.IDLE);
        if (reply.isSuccess())
        {
            mEventCbListener.onRecorderConnected(getClientId(), mToken, reply.getData("listener"));
        }
    }

    public void disconnect()
    {
        Log.d(getTag(), String.format("disconnect[%s]", new Object[] {
            mState.name()
        }));
        if (isStateAt(new State[] {
    State.UNINITIALIZED
}))
        {
            Log.d(getTag(), "ignore after release");
        } else
        if (isConnected())
        {
            if (mRecorder != null)
            {
                mRecorder.release();
                mRecorder = null;
            }
            isRecorderConnect = false;
            mEventCbListener.onRecorderDisconnected(getClientId());
            return;
        }
    }

    public Surface getSurface()
        throws RemoteException
    {
        Log.d(getTag(), getStateLog("getSurface"));
        Reply reply = doStateIf(new SemMotionPhotoComposer.StateHandler(State.connected()) {

            final LocalComposer this$0;

            void onState(List list, Reply reply1)
                throws Exception
            {
                reply1.setData("surface", mRecorder.getSurface());
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
        if (reply.isSuccess())
        {
            return (Surface)reply.getData("surface");
        } else
        {
            return null;
        }
    }

    protected String getTag()
    {
        return TAG;
    }

    public boolean isConnected()
    {
        return isRecorderConnect;
    }

    public void onError(int i, int j, int k, Object obj)
    {
        Log.d(getTag(), String.format("onerror: %d, %d, %d", new Object[] {
            Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
        }));
        if (mEventCbListener == null)
        {
            Log.d(getTag(), "callback listener is already released");
            return;
        }
        switch (i)
        {
        default:
            return;

        case -9998: 
            mEventCbListener.onRecordingProxyDead(getClientId(), k);
            return;

        case -9984: 
            mEventCbListener.onApexServerDead(getClientId(), k);
            break;
        }
    }

    public void onInfo(int i, int j, int k, Object obj)
    {
        Log.d(getTag(), String.format("oninfo: %d, %d, %d", new Object[] {
            Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
        }));
        if (mEventCbListener == null)
        {
            Log.d(getTag(), "callback listener is already released");
            return;
        }
        switch (i)
        {
        default:
            return;

        case 10002: 
            mEventCbListener.onRecordingComplete((HashMap)obj);
            return;

        case 10003: 
            mEventCbListener.onRecorderReleased(getClientId(), k);
            break;
        }
    }

    public void release()
    {
        Log.d(getTag(), "release");
        super.release();
        if (mRecorder != null)
        {
            mRecorder.release();
            mRecorder = null;
        }
    }

    public long requestId()
        throws RemoteException, IllegalStateException
    {
        return mEventCbListener.onRequestId();
    }

    public void setParameters(SemMotionPhotoComposer.Parameters parameters)
        throws RemoteException, IllegalStateException
    {
        Log.d(getTag(), String.format("setParameters[%s]", new Object[] {
            mState.name()
        }));
        doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.connected(), parameters
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                list = (SemMotionPhotoComposer.Parameters)list.get(0);
                mRecorder.setParameters(list.flatten());
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
    }

    public void setStoreData(Bundle bundle)
        throws RemoteException, IllegalStateException
    {
        Log.d(getTag(), String.format("setStoreData[%s]: data=%s", new Object[] {
            mState.name(), bundle.toString()
        }));
        doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.connected(), bundle
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                mEventCbListener.onStoreData((Bundle)list.get(0));
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
    }

    public void setStorePath(long l, String s)
        throws RemoteException
    {
        Log.d(getTag(), String.format("setStorePath[%s]: id=%d, path=%s", new Object[] {
            mState.name(), Long.valueOf(l), s
        }));
        doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.connected(), Long.valueOf(l), s
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                long l1 = ((Long)list.get(0)).longValue();
                list = (String)list.get(1);
                mEventCbListener.onStoreData((new SemApexStoreData(l1, mToken, list)).toBundle());
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
    }

    public void start(SemMotionPhotoComposer.Parameters parameters)
        throws RemoteException
    {
        Log.d(getTag(), String.format("start[%s]: %s", new Object[] {
            mState.name(), parameters.flatten()
        }));
        if (changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.IDLE, parameters
}) {

        final LocalComposer this$0;

        void onState(List list, Reply reply)
            throws Exception
        {
            list = (SemMotionPhotoComposer.Parameters)list.get(0);
            mRecorder.start(list.flatten());
        }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
    }, State.EXECUTING).isSuccess())
        {
            mEventCbListener.onRecorderStrated(getClientId());
        }
    }

    public void stop()
        throws RemoteException
    {
        Log.d(getTag(), String.format("stop[%s]", new Object[] {
            mState.name()
        }));
        if (changeStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
    State.EXECUTING
}) {

        final LocalComposer this$0;

        void onState(List list, Reply reply)
            throws Exception
        {
            mRecorder.stop();
        }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
    }, State.IDLE).isSuccess())
        {
            mEventCbListener.onRecoderStopped(getClientId());
        }
    }

    public long store()
        throws RemoteException
    {
        Log.d(getTag(), String.format("store[%s]", new Object[] {
            mState.name()
        }));
        Reply reply = doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.EXECUTING
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply1)
                throws Exception
            {
                long l = mEventCbListener.onRequestId();
                mRecorder.store(l);
                reply1.setData("id", Long.valueOf(l));
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
        if (reply.isSuccess())
        {
            return ((Long)reply.getData("id")).longValue();
        } else
        {
            return -1L;
        }
    }

    public long store(SemApexStoreData semapexstoredata)
        throws RemoteException
    {
        Log.d(getTag(), String.format("store[%s]: %s", new Object[] {
            mState.name(), semapexstoredata
        }));
        semapexstoredata = doStateIf(new SemMotionPhotoComposer.StateHandler(new Object[] {
            State.EXECUTING, semapexstoredata
        }) {

            final LocalComposer this$0;

            void onState(List list, Reply reply)
                throws Exception
            {
                list = (SemApexStoreData)list.get(0);
                long l = mEventCbListener.onRequestId();
                list.setId(l);
                list.setToken(mToken);
                mRecorder.store(list);
                reply.setData("id", Long.valueOf(l));
            }

            transient 
            {
                this$0 = LocalComposer.this;
                super(aobj);
            }
        });
        if (semapexstoredata.isSuccess())
        {
            return ((Long)semapexstoredata.getData("id")).longValue();
        } else
        {
            return -1L;
        }
    }

    static 
    {
        TAG = (new StringBuilder()).append(SemMotionPhotoComposer.TAG).append("-local").toString();
    }



/*
    static SemApexRecorder access$002(LocalComposer localcomposer, SemApexRecorder semapexrecorder)
    {
        localcomposer.mRecorder = semapexrecorder;
        return semapexrecorder;
    }

*/


/*
    static boolean access$102(LocalComposer localcomposer, boolean flag)
    {
        localcomposer.isRecorderConnect = flag;
        return flag;
    }

*/
}
