// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer.utils;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import com.samsung.android.apex.service.IApexService;
import java.lang.ref.WeakReference;

public class ConnectionManager
    implements ServiceConnection
{
    public static interface OnConnectionListener
    {

        public abstract void onServiceConnected(IApexService iapexservice);

        public abstract void onServiceDisconnected();
    }

    private static class SingletonHolder
    {

        static ConnectionManager sInstance = new ConnectionManager();


        private SingletonHolder()
        {
        }
    }


    private static final String TAG = com/samsung/android/apex/motionphoto/composer/utils/ConnectionManager.getSimpleName();
    private IApexService mApex;
    private WeakReference mContext;
    private boolean mIsConnected;
    private boolean mIsConnecting;
    private OnConnectionListener mOnConnectionListener;

    private ConnectionManager()
    {
        mIsConnecting = false;
        mIsConnected = false;
        Log.d(TAG, "ConnectionManager");
    }


    public static ConnectionManager getInstance()
    {
        return SingletonHolder.sInstance;
    }

    public IApexService getApex()
    {
        return mApex;
    }

    public void init(Context context, OnConnectionListener onconnectionlistener)
    {
        Log.d(TAG, (new StringBuilder()).append("init: ").append(context).toString());
        setContext(context);
        setConnectionListener(onconnectionlistener);
        onconnectionlistener = new Intent();
        onconnectionlistener.setClassName("com.sec.android.app.apex", "com.sec.android.app.apex.service.ApexService");
        context.startService(onconnectionlistener);
        context.bindService(onconnectionlistener, this, 1);
    }

    public boolean isBound()
    {
        return mIsConnected;
    }

    public void onServiceConnected(ComponentName componentname, IBinder ibinder)
    {
        Log.d(TAG, "onServiceConnected");
        mIsConnected = true;
        mApex = com.samsung.android.apex.service.IApexService.Stub.asInterface(ibinder);
        if (mOnConnectionListener != null)
        {
            mOnConnectionListener.onServiceConnected(mApex);
        }
    }

    public void onServiceDisconnected(ComponentName componentname)
    {
        Log.d(TAG, "onServiceDisconnected");
        mIsConnected = false;
        if (mOnConnectionListener != null)
        {
            mOnConnectionListener.onServiceDisconnected();
        }
    }

    public void setConnectionListener(OnConnectionListener onconnectionlistener)
    {
        mOnConnectionListener = onconnectionlistener;
    }

    public void setContext(Context context)
    {
        mContext = new WeakReference(context);
    }

    public void unbind()
    {
        Log.d(TAG, "unbind");
        if (mIsConnected)
        {
            mIsConnected = false;
            if (mContext.get() != null)
            {
                ((Context)mContext.get()).unbindService(this);
            }
        }
    }

}
