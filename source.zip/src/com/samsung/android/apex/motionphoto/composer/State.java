// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;


public final class State extends Enum
{

    private static final State $VALUES[];
    public static final State ERROR;
    public static final State EXECUTING;
    public static final State IDLE;
    public static final State LOADED;
    public static final State UNINITIALIZED;

    private State(String s, int i)
    {
        super(s, i);
    }

    public static State[] connected()
    {
        return (new State[] {
            IDLE, EXECUTING
        });
    }

    public static State[] disconnected()
    {
        return (new State[] {
            UNINITIALIZED, LOADED, ERROR
        });
    }

    public static State[] unloaded()
    {
        return (new State[] {
            UNINITIALIZED, ERROR
        });
    }

    public static State valueOf(String s)
    {
        return (State)Enum.valueOf(com/samsung/android/apex/motionphoto/composer/State, s);
    }

    public static State[] values()
    {
        return (State[])$VALUES.clone();
    }

    static 
    {
        UNINITIALIZED = new State("UNINITIALIZED", 0);
        LOADED = new State("LOADED", 1);
        IDLE = new State("IDLE", 2);
        EXECUTING = new State("EXECUTING", 3);
        ERROR = new State("ERROR", 4);
        $VALUES = (new State[] {
            UNINITIALIZED, LOADED, IDLE, EXECUTING, ERROR
        });
    }
}
