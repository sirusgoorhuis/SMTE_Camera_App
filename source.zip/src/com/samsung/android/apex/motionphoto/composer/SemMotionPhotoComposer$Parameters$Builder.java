// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import java.util.HashMap;

// Referenced classes of package com.samsung.android.apex.motionphoto.composer:
//            SemMotionPhotoComposer

public static final class mMap
{

    private String mFlattenParam;
    private HashMap mMap;

    public mMap build()
    {
        mMap mmap = new mMap(null);
        if (mFlattenParam != null)
        {
            mmap.n(mFlattenParam);
        }
        mmap.mFlattenParam(mMap);
        if (mmap.mMap("buffering-mode") == null)
        {
            mmap.mMap("buffering-mode", "front");
        }
        if ("on".equals(mmap.mMap("effect-mode")))
        {
            mmap.mMap("preview-format", "android-opaque");
        }
        return mmap;
    }

    public mMap set(String s, Object obj)
    {
        mMap.put(s, obj);
        return this;
    }

    public mMap setAllocPreviewBuffer(boolean flag)
    {
        mMap.put("alloc-preview-buffer", Boolean.valueOf(flag));
        return this;
    }

    public mMap setBufferingMode(boolean flag)
    {
        HashMap hashmap = mMap;
        String s;
        if (flag)
        {
            s = "front";
        } else
        {
            s = "back";
        }
        hashmap.put("buffering-mode", s);
        return this;
    }

    public mMap setDuration(int i)
    {
        mMap.put("duration", Integer.valueOf(i));
        return this;
    }

    public mMap setEffectRecording(boolean flag)
    {
        HashMap hashmap = mMap;
        String s;
        if (flag)
        {
            s = "on";
        } else
        {
            s = "off";
        }
        hashmap.put("effect-mode", s);
        return this;
    }

    public mMap setFlattenParameter(String s)
    {
        mFlattenParam = s;
        return this;
    }

    public mFlattenParam setFpsFactor(int i)
    {
        mMap.put("fps-factor", Integer.valueOf(i));
        return this;
    }

    public mMap setPreviewFpsRange(int ai[])
    {
        mMap.put("fps-range", ai);
        return this;
    }

    public mMap setPreviewSize(int i, int j)
    {
        mMap.put("preview-size", (new StringBuilder()).append(i).append("x").append(j).toString());
        return this;
    }

    public mMap setPreviewSize(String s)
    {
        mMap.put("preview-size", s);
        return this;
    }

    public mMap setRecordDuration(int i)
    {
        mMap.put("duration", Integer.valueOf(i));
        return this;
    }

    public mMap setSaveAsFlipped(boolean flag)
    {
        mMap.put("save-as-flipped", Boolean.valueOf(flag));
        return this;
    }

    public mMap setToken(int i)
    {
        mMap.put("token", Integer.valueOf(i));
        return this;
    }

    public mMap setUseIntrinsicTimestamp(boolean flag)
    {
        mMap.put("use-intrinsic-timestamp", Boolean.valueOf(flag));
        return this;
    }

    public mMap setUseProxyStoretime(boolean flag)
    {
        mMap.put("use-proxy-storetime", Boolean.valueOf(flag));
        return this;
    }

    public mMap setVideoFrameRate(int i)
    {
        mMap.put("frame-rate", Integer.valueOf(i));
        return this;
    }

    public ()
    {
        mMap = new HashMap();
    }
}
