// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.composer;

import android.os.Looper;
import android.util.Log;
import com.samsung.android.apex.motionphoto.SemApexClientEventHandler;
import java.io.FileDescriptor;
import java.lang.ref.WeakReference;

public class SemApexVideoSplitter
{

    private static final String TAG = com/samsung/android/apex/motionphoto/composer/SemApexVideoSplitter.getSimpleName();
    private SemApexClientEventHandler mEventHandler;
    private long mNativeContext;

    public SemApexVideoSplitter()
    {
        Object obj = Looper.myLooper();
        if (obj != null)
        {
            mEventHandler = new SemApexClientEventHandler(((Looper) (obj)));
        } else
        {
            Looper looper = Looper.getMainLooper();
            if (looper != null)
            {
                mEventHandler = new SemApexClientEventHandler(looper);
            } else
            {
                mEventHandler = null;
            }
        }
        obj = getClass().getName();
        native_setup(new WeakReference(this), ((String) (obj)));
    }

    private final native void native_finalize();

    private static final native void native_init();

    private final native void native_setSource(FileDescriptor filedescriptor, long l, long l1);

    private final native void native_setup(Object obj, String s);

    private final native void native_split(FileDescriptor filedescriptor, long l, long l1, long l2, 
            int i, boolean flag, boolean flag1, boolean flag2);

    private final native void native_split(FileDescriptor filedescriptor, long l, long l1, long l2, 
            boolean flag, boolean flag1, boolean flag2);

    private static void postEventFromNative(Object obj, int i, int j, int k, Object obj1)
    {
        for (obj = (SemApexVideoSplitter)((WeakReference)obj).get(); obj == null || ((SemApexVideoSplitter) (obj)).mEventHandler == null;)
        {
            return;
        }

        obj1 = ((SemApexVideoSplitter) (obj)).mEventHandler.obtainMessage(i, j, k, obj1);
        ((SemApexVideoSplitter) (obj)).mEventHandler.sendMessage(((android.os.Message) (obj1)));
    }

    public void release()
    {
        Log.d(TAG, "release");
        setOnErrorListener(null);
        setOnInfoListener(null);
        mEventHandler.removeCallbacksAndMessages(null);
        mEventHandler = null;
        native_finalize();
    }

    public void setOnErrorListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnErrorListener onerrorlistener)
    {
        if (mEventHandler != null)
        {
            mEventHandler.setOnErrorListener(onerrorlistener);
        }
    }

    public void setOnInfoListener(com.samsung.android.apex.motionphoto.SemApexClientEventHandler.OnInfoListener oninfolistener)
    {
        if (mEventHandler != null)
        {
            mEventHandler.setOnInfoListener(oninfolistener);
        }
    }

    public void setSource(FileDescriptor filedescriptor, long l, long l1)
    {
        native_setSource(filedescriptor, l, l1);
    }

    public void split(FileDescriptor filedescriptor, long l, long l1, int i, boolean flag, 
            boolean flag1, boolean flag2)
    {
        native_split(filedescriptor, 0L, l, l1, i, flag, flag1, flag2);
    }

    public void split(FileDescriptor filedescriptor, long l, long l1, long l2, 
            int i, boolean flag, boolean flag1, boolean flag2)
    {
        native_split(filedescriptor, l, l1, l2, i, flag, flag1, flag2);
    }

    public void split(FileDescriptor filedescriptor, long l, long l1, long l2, 
            boolean flag, boolean flag1, boolean flag2)
    {
        native_split(filedescriptor, l, l1, l2, flag, flag1, flag2);
    }

    public void split(FileDescriptor filedescriptor, long l, long l1, boolean flag, boolean flag1, 
            boolean flag2)
    {
        native_split(filedescriptor, 0L, l, l1, flag, flag1, flag2);
    }

    static 
    {
        System.loadLibrary("apex_jni");
        native_init();
    }
}
