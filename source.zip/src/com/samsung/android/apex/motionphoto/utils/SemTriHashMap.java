// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.utils;

import java.util.HashMap;
import java.util.Set;

public class SemTriHashMap
{
    private static class ValueVO
    {

        Object v1;
        Object v2;

        public ValueVO(Object obj, Object obj1)
        {
            v1 = obj;
            v2 = obj1;
        }
    }


    private HashMap mMap;

    public SemTriHashMap()
    {
        mMap = new HashMap();
    }

    public void clear()
    {
        mMap.clear();
        mMap = null;
    }

    public Object getFirst(Object obj)
    {
        return ((ValueVO)mMap.get(obj)).v1;
    }

    public Object getSecond(Object obj)
    {
        return ((ValueVO)mMap.get(obj)).v2;
    }

    public Set keySet()
    {
        return mMap.keySet();
    }

    public void put(Object obj, Object obj1, Object obj2)
    {
        mMap.put(obj, new ValueVO(obj1, obj2));
    }

    public void remove(Object obj)
    {
        mMap.remove(obj);
    }
}
