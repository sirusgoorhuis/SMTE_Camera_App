// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.samsung.android.apex.motionphoto.utils;


// Referenced classes of package com.samsung.android.apex.motionphoto.utils:
//            SemTriHashMap

private static class v2
{

    Object v1;
    Object v2;

    public (Object obj, Object obj1)
    {
        v1 = obj;
        v2 = obj1;
    }
}
